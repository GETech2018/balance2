﻿    /*
    ** Watch_Face_Editor tool v 17.1
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_stand_TextRotate = new Array(2);
        let normal_stand_TextRotate_ASCIIARRAY = new Array(10);
        let normal_stand_TextRotate_img_width = 20;
        let normal_bio_charge_text_text_img = ''
        let normal_battery_TextRotate = new Array(3);
        let normal_battery_TextRotate_ASCIIARRAY = new Array(10);
        let normal_battery_TextRotate_img_width = 20;
        let normal_battery_TextRotate_unit = null;
        let normal_battery_TextRotate_unit_width = 30;
        let normal_moon_high_text_img = ''
        let normal_moon_low_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_sunrise_TextRotate = new Array(5);
        let normal_sunrise_TextRotate_ASCIIARRAY = new Array(10);
        let normal_sunrise_TextRotate_img_width = 14;
        let normal_sunrise_TextRotate_dot_width = 14;
        let normal_sunset_TextRotate = new Array(5);
        let normal_sunset_TextRotate_ASCIIARRAY = new Array(10);
        let normal_sunset_TextRotate_img_width = 14;
        let normal_sunset_TextRotate_dot_width = 14;
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_TextRotate = new Array(4);
        let normal_temperature_current_TextRotate_ASCIIARRAY = new Array(10);
        let normal_temperature_current_TextRotate_img_width = 14;
        let normal_temperature_current_TextRotate_unit = null;
        let normal_temperature_current_TextRotate_unit_width = 15;
        let normal_temperature_current_TextRotate_dot_width = 12;
        let normal_temperature_high_low_TextRotate = new Array(9);
        let normal_temperature_high_low_TextRotate_ASCIIARRAY = new Array(10);
        let normal_temperature_high_low_TextRotate_img_width = 14;
        let normal_temperature_high_low_TextRotate_unit = null;
        let normal_temperature_high_low_TextRotate_unit_width = 15;
        let normal_temperature_high_low_TextRotate_dot_width = 12;
        let normal_temperature_high_low_TextRotate_separator_width = 24;
        let normal_city_name_text = ''
        let normal_floor_text_text_img = ''
        let normal_calorie_TextRotate = new Array(4);
        let normal_calorie_TextRotate_ASCIIARRAY = new Array(10);
        let normal_calorie_TextRotate_img_width = 20;
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY', 'SUNDAY'];
        let normal_year_TextRotate = new Array(4);
        let normal_year_TextRotate_ASCIIARRAY = new Array(10);
        let normal_year_TextRotate_img_width = 20;
        let normal_timerTextUpdate = undefined;
        let normal_month_TextRotate = new Array(2);
        let normal_month_TextRotate_ASCIIARRAY = new Array(10);
        let normal_month_TextRotate_img_width = 20;
        let normal_day_TextRotate = new Array(2);
        let normal_day_TextRotate_ASCIIARRAY = new Array(10);
        let normal_day_TextRotate_img_width = 20;
        let normal_heart_rate_TextRotate = new Array(3);
        let normal_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextRotate_img_width = 20;
        let normal_distance_TextRotate = new Array(5);
        let normal_distance_TextRotate_ASCIIARRAY = new Array(10);
        let normal_distance_TextRotate_img_width = 20;
        let normal_distance_TextRotate_dot_width = 14;
        let normal_step_TextRotate = new Array(5);
        let normal_step_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step_TextRotate_img_width = 20;
        let normal_hour_TextRotate = new Array(2);
        let normal_hour_TextRotate_ASCIIARRAY = new Array(10);
        let normal_hour_TextRotate_img_width = 65;
        let normal_minute_TextRotate = new Array(2);
        let normal_minute_TextRotate_ASCIIARRAY = new Array(10);
        let normal_minute_TextRotate_img_width = 65;
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_TextRotate = new Array(3);
        let idle_battery_TextRotate_ASCIIARRAY = new Array(10);
        let idle_battery_TextRotate_img_width = 20;
        let idle_battery_TextRotate_unit = null;
        let idle_battery_TextRotate_unit_width = 30;
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY', 'SUNDAY'];
        let idle_year_TextRotate = new Array(4);
        let idle_year_TextRotate_ASCIIARRAY = new Array(10);
        let idle_year_TextRotate_img_width = 20;
        let idle_timerTextUpdate = undefined;
        let idle_month_TextRotate = new Array(2);
        let idle_month_TextRotate_ASCIIARRAY = new Array(10);
        let idle_month_TextRotate_img_width = 20;
        let idle_day_TextRotate = new Array(2);
        let idle_day_TextRotate_ASCIIARRAY = new Array(10);
        let idle_day_TextRotate_img_width = 20;
        let idle_hour_TextRotate = new Array(2);
        let idle_hour_TextRotate_ASCIIARRAY = new Array(10);
        let idle_hour_TextRotate_img_width = 65;
        let idle_minute_TextRotate = new Array(2);
        let idle_minute_TextRotate_ASCIIARRAY = new Array(10);
        let idle_minute_TextRotate_img_width = 65;
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stand_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Barlow_Medium.ttf; FontSize: 33; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 39,
              h: 39,
              text_size: 33,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Barlow_Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 281,
              y: 382,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 205,
              y: 22,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_stand_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 219,
              // y: 434,
              // font_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 25,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_stand_TextRotate_ASCIIARRAY[0] = '27.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[1] = '28.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[2] = '29.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[3] = '30.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[4] = '31.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[5] = '32.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[6] = '33.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[7] = '34.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[8] = '35.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[9] = '36.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              normal_stand_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 219,
                center_y: 434,
                pos_x: 219,
                pos_y: 434,
                angle: 25,
                src: '27.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_stand_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            
            const stand = hmSensor.createSensor(hmSensor.id.STAND);
            stand.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_bio_charge_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 154,
              y: 348,
              font_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              padding: false,
              h_space: 0,
              angle: 25,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 105,
              // y: 388,
              // font_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 25,
              // unit_en: 'sm_proc.png',
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextRotate_ASCIIARRAY[0] = '27.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[1] = '28.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[2] = '29.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[3] = '30.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[4] = '31.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[5] = '32.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[6] = '33.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[7] = '34.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[8] = '35.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[9] = '36.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 3; i++) {
              normal_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 105,
                center_y: 388,
                pos_x: 105,
                pos_y: 388,
                angle: 25,
                src: '27.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 105,
              center_y: 388,
              pos_x: 105,
              pos_y: 388,
              angle: 25,
              src: 'sm_proc.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_moon_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 324,
              y: 82,
              font_array: ["0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
              padding: false,
              h_space: 0,
              angle: 25,
              dot_image: 'punt.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.MOON_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 339,
              y: 52,
              font_array: ["0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
              padding: false,
              h_space: 0,
              angle: 25,
              dot_image: 'punt.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.MOON_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 259,
              y: 14,
              image_array: ["LUN00.png","LUN01.png","LUN02.png","LUN03.png","LUN04.png","LUN05.png","LUN06.png","LUN07.png","LUN08.png","LUN09.png","LUN10.png","LUN11.png","LUN12.png","LUN13.png","LUN14.png","LUN15.png","LUN16.png","LUN17.png","LUN18.png","LUN19.png","LUN20.png","LUN21.png","LUN22.png","LUN23.png","LUN24.png","LUN25.png","LUN26.png","LUN27.png","LUN28.png","LUN29.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_sunrise_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 85,
              // y: 112,
              // font_array: ["0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
              // zero: true,
              // unit_in_alignment: true,
              // h_space: 0,
              // angle: 25,
              // negative_image: 'punt.png',
              // dot_image: 'punt.png',
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.SUN_RISE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_sunrise_TextRotate_ASCIIARRAY[0] = '0055.png';  // set of images with numbers
            normal_sunrise_TextRotate_ASCIIARRAY[1] = '0056.png';  // set of images with numbers
            normal_sunrise_TextRotate_ASCIIARRAY[2] = '0057.png';  // set of images with numbers
            normal_sunrise_TextRotate_ASCIIARRAY[3] = '0058.png';  // set of images with numbers
            normal_sunrise_TextRotate_ASCIIARRAY[4] = '0059.png';  // set of images with numbers
            normal_sunrise_TextRotate_ASCIIARRAY[5] = '0060.png';  // set of images with numbers
            normal_sunrise_TextRotate_ASCIIARRAY[6] = '0061.png';  // set of images with numbers
            normal_sunrise_TextRotate_ASCIIARRAY[7] = '0062.png';  // set of images with numbers
            normal_sunrise_TextRotate_ASCIIARRAY[8] = '0063.png';  // set of images with numbers
            normal_sunrise_TextRotate_ASCIIARRAY[9] = '0064.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 5; i++) {
              normal_sunrise_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 85,
                center_y: 112,
                pos_x: 85,
                pos_y: 112,
                angle: 25,
                src: '0055.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_sunrise_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            // normal_sunset_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 187,
              // y: 159,
              // font_array: ["0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
              // zero: true,
              // unit_in_alignment: true,
              // h_space: 0,
              // angle: 25,
              // negative_image: 'punt.png',
              // dot_image: 'punt.png',
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.SUN_SET,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_sunset_TextRotate_ASCIIARRAY[0] = '0055.png';  // set of images with numbers
            normal_sunset_TextRotate_ASCIIARRAY[1] = '0056.png';  // set of images with numbers
            normal_sunset_TextRotate_ASCIIARRAY[2] = '0057.png';  // set of images with numbers
            normal_sunset_TextRotate_ASCIIARRAY[3] = '0058.png';  // set of images with numbers
            normal_sunset_TextRotate_ASCIIARRAY[4] = '0059.png';  // set of images with numbers
            normal_sunset_TextRotate_ASCIIARRAY[5] = '0060.png';  // set of images with numbers
            normal_sunset_TextRotate_ASCIIARRAY[6] = '0061.png';  // set of images with numbers
            normal_sunset_TextRotate_ASCIIARRAY[7] = '0062.png';  // set of images with numbers
            normal_sunset_TextRotate_ASCIIARRAY[8] = '0063.png';  // set of images with numbers
            normal_sunset_TextRotate_ASCIIARRAY[9] = '0064.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 5; i++) {
              normal_sunset_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 187,
                center_y: 159,
                pos_x: 187,
                pos_y: 159,
                angle: 25,
                src: '0055.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_sunset_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 234,
              y: 198,
              image_array: ["w095.png","w096.png","w097.png","w098.png","w099.png","w100.png","w101.png","w102.png","w103.png","w104.png","w105.png","w106.png","w107.png","w108.png","w109.png","w110.png","w111.png","w112.png","w113.png","w114.png","w115.png","w116.png","w117.png","w118.png","w119.png","w120.png","w121.png","w122.png","w123.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_temperature_current_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 306,
              // y: 348,
              // font_array: ["0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
              // zero: false,
              // unit_in_alignment: true,
              // h_space: 0,
              // angle: -65,
              // unit_en: 'GRAD-.png',
              // imperial_unit_en: 'GRAD-.png',
              // negative_image: 'nega1.png',
              // dot_image: 'nega1.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.WEATHER_CURRENT,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_temperature_current_TextRotate_ASCIIARRAY[0] = '0055.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[1] = '0056.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[2] = '0057.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[3] = '0058.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[4] = '0059.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[5] = '0060.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[6] = '0061.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[7] = '0062.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[8] = '0063.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[9] = '0064.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 4; i++) {
              normal_temperature_current_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 306,
                center_y: 348,
                pos_x: 306,
                pos_y: 348,
                angle: -65,
                src: '0055.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_temperature_current_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 306,
              center_y: 348,
              pos_x: 306,
              pos_y: 348,
              angle: -65,
              src: 'GRAD-.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);

            const temperatureUnit = hmSetting.getTemperatureUnit();
            if (temperatureUnit == 1) {
              normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.SRC, 'GRAD-.png');
            };
            //#endregion

            // normal_temperature_high_low_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 400,
              // y: 163,
              // font_array: ["0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
              // zero: false,
              // unit_in_alignment: true,
              // h_space: 0,
              // angle: -65,
              // unit_en: 'GRAD-.png',
              // imperial_unit_en: 'GRAD-.png',
              // negative_image: 'nega1.png',
              // dot_image: 'nega1.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.WEATHER_HIGH_LOW,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_temperature_high_low_TextRotate_ASCIIARRAY[0] = '0055.png';  // set of images with numbers
            normal_temperature_high_low_TextRotate_ASCIIARRAY[1] = '0056.png';  // set of images with numbers
            normal_temperature_high_low_TextRotate_ASCIIARRAY[2] = '0057.png';  // set of images with numbers
            normal_temperature_high_low_TextRotate_ASCIIARRAY[3] = '0058.png';  // set of images with numbers
            normal_temperature_high_low_TextRotate_ASCIIARRAY[4] = '0059.png';  // set of images with numbers
            normal_temperature_high_low_TextRotate_ASCIIARRAY[5] = '0060.png';  // set of images with numbers
            normal_temperature_high_low_TextRotate_ASCIIARRAY[6] = '0061.png';  // set of images with numbers
            normal_temperature_high_low_TextRotate_ASCIIARRAY[7] = '0062.png';  // set of images with numbers
            normal_temperature_high_low_TextRotate_ASCIIARRAY[8] = '0063.png';  // set of images with numbers
            normal_temperature_high_low_TextRotate_ASCIIARRAY[9] = '0064.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 9; i++) {
              normal_temperature_high_low_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 400,
                center_y: 163,
                pos_x: 400,
                pos_y: 163,
                angle: -65,
                src: '0055.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_temperature_high_low_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_temperature_high_low_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 400,
              center_y: 163,
              pos_x: 400,
              pos_y: 163,
              angle: -65,
              src: 'GRAD-.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_temperature_high_low_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);

            if (temperatureUnit == 1) {
              normal_temperature_high_low_TextRotate_unit.setProperty(hmUI.prop.SRC, 'GRAD-.png');
            };
            //#endregion

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 0,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              color: 0xFFFF8C00,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_floor_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 161,
              y: 214,
              font_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              padding: false,
              h_space: 0,
              angle: 25,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.FLOOR,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_calorie_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 66,
              // y: 162,
              // font_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 25,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_TextRotate_ASCIIARRAY[0] = '27.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[1] = '28.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[2] = '29.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[3] = '30.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[4] = '31.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[5] = '32.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[6] = '33.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[7] = '34.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[8] = '35.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[9] = '36.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 66,
                center_y: 162,
                pos_x: 66,
                pos_y: 162,
                angle: 25,
                src: '27.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: -5,
              y: -5,
              w: 490,
              h: 490,
              text_size: 33,
              char_space: 0,
              font: 'fonts/Barlow_Medium.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 88,
              end_angle: 144,
              mode: 1,
              // radius: 245,
              align_h: hmUI.align.CENTER_H,
              // unit_string: MONDAY,TUESDAY,WEDNESDAY,THURSDAY,FRIDAY,SATURDAY,SUNDAY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_year_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 409,
              // y: 228,
              // font_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -62,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.YEAR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_year_TextRotate_ASCIIARRAY[0] = '27.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[1] = '28.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[2] = '29.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[3] = '30.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[4] = '31.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[5] = '32.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[6] = '33.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[7] = '34.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[8] = '35.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[9] = '36.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 4; i++) {
              normal_year_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 409,
                center_y: 228,
                pos_x: 409,
                pos_y: 228,
                angle: -62,
                src: '27.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_year_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            let screenType = hmSetting.getScreenType();
            // normal_month_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 369,
              // y: 314,
              // font_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -62,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.MONTH,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_month_TextRotate_ASCIIARRAY[0] = '27.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[1] = '28.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[2] = '29.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[3] = '30.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[4] = '31.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[5] = '32.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[6] = '33.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[7] = '34.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[8] = '35.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[9] = '36.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              normal_month_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 369,
                center_y: 314,
                pos_x: 369,
                pos_y: 314,
                angle: -62,
                src: '27.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_month_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            // normal_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 336,
              // y: 381,
              // font_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -62,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_day_TextRotate_ASCIIARRAY[0] = '27.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[1] = '28.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[2] = '29.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[3] = '30.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[4] = '31.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[5] = '32.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[6] = '33.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[7] = '34.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[8] = '35.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[9] = '36.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              normal_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 336,
                center_y: 381,
                pos_x: 336,
                pos_y: 381,
                angle: -62,
                src: '27.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            // normal_heart_rate_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 91,
              // y: 311,
              // font_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 25,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextRotate_ASCIIARRAY[0] = '27.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[1] = '28.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[2] = '29.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[3] = '30.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[4] = '31.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[5] = '32.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[6] = '33.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[7] = '34.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[8] = '35.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[9] = '36.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 91,
                center_y: 311,
                pos_x: 91,
                pos_y: 311,
                angle: 25,
                src: '27.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_distance_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 232,
              // y: 308,
              // font_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 25,
              // negative_image: 'pun.png',
              // dot_image: 'pun.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_distance_TextRotate_ASCIIARRAY[0] = '27.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[1] = '28.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[2] = '29.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[3] = '30.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[4] = '31.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[5] = '32.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[6] = '33.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[7] = '34.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[8] = '35.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[9] = '36.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 5; i++) {
              normal_distance_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 232,
                center_y: 308,
                pos_x: 232,
                pos_y: 308,
                angle: 25,
                src: '27.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            const mileageUnit = hmSetting.getMileageUnit();            //#endregion
            
            const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
            distance.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 60,
              // y: 228,
              // font_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 25,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextRotate_ASCIIARRAY[0] = '27.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = '28.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = '29.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = '30.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = '31.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = '32.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = '33.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = '34.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = '35.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = '36.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 5; i++) {
              normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 60,
                center_y: 228,
                pos_x: 60,
                pos_y: 228,
                angle: 25,
                src: '27.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 179,
              // y: 53,
              // font_array: ["hour_0.png","hour_1.png","hour_2.png","hour_3.png","hour_4.png","hour_5.png","hour_6.png","hour_7.png","hour_8.png","hour_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 25,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextRotate_ASCIIARRAY[0] = 'hour_0.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[1] = 'hour_1.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[2] = 'hour_2.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[3] = 'hour_3.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[4] = 'hour_4.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[5] = 'hour_5.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[6] = 'hour_6.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[7] = 'hour_7.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[8] = 'hour_8.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[9] = 'hour_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              normal_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 179,
                center_y: 53,
                pos_x: 179,
                pos_y: 53,
                angle: 25,
                src: 'hour_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            // normal_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 316,
              // y: 116,
              // font_array: ["hour_0.png","hour_1.png","hour_2.png","hour_3.png","hour_4.png","hour_5.png","hour_6.png","hour_7.png","hour_8.png","hour_9.png"],
              // zero: true,
              // unit_in_alignment: true,
              // h_space: 0,
              // angle: 25,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_minute_TextRotate_ASCIIARRAY[0] = 'hour_0.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[1] = 'hour_1.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[2] = 'hour_2.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[3] = 'hour_3.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[4] = 'hour_4.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[5] = 'hour_5.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[6] = 'hour_6.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[7] = 'hour_7.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[8] = 'hour_8.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[9] = 'hour_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              normal_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 316,
                center_y: 116,
                pos_x: 316,
                pos_y: 116,
                angle: 25,
                src: 'hour_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            const deviceInfo = hmSetting.getDeviceInfo();
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Seg.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 240,
              // start_angle: 20,
              // end_angle: 380,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 'Seg.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 314,
              y: 411,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 436,
              y: 161,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 208,
              // y: 0,
              // font_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // unit_en: 'sm_proc.png',
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_TextRotate_ASCIIARRAY[0] = '27.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[1] = '28.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[2] = '29.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[3] = '30.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[4] = '31.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[5] = '32.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[6] = '33.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[7] = '34.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[8] = '35.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[9] = '36.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 3; i++) {
              idle_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 208,
                center_y: 0,
                pos_x: 208,
                pos_y: 0,
                angle: 0,
                src: '27.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_battery_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 208,
              center_y: 0,
              pos_x: 208,
              pos_y: 0,
              angle: 0,
              src: 'sm_proc.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: -5,
              y: -5,
              w: 490,
              h: 490,
              text_size: 33,
              char_space: 0,
              font: 'fonts/Barlow_Medium.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 88,
              end_angle: 144,
              mode: 1,
              // radius: 245,
              align_h: hmUI.align.CENTER_H,
              // unit_string: MONDAY,TUESDAY,WEDNESDAY,THURSDAY,FRIDAY,SATURDAY,SUNDAY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_year_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 409,
              // y: 228,
              // font_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -62,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.YEAR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_year_TextRotate_ASCIIARRAY[0] = '27.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[1] = '28.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[2] = '29.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[3] = '30.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[4] = '31.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[5] = '32.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[6] = '33.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[7] = '34.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[8] = '35.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[9] = '36.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 4; i++) {
              idle_year_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 409,
                center_y: 228,
                pos_x: 409,
                pos_y: 228,
                angle: -62,
                src: '27.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_year_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            // idle_month_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 369,
              // y: 314,
              // font_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -62,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.MONTH,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_month_TextRotate_ASCIIARRAY[0] = '27.png';  // set of images with numbers
            idle_month_TextRotate_ASCIIARRAY[1] = '28.png';  // set of images with numbers
            idle_month_TextRotate_ASCIIARRAY[2] = '29.png';  // set of images with numbers
            idle_month_TextRotate_ASCIIARRAY[3] = '30.png';  // set of images with numbers
            idle_month_TextRotate_ASCIIARRAY[4] = '31.png';  // set of images with numbers
            idle_month_TextRotate_ASCIIARRAY[5] = '32.png';  // set of images with numbers
            idle_month_TextRotate_ASCIIARRAY[6] = '33.png';  // set of images with numbers
            idle_month_TextRotate_ASCIIARRAY[7] = '34.png';  // set of images with numbers
            idle_month_TextRotate_ASCIIARRAY[8] = '35.png';  // set of images with numbers
            idle_month_TextRotate_ASCIIARRAY[9] = '36.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              idle_month_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 369,
                center_y: 314,
                pos_x: 369,
                pos_y: 314,
                angle: -62,
                src: '27.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_month_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            // idle_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 336,
              // y: 381,
              // font_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -62,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_day_TextRotate_ASCIIARRAY[0] = '27.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[1] = '28.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[2] = '29.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[3] = '30.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[4] = '31.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[5] = '32.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[6] = '33.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[7] = '34.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[8] = '35.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[9] = '36.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              idle_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 336,
                center_y: 381,
                pos_x: 336,
                pos_y: 381,
                angle: -62,
                src: '27.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            // idle_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 284,
              // y: 335,
              // font_array: ["hour_0.png","hour_1.png","hour_2.png","hour_3.png","hour_4.png","hour_5.png","hour_6.png","hour_7.png","hour_8.png","hour_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -60,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_hour_TextRotate_ASCIIARRAY[0] = 'hour_0.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[1] = 'hour_1.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[2] = 'hour_2.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[3] = 'hour_3.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[4] = 'hour_4.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[5] = 'hour_5.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[6] = 'hour_6.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[7] = 'hour_7.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[8] = 'hour_8.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[9] = 'hour_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              idle_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 284,
                center_y: 335,
                pos_x: 284,
                pos_y: 335,
                angle: -60,
                src: 'hour_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            // idle_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 351,
              // y: 201,
              // font_array: ["hour_0.png","hour_1.png","hour_2.png","hour_3.png","hour_4.png","hour_5.png","hour_6.png","hour_7.png","hour_8.png","hour_9.png"],
              // zero: true,
              // unit_in_alignment: true,
              // h_space: 0,
              // angle: -60,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_minute_TextRotate_ASCIIARRAY[0] = 'hour_0.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[1] = 'hour_1.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[2] = 'hour_2.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[3] = 'hour_3.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[4] = 'hour_4.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[5] = 'hour_5.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[6] = 'hour_6.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[7] = 'hour_7.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[8] = 'hour_8.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[9] = 'hour_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              idle_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 351,
                center_y: 201,
                pos_x: 351,
                pos_y: 201,
                angle: -60,
                src: 'hour_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 10,
              y: 216,
              w: 100,
              h: 67,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 160,
              y: 275,
              w: 100,
              h: 70,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 20,
              y: 287,
              w: 100,
              h: 70,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 69,
              y: 390,
              w: 106,
              h: 100,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 132,
              y: 148,
              w: 105,
              h: 44,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 284,
              y: 21,
              w: 100,
              h: 83,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 269,
              y: 224,
              w: 82,
              h: 144,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 189,
              y: 383,
              w: 70,
              h: 100,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 251,
              y: 111,
              w: 100,
              h: 80,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 185,
              y: -9,
              w: 70,
              h: 70,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 12,
              y: 145,
              w: 100,
              h: 70,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 102,
              y: 62,
              w: 128,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WorldClockScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 356,
              y: 201,
              w: 128,
              h: 227,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 263,
              y: 420,
              w: 70,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AppListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
                if (timeSensor.week >= 6) normal_dow_text_font.setProperty(hmUI.prop.COLOR, 0xFFFF0000);
                else normal_dow_text_font.setProperty(hmUI.prop.COLOR, 0xFFFFFFFF);
              };

              // Second Pointer
              let normal_fullAngle_second = 360;
              let normal_angle_second = 20 + normal_fullAngle_second*second/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

            };

            //#endregion
            //#region text_update
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate stand_STAND');
              let valueStand = stand.current;
              let normal_stand_rotate_string = parseInt(valueStand).toString();
              normal_stand_rotate_string = normal_stand_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_stand_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStand != null && valueStand != undefined && isFinite(valueStand) && normal_stand_rotate_string.length > 0 && normal_stand_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_stand_TextRotate_posOffset = normal_stand_TextRotate_img_width * normal_stand_rotate_string.length;
                  img_offset -= normal_stand_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_stand_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_stand_TextRotate[index].setProperty(hmUI.prop.POS_X, 219 + img_offset);
                      normal_stand_TextRotate[index].setProperty(hmUI.prop.SRC, normal_stand_TextRotate_ASCIIARRAY[charCode]);
                      normal_stand_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_stand_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_rotate_string.length > 0 && normal_battery_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 105 + img_offset);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.SRC, normal_battery_TextRotate_ASCIIARRAY[charCode]);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_battery_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.POS_X, 105 + img_offset);
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };
              let weatherData = weatherSensor.getForecastWeather();
              let tideData = weatherData.tideData;
              let sunrise_hour = -1;
              let sunrise_minute = -1;
              if (tideData.count > 0) {
                sunrise_hour = tideData.data[0].sunrise.hour;
                sunrise_minute = tideData.data[0].sunrise.minute;
              }; // end tideData;

              console.log('update text rotate sunrise_tideData');
              let sunriseTime = undefined;
              let normal_sunrise_rotate_string = undefined;
              if (sunrise_hour >= 0 && sunrise_minute >= 0) {
                sunriseTime = 0;
                normal_sunrise_rotate_string = String(sunrise_hour).padStart(2, '0') + '.' + String(sunrise_minute).padStart(2, '0');
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_sunrise_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (sunriseTime != null && sunriseTime != undefined && isFinite(sunriseTime) && normal_sunrise_rotate_string.length > 0 && normal_sunrise_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_sunrise_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_sunrise_TextRotate[index].setProperty(hmUI.prop.POS_X, 85 + img_offset);
                      normal_sunrise_TextRotate[index].setProperty(hmUI.prop.SRC, normal_sunrise_TextRotate_ASCIIARRAY[charCode]);
                      normal_sunrise_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_sunrise_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      normal_sunrise_TextRotate[index].setProperty(hmUI.prop.POS_X, 85 + img_offset);
                      normal_sunrise_TextRotate[index].setProperty(hmUI.prop.SRC, 'punt.png');
                      normal_sunrise_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_sunrise_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite

              };
              let sunset_hour = -1;
              let sunset_minute = -1;
              if (tideData.count > 0) {
                sunset_hour = tideData.data[0].sunset.hour;
                sunset_minute = tideData.data[0].sunset.minute;
              }; // end tideData;

              console.log('update text rotate sunset_tideData');
              let sunsetTime = undefined;
              let normal_sunset_rotate_string = undefined;
              if (sunset_hour >= 0 && sunset_minute >= 0) {
                sunsetTime = 0;
                normal_sunset_rotate_string = String(sunset_hour).padStart(2, '0') + '.' + String(sunset_minute).padStart(2, '0');
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_sunset_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (sunsetTime != null && sunsetTime != undefined && isFinite(sunsetTime) && normal_sunset_rotate_string.length > 0 && normal_sunset_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_sunset_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_sunset_TextRotate[index].setProperty(hmUI.prop.POS_X, 187 + img_offset);
                      normal_sunset_TextRotate[index].setProperty(hmUI.prop.SRC, normal_sunset_TextRotate_ASCIIARRAY[charCode]);
                      normal_sunset_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_sunset_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      normal_sunset_TextRotate[index].setProperty(hmUI.prop.POS_X, 187 + img_offset);
                      normal_sunset_TextRotate[index].setProperty(hmUI.prop.SRC, 'punt.png');
                      normal_sunset_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_sunset_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite

              };
              let temperature_current_temp = -100;
              if (weatherSensor.current != undefined && weatherSensor.current != 'undefined') {
                temperature_current_temp = weatherSensor.current;
              }; // end currentWeather;

              console.log('update text rotate temperature_current_currentWeather');
              let temperatureCurrent = undefined;
              let normal_temperature_current_rotate_string = undefined;
              if (temperature_current_temp > -100) {
                temperatureCurrent = 0;
                normal_temperature_current_rotate_string = String(temperature_current_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureCurrent != null && temperatureCurrent != undefined && isFinite(temperatureCurrent) && normal_temperature_current_rotate_string.length > 0 && normal_temperature_current_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_temperature_current_TextRotate_posOffset = normal_temperature_current_TextRotate_img_width * normal_temperature_current_rotate_string.length;
                  normal_temperature_current_TextRotate_posOffset = normal_temperature_current_TextRotate_posOffset + normal_temperature_current_TextRotate_unit_width + 0;
                  img_offset -= normal_temperature_current_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_temperature_current_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 306 + img_offset);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, normal_temperature_current_TextRotate_ASCIIARRAY[charCode]);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_current_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 306 + img_offset);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, 'nega1.png');
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_current_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.POS_X, 306 + img_offset);
                  normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };
              let forecastData = weatherData.forecastData;
              let temperature_high_low_temp_max = -100;
              let temperature_high_low_temp_min = -100;
              if (forecastData.count > 0) {
                temperature_high_low_temp_max = forecastData.data[0].high;
                temperature_high_low_temp_min = forecastData.data[0].low;
              }; // end forecastData;

              console.log('update text rotate temperature_high_low_forecastData');
              let temperatureHighLow = undefined;
              let normal_temperature_high_low_rotate_string = undefined;
              if (temperature_high_low_temp_max > -100) {
                temperatureHighLow = 0;
                normal_temperature_high_low_rotate_string = String(temperature_high_low_temp_max)+ '*' + String(temperature_high_low_temp_min);
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 9; i++) {  // hide all symbols
                  normal_temperature_high_low_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_temperature_high_low_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureHighLow != null && temperatureHighLow != undefined && isFinite(temperatureHighLow) && normal_temperature_high_low_rotate_string.length > 0 && normal_temperature_high_low_rotate_string.length <= 9) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_temperature_high_low_TextRotate_posOffset = normal_temperature_high_low_TextRotate_img_width * normal_temperature_high_low_rotate_string.length;
                  normal_temperature_high_low_TextRotate_posOffset = normal_temperature_high_low_TextRotate_posOffset - normal_temperature_high_low_TextRotate_img_width + normal_temperature_high_low_TextRotate_separator_width;
                  if (normal_temperature_high_low_rotate_string.indexOf('-') >= 0) normal_temperature_high_low_TextRotate_posOffset = normal_temperature_high_low_TextRotate_posOffset - normal_temperature_high_low_TextRotate_img_width + normal_temperature_high_low_TextRotate_dot_width;
                  if (normal_temperature_high_low_rotate_string.indexOf('-', 2) >= 0) normal_temperature_high_low_TextRotate_posOffset = normal_temperature_high_low_TextRotate_posOffset - normal_temperature_high_low_TextRotate_img_width + normal_temperature_high_low_TextRotate_dot_width;
                  normal_temperature_high_low_TextRotate_posOffset = normal_temperature_high_low_TextRotate_posOffset + normal_temperature_high_low_TextRotate_unit_width + 0;
                  img_offset -= normal_temperature_high_low_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_temperature_high_low_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 9) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_temperature_high_low_TextRotate[index].setProperty(hmUI.prop.POS_X, 400 + img_offset);
                      normal_temperature_high_low_TextRotate[index].setProperty(hmUI.prop.SRC, normal_temperature_high_low_TextRotate_ASCIIARRAY[charCode]);
                      normal_temperature_high_low_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_high_low_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else if (charCode == -6) { 
                      normal_temperature_high_low_TextRotate[index].setProperty(hmUI.prop.POS_X, 400 + img_offset);
                      normal_temperature_high_low_TextRotate[index].setProperty(hmUI.prop.SRC, 'sep.png');
                      normal_temperature_high_low_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_high_low_TextRotate_separator_width;
                      index++;
                    }  // end if separator
                    else { 
                      normal_temperature_high_low_TextRotate[index].setProperty(hmUI.prop.POS_X, 400 + img_offset);
                      normal_temperature_high_low_TextRotate[index].setProperty(hmUI.prop.SRC, 'nega1.png');
                      normal_temperature_high_low_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_high_low_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_temperature_high_low_TextRotate_unit.setProperty(hmUI.prop.POS_X, 400 + img_offset);
                  normal_temperature_high_low_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text rotate calorie_CALORIE');
              let valueCalories = calorie.current;
              let normal_calorie_rotate_string = parseInt(valueCalories).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_rotate_string.length > 0 && normal_calorie_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_calorie_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.POS_X, 66 + img_offset);
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.SRC, normal_calorie_TextRotate_ASCIIARRAY[charCode]);
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_calorie_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate year_TIME');
              let valueYear = timeSensor.year;
              let normal_year_rotate_string = parseInt(valueYear).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_year_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueYear != null && valueYear != undefined && isFinite(valueYear) && normal_year_rotate_string.length > 0 && normal_year_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_year_TextRotate_posOffset = normal_year_TextRotate_img_width * normal_year_rotate_string.length;
                  img_offset -= normal_year_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_year_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_year_TextRotate[index].setProperty(hmUI.prop.POS_X, 409 + img_offset);
                      normal_year_TextRotate[index].setProperty(hmUI.prop.SRC, normal_year_TextRotate_ASCIIARRAY[charCode]);
                      normal_year_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_year_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate month_TIME');
              let valueMonth = timeSensor.month;
              let normal_month_rotate_string = parseInt(valueMonth).toString();
              normal_month_rotate_string = normal_month_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_month_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMonth != null && valueMonth != undefined && isFinite(valueMonth) && normal_month_rotate_string.length > 0 && normal_month_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_month_TextRotate_posOffset = normal_month_TextRotate_img_width * normal_month_rotate_string.length;
                  img_offset -= normal_month_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_month_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_month_TextRotate[index].setProperty(hmUI.prop.POS_X, 369 + img_offset);
                      normal_month_TextRotate[index].setProperty(hmUI.prop.SRC, normal_month_TextRotate_ASCIIARRAY[charCode]);
                      normal_month_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_month_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate day_TIME');
              let valueDay = timeSensor.day;
              let normal_day_rotate_string = parseInt(valueDay).toString();
              normal_day_rotate_string = normal_day_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && normal_day_rotate_string.length > 0 && normal_day_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_day_TextRotate_posOffset = normal_day_TextRotate_img_width * normal_day_rotate_string.length;
                  img_offset -= normal_day_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_day_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 336 + img_offset);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.SRC, normal_day_TextRotate_ASCIIARRAY[charCode]);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_day_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_rotate_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_rotate_string.length > 0 && normal_heart_rate_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_heart_rate_TextRotate_posOffset = normal_heart_rate_TextRotate_img_width * normal_heart_rate_rotate_string.length;
                  img_offset -= normal_heart_rate_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_heart_rate_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.POS_X, 91 + img_offset);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextRotate_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_heart_rate_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate DISTANCE');
              let distanceCurrent = distance.current;
              let normal_distance_rotate_string = (distanceCurrent / 1000).toFixed(2);
              if (mileageUnit == 1) normal_distance_rotate_string = (0.621371 * distanceCurrent / 1000).toFixed(2);
              normal_distance_rotate_string = normal_distance_rotate_string.padStart(5, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && normal_distance_rotate_string.length > 0 && normal_distance_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_distance_TextRotate_posOffset = normal_distance_TextRotate_img_width * normal_distance_rotate_string.length;
                  normal_distance_TextRotate_posOffset = normal_distance_TextRotate_posOffset - normal_distance_TextRotate_img_width + normal_distance_TextRotate_dot_width;
                  img_offset -= normal_distance_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_distance_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 232 + img_offset);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.SRC, normal_distance_TextRotate_ASCIIARRAY[charCode]);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_distance_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 232 + img_offset);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.SRC, 'pun.png');
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_distance_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate step_STEP');
              let valueStep = step.current;
              let normal_step_rotate_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_rotate_string.length > 0 && normal_step_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 60 + img_offset);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step_TextRotate_ASCIIARRAY[charCode]);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_step_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate hour_TIME');
              let valueHour = timeSensor.format_hour;
              let normal_hour_rotate_string = parseInt(valueHour).toString();
              normal_hour_rotate_string = normal_hour_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_rotate_string.length > 0 && normal_hour_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_hour_TextRotate_posOffset = normal_hour_TextRotate_img_width * normal_hour_rotate_string.length;
                  img_offset -= normal_hour_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 179 + img_offset);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.SRC, normal_hour_TextRotate_ASCIIARRAY[charCode]);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_hour_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let valueMinute = timeSensor.minute;
              let normal_minute_rotate_string = parseInt(valueMinute).toString();
              normal_minute_rotate_string = normal_minute_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_rotate_string.length > 0 && normal_minute_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_minute_TextRotate_posOffset = normal_minute_TextRotate_img_width * normal_minute_rotate_string.length;
                  img_offset -= normal_minute_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 316 + img_offset);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.SRC, normal_minute_TextRotate_ASCIIARRAY[charCode]);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_minute_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate battery_BATTERY');
              let idle_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && idle_battery_rotate_string.length > 0 && idle_battery_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 208 + img_offset);
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.SRC, idle_battery_TextRotate_ASCIIARRAY[charCode]);
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_battery_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  idle_battery_TextRotate_unit.setProperty(hmUI.prop.POS_X, 208 + img_offset);
                  idle_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text rotate year_TIME');
              let idle_year_rotate_string = parseInt(valueYear).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_year_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueYear != null && valueYear != undefined && isFinite(valueYear) && idle_year_rotate_string.length > 0 && idle_year_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_year_TextRotate_posOffset = idle_year_TextRotate_img_width * idle_year_rotate_string.length;
                  img_offset -= idle_year_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_year_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_year_TextRotate[index].setProperty(hmUI.prop.POS_X, 409 + img_offset);
                      idle_year_TextRotate[index].setProperty(hmUI.prop.SRC, idle_year_TextRotate_ASCIIARRAY[charCode]);
                      idle_year_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_year_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate month_TIME');
              let idle_month_rotate_string = parseInt(valueMonth).toString();
              idle_month_rotate_string = idle_month_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_month_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMonth != null && valueMonth != undefined && isFinite(valueMonth) && idle_month_rotate_string.length > 0 && idle_month_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_month_TextRotate_posOffset = idle_month_TextRotate_img_width * idle_month_rotate_string.length;
                  img_offset -= idle_month_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_month_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_month_TextRotate[index].setProperty(hmUI.prop.POS_X, 369 + img_offset);
                      idle_month_TextRotate[index].setProperty(hmUI.prop.SRC, idle_month_TextRotate_ASCIIARRAY[charCode]);
                      idle_month_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_month_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate day_TIME');
              let idle_day_rotate_string = parseInt(valueDay).toString();
              idle_day_rotate_string = idle_day_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && idle_day_rotate_string.length > 0 && idle_day_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_day_TextRotate_posOffset = idle_day_TextRotate_img_width * idle_day_rotate_string.length;
                  img_offset -= idle_day_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_day_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 336 + img_offset);
                      idle_day_TextRotate[index].setProperty(hmUI.prop.SRC, idle_day_TextRotate_ASCIIARRAY[charCode]);
                      idle_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_day_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate hour_TIME');
              let idle_hour_rotate_string = parseInt(valueHour).toString();
              idle_hour_rotate_string = idle_hour_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && idle_hour_rotate_string.length > 0 && idle_hour_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_hour_TextRotate_posOffset = idle_hour_TextRotate_img_width * idle_hour_rotate_string.length;
                  img_offset -= idle_hour_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 284 + img_offset);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.SRC, idle_hour_TextRotate_ASCIIARRAY[charCode]);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_hour_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let idle_minute_rotate_string = parseInt(valueMinute).toString();
              idle_minute_rotate_string = idle_minute_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && idle_minute_rotate_string.length > 0 && idle_minute_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_minute_TextRotate_posOffset = idle_minute_TextRotate_img_width * idle_minute_rotate_string.length;
                  img_offset -= idle_minute_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 351 + img_offset);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.SRC, idle_minute_TextRotate_ASCIIARRAY[charCode]);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_minute_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let normal_cityNameStr = weatherData.cityName;
              normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                heart_rate.removeEventListener(heart.event.CURRENT, hrCurrListener);
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}