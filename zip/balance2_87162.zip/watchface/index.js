/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v3.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_img1 = '';
		let normal_img2 = '';
		let normal_img3 = '';
		let normal_img4 = '';
		let normal_img6 = '';
		let normal_hour_imagecombo7 = '';
		let normal_minute_imagecombo8 = '';
		let normal_second_imagecombo9 = '';
		let normal_img10 = '';
		let normal_img11 = '';
		let normal_img12 = '';
		let normal_img13 = '';
		let normal_img14 = '';
		let normal_img15 = '';
		let normal_img16 = '';
		let normal_img17 = '';
		let normal_img18 = '';
		let normal_img19 = '';
		let normal_img20 = '';
		let normal_img22 = '';
		let normal_hour_imagecombo23 = '';
		let normal_minute_imagecombo24 = '';
		let normal_second_imagecombo25 = '';
		let normal_img26 = '';
		let normal_img27 = '';
		let normal_img28 = '';
		let normal_img29 = '';
		let normal_img31 = '';
		let normal_hour_imagecombo32 = '';
		let normal_minute_imagecombo33 = '';
		let normal_second_imagecombo34 = '';
		let normal_img35 = '';
		let normal_img36 = '';
		let normal_img37 = '';
		let normal_img38 = '';
		let normal_img40 = '';
		let normal_hour_imagecombo41 = '';
		let normal_minute_imagecombo42 = '';
		let normal_second_imagecombo43 = '';
		let normal_img44 = '';
		let normal_img45 = '';
		let normal_img46 = '';
		let normal_img47 = '';
		let normal_img49 = '';
		let normal_hour_imagecombo50 = '';
		let normal_minute_imagecombo51 = '';
		let normal_second_imagecombo52 = '';
		let normal_img53 = '';
		let normal_img54 = '';
		let normal_img55 = '';
		let normal_img56 = '';
		let normal_img58 = '';
		let normal_hour_imagecombo59 = '';
		let normal_minute_imagecombo60 = '';
		let normal_second_imagecombo61 = '';
		let normal_img62 = '';
		let normal_img63 = '';
		let normal_img64 = '';
		let normal_img65 = '';
		let normal_img67 = '';
		let normal_img68 = '';
		let normal_img69 = '';
		let normal_img70 = '';
		let normal_hour_imagecombo71 = '';
		let normal_minute_imagecombo72 = '';
		let normal_second_imagecombo73 = '';
		let normal_img74 = '';
		let normal_img76 = '';
		let normal_img77 = '';
		let normal_img78 = '';
		let normal_img79 = '';
		let normal_hour_imagecombo80 = '';
		let normal_minute_imagecombo81 = '';
		let normal_second_imagecombo82 = '';
		let normal_img83 = '';
		let normal_img85 = '';
		let normal_hour_imagecombo86 = '';
		let normal_minute_imagecombo87 = '';
		let normal_second_imagecombo88 = '';
		let normal_img89 = '';
		let normal_img90 = '';
		let normal_img91 = '';
		let normal_img92 = '';
		let normal_img94 = '';
		let normal_hour_imagecombo95 = '';
		let normal_minute_imagecombo96 = '';
		let normal_second_imagecombo97 = '';
		let normal_img98 = '';
		let normal_img99 = '';
		let normal_img100 = '';
		let normal_img101 = '';
		let normal_img103 = '';
		let normal_hour_imagecombo104 = '';
		let normal_minute_imagecombo105 = '';
		let normal_second_imagecombo106 = '';
		let normal_img107 = '';
		let normal_img108 = '';
		let normal_img109 = '';
		let normal_img110 = '';
		let normal_img112 = '';
		let normal_hour_imagecombo113 = '';
		let normal_minute_imagecombo114 = '';
		let normal_second_imagecombo115 = '';
		let normal_img116 = '';
		let normal_img117 = '';
		let normal_img118 = '';
		let normal_img119 = '';
		let normal_img121 = '';
		let normal_hour_imagecombo122 = '';
		let normal_minute_imagecombo123 = '';
		let normal_second_imagecombo124 = '';
		let normal_img125 = '';
		let normal_img126 = '';
		let normal_img127 = '';
		let normal_img128 = '';
		let normal_img130 = '';
		let normal_hour_imagecombo131 = '';
		let normal_minute_imagecombo132 = '';
		let normal_second_imagecombo133 = '';
		let normal_img134 = '';
		let normal_img135 = '';
		let normal_img136 = '';
		let normal_img137 = '';
		let normal_img139 = '';
		let normal_hour_imagecombo140 = '';
		let normal_minute_imagecombo141 = '';
		let normal_second_imagecombo142 = '';
		let normal_img143 = '';
		let normal_img144 = '';
		let normal_img145 = '';
		let normal_img146 = '';
		let normal_img148 = '';
		let normal_hour_imagecombo149 = '';
		let normal_minute_imagecombo150 = '';
		let normal_second_imagecombo151 = '';
		let normal_img152 = '';
		let normal_img153 = '';
		let normal_img154 = '';
		let normal_img155 = '';
		let normal_img157 = '';
		let normal_hour_imagecombo158 = '';
		let normal_minute_imagecombo159 = '';
		let normal_second_imagecombo160 = '';
		let normal_img161 = '';
		let normal_img162 = '';
		let normal_img163 = '';
		let normal_img164 = '';
		let normal_img166 = '';
		let normal_hour_imagecombo167 = '';
		let normal_minute_imagecombo168 = '';
		let normal_second_imagecombo169 = '';
		let normal_img170 = '';
		let normal_img171 = '';
		let normal_img172 = '';
		let normal_img173 = '';
		let normal_img175 = '';
		let normal_hour_imagecombo176 = '';
		let normal_minute_imagecombo177 = '';
		let normal_second_imagecombo178 = '';
		let normal_img179 = '';
		let normal_img180 = '';
		let normal_img181 = '';
		let normal_img182 = '';
		let normal_img184 = '';
		let normal_hour_imagecombo185 = '';
		let normal_minute_imagecombo186 = '';
		let normal_second_imagecombo187 = '';
		let normal_img188 = '';
		let normal_img189 = '';
		let normal_img190 = '';
		let normal_img191 = '';
		let normal_img193 = '';
		let normal_hour_imagecombo194 = '';
		let normal_minute_imagecombo195 = '';
		let normal_second_imagecombo196 = '';
		let normal_img197 = '';
		let normal_img198 = '';
		let normal_img199 = '';
		let normal_img200 = '';
		let normal_img202 = '';
		let normal_hour_imagecombo203 = '';
		let normal_minute_imagecombo204 = '';
		let normal_second_imagecombo205 = '';
		let normal_img206 = '';
		let normal_img207 = '';
		let normal_img208 = '';
		let normal_img209 = '';
		let normal_img211 = '';
		let normal_hour_imagecombo212 = '';
		let normal_minute_imagecombo213 = '';
		let normal_second_imagecombo214 = '';
		let normal_img215 = '';
		let normal_img216 = '';
		let normal_img217 = '';
		let normal_img218 = '';
		let normal_img220 = '';
		let normal_hour_imagecombo221 = '';
		let normal_minute_imagecombo222 = '';
		let normal_second_imagecombo223 = '';
		let normal_img224 = '';
		let normal_img225 = '';
		let normal_img226 = '';
		let normal_img227 = '';
		let normal_img229 = '';
		let normal_hour_imagecombo230 = '';
		let normal_minute_imagecombo231 = '';
		let normal_second_imagecombo232 = '';
		let normal_img233 = '';
		let normal_img234 = '';
		let normal_img235 = '';
		let normal_img236 = '';
		let normal_img238 = '';
		let normal_img239 = '';
		let normal_img240 = '';
		let normal_second_imagecombo241 = '';
		let normal_minute_imagecombo242 = '';
		let normal_hour_imagecombo243 = '';
		let normal_img244 = '';
		let normal_img245 = '';
		let normal_img246 = '';
		let normal_img247 = '';
		let normal_steps_imageset250 = '';
		let normal_steps_first_imageset251 = '';
		let normal_steps_first_imageset251_array = ['0641.png','0642.png','0643.png','0644.png','0645.png','0646.png','0647.png','0648.png','0649.png','0650.png'];
		let normal_steps_second_imageset252 = '';
		let normal_steps_second_imageset252_array = ['0651.png','0652.png','0653.png','0654.png','0655.png','0656.png','0657.png','0658.png','0659.png','0660.png'];
		let normal_steps_third_imageset253 = '';
		let normal_steps_third_imageset253_array = ['0661.png','0662.png','0663.png','0664.png','0665.png','0666.png','0667.png','0668.png','0669.png','0670.png'];
		let normal_steps_fourth_imageset254 = '';
		let normal_steps_fourth_imageset254_array = ['0671.png','0672.png','0673.png','0674.png','0675.png','0676.png','0677.png','0678.png','0679.png','0680.png'];
		let normal_img255 = '';
		let normal_steps_fifth_imageset256 = '';
		let normal_steps_fifth_imageset256_array = ['0682.png','0683.png','0684.png','0685.png','0686.png','0687.png','0688.png','0689.png','0690.png','0691.png'];
		let normal_calories_imageset258 = '';
		let normal_calories_fourth_imageset259 = '';
		let normal_calories_fourth_imageset259_array = ['0718.png','0719.png','0720.png','0721.png','0722.png','0723.png','0724.png','0725.png','0726.png','0727.png'];
		let normal_calories_third_imageset260 = '';
		let normal_calories_third_imageset260_array = ['0728.png','0729.png','0730.png','0731.png','0732.png','0733.png','0734.png','0735.png','0736.png','0737.png'];
		let normal_calories_second_imageset261 = '';
		let normal_calories_second_imageset261_array = ['0738.png','0739.png','0740.png','0741.png','0742.png','0743.png','0744.png','0745.png','0746.png','0747.png'];
		let normal_calories_first_imageset262 = '';
		let normal_calories_first_imageset262_array = ['0748.png','0749.png','0750.png','0751.png','0752.png','0753.png','0754.png','0755.png','0756.png','0757.png'];
		let normal_battery_imageset264 = '';
		let normal_battery_third_imageset265 = '';
		let normal_battery_third_imageset265_array = ['0784.png','0652.png','0784.png','0784.png','0784.png','0784.png','0784.png','0784.png','0784.png','0784.png'];
		let normal_battery_second_imageset266 = '';
		let normal_battery_second_imageset266_array = ['0785.png','0786.png','0787.png','0788.png','0789.png','0790.png','0791.png','0792.png','0793.png','0794.png'];
		let normal_battery_first_imageset267 = '';
		let normal_battery_first_imageset267_array = ['0795.png','0796.png','0797.png','0798.png','0799.png','0800.png','0801.png','0802.png','0803.png','0804.png'];
		let normal_img268 = '';
		let normal_stress_imageset270 = '';
		let normal_stress_first_imageset271 = '';
		let normal_stress_first_imageset271_array = ['0728.png','0729.png','0730.png','0731.png','0732.png','0733.png','0734.png','0735.png','0736.png','0737.png'];
		let normal_stress_second_imageset272 = '';
		let normal_stress_second_imageset272_array = ['0738.png','0739.png','0740.png','0741.png','0742.png','0743.png','0744.png','0745.png','0746.png','0747.png'];
		let normal_stress_third_imageset273 = '';
		let normal_stress_third_imageset273_array = ['0832.png','0833.png'];
		let normal_heart_current_imagecombo275 = '';
		let normal_distance_units_imageset277 = '';
		let normal_distance_units_imageset277_array = ['0845.png','0846.png'];
		let normal_distance_imagecombo278 = '';
		let normal_img279 = '';
		let normal_img281 = '';
		let normal_blood_oxygen_imagecombo282 = '';
		let normal_img284 = '';
		let normal_vo2max_imagecombo285 = '';
		let normal_img287 = '';
		let normal_img288 = '';
		let normal_pai_imagecombo289 = '';
		let normal_img290 = '';
		let normal_pai_weekly_imagecombo291 = '';
		let normal_img292 = '';
		let normal_img294 = '';
		let normal_sleep_hour_high_imageset295 = '';
		let normal_sleep_hour_high_imageset295_array = ['0896.png','0897.png','0898.png'];
		let normal_sleep_hour_low_imageset296 = '';
		let normal_sleep_hour_low_imageset296_array = ['0896.png','0897.png','0898.png','0899.png','0900.png','0901.png','0902.png','0903.png','0904.png','0905.png'];
		let normal_sleep_minute_high_imageset297 = '';
		let normal_sleep_minute_high_imageset297_array = ['0896.png','0897.png','0898.png','0899.png','0900.png','0901.png'];
		let normal_sleep_minute_low_imageset298 = '';
		let normal_sleep_minute_low_imageset298_array = ['0896.png','0897.png','0898.png','0899.png','0900.png','0901.png','0902.png','0903.png','0904.png','0905.png'];
		let normal_img299 = '';
		let normal_img301 = '';
		let normal_stand_imagecombo302 = '';
		let normal_img304 = '';
		let normal_airpressure_imagecombo305 = '';
		let normal_img307 = '';
		let normal_altitude_imagecombo308 = '';
		let normal_img310 = '';
		let normal_humidity_imagecombo311 = '';
		let normal_img313 = '';
		let normal_wind_bearing_imageset314 = '';
		let normal_wind_imagecombo315 = '';
		let normal_img317 = '';
		let normal_uvindex_imageset318 = '';
		let normal_img319 = '';
		let normal_img321 = '';
		let normal_img322 = '';
		let normal_sunrise_hours_high_imageset323 = '';
		let normal_sunrise_hours_high_imageset323_array = ['0896.png','0897.png','0898.png'];
		let normal_sunrise_hours_low_imageset324 = '';
		let normal_sunrise_hours_low_imageset324_array = ['0896.png','0897.png','0898.png','0899.png','0900.png','0901.png','0902.png','0903.png','0904.png','0905.png'];
		let normal_sunrise_minutes_high_imageset325 = '';
		let normal_sunrise_minutes_high_imageset325_array = ['0896.png','0897.png','0898.png','0899.png','0900.png','0901.png'];
		let normal_sunrise_minutes_low_imageset326 = '';
		let normal_sunrise_minutes_low_imageset326_array = ['0896.png','0897.png','0898.png','0899.png','0900.png','0901.png','0902.png','0903.png','0904.png','0905.png'];
		let normal_img327 = '';
		let normal_sunset_hours_high_imageset328 = '';
		let normal_sunset_hours_high_imageset328_array = ['0896.png','0897.png','0898.png'];
		let normal_sunset_hours_low_imageset329 = '';
		let normal_sunset_hours_low_imageset329_array = ['0896.png','0897.png','0898.png','0899.png','0900.png','0901.png','0902.png','0903.png','0904.png','0905.png'];
		let normal_img330 = '';
		let normal_sunset_minutes_high_imageset331 = '';
		let normal_sunset_minutes_high_imageset331_array = ['0896.png','0897.png','0898.png','0899.png','0900.png','0901.png'];
		let normal_sunset_minutes_low_imageset332 = '';
		let normal_sunset_minutes_low_imageset332_array = ['0896.png','0897.png','0898.png','0899.png','0900.png','0901.png','0902.png','0903.png','0904.png','0905.png'];
		let normal_img333 = '';
		let normal_img335 = '';
		let normal_biocharge_imagecombo336 = '';
		let normal_distance_units_imageset339 = '';
		let normal_distance_units_imageset339_array = ['0845.png','0846.png'];
		let normal_distance_imagecombo340 = '';
		let normal_img341 = '';
		let normal_img343 = '';
		let normal_blood_oxygen_imagecombo344 = '';
		let normal_img346 = '';
		let normal_vo2max_imagecombo347 = '';
		let normal_img349 = '';
		let normal_img350 = '';
		let normal_pai_imagecombo351 = '';
		let normal_img352 = '';
		let normal_pai_weekly_imagecombo353 = '';
		let normal_img354 = '';
		let normal_img356 = '';
		let normal_sleep_hour_high_imageset357 = '';
		let normal_sleep_hour_high_imageset357_array = ['0896.png','0897.png','0898.png'];
		let normal_sleep_hour_low_imageset358 = '';
		let normal_sleep_hour_low_imageset358_array = ['0896.png','0897.png','0898.png','0899.png','0900.png','0901.png','0902.png','0903.png','0904.png','0905.png'];
		let normal_sleep_minute_high_imageset359 = '';
		let normal_sleep_minute_high_imageset359_array = ['0896.png','0897.png','0898.png','0899.png','0900.png','0901.png'];
		let normal_sleep_minute_low_imageset360 = '';
		let normal_sleep_minute_low_imageset360_array = ['0896.png','0897.png','0898.png','0899.png','0900.png','0901.png','0902.png','0903.png','0904.png','0905.png'];
		let normal_img361 = '';
		let normal_img363 = '';
		let normal_stand_imagecombo364 = '';
		let normal_img366 = '';
		let normal_airpressure_imagecombo367 = '';
		let normal_img369 = '';
		let normal_altitude_imagecombo370 = '';
		let normal_img372 = '';
		let normal_humidity_imagecombo373 = '';
		let normal_img375 = '';
		let normal_wind_bearing_imageset376 = '';
		let normal_wind_imagecombo377 = '';
		let normal_img379 = '';
		let normal_img380 = '';
		let normal_img381 = '';
		let normal_img382 = '';
		let normal_img383 = '';
		let normal_sunrise_hours_high_imageset384 = '';
		let normal_sunrise_hours_high_imageset384_array = ['0896.png','0897.png','0898.png'];
		let normal_sunrise_hours_low_imageset385 = '';
		let normal_sunrise_hours_low_imageset385_array = ['0896.png','0897.png','0898.png','0899.png','0900.png','0901.png','0902.png','0903.png','0904.png','0905.png'];
		let normal_sunrise_minutes_high_imageset386 = '';
		let normal_sunrise_minutes_high_imageset386_array = ['0896.png','0897.png','0898.png','0899.png','0900.png','0901.png'];
		let normal_sunrise_minutes_low_imageset387 = '';
		let normal_sunrise_minutes_low_imageset387_array = ['0896.png','0897.png','0898.png','0899.png','0900.png','0901.png','0902.png','0903.png','0904.png','0905.png'];
		let normal_sunset_hours_high_imageset388 = '';
		let normal_sunset_hours_high_imageset388_array = ['0896.png','0897.png','0898.png'];
		let normal_sunset_hours_low_imageset389 = '';
		let normal_sunset_hours_low_imageset389_array = ['0896.png','0897.png','0898.png','0899.png','0900.png','0901.png','0902.png','0903.png','0904.png','0905.png'];
		let normal_sunset_minutes_high_imageset390 = '';
		let normal_sunset_minutes_high_imageset390_array = ['0896.png','0897.png','0898.png','0899.png','0900.png','0901.png'];
		let normal_sunset_minutes_low_imageset391 = '';
		let normal_sunset_minutes_low_imageset391_array = ['0896.png','0897.png','0898.png','0899.png','0900.png','0901.png','0902.png','0903.png','0904.png','0905.png'];
		let normal_img393 = '';
		let normal_uvindex_imageset394 = '';
		let normal_img395 = '';
		let normal_img397 = '';
		let normal_biocharge_imagecombo398 = '';
		let normal_week_imageset401 = '';
		let normal_date_imagecombo402 = '';
		let normal_weather_imageset404 = '';
		let normal_weather_imageset405 = '';
		let normal_temperature_current_imagecombo406 = '';
		let normal_temperature_high_imagecombo407 = '';
		let normal_temperature_low_imagecombo408 = '';
		let normal_img409 = '';
		let normal_img410 = '';
		let normal_weatherplusone_imageset412 = '';
		let normal_weatherplusone_imageset412_array = ['1046.png','1047.png','1048.png','1049.png','1050.png','1051.png','1052.png','1053.png','1054.png','1055.png','1053.png','1056.png','1057.png','1058.png','1059.png','1060.png','1061.png','1062.png','1063.png','1064.png','1065.png','1063.png','1062.png','1066.png','1063.png','1067.png','1068.png','1051.png','1069.png'];
		let normal_weatherplustwo_imageset413 = '';
		let normal_weatherplustwo_imageset413_array = ['1046.png','1047.png','1048.png','1049.png','1050.png','1051.png','1052.png','1053.png','1054.png','1055.png','1053.png','1056.png','1057.png','1058.png','1059.png','1060.png','1061.png','1062.png','1063.png','1064.png','1065.png','1063.png','1062.png','1066.png','1063.png','1067.png','1068.png','1051.png','1069.png'];
		let normal_weatherplusthree_imageset414 = '';
		let normal_weatherplusthree_imageset414_array = ['1046.png','1047.png','1048.png','1049.png','1050.png','1051.png','1052.png','1053.png','1054.png','1055.png','1053.png','1056.png','1057.png','1058.png','1059.png','1060.png','1061.png','1062.png','1063.png','1064.png','1065.png','1063.png','1062.png','1066.png','1063.png','1067.png','1068.png','1051.png','1069.png'];
		let normal_weatherplusfour_imageset415 = '';
		let normal_weatherplusfour_imageset415_array = ['1046.png','1047.png','1048.png','1049.png','1050.png','1051.png','1052.png','1053.png','1054.png','1055.png','1053.png','1056.png','1057.png','1058.png','1059.png','1060.png','1061.png','1062.png','1063.png','1064.png','1065.png','1063.png','1062.png','1066.png','1063.png','1067.png','1068.png','1051.png','1069.png'];
		let normal_img416 = '';
		let normal_img417 = '';
		let normal_img418 = '';
		let normal_img419 = '';
		let normal_img420 = '';
		let normal_img423 = '';
		let normal_img425 = '';
		let normal_biocharge_imagecombo426 = '';
		let normal_heart_shortcut430 = '';
		let normal_stress_shortcut431 = '';
		let normal_steps_shortcut432 = '';
		let normal_calories_shortcut433 = '';
		let normal_battery_shortcut434 = '';
		let normal_weather_shortcut435 = '';
		let idle_minute_imagecombo437 = '';
		let idle_hour_imagecombo438 = '';
		let idle_img439 = '';
		let idle_img440 = '';
		let idle_date_imagecombo442 = '';
		let idle_week_imageset443 = '';
		let idle_steps_imageset445 = '';
		let idle_steps_first_imageset446 = '';
		let idle_steps_first_imageset446_array = ['0641.png','0642.png','0643.png','0644.png','0645.png','0646.png','0647.png','0648.png','0649.png','0650.png'];
		let idle_steps_second_imageset447 = '';
		let idle_steps_second_imageset447_array = ['0651.png','0652.png','0653.png','0654.png','0655.png','0656.png','0657.png','0658.png','0659.png','0660.png'];
		let idle_steps_third_imageset448 = '';
		let idle_steps_third_imageset448_array = ['0661.png','0662.png','0663.png','0664.png','0665.png','0666.png','0667.png','0668.png','0669.png','0670.png'];
		let idle_steps_fourth_imageset449 = '';
		let idle_steps_fourth_imageset449_array = ['0671.png','0672.png','0673.png','0674.png','0675.png','0676.png','0677.png','0678.png','0679.png','0680.png'];
		let idle_img450 = '';
		let idle_steps_fifth_imageset451 = '';
		let idle_steps_fifth_imageset451_array = ['0682.png','0683.png','0684.png','0685.png','0686.png','0687.png','0688.png','0689.png','0690.png','0691.png'];
		let idle_calories_imageset453 = '';
		let idle_calories_fourth_imageset454 = '';
		let idle_calories_fourth_imageset454_array = ['0718.png','0719.png','0720.png','0721.png','0722.png','0723.png','0724.png','0725.png','0726.png','0727.png'];
		let idle_calories_third_imageset455 = '';
		let idle_calories_third_imageset455_array = ['0728.png','0729.png','0730.png','0731.png','0732.png','0733.png','0734.png','0735.png','0736.png','0737.png'];
		let idle_calories_second_imageset456 = '';
		let idle_calories_second_imageset456_array = ['0738.png','0739.png','0740.png','0741.png','0742.png','0743.png','0744.png','0745.png','0746.png','0747.png'];
		let idle_calories_first_imageset457 = '';
		let idle_calories_first_imageset457_array = ['0748.png','0749.png','0750.png','0751.png','0752.png','0753.png','0754.png','0755.png','0756.png','0757.png'];
		let idle_battery_imageset459 = '';
		let idle_battery_third_imageset460 = '';
		let idle_battery_third_imageset460_array = ['0784.png','0652.png','0784.png','0784.png','0784.png','0784.png','0784.png','0784.png','0784.png','0784.png'];
		let idle_battery_second_imageset461 = '';
		let idle_battery_second_imageset461_array = ['0785.png','0786.png','0787.png','0788.png','0789.png','0790.png','0791.png','0792.png','0793.png','0794.png'];
		let idle_battery_first_imageset462 = '';
		let idle_battery_first_imageset462_array = ['0795.png','0796.png','0797.png','0798.png','0799.png','0800.png','0801.png','0802.png','0803.png','0804.png'];
		let idle_img463 = '';
		let idle_stress_imageset465 = '';
		let idle_stress_first_imageset466 = '';
		let idle_stress_first_imageset466_array = ['0728.png','0729.png','0730.png','0731.png','0732.png','0733.png','0734.png','0735.png','0736.png','0737.png'];
		let idle_stress_second_imageset467 = '';
		let idle_stress_second_imageset467_array = ['0738.png','0739.png','0740.png','0741.png','0742.png','0743.png','0744.png','0745.png','0746.png','0747.png'];
		let idle_stress_third_imageset468 = '';
		let idle_stress_third_imageset468_array = ['0832.png','0833.png'];
		let idle_img470 = '';
		let idle_heart_current_imagecombo471 = '';
		let idle_img473 = '';
		let idle_img474 = '';
		let idle_temperature_low_imagecombo475 = '';
		let idle_temperature_high_imagecombo476 = '';
		let idle_weather_imageset477 = '';
		let idle_temperature_current_imagecombo478 = '';
		let idle_weather_imageset479 = '';
		let idle_distance_units_imageset481 = '';
		let idle_distance_units_imageset481_array = ['0845.png','0846.png'];
		let idle_distance_imagecombo482 = '';
		let idle_img483 = '';
		let idle_img485 = '';
		let idle_biocharge_imagecombo486 = '';
		let container_1758240800721 = '';
		let container_1758240800721_customs = [
			{
				label: 'Digital Dial',
				widgets: [
					'normal_img6',
					'normal_hour_imagecombo7',
					'normal_minute_imagecombo8',
					'normal_second_imagecombo9',
					'normal_img10',
					'normal_img11',
					'normal_img12',
					'normal_img13',
					'normal_img14',
					'normal_img15',
					'normal_img16',
					'normal_img17',
					'normal_img18',
					'normal_img19',
					'normal_img20',
				]
			},
			{
				label: 'Digital Dial',
				widgets: [
					'normal_img22',
					'normal_hour_imagecombo23',
					'normal_minute_imagecombo24',
					'normal_second_imagecombo25',
					'normal_img26',
					'normal_img27',
					'normal_img28',
					'normal_img29',
				]
			},
			{
				label: 'Digital Dial',
				widgets: [
					'normal_img31',
					'normal_hour_imagecombo32',
					'normal_minute_imagecombo33',
					'normal_second_imagecombo34',
					'normal_img35',
					'normal_img36',
					'normal_img37',
					'normal_img38',
				]
			},
			{
				label: 'Digital Dial',
				widgets: [
					'normal_img40',
					'normal_hour_imagecombo41',
					'normal_minute_imagecombo42',
					'normal_second_imagecombo43',
					'normal_img44',
					'normal_img45',
					'normal_img46',
					'normal_img47',
				]
			},
			{
				label: 'Digital Dial',
				widgets: [
					'normal_img49',
					'normal_hour_imagecombo50',
					'normal_minute_imagecombo51',
					'normal_second_imagecombo52',
					'normal_img53',
					'normal_img54',
					'normal_img55',
					'normal_img56',
				]
			},
			{
				label: 'Digital Dial',
				widgets: [
					'normal_img58',
					'normal_hour_imagecombo59',
					'normal_minute_imagecombo60',
					'normal_second_imagecombo61',
					'normal_img62',
					'normal_img63',
					'normal_img64',
					'normal_img65',
				]
			},
			{
				label: 'Digital Dial',
				widgets: [
					'normal_img67',
					'normal_img68',
					'normal_img69',
					'normal_img70',
					'normal_hour_imagecombo71',
					'normal_minute_imagecombo72',
					'normal_second_imagecombo73',
					'normal_img74',
				]
			},
			{
				label: 'Digital Dial',
				widgets: [
					'normal_img76',
					'normal_img77',
					'normal_img78',
					'normal_img79',
					'normal_hour_imagecombo80',
					'normal_minute_imagecombo81',
					'normal_second_imagecombo82',
					'normal_img83',
				]
			},
			{
				label: 'Digital Dial',
				widgets: [
					'normal_img85',
					'normal_hour_imagecombo86',
					'normal_minute_imagecombo87',
					'normal_second_imagecombo88',
					'normal_img89',
					'normal_img90',
					'normal_img91',
					'normal_img92',
				]
			},
			{
				label: 'Digital Dial',
				widgets: [
					'normal_img94',
					'normal_hour_imagecombo95',
					'normal_minute_imagecombo96',
					'normal_second_imagecombo97',
					'normal_img98',
					'normal_img99',
					'normal_img100',
					'normal_img101',
				]
			},
			{
				label: 'Digital Dial',
				widgets: [
					'normal_img103',
					'normal_hour_imagecombo104',
					'normal_minute_imagecombo105',
					'normal_second_imagecombo106',
					'normal_img107',
					'normal_img108',
					'normal_img109',
					'normal_img110',
				]
			},
			{
				label: 'Digital Dial',
				widgets: [
					'normal_img112',
					'normal_hour_imagecombo113',
					'normal_minute_imagecombo114',
					'normal_second_imagecombo115',
					'normal_img116',
					'normal_img117',
					'normal_img118',
					'normal_img119',
				]
			},
			{
				label: 'Digital Dial',
				widgets: [
					'normal_img121',
					'normal_hour_imagecombo122',
					'normal_minute_imagecombo123',
					'normal_second_imagecombo124',
					'normal_img125',
					'normal_img126',
					'normal_img127',
					'normal_img128',
				]
			},
			{
				label: 'Digital Dial',
				widgets: [
					'normal_img130',
					'normal_hour_imagecombo131',
					'normal_minute_imagecombo132',
					'normal_second_imagecombo133',
					'normal_img134',
					'normal_img135',
					'normal_img136',
					'normal_img137',
				]
			},
			{
				label: 'Digital Dial',
				widgets: [
					'normal_img139',
					'normal_hour_imagecombo140',
					'normal_minute_imagecombo141',
					'normal_second_imagecombo142',
					'normal_img143',
					'normal_img144',
					'normal_img145',
					'normal_img146',
				]
			},
			{
				label: 'Digital Dial',
				widgets: [
					'normal_img148',
					'normal_hour_imagecombo149',
					'normal_minute_imagecombo150',
					'normal_second_imagecombo151',
					'normal_img152',
					'normal_img153',
					'normal_img154',
					'normal_img155',
				]
			},
			{
				label: 'Digital Dial',
				widgets: [
					'normal_img157',
					'normal_hour_imagecombo158',
					'normal_minute_imagecombo159',
					'normal_second_imagecombo160',
					'normal_img161',
					'normal_img162',
					'normal_img163',
					'normal_img164',
				]
			},
			{
				label: 'Digital Dial',
				widgets: [
					'normal_img166',
					'normal_hour_imagecombo167',
					'normal_minute_imagecombo168',
					'normal_second_imagecombo169',
					'normal_img170',
					'normal_img171',
					'normal_img172',
					'normal_img173',
				]
			},
			{
				label: 'Digital Dial',
				widgets: [
					'normal_img175',
					'normal_hour_imagecombo176',
					'normal_minute_imagecombo177',
					'normal_second_imagecombo178',
					'normal_img179',
					'normal_img180',
					'normal_img181',
					'normal_img182',
				]
			},
			{
				label: 'Digital Dial',
				widgets: [
					'normal_img184',
					'normal_hour_imagecombo185',
					'normal_minute_imagecombo186',
					'normal_second_imagecombo187',
					'normal_img188',
					'normal_img189',
					'normal_img190',
					'normal_img191',
				]
			},
			{
				label: 'Digital Dial',
				widgets: [
					'normal_img193',
					'normal_hour_imagecombo194',
					'normal_minute_imagecombo195',
					'normal_second_imagecombo196',
					'normal_img197',
					'normal_img198',
					'normal_img199',
					'normal_img200',
				]
			},
			{
				label: 'Digital Dial',
				widgets: [
					'normal_img202',
					'normal_hour_imagecombo203',
					'normal_minute_imagecombo204',
					'normal_second_imagecombo205',
					'normal_img206',
					'normal_img207',
					'normal_img208',
					'normal_img209',
				]
			},
			{
				label: 'Digital Dial',
				widgets: [
					'normal_img211',
					'normal_hour_imagecombo212',
					'normal_minute_imagecombo213',
					'normal_second_imagecombo214',
					'normal_img215',
					'normal_img216',
					'normal_img217',
					'normal_img218',
				]
			},
			{
				label: 'Digital Dial',
				widgets: [
					'normal_img220',
					'normal_hour_imagecombo221',
					'normal_minute_imagecombo222',
					'normal_second_imagecombo223',
					'normal_img224',
					'normal_img225',
					'normal_img226',
					'normal_img227',
				]
			},
			{
				label: 'Digital Dial',
				widgets: [
					'normal_img229',
					'normal_hour_imagecombo230',
					'normal_minute_imagecombo231',
					'normal_second_imagecombo232',
					'normal_img233',
					'normal_img234',
					'normal_img235',
					'normal_img236',
				]
			},
			{
				label: 'Digital Dial',
				widgets: [
					'normal_img238',
					'normal_img239',
					'normal_img240',
					'normal_second_imagecombo241',
					'normal_minute_imagecombo242',
					'normal_hour_imagecombo243',
					'normal_img244',
					'normal_img245',
					'normal_img246',
					'normal_img247',
				]
			},
		];
		let container_1758240800721_selected = 16;
		let container_1758386599609 = '';
		let container_1758386599609_customs = [
			{
				label: 'Distance',
				widgets: [
					'normal_distance_units_imageset277',
					'normal_distance_imagecombo278',
					'normal_img279',
				]
			},
			{
				label: 'SPO2',
				widgets: [
					'normal_img281',
					'normal_blood_oxygen_imagecombo282',
				]
			},
			{
				label: 'VO2Max',
				widgets: [
					'normal_img284',
					'normal_vo2max_imagecombo285',
				]
			},
			{
				label: 'PAI',
				widgets: [
					'normal_img287',
					'normal_img288',
					'normal_pai_imagecombo289',
					'normal_img290',
					'normal_pai_weekly_imagecombo291',
					'normal_img292',
				]
			},
			{
				label: 'Sleep',
				widgets: [
					'normal_img294',
					'normal_sleep_hour_high_imageset295',
					'normal_sleep_hour_low_imageset296',
					'normal_sleep_minute_high_imageset297',
					'normal_sleep_minute_low_imageset298',
					'normal_img299',
				]
			},
			{
				label: 'Standup times',
				widgets: [
					'normal_img301',
					'normal_stand_imagecombo302',
				]
			},
			{
				label: 'Atmospheric pressure',
				widgets: [
					'normal_img304',
					'normal_airpressure_imagecombo305',
				]
			},
			{
				label: 'Altitude',
				widgets: [
					'normal_img307',
					'normal_altitude_imagecombo308',
				]
			},
			{
				label: 'Humidity',
				widgets: [
					'normal_img310',
					'normal_humidity_imagecombo311',
				]
			},
			{
				label: 'Wind',
				widgets: [
					'normal_img313',
					'normal_wind_bearing_imageset314',
					'normal_wind_imagecombo315',
				]
			},
			{
				label: 'UV Index',
				widgets: [
					'normal_img317',
					'normal_uvindex_imageset318',
					'normal_img319',
				]
			},
			{
				label: 'Sunrise and Sunset',
				widgets: [
					'normal_img321',
					'normal_img322',
					'normal_sunrise_hours_high_imageset323',
					'normal_sunrise_hours_low_imageset324',
					'normal_sunrise_minutes_high_imageset325',
					'normal_sunrise_minutes_low_imageset326',
					'normal_img327',
					'normal_sunset_hours_high_imageset328',
					'normal_sunset_hours_low_imageset329',
					'normal_img330',
					'normal_sunset_minutes_high_imageset331',
					'normal_sunset_minutes_low_imageset332',
					'normal_img333',
				]
			},
			{
				label: 'BioCharge',
				widgets: [
					'normal_img335',
					'normal_biocharge_imagecombo336',
				]
			},
		];
		let container_1758386599609_selected = 6;
		let container_1758386601789 = '';
		let container_1758386601789_customs = [
			{
				label: 'Distance',
				widgets: [
					'normal_distance_units_imageset339',
					'normal_distance_imagecombo340',
					'normal_img341',
				]
			},
			{
				label: 'SPO2',
				widgets: [
					'normal_img343',
					'normal_blood_oxygen_imagecombo344',
				]
			},
			{
				label: 'VO2Max',
				widgets: [
					'normal_img346',
					'normal_vo2max_imagecombo347',
				]
			},
			{
				label: 'PAI',
				widgets: [
					'normal_img349',
					'normal_img350',
					'normal_pai_imagecombo351',
					'normal_img352',
					'normal_pai_weekly_imagecombo353',
					'normal_img354',
				]
			},
			{
				label: 'Sleep',
				widgets: [
					'normal_img356',
					'normal_sleep_hour_high_imageset357',
					'normal_sleep_hour_low_imageset358',
					'normal_sleep_minute_high_imageset359',
					'normal_sleep_minute_low_imageset360',
					'normal_img361',
				]
			},
			{
				label: 'Standup times',
				widgets: [
					'normal_img363',
					'normal_stand_imagecombo364',
				]
			},
			{
				label: 'Atmospheric pressure',
				widgets: [
					'normal_img366',
					'normal_airpressure_imagecombo367',
				]
			},
			{
				label: 'Altitude',
				widgets: [
					'normal_img369',
					'normal_altitude_imagecombo370',
				]
			},
			{
				label: 'Humidity',
				widgets: [
					'normal_img372',
					'normal_humidity_imagecombo373',
				]
			},
			{
				label: 'Wind',
				widgets: [
					'normal_img375',
					'normal_wind_bearing_imageset376',
					'normal_wind_imagecombo377',
				]
			},
			{
				label: 'Sunrise and Sunset',
				widgets: [
					'normal_img379',
					'normal_img380',
					'normal_img381',
					'normal_img382',
					'normal_img383',
					'normal_sunrise_hours_high_imageset384',
					'normal_sunrise_hours_low_imageset385',
					'normal_sunrise_minutes_high_imageset386',
					'normal_sunrise_minutes_low_imageset387',
					'normal_sunset_hours_high_imageset388',
					'normal_sunset_hours_low_imageset389',
					'normal_sunset_minutes_high_imageset390',
					'normal_sunset_minutes_low_imageset391',
				]
			},
			{
				label: 'UV Index',
				widgets: [
					'normal_img393',
					'normal_uvindex_imageset394',
					'normal_img395',
				]
			},
			{
				label: 'BioCharge',
				widgets: [
					'normal_img397',
					'normal_biocharge_imagecombo398',
				]
			},
		];
		let container_1758386601789_selected = 0;
		let container_1768268434367 = '';
		let container_1768268434367_customs = [
			{
				label: 'Weather',
				widgets: [
					'normal_weather_imageset404',
					'normal_weather_imageset405',
					'normal_temperature_current_imagecombo406',
					'normal_temperature_high_imagecombo407',
					'normal_temperature_low_imagecombo408',
					'normal_img409',
					'normal_img410',
				]
			},
			{
				label: 'Forecast',
				widgets: [
					'normal_weatherplusone_imageset412',
					'normal_weatherplustwo_imageset413',
					'normal_weatherplusthree_imageset414',
					'normal_weatherplusfour_imageset415',
					'normal_img416',
					'normal_img417',
					'normal_img418',
					'normal_img419',
					'normal_img420',
				]
			},
		];
		let container_1768268434367_selected = 0;
		let container_1768268743618 = '';
		let container_1768268743618_customs = [
			{
				label: 'None',
				widgets: [
					'normal_img423',
				]
			},
			{
				label: 'BioCharge',
				widgets: [
					'normal_img425',
					'normal_biocharge_imagecombo426',
				]
			},
		];
		let container_1768268743618_selected = 0;
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
				const stepSensor = hmSensor.createSensor(hmSensor.id.STEP);
				const calorieSensor = hmSensor.createSensor(hmSensor.id.CALORIE);
				const distanceSensor = hmSensor.createSensor(hmSensor.id.DISTANCE);
				const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
				const stressSensor = hmSensor.createSensor(hmSensor.id.STRESS);
				const vibrateSensor = hmSensor.createSensor(hmSensor.id.VIBRATE);
				const sleepSensor = hmSensor.createSensor(hmSensor.id.SLEEP);
				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 3,
					y: 3,
					w: 475,
					h: 475,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img1 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 2,
					y: 3,
					w: 475,
					h: 475,
					src: '0003.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img2 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 3,
					y: 3,
					w: 474,
					h: 474,
					src: '0004.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img3 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -1,
					y: -2,
					w: 483,
					h: 483,
					src: '0005.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img4 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 190,
					y: 190,
					w: 361,
					h: 361,
					src: '0006.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img6 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0007.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img6.setProperty(hmUI.prop.VISIBLE, false);

				normal_hour_imagecombo7 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 85,
					hour_startY: 306,
					hour_array: ["0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo7.setProperty(hmUI.prop.VISIBLE, false);

				normal_minute_imagecombo8 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 197,
					minute_startY: 306,
					minute_array: ["0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo8.setProperty(hmUI.prop.VISIBLE, false);

				normal_second_imagecombo9 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 309,
					second_startY: 306,
					second_array: ["0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo9.setProperty(hmUI.prop.VISIBLE, false);

				normal_img10 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 177,
					y: 305,
					w: 14,
					h: 88,
					src: '0028.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img10.setProperty(hmUI.prop.VISIBLE, false);

				normal_img11 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 289,
					y: 305,
					w: 14,
					h: 88,
					src: '0028.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img11.setProperty(hmUI.prop.VISIBLE, false);

				normal_img12 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 42,
					y: 164,
					w: 114,
					h: 114,
					src: '0029.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img12.setProperty(hmUI.prop.VISIBLE, false);

				normal_img13 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 324,
					y: 164,
					w: 114,
					h: 114,
					src: '0029.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img13.setProperty(hmUI.prop.VISIBLE, false);

				normal_img14 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 138,
					y: 119,
					w: 201,
					h: 201,
					src: '0030.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img14.setProperty(hmUI.prop.VISIBLE, false);

				normal_img15 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -1,
					y: -1,
					w: 483,
					h: 483,
					src: '0031.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img15.setProperty(hmUI.prop.VISIBLE, false);

				normal_img16 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -2,
					y: 188,
					w: 37,
					h: 37,
					src: '0032.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img16.setProperty(hmUI.prop.VISIBLE, false);

				normal_img17 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 183,
					y: 445,
					w: 33,
					h: 33,
					src: '0033.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img17.setProperty(hmUI.prop.VISIBLE, false);

				normal_img18 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 266,
					y: -1,
					w: 36,
					h: 36,
					src: '0034.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img18.setProperty(hmUI.prop.VISIBLE, false);

				normal_img19 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 445,
					y: 257,
					w: 36,
					h: 36,
					src: '0035.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img19.setProperty(hmUI.prop.VISIBLE, false);

				normal_img20 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 221,
					y: 260,
					w: 38,
					h: 38,
					src: '0036.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img20.setProperty(hmUI.prop.VISIBLE, false);

				normal_img22 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0037.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img22.setProperty(hmUI.prop.VISIBLE, false);

				normal_hour_imagecombo23 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 85,
					hour_startY: 306,
					hour_array: ["0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo23.setProperty(hmUI.prop.VISIBLE, false);

				normal_minute_imagecombo24 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 197,
					minute_startY: 306,
					minute_array: ["0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo24.setProperty(hmUI.prop.VISIBLE, false);

				normal_second_imagecombo25 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 309,
					second_startY: 306,
					second_array: ["0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo25.setProperty(hmUI.prop.VISIBLE, false);

				normal_img26 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 177,
					y: 305,
					w: 14,
					h: 88,
					src: '0058.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img26.setProperty(hmUI.prop.VISIBLE, false);

				normal_img27 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 289,
					y: 305,
					w: 14,
					h: 88,
					src: '0058.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img27.setProperty(hmUI.prop.VISIBLE, false);

				normal_img28 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -2,
					y: -1,
					w: 484,
					h: 483,
					src: '0059.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img28.setProperty(hmUI.prop.VISIBLE, false);

				normal_img29 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 221,
					y: 260,
					w: 38,
					h: 38,
					src: '0060.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img29.setProperty(hmUI.prop.VISIBLE, false);

				normal_img31 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0061.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img31.setProperty(hmUI.prop.VISIBLE, false);

				normal_hour_imagecombo32 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 85,
					hour_startY: 306,
					hour_array: ["0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo32.setProperty(hmUI.prop.VISIBLE, false);

				normal_minute_imagecombo33 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 197,
					minute_startY: 306,
					minute_array: ["0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo33.setProperty(hmUI.prop.VISIBLE, false);

				normal_second_imagecombo34 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 309,
					second_startY: 306,
					second_array: ["0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo34.setProperty(hmUI.prop.VISIBLE, false);

				normal_img35 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 177,
					y: 305,
					w: 14,
					h: 88,
					src: '0082.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img35.setProperty(hmUI.prop.VISIBLE, false);

				normal_img36 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 289,
					y: 305,
					w: 14,
					h: 88,
					src: '0082.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img36.setProperty(hmUI.prop.VISIBLE, false);

				normal_img37 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -2,
					y: -1,
					w: 484,
					h: 483,
					src: '0083.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img37.setProperty(hmUI.prop.VISIBLE, false);

				normal_img38 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 221,
					y: 260,
					w: 38,
					h: 38,
					src: '0084.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img38.setProperty(hmUI.prop.VISIBLE, false);

				normal_img40 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0085.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img40.setProperty(hmUI.prop.VISIBLE, false);

				normal_hour_imagecombo41 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 85,
					hour_startY: 306,
					hour_array: ["0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo41.setProperty(hmUI.prop.VISIBLE, false);

				normal_minute_imagecombo42 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 197,
					minute_startY: 306,
					minute_array: ["0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo42.setProperty(hmUI.prop.VISIBLE, false);

				normal_second_imagecombo43 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 309,
					second_startY: 306,
					second_array: ["0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo43.setProperty(hmUI.prop.VISIBLE, false);

				normal_img44 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 177,
					y: 305,
					w: 14,
					h: 88,
					src: '0106.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img44.setProperty(hmUI.prop.VISIBLE, false);

				normal_img45 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 289,
					y: 305,
					w: 14,
					h: 88,
					src: '0106.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img45.setProperty(hmUI.prop.VISIBLE, false);

				normal_img46 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -2,
					y: -1,
					w: 484,
					h: 483,
					src: '0107.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img46.setProperty(hmUI.prop.VISIBLE, false);

				normal_img47 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 221,
					y: 260,
					w: 38,
					h: 38,
					src: '0108.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img47.setProperty(hmUI.prop.VISIBLE, false);

				normal_img49 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0109.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img49.setProperty(hmUI.prop.VISIBLE, false);

				normal_hour_imagecombo50 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 85,
					hour_startY: 306,
					hour_array: ["0110.png","0111.png","0112.png","0113.png","0114.png","0115.png","0116.png","0117.png","0118.png","0119.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo50.setProperty(hmUI.prop.VISIBLE, false);

				normal_minute_imagecombo51 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 197,
					minute_startY: 306,
					minute_array: ["0110.png","0111.png","0112.png","0113.png","0114.png","0115.png","0116.png","0117.png","0118.png","0119.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo51.setProperty(hmUI.prop.VISIBLE, false);

				normal_second_imagecombo52 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 309,
					second_startY: 306,
					second_array: ["0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png","0129.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo52.setProperty(hmUI.prop.VISIBLE, false);

				normal_img53 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 177,
					y: 305,
					w: 14,
					h: 88,
					src: '0130.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img53.setProperty(hmUI.prop.VISIBLE, false);

				normal_img54 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 289,
					y: 305,
					w: 14,
					h: 88,
					src: '0130.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img54.setProperty(hmUI.prop.VISIBLE, false);

				normal_img55 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -2,
					y: -1,
					w: 484,
					h: 483,
					src: '0131.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img55.setProperty(hmUI.prop.VISIBLE, false);

				normal_img56 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 221,
					y: 260,
					w: 38,
					h: 38,
					src: '0132.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img56.setProperty(hmUI.prop.VISIBLE, false);

				normal_img58 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0133.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img58.setProperty(hmUI.prop.VISIBLE, false);

				normal_hour_imagecombo59 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 85,
					hour_startY: 306,
					hour_array: ["0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo59.setProperty(hmUI.prop.VISIBLE, false);

				normal_minute_imagecombo60 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 197,
					minute_startY: 306,
					minute_array: ["0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo60.setProperty(hmUI.prop.VISIBLE, false);

				normal_second_imagecombo61 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 309,
					second_startY: 306,
					second_array: ["0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png","0153.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo61.setProperty(hmUI.prop.VISIBLE, false);

				normal_img62 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 177,
					y: 305,
					w: 14,
					h: 88,
					src: '0154.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img62.setProperty(hmUI.prop.VISIBLE, false);

				normal_img63 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 289,
					y: 305,
					w: 14,
					h: 88,
					src: '0154.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img63.setProperty(hmUI.prop.VISIBLE, false);

				normal_img64 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -2,
					y: -1,
					w: 484,
					h: 483,
					src: '0155.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img64.setProperty(hmUI.prop.VISIBLE, false);

				normal_img65 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 221,
					y: 260,
					w: 38,
					h: 38,
					src: '0156.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img65.setProperty(hmUI.prop.VISIBLE, false);

				normal_img67 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0157.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img67.setProperty(hmUI.prop.VISIBLE, false);

				normal_img68 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 177,
					y: 305,
					w: 14,
					h: 88,
					src: '0158.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img68.setProperty(hmUI.prop.VISIBLE, false);

				normal_img69 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 289,
					y: 305,
					w: 14,
					h: 88,
					src: '0158.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img69.setProperty(hmUI.prop.VISIBLE, false);

				normal_img70 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -2,
					y: -1,
					w: 484,
					h: 483,
					src: '0159.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img70.setProperty(hmUI.prop.VISIBLE, false);

				normal_hour_imagecombo71 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 85,
					hour_startY: 306,
					hour_array: ["0160.png","0161.png","0162.png","0163.png","0164.png","0165.png","0166.png","0167.png","0168.png","0169.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo71.setProperty(hmUI.prop.VISIBLE, false);

				normal_minute_imagecombo72 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 197,
					minute_startY: 306,
					minute_array: ["0160.png","0161.png","0162.png","0163.png","0164.png","0165.png","0166.png","0167.png","0168.png","0169.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo72.setProperty(hmUI.prop.VISIBLE, false);

				normal_second_imagecombo73 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 309,
					second_startY: 306,
					second_array: ["0170.png","0171.png","0172.png","0173.png","0174.png","0175.png","0176.png","0177.png","0178.png","0179.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo73.setProperty(hmUI.prop.VISIBLE, false);

				normal_img74 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 221,
					y: 260,
					w: 38,
					h: 38,
					src: '0180.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img74.setProperty(hmUI.prop.VISIBLE, false);

				normal_img76 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0181.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img76.setProperty(hmUI.prop.VISIBLE, false);

				normal_img77 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 177,
					y: 305,
					w: 14,
					h: 88,
					src: '0182.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img77.setProperty(hmUI.prop.VISIBLE, false);

				normal_img78 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 289,
					y: 305,
					w: 14,
					h: 88,
					src: '0182.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img78.setProperty(hmUI.prop.VISIBLE, false);

				normal_img79 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -2,
					y: -1,
					w: 484,
					h: 483,
					src: '0183.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img79.setProperty(hmUI.prop.VISIBLE, false);

				normal_hour_imagecombo80 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 85,
					hour_startY: 306,
					hour_array: ["0184.png","0185.png","0186.png","0187.png","0188.png","0189.png","0190.png","0191.png","0192.png","0193.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo80.setProperty(hmUI.prop.VISIBLE, false);

				normal_minute_imagecombo81 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 197,
					minute_startY: 306,
					minute_array: ["0184.png","0185.png","0186.png","0187.png","0188.png","0189.png","0190.png","0191.png","0192.png","0193.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo81.setProperty(hmUI.prop.VISIBLE, false);

				normal_second_imagecombo82 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 309,
					second_startY: 306,
					second_array: ["0194.png","0195.png","0196.png","0197.png","0198.png","0199.png","0200.png","0201.png","0202.png","0203.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo82.setProperty(hmUI.prop.VISIBLE, false);

				normal_img83 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 221,
					y: 260,
					w: 38,
					h: 38,
					src: '0204.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img83.setProperty(hmUI.prop.VISIBLE, false);

				normal_img85 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0205.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img85.setProperty(hmUI.prop.VISIBLE, false);

				normal_hour_imagecombo86 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 85,
					hour_startY: 306,
					hour_array: ["0206.png","0207.png","0208.png","0209.png","0210.png","0211.png","0212.png","0213.png","0214.png","0215.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo86.setProperty(hmUI.prop.VISIBLE, false);

				normal_minute_imagecombo87 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 197,
					minute_startY: 306,
					minute_array: ["0206.png","0207.png","0208.png","0209.png","0210.png","0211.png","0212.png","0213.png","0214.png","0215.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo87.setProperty(hmUI.prop.VISIBLE, false);

				normal_second_imagecombo88 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 309,
					second_startY: 306,
					second_array: ["0216.png","0217.png","0218.png","0219.png","0220.png","0221.png","0222.png","0223.png","0224.png","0225.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo88.setProperty(hmUI.prop.VISIBLE, false);

				normal_img89 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 177,
					y: 305,
					w: 14,
					h: 88,
					src: '0226.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img89.setProperty(hmUI.prop.VISIBLE, false);

				normal_img90 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 289,
					y: 305,
					w: 14,
					h: 88,
					src: '0226.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img90.setProperty(hmUI.prop.VISIBLE, false);

				normal_img91 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -2,
					y: -1,
					w: 484,
					h: 483,
					src: '0227.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img91.setProperty(hmUI.prop.VISIBLE, false);

				normal_img92 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 221,
					y: 260,
					w: 38,
					h: 38,
					src: '0228.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img92.setProperty(hmUI.prop.VISIBLE, false);

				normal_img94 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0229.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img94.setProperty(hmUI.prop.VISIBLE, false);

				normal_hour_imagecombo95 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 85,
					hour_startY: 306,
					hour_array: ["0230.png","0231.png","0232.png","0233.png","0234.png","0235.png","0236.png","0237.png","0238.png","0239.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo95.setProperty(hmUI.prop.VISIBLE, false);

				normal_minute_imagecombo96 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 197,
					minute_startY: 306,
					minute_array: ["0230.png","0231.png","0232.png","0233.png","0234.png","0235.png","0236.png","0237.png","0238.png","0239.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo96.setProperty(hmUI.prop.VISIBLE, false);

				normal_second_imagecombo97 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 309,
					second_startY: 306,
					second_array: ["0240.png","0241.png","0242.png","0243.png","0244.png","0245.png","0246.png","0247.png","0248.png","0249.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo97.setProperty(hmUI.prop.VISIBLE, false);

				normal_img98 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 177,
					y: 305,
					w: 14,
					h: 88,
					src: '0250.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img98.setProperty(hmUI.prop.VISIBLE, false);

				normal_img99 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 289,
					y: 305,
					w: 14,
					h: 88,
					src: '0250.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img99.setProperty(hmUI.prop.VISIBLE, false);

				normal_img100 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -2,
					y: -1,
					w: 484,
					h: 483,
					src: '0251.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img100.setProperty(hmUI.prop.VISIBLE, false);

				normal_img101 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 221,
					y: 260,
					w: 38,
					h: 38,
					src: '0252.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img101.setProperty(hmUI.prop.VISIBLE, false);

				normal_img103 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0253.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img103.setProperty(hmUI.prop.VISIBLE, false);

				normal_hour_imagecombo104 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 85,
					hour_startY: 306,
					hour_array: ["0254.png","0255.png","0256.png","0257.png","0258.png","0259.png","0260.png","0261.png","0262.png","0263.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo104.setProperty(hmUI.prop.VISIBLE, false);

				normal_minute_imagecombo105 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 197,
					minute_startY: 306,
					minute_array: ["0254.png","0255.png","0256.png","0257.png","0258.png","0259.png","0260.png","0261.png","0262.png","0263.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo105.setProperty(hmUI.prop.VISIBLE, false);

				normal_second_imagecombo106 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 309,
					second_startY: 306,
					second_array: ["0264.png","0265.png","0266.png","0267.png","0268.png","0269.png","0270.png","0271.png","0272.png","0273.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo106.setProperty(hmUI.prop.VISIBLE, false);

				normal_img107 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 177,
					y: 305,
					w: 14,
					h: 88,
					src: '0274.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img107.setProperty(hmUI.prop.VISIBLE, false);

				normal_img108 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 289,
					y: 305,
					w: 14,
					h: 88,
					src: '0274.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img108.setProperty(hmUI.prop.VISIBLE, false);

				normal_img109 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -2,
					y: -1,
					w: 484,
					h: 483,
					src: '0275.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img109.setProperty(hmUI.prop.VISIBLE, false);

				normal_img110 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 221,
					y: 260,
					w: 38,
					h: 38,
					src: '0276.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img110.setProperty(hmUI.prop.VISIBLE, false);

				normal_img112 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0277.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img112.setProperty(hmUI.prop.VISIBLE, false);

				normal_hour_imagecombo113 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 85,
					hour_startY: 306,
					hour_array: ["0278.png","0279.png","0280.png","0281.png","0282.png","0283.png","0284.png","0285.png","0286.png","0287.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo113.setProperty(hmUI.prop.VISIBLE, false);

				normal_minute_imagecombo114 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 197,
					minute_startY: 306,
					minute_array: ["0278.png","0279.png","0280.png","0281.png","0282.png","0283.png","0284.png","0285.png","0286.png","0287.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo114.setProperty(hmUI.prop.VISIBLE, false);

				normal_second_imagecombo115 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 309,
					second_startY: 306,
					second_array: ["0288.png","0289.png","0290.png","0291.png","0292.png","0293.png","0294.png","0295.png","0296.png","0297.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo115.setProperty(hmUI.prop.VISIBLE, false);

				normal_img116 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 177,
					y: 305,
					w: 14,
					h: 88,
					src: '0298.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img116.setProperty(hmUI.prop.VISIBLE, false);

				normal_img117 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 289,
					y: 305,
					w: 14,
					h: 88,
					src: '0298.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img117.setProperty(hmUI.prop.VISIBLE, false);

				normal_img118 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -2,
					y: -1,
					w: 484,
					h: 483,
					src: '0299.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img118.setProperty(hmUI.prop.VISIBLE, false);

				normal_img119 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 221,
					y: 260,
					w: 38,
					h: 38,
					src: '0300.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img119.setProperty(hmUI.prop.VISIBLE, false);

				normal_img121 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0301.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img121.setProperty(hmUI.prop.VISIBLE, false);

				normal_hour_imagecombo122 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 85,
					hour_startY: 306,
					hour_array: ["0302.png","0303.png","0304.png","0305.png","0306.png","0307.png","0308.png","0309.png","0310.png","0311.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo122.setProperty(hmUI.prop.VISIBLE, false);

				normal_minute_imagecombo123 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 197,
					minute_startY: 306,
					minute_array: ["0302.png","0303.png","0304.png","0305.png","0306.png","0307.png","0308.png","0309.png","0310.png","0311.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo123.setProperty(hmUI.prop.VISIBLE, false);

				normal_second_imagecombo124 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 309,
					second_startY: 306,
					second_array: ["0312.png","0313.png","0314.png","0315.png","0316.png","0317.png","0318.png","0319.png","0320.png","0321.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo124.setProperty(hmUI.prop.VISIBLE, false);

				normal_img125 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 177,
					y: 305,
					w: 14,
					h: 88,
					src: '0322.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img125.setProperty(hmUI.prop.VISIBLE, false);

				normal_img126 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 289,
					y: 305,
					w: 14,
					h: 88,
					src: '0322.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img126.setProperty(hmUI.prop.VISIBLE, false);

				normal_img127 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -2,
					y: -1,
					w: 484,
					h: 483,
					src: '0323.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img127.setProperty(hmUI.prop.VISIBLE, false);

				normal_img128 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 221,
					y: 260,
					w: 38,
					h: 38,
					src: '0324.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img128.setProperty(hmUI.prop.VISIBLE, false);

				normal_img130 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0325.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img130.setProperty(hmUI.prop.VISIBLE, false);

				normal_hour_imagecombo131 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 85,
					hour_startY: 306,
					hour_array: ["0326.png","0327.png","0328.png","0329.png","0330.png","0331.png","0332.png","0333.png","0334.png","0335.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo131.setProperty(hmUI.prop.VISIBLE, false);

				normal_minute_imagecombo132 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 197,
					minute_startY: 306,
					minute_array: ["0326.png","0327.png","0328.png","0329.png","0330.png","0331.png","0332.png","0333.png","0334.png","0335.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo132.setProperty(hmUI.prop.VISIBLE, false);

				normal_second_imagecombo133 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 309,
					second_startY: 306,
					second_array: ["0336.png","0337.png","0338.png","0339.png","0340.png","0341.png","0342.png","0343.png","0344.png","0345.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo133.setProperty(hmUI.prop.VISIBLE, false);

				normal_img134 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 177,
					y: 305,
					w: 14,
					h: 88,
					src: '0346.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img134.setProperty(hmUI.prop.VISIBLE, false);

				normal_img135 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 289,
					y: 305,
					w: 14,
					h: 88,
					src: '0346.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img135.setProperty(hmUI.prop.VISIBLE, false);

				normal_img136 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -2,
					y: -1,
					w: 484,
					h: 483,
					src: '0347.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img136.setProperty(hmUI.prop.VISIBLE, false);

				normal_img137 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 221,
					y: 260,
					w: 38,
					h: 38,
					src: '0348.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img137.setProperty(hmUI.prop.VISIBLE, false);

				normal_img139 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0349.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img139.setProperty(hmUI.prop.VISIBLE, false);

				normal_hour_imagecombo140 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 85,
					hour_startY: 306,
					hour_array: ["0350.png","0351.png","0352.png","0353.png","0354.png","0355.png","0356.png","0357.png","0358.png","0359.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo140.setProperty(hmUI.prop.VISIBLE, false);

				normal_minute_imagecombo141 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 197,
					minute_startY: 306,
					minute_array: ["0350.png","0351.png","0352.png","0353.png","0354.png","0355.png","0356.png","0357.png","0358.png","0359.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo141.setProperty(hmUI.prop.VISIBLE, false);

				normal_second_imagecombo142 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 309,
					second_startY: 306,
					second_array: ["0360.png","0361.png","0362.png","0363.png","0364.png","0365.png","0366.png","0367.png","0368.png","0369.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo142.setProperty(hmUI.prop.VISIBLE, false);

				normal_img143 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 177,
					y: 305,
					w: 14,
					h: 88,
					src: '0370.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img143.setProperty(hmUI.prop.VISIBLE, false);

				normal_img144 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 289,
					y: 305,
					w: 14,
					h: 88,
					src: '0370.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img144.setProperty(hmUI.prop.VISIBLE, false);

				normal_img145 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -2,
					y: -1,
					w: 484,
					h: 483,
					src: '0371.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img145.setProperty(hmUI.prop.VISIBLE, false);

				normal_img146 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 221,
					y: 260,
					w: 38,
					h: 38,
					src: '0372.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img146.setProperty(hmUI.prop.VISIBLE, false);

				normal_img148 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0373.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img148.setProperty(hmUI.prop.VISIBLE, false);

				normal_hour_imagecombo149 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 85,
					hour_startY: 306,
					hour_array: ["0374.png","0375.png","0376.png","0377.png","0378.png","0379.png","0380.png","0381.png","0382.png","0383.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo149.setProperty(hmUI.prop.VISIBLE, false);

				normal_minute_imagecombo150 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 197,
					minute_startY: 306,
					minute_array: ["0374.png","0375.png","0376.png","0377.png","0378.png","0379.png","0380.png","0381.png","0382.png","0383.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo150.setProperty(hmUI.prop.VISIBLE, false);

				normal_second_imagecombo151 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 309,
					second_startY: 306,
					second_array: ["0384.png","0385.png","0386.png","0387.png","0388.png","0389.png","0390.png","0391.png","0392.png","0393.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo151.setProperty(hmUI.prop.VISIBLE, false);

				normal_img152 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 177,
					y: 305,
					w: 14,
					h: 88,
					src: '0394.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img152.setProperty(hmUI.prop.VISIBLE, false);

				normal_img153 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 289,
					y: 305,
					w: 14,
					h: 88,
					src: '0394.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img153.setProperty(hmUI.prop.VISIBLE, false);

				normal_img154 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -2,
					y: -1,
					w: 484,
					h: 483,
					src: '0395.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img154.setProperty(hmUI.prop.VISIBLE, false);

				normal_img155 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 221,
					y: 260,
					w: 38,
					h: 38,
					src: '0396.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img155.setProperty(hmUI.prop.VISIBLE, false);

				normal_img157 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0397.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo158 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 85,
					hour_startY: 306,
					hour_array: ["0398.png","0399.png","0400.png","0401.png","0402.png","0403.png","0404.png","0405.png","0406.png","0407.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo159 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 197,
					minute_startY: 306,
					minute_array: ["0398.png","0399.png","0400.png","0401.png","0402.png","0403.png","0404.png","0405.png","0406.png","0407.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo160 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 309,
					second_startY: 306,
					second_array: ["0408.png","0409.png","0410.png","0411.png","0412.png","0413.png","0414.png","0415.png","0416.png","0417.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img161 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 177,
					y: 305,
					w: 14,
					h: 88,
					src: '0418.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img162 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 289,
					y: 305,
					w: 14,
					h: 88,
					src: '0418.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img163 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -2,
					y: -1,
					w: 484,
					h: 483,
					src: '0419.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img164 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 221,
					y: 260,
					w: 38,
					h: 38,
					src: '0420.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img166 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0421.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img166.setProperty(hmUI.prop.VISIBLE, false);

				normal_hour_imagecombo167 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 85,
					hour_startY: 306,
					hour_array: ["0422.png","0423.png","0424.png","0425.png","0426.png","0427.png","0428.png","0429.png","0430.png","0431.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo167.setProperty(hmUI.prop.VISIBLE, false);

				normal_minute_imagecombo168 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 197,
					minute_startY: 306,
					minute_array: ["0422.png","0423.png","0424.png","0425.png","0426.png","0427.png","0428.png","0429.png","0430.png","0431.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo168.setProperty(hmUI.prop.VISIBLE, false);

				normal_second_imagecombo169 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 309,
					second_startY: 306,
					second_array: ["0432.png","0433.png","0434.png","0435.png","0436.png","0437.png","0438.png","0439.png","0440.png","0441.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo169.setProperty(hmUI.prop.VISIBLE, false);

				normal_img170 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 177,
					y: 305,
					w: 14,
					h: 88,
					src: '0442.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img170.setProperty(hmUI.prop.VISIBLE, false);

				normal_img171 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 289,
					y: 305,
					w: 14,
					h: 88,
					src: '0442.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img171.setProperty(hmUI.prop.VISIBLE, false);

				normal_img172 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -2,
					y: -1,
					w: 484,
					h: 483,
					src: '0443.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img172.setProperty(hmUI.prop.VISIBLE, false);

				normal_img173 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 221,
					y: 260,
					w: 38,
					h: 38,
					src: '0444.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img173.setProperty(hmUI.prop.VISIBLE, false);

				normal_img175 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0445.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img175.setProperty(hmUI.prop.VISIBLE, false);

				normal_hour_imagecombo176 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 85,
					hour_startY: 306,
					hour_array: ["0446.png","0447.png","0448.png","0449.png","0450.png","0451.png","0452.png","0453.png","0454.png","0455.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo176.setProperty(hmUI.prop.VISIBLE, false);

				normal_minute_imagecombo177 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 197,
					minute_startY: 306,
					minute_array: ["0446.png","0447.png","0448.png","0449.png","0450.png","0451.png","0452.png","0453.png","0454.png","0455.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo177.setProperty(hmUI.prop.VISIBLE, false);

				normal_second_imagecombo178 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 309,
					second_startY: 306,
					second_array: ["0456.png","0457.png","0458.png","0459.png","0460.png","0461.png","0462.png","0463.png","0464.png","0465.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo178.setProperty(hmUI.prop.VISIBLE, false);

				normal_img179 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 177,
					y: 305,
					w: 14,
					h: 88,
					src: '0466.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img179.setProperty(hmUI.prop.VISIBLE, false);

				normal_img180 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 289,
					y: 305,
					w: 14,
					h: 88,
					src: '0466.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img180.setProperty(hmUI.prop.VISIBLE, false);

				normal_img181 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -2,
					y: -1,
					w: 484,
					h: 483,
					src: '0467.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img181.setProperty(hmUI.prop.VISIBLE, false);

				normal_img182 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 221,
					y: 260,
					w: 38,
					h: 38,
					src: '0468.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img182.setProperty(hmUI.prop.VISIBLE, false);

				normal_img184 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0469.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img184.setProperty(hmUI.prop.VISIBLE, false);

				normal_hour_imagecombo185 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 85,
					hour_startY: 306,
					hour_array: ["0470.png","0471.png","0472.png","0473.png","0474.png","0475.png","0476.png","0477.png","0478.png","0479.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo185.setProperty(hmUI.prop.VISIBLE, false);

				normal_minute_imagecombo186 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 197,
					minute_startY: 306,
					minute_array: ["0470.png","0471.png","0472.png","0473.png","0474.png","0475.png","0476.png","0477.png","0478.png","0479.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo186.setProperty(hmUI.prop.VISIBLE, false);

				normal_second_imagecombo187 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 309,
					second_startY: 306,
					second_array: ["0480.png","0481.png","0482.png","0483.png","0484.png","0485.png","0486.png","0487.png","0488.png","0489.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo187.setProperty(hmUI.prop.VISIBLE, false);

				normal_img188 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 177,
					y: 305,
					w: 14,
					h: 88,
					src: '0490.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img188.setProperty(hmUI.prop.VISIBLE, false);

				normal_img189 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 289,
					y: 305,
					w: 14,
					h: 88,
					src: '0490.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img189.setProperty(hmUI.prop.VISIBLE, false);

				normal_img190 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -2,
					y: -1,
					w: 484,
					h: 483,
					src: '0491.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img190.setProperty(hmUI.prop.VISIBLE, false);

				normal_img191 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 221,
					y: 260,
					w: 38,
					h: 38,
					src: '0492.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img191.setProperty(hmUI.prop.VISIBLE, false);

				normal_img193 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0493.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img193.setProperty(hmUI.prop.VISIBLE, false);

				normal_hour_imagecombo194 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 85,
					hour_startY: 306,
					hour_array: ["0494.png","0495.png","0496.png","0497.png","0498.png","0499.png","0500.png","0501.png","0502.png","0503.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo194.setProperty(hmUI.prop.VISIBLE, false);

				normal_minute_imagecombo195 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 197,
					minute_startY: 306,
					minute_array: ["0494.png","0495.png","0496.png","0497.png","0498.png","0499.png","0500.png","0501.png","0502.png","0503.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo195.setProperty(hmUI.prop.VISIBLE, false);

				normal_second_imagecombo196 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 309,
					second_startY: 306,
					second_array: ["0504.png","0505.png","0506.png","0507.png","0508.png","0509.png","0510.png","0511.png","0512.png","0513.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo196.setProperty(hmUI.prop.VISIBLE, false);

				normal_img197 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 177,
					y: 305,
					w: 14,
					h: 88,
					src: '0514.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img197.setProperty(hmUI.prop.VISIBLE, false);

				normal_img198 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 289,
					y: 305,
					w: 14,
					h: 88,
					src: '0514.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img198.setProperty(hmUI.prop.VISIBLE, false);

				normal_img199 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -2,
					y: -1,
					w: 484,
					h: 483,
					src: '0515.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img199.setProperty(hmUI.prop.VISIBLE, false);

				normal_img200 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 221,
					y: 260,
					w: 38,
					h: 38,
					src: '0516.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img200.setProperty(hmUI.prop.VISIBLE, false);

				normal_img202 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0517.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img202.setProperty(hmUI.prop.VISIBLE, false);

				normal_hour_imagecombo203 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 85,
					hour_startY: 306,
					hour_array: ["0518.png","0519.png","0520.png","0521.png","0522.png","0523.png","0524.png","0525.png","0526.png","0527.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo203.setProperty(hmUI.prop.VISIBLE, false);

				normal_minute_imagecombo204 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 197,
					minute_startY: 306,
					minute_array: ["0518.png","0519.png","0520.png","0521.png","0522.png","0523.png","0524.png","0525.png","0526.png","0527.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo204.setProperty(hmUI.prop.VISIBLE, false);

				normal_second_imagecombo205 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 309,
					second_startY: 306,
					second_array: ["0528.png","0529.png","0530.png","0531.png","0532.png","0533.png","0534.png","0535.png","0536.png","0537.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo205.setProperty(hmUI.prop.VISIBLE, false);

				normal_img206 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 177,
					y: 305,
					w: 14,
					h: 88,
					src: '0538.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img206.setProperty(hmUI.prop.VISIBLE, false);

				normal_img207 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 289,
					y: 305,
					w: 14,
					h: 88,
					src: '0538.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img207.setProperty(hmUI.prop.VISIBLE, false);

				normal_img208 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -2,
					y: -1,
					w: 484,
					h: 483,
					src: '0539.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img208.setProperty(hmUI.prop.VISIBLE, false);

				normal_img209 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 221,
					y: 260,
					w: 38,
					h: 38,
					src: '0540.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img209.setProperty(hmUI.prop.VISIBLE, false);

				normal_img211 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0541.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img211.setProperty(hmUI.prop.VISIBLE, false);

				normal_hour_imagecombo212 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 85,
					hour_startY: 306,
					hour_array: ["0542.png","0543.png","0544.png","0545.png","0546.png","0547.png","0548.png","0549.png","0550.png","0551.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo212.setProperty(hmUI.prop.VISIBLE, false);

				normal_minute_imagecombo213 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 197,
					minute_startY: 306,
					minute_array: ["0542.png","0543.png","0544.png","0545.png","0546.png","0547.png","0548.png","0549.png","0550.png","0551.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo213.setProperty(hmUI.prop.VISIBLE, false);

				normal_second_imagecombo214 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 309,
					second_startY: 306,
					second_array: ["0552.png","0553.png","0554.png","0555.png","0556.png","0557.png","0558.png","0559.png","0560.png","0561.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo214.setProperty(hmUI.prop.VISIBLE, false);

				normal_img215 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 177,
					y: 305,
					w: 14,
					h: 88,
					src: '0562.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img215.setProperty(hmUI.prop.VISIBLE, false);

				normal_img216 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 289,
					y: 305,
					w: 14,
					h: 88,
					src: '0562.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img216.setProperty(hmUI.prop.VISIBLE, false);

				normal_img217 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -2,
					y: -1,
					w: 484,
					h: 483,
					src: '0563.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img217.setProperty(hmUI.prop.VISIBLE, false);

				normal_img218 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 221,
					y: 260,
					w: 38,
					h: 38,
					src: '0564.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img218.setProperty(hmUI.prop.VISIBLE, false);

				normal_img220 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0565.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img220.setProperty(hmUI.prop.VISIBLE, false);

				normal_hour_imagecombo221 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 85,
					hour_startY: 306,
					hour_array: ["0566.png","0567.png","0568.png","0569.png","0570.png","0571.png","0572.png","0573.png","0574.png","0575.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo221.setProperty(hmUI.prop.VISIBLE, false);

				normal_minute_imagecombo222 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 197,
					minute_startY: 306,
					minute_array: ["0566.png","0567.png","0568.png","0569.png","0570.png","0571.png","0572.png","0573.png","0574.png","0575.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo222.setProperty(hmUI.prop.VISIBLE, false);

				normal_second_imagecombo223 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 309,
					second_startY: 306,
					second_array: ["0576.png","0577.png","0578.png","0579.png","0580.png","0581.png","0582.png","0583.png","0584.png","0576.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo223.setProperty(hmUI.prop.VISIBLE, false);

				normal_img224 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 177,
					y: 305,
					w: 14,
					h: 88,
					src: '0585.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img224.setProperty(hmUI.prop.VISIBLE, false);

				normal_img225 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 289,
					y: 305,
					w: 14,
					h: 88,
					src: '0585.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img225.setProperty(hmUI.prop.VISIBLE, false);

				normal_img226 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -2,
					y: -1,
					w: 484,
					h: 483,
					src: '0586.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img226.setProperty(hmUI.prop.VISIBLE, false);

				normal_img227 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 221,
					y: 260,
					w: 38,
					h: 38,
					src: '0587.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img227.setProperty(hmUI.prop.VISIBLE, false);

				normal_img229 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0588.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img229.setProperty(hmUI.prop.VISIBLE, false);

				normal_hour_imagecombo230 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 85,
					hour_startY: 306,
					hour_array: ["0589.png","0590.png","0591.png","0592.png","0593.png","0594.png","0595.png","0596.png","0597.png","0598.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo230.setProperty(hmUI.prop.VISIBLE, false);

				normal_minute_imagecombo231 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 197,
					minute_startY: 306,
					minute_array: ["0589.png","0590.png","0591.png","0592.png","0593.png","0594.png","0595.png","0596.png","0597.png","0598.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo231.setProperty(hmUI.prop.VISIBLE, false);

				normal_second_imagecombo232 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 309,
					second_startY: 306,
					second_array: ["0599.png","0600.png","0601.png","0602.png","0603.png","0604.png","0605.png","0606.png","0607.png","0608.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo232.setProperty(hmUI.prop.VISIBLE, false);

				normal_img233 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 177,
					y: 305,
					w: 14,
					h: 88,
					src: '0609.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img233.setProperty(hmUI.prop.VISIBLE, false);

				normal_img234 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 289,
					y: 305,
					w: 14,
					h: 88,
					src: '0609.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img234.setProperty(hmUI.prop.VISIBLE, false);

				normal_img235 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -2,
					y: -1,
					w: 484,
					h: 483,
					src: '0610.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img235.setProperty(hmUI.prop.VISIBLE, false);

				normal_img236 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 221,
					y: 260,
					w: 38,
					h: 38,
					src: '0611.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img236.setProperty(hmUI.prop.VISIBLE, false);

				normal_img238 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0612.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img238.setProperty(hmUI.prop.VISIBLE, false);

				normal_img239 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 177,
					y: 305,
					w: 14,
					h: 88,
					src: '0028.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img239.setProperty(hmUI.prop.VISIBLE, false);

				normal_img240 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 289,
					y: 305,
					w: 14,
					h: 88,
					src: '0028.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img240.setProperty(hmUI.prop.VISIBLE, false);

				normal_second_imagecombo241 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 309,
					second_startY: 306,
					second_array: ["0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo241.setProperty(hmUI.prop.VISIBLE, false);

				normal_minute_imagecombo242 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 197,
					minute_startY: 306,
					minute_array: ["0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo242.setProperty(hmUI.prop.VISIBLE, false);

				normal_hour_imagecombo243 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 85,
					hour_startY: 306,
					hour_array: ["0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo243.setProperty(hmUI.prop.VISIBLE, false);

				normal_img244 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 177,
					y: 305,
					w: 14,
					h: 88,
					src: '0028.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img244.setProperty(hmUI.prop.VISIBLE, false);

				normal_img245 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 289,
					y: 305,
					w: 14,
					h: 88,
					src: '0028.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img245.setProperty(hmUI.prop.VISIBLE, false);

				normal_img246 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -2,
					y: -1,
					w: 484,
					h: 483,
					src: '0613.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img246.setProperty(hmUI.prop.VISIBLE, false);

				normal_img247 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 221,
					y: 260,
					w: 38,
					h: 38,
					src: '0036.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img247.setProperty(hmUI.prop.VISIBLE, false);

				normal_steps_imageset250 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 3,
					y: 4,
					image_array: ["0615.png","0616.png","0617.png","0618.png","0619.png","0620.png","0621.png","0622.png","0623.png","0624.png","0625.png","0626.png","0627.png","0628.png","0629.png","0630.png","0631.png","0632.png","0633.png","0634.png","0635.png","0636.png","0637.png","0638.png","0639.png","0640.png"],
					image_length: 26,
					type: hmUI.data_type.STEP,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_first_imageset251 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 300,
					y: 442,
					w: 304,
					h: 444,
					src: '0650.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_steps_second_imageset252 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 287,
					y: 447,
					w: 290,
					h: 449,
					src: '0660.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_steps_third_imageset253 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 273,
					y: 452,
					w: 275,
					h: 453,
					src: '0670.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_steps_fourth_imageset254 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 257,
					y: 455,
					w: 258,
					h: 455,
					src: '0680.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_img255 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 271,
					y: 454,
					w: 6,
					h: 25,
					src: '0681.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_fifth_imageset256 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 242,
					y: 456,
					w: 242,
					h: 456,
					src: '0691.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_calories_imageset258 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 0,
					y: 1,
					image_array: ["0692.png","0693.png","0694.png","0695.png","0696.png","0697.png","0698.png","0699.png","0700.png","0701.png","0702.png","0703.png","0704.png","0705.png","0706.png","0707.png","0708.png","0709.png","0710.png","0711.png","0712.png","0713.png","0714.png","0715.png","0716.png","0717.png"],
					image_length: 26,
					type: hmUI.data_type.CAL,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calories_fourth_imageset259 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -1,
					y: 258,
					w: 6,
					h: 254,
					src: '0727.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_calories_third_imageset260 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 274,
					w: 7,
					h: 271,
					src: '0737.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_calories_second_imageset261 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 3,
					y: 290,
					w: 10,
					h: 287,
					src: '0747.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_calories_first_imageset262 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 8,
					y: 305,
					w: 15,
					h: 303,
					src: '0757.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_battery_imageset264 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 2,
					y: 2,
					image_array: ["0758.png","0759.png","0760.png","0761.png","0762.png","0763.png","0764.png","0765.png","0766.png","0767.png","0768.png","0769.png","0770.png","0771.png","0772.png","0773.png","0774.png","0775.png","0776.png","0777.png","0778.png","0779.png","0780.png","0781.png","0782.png","0783.png"],
					image_length: 26,
					type: hmUI.data_type.BATTERY,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_third_imageset265 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 159,
					y: 11,
					w: 162,
					h: 13,
					src: '0784.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_battery_second_imageset266 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 174,
					y: 7,
					w: 177,
					h: 9,
					src: '0794.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_battery_first_imageset267 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 191,
					y: 4,
					w: 193,
					h: 5,
					src: '0804.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_img268 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 208,
					y: 0,
					w: 24,
					h: 28,
					src: '0805.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stress_imageset270 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 4,
					y: 3,
					image_array: ["0806.png","0807.png","0808.png","0809.png","0810.png","0811.png","0812.png","0813.png","0814.png","0815.png","0816.png","0817.png","0818.png","0819.png","0820.png","0821.png","0822.png","0823.png","0824.png","0825.png","0826.png","0827.png","0828.png","0829.png","0830.png","0831.png"],
					image_length: 26,
					type: hmUI.data_type.STRESS,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stress_first_imageset271 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 446,
					y: 191,
					w: 453,
					h: 188,
					src: '0737.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_stress_second_imageset272 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 442,
					y: 175,
					w: 449,
					h: 172,
					src: '0747.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_stress_third_imageset273 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 439,
					y: 158,
					w: 446,
					h: 156,
					src: '0833.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_heart_current_imagecombo275 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 203,
					y: 202,
					font_array: ["0834.png","0835.png","0836.png","0837.png","0838.png","0839.png","0840.png","0841.png","0842.png","0843.png"],
					padding: false,
					h_space: 0,
					invalid_image: '0844.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_distance_units_imageset277 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 370,
					y: 244,
					w: 370,
					h: 244,
					src: normal_distance_units_imageset277_array[hmSetting.getMileageUnit()],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_distance_units_imageset277.setProperty(hmUI.prop.VISIBLE, false);

				normal_distance_imagecombo278 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 345,
					y: 214,
					font_array: ["0847.png","0848.png","0849.png","0850.png","0851.png","0852.png","0853.png","0854.png","0855.png","0856.png"],
					padding: false,
					h_space: 0,
					dot_image: '0857.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.DISTANCE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_distance_imagecombo278.setProperty(hmUI.prop.VISIBLE, false);

				normal_img279 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 366,
					y: 177,
					w: 30,
					h: 30,
					src: '0858.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img279.setProperty(hmUI.prop.VISIBLE, false);

				normal_img281 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 366,
					y: 177,
					w: 30,
					h: 30,
					src: '0859.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img281.setProperty(hmUI.prop.VISIBLE, false);

				normal_blood_oxygen_imagecombo282 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 357,
					y: 214,
					font_array: ["0860.png","0861.png","0862.png","0863.png","0864.png","0865.png","0866.png","0867.png","0868.png","0869.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.SPO2,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_blood_oxygen_imagecombo282.setProperty(hmUI.prop.VISIBLE, false);

				normal_img284 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 361,
					y: 173,
					w: 40,
					h: 40,
					src: '0870.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img284.setProperty(hmUI.prop.VISIBLE, false);

				normal_vo2max_imagecombo285 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 365,
					y: 214,
					font_array: ["0871.png","0872.png","0873.png","0874.png","0875.png","0876.png","0877.png","0878.png","0879.png","0880.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.VO2MAX,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_vo2max_imagecombo285.setProperty(hmUI.prop.VISIBLE, false);

				normal_img287 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 361,
					y: 173,
					w: 40,
					h: 40,
					src: '0881.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img287.setProperty(hmUI.prop.VISIBLE, false);

				normal_img288 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 331,
					y: 212,
					w: 52,
					h: 26,
					src: '0882.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img288.setProperty(hmUI.prop.VISIBLE, false);

				normal_pai_imagecombo289 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 383,
					y: 212,
					font_array: ["0860.png","0861.png","0862.png","0863.png","0864.png","0865.png","0866.png","0867.png","0868.png","0869.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.PAI_DAILY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_pai_imagecombo289.setProperty(hmUI.prop.VISIBLE, false);

				normal_img290 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 339,
					y: 244,
					w: 48,
					h: 18,
					src: '0883.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img290.setProperty(hmUI.prop.VISIBLE, false);

				normal_pai_weekly_imagecombo291 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 388,
					y: 244,
					font_array: ["0884.png","0885.png","0886.png","0887.png","0888.png","0889.png","0890.png","0891.png","0892.png","0893.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.PAI_WEEKLY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_pai_weekly_imagecombo291.setProperty(hmUI.prop.VISIBLE, false);

				normal_img292 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 334,
					y: 241,
					w: 95,
					h: 1,
					src: '0894.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img292.setProperty(hmUI.prop.VISIBLE, false);

				normal_img294 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 361,
					y: 173,
					w: 40,
					h: 40,
					src: '0895.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img294.setProperty(hmUI.prop.VISIBLE, false);

				normal_sleep_hour_high_imageset295 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 351,
					y: 214,
					w: 351,
					h: 214,
					src: '0898.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sleep_hour_high_imageset295.setProperty(hmUI.prop.VISIBLE, false);

				normal_sleep_hour_low_imageset296 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 365,
					y: 214,
					w: 365,
					h: 214,
					src: '0905.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sleep_hour_low_imageset296.setProperty(hmUI.prop.VISIBLE, false);

				normal_sleep_minute_high_imageset297 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 384,
					y: 214,
					w: 384,
					h: 214,
					src: '0901.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sleep_minute_high_imageset297.setProperty(hmUI.prop.VISIBLE, false);

				normal_sleep_minute_low_imageset298 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 398,
					y: 214,
					w: 398,
					h: 214,
					src: '0905.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sleep_minute_low_imageset298.setProperty(hmUI.prop.VISIBLE, false);

				normal_img299 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 379,
					y: 212,
					w: 4,
					h: 26,
					src: '0906.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img299.setProperty(hmUI.prop.VISIBLE, false);

				normal_img301 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 361,
					y: 173,
					w: 40,
					h: 40,
					src: '0907.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img301.setProperty(hmUI.prop.VISIBLE, false);

				normal_stand_imagecombo302 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 350,
					y: 214,
					font_array: ["0860.png","0861.png","0862.png","0863.png","0864.png","0865.png","0866.png","0867.png","0868.png","0869.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STAND,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stand_imagecombo302.setProperty(hmUI.prop.VISIBLE, false);

				normal_img304 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 361,
					y: 173,
					w: 40,
					h: 40,
					src: '0908.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_airpressure_imagecombo305 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 349,
					y: 214,
					font_array: ["0847.png","0848.png","0849.png","0850.png","0851.png","0852.png","0853.png","0854.png","0855.png","0856.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.ALTIMETER,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img307 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 361,
					y: 173,
					w: 40,
					h: 40,
					src: '0909.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img307.setProperty(hmUI.prop.VISIBLE, false);

				normal_altitude_imagecombo308 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 350,
					y: 214,
					font_array: ["0910.png","0911.png","0912.png","0913.png","0914.png","0915.png","0916.png","0917.png","0918.png","0919.png"],
					padding: false,
					h_space: 0,
					negative_image: '0920.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.ALTITUDE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_altitude_imagecombo308.setProperty(hmUI.prop.VISIBLE, false);

				normal_img310 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 369,
					y: 173,
					w: 24,
					h: 31,
					src: '0921.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img310.setProperty(hmUI.prop.VISIBLE, false);

				normal_humidity_imagecombo311 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 357,
					y: 214,
					font_array: ["0860.png","0861.png","0862.png","0863.png","0864.png","0865.png","0866.png","0867.png","0868.png","0869.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.HUMIDITY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_humidity_imagecombo311.setProperty(hmUI.prop.VISIBLE, false);

				normal_img313 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 361,
					y: 171,
					w: 42,
					h: 40,
					src: '0922.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img313.setProperty(hmUI.prop.VISIBLE, false);

				normal_wind_bearing_imageset314 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 361,
					y: 242,
					image_array: ["0923.png","0924.png","0925.png","0926.png","0927.png","0928.png","0929.png","0930.png"],
					image_length: 8,
					type: hmUI.data_type.WIND_DIRECTION,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_wind_bearing_imageset314.setProperty(hmUI.prop.VISIBLE, false);

				normal_wind_imagecombo315 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 365,
					y: 214,
					font_array: ["0871.png","0872.png","0873.png","0874.png","0875.png","0876.png","0877.png","0878.png","0879.png","0880.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WIND,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_wind_imagecombo315.setProperty(hmUI.prop.VISIBLE, false);

				normal_img317 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 361,
					y: 173,
					w: 40,
					h: 40,
					src: '0932.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img317.setProperty(hmUI.prop.VISIBLE, false);

				normal_uvindex_imageset318 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 361,
					y: 214,
					image_array: ["0933.png","0934.png","0935.png","0936.png","0937.png","0938.png","0939.png","0940.png","0941.png","0942.png","0943.png"],
					image_length: 11,
					type: hmUI.data_type.UVI,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_uvindex_imageset318.setProperty(hmUI.prop.VISIBLE, false);

				normal_img319 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 363,
					y: 242,
					w: 35,
					h: 26,
					src: '0944.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img319.setProperty(hmUI.prop.VISIBLE, false);

				normal_img321 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 366,
					y: 167,
					w: 30,
					h: 30,
					src: '0945.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img321.setProperty(hmUI.prop.VISIBLE, false);

				normal_img322 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 366,
					y: 245,
					w: 30,
					h: 30,
					src: '0946.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img322.setProperty(hmUI.prop.VISIBLE, false);

				normal_sunrise_hours_high_imageset323 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 351,
					y: 195,
					w: 351,
					h: 195,
					src: '0898.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sunrise_hours_high_imageset323.setProperty(hmUI.prop.VISIBLE, false);

				normal_sunrise_hours_low_imageset324 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 365,
					y: 195,
					w: 365,
					h: 195,
					src: '0905.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sunrise_hours_low_imageset324.setProperty(hmUI.prop.VISIBLE, false);

				normal_sunrise_minutes_high_imageset325 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 384,
					y: 195,
					w: 384,
					h: 195,
					src: '0901.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sunrise_minutes_high_imageset325.setProperty(hmUI.prop.VISIBLE, false);

				normal_sunrise_minutes_low_imageset326 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 398,
					y: 195,
					w: 398,
					h: 195,
					src: '0905.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sunrise_minutes_low_imageset326.setProperty(hmUI.prop.VISIBLE, false);

				normal_img327 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 379,
					y: 195,
					w: 4,
					h: 26,
					src: '0906.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img327.setProperty(hmUI.prop.VISIBLE, false);

				normal_sunset_hours_high_imageset328 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 351,
					y: 222,
					w: 351,
					h: 222,
					src: '0898.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sunset_hours_high_imageset328.setProperty(hmUI.prop.VISIBLE, false);

				normal_sunset_hours_low_imageset329 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 365,
					y: 222,
					w: 365,
					h: 222,
					src: '0905.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sunset_hours_low_imageset329.setProperty(hmUI.prop.VISIBLE, false);

				normal_img330 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 379,
					y: 222,
					w: 4,
					h: 26,
					src: '0906.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img330.setProperty(hmUI.prop.VISIBLE, false);

				normal_sunset_minutes_high_imageset331 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 384,
					y: 222,
					w: 384,
					h: 222,
					src: '0901.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sunset_minutes_high_imageset331.setProperty(hmUI.prop.VISIBLE, false);

				normal_sunset_minutes_low_imageset332 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 398,
					y: 222,
					w: 398,
					h: 222,
					src: '0905.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sunset_minutes_low_imageset332.setProperty(hmUI.prop.VISIBLE, false);

				normal_img333 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 331,
					y: 221,
					w: 100,
					h: 1,
					src: '0947.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img333.setProperty(hmUI.prop.VISIBLE, false);

				normal_img335 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 356,
					y: 169,
					w: 48,
					h: 48,
					src: '0948.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img335.setProperty(hmUI.prop.VISIBLE, false);

				normal_biocharge_imagecombo336 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 357,
					y: 214,
					font_array: ["0949.png","0950.png","0951.png","0952.png","0953.png","0954.png","0955.png","0956.png","0957.png","0958.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.BIO_CHARGE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_biocharge_imagecombo336.setProperty(hmUI.prop.VISIBLE, false);

				normal_distance_units_imageset339 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 88,
					y: 244,
					w: 88,
					h: 244,
					src: normal_distance_units_imageset339_array[hmSetting.getMileageUnit()],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_distance_imagecombo340 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 63,
					y: 214,
					font_array: ["0847.png","0848.png","0849.png","0850.png","0851.png","0852.png","0853.png","0854.png","0855.png","0856.png"],
					padding: false,
					h_space: 0,
					dot_image: '0857.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.DISTANCE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img341 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 84,
					y: 177,
					w: 30,
					h: 30,
					src: '0858.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img343 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 84,
					y: 177,
					w: 30,
					h: 30,
					src: '0859.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img343.setProperty(hmUI.prop.VISIBLE, false);

				normal_blood_oxygen_imagecombo344 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 75,
					y: 214,
					font_array: ["0860.png","0861.png","0862.png","0863.png","0864.png","0865.png","0866.png","0867.png","0868.png","0869.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.SPO2,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_blood_oxygen_imagecombo344.setProperty(hmUI.prop.VISIBLE, false);

				normal_img346 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 79,
					y: 173,
					w: 40,
					h: 40,
					src: '0870.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img346.setProperty(hmUI.prop.VISIBLE, false);

				normal_vo2max_imagecombo347 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 83,
					y: 214,
					font_array: ["0871.png","0872.png","0873.png","0874.png","0875.png","0876.png","0877.png","0878.png","0879.png","0880.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.VO2MAX,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_vo2max_imagecombo347.setProperty(hmUI.prop.VISIBLE, false);

				normal_img349 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 79,
					y: 173,
					w: 40,
					h: 40,
					src: '0881.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img349.setProperty(hmUI.prop.VISIBLE, false);

				normal_img350 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 49,
					y: 212,
					w: 52,
					h: 26,
					src: '0882.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img350.setProperty(hmUI.prop.VISIBLE, false);

				normal_pai_imagecombo351 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 101,
					y: 212,
					font_array: ["0860.png","0861.png","0862.png","0863.png","0864.png","0865.png","0866.png","0867.png","0868.png","0869.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.PAI_DAILY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_pai_imagecombo351.setProperty(hmUI.prop.VISIBLE, false);

				normal_img352 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 57,
					y: 244,
					w: 48,
					h: 18,
					src: '0883.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img352.setProperty(hmUI.prop.VISIBLE, false);

				normal_pai_weekly_imagecombo353 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 106,
					y: 244,
					font_array: ["0884.png","0885.png","0886.png","0887.png","0888.png","0889.png","0890.png","0891.png","0892.png","0893.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.PAI_WEEKLY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_pai_weekly_imagecombo353.setProperty(hmUI.prop.VISIBLE, false);

				normal_img354 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 52,
					y: 241,
					w: 95,
					h: 1,
					src: '0894.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img354.setProperty(hmUI.prop.VISIBLE, false);

				normal_img356 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 79,
					y: 173,
					w: 40,
					h: 40,
					src: '0895.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img356.setProperty(hmUI.prop.VISIBLE, false);

				normal_sleep_hour_high_imageset357 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 69,
					y: 214,
					w: 69,
					h: 214,
					src: '0898.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sleep_hour_high_imageset357.setProperty(hmUI.prop.VISIBLE, false);

				normal_sleep_hour_low_imageset358 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 83,
					y: 214,
					w: 83,
					h: 214,
					src: '0905.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sleep_hour_low_imageset358.setProperty(hmUI.prop.VISIBLE, false);

				normal_sleep_minute_high_imageset359 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 102,
					y: 214,
					w: 102,
					h: 214,
					src: '0901.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sleep_minute_high_imageset359.setProperty(hmUI.prop.VISIBLE, false);

				normal_sleep_minute_low_imageset360 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 116,
					y: 214,
					w: 116,
					h: 214,
					src: '0905.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sleep_minute_low_imageset360.setProperty(hmUI.prop.VISIBLE, false);

				normal_img361 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 97,
					y: 212,
					w: 4,
					h: 26,
					src: '0906.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img361.setProperty(hmUI.prop.VISIBLE, false);

				normal_img363 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 79,
					y: 173,
					w: 40,
					h: 40,
					src: '0907.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img363.setProperty(hmUI.prop.VISIBLE, false);

				normal_stand_imagecombo364 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 68,
					y: 214,
					font_array: ["0860.png","0861.png","0862.png","0863.png","0864.png","0865.png","0866.png","0867.png","0868.png","0869.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STAND,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stand_imagecombo364.setProperty(hmUI.prop.VISIBLE, false);

				normal_img366 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 79,
					y: 173,
					w: 40,
					h: 40,
					src: '0908.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img366.setProperty(hmUI.prop.VISIBLE, false);

				normal_airpressure_imagecombo367 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 67,
					y: 214,
					font_array: ["0847.png","0848.png","0849.png","0850.png","0851.png","0852.png","0853.png","0854.png","0855.png","0856.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.ALTIMETER,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_airpressure_imagecombo367.setProperty(hmUI.prop.VISIBLE, false);

				normal_img369 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 79,
					y: 173,
					w: 40,
					h: 40,
					src: '0909.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img369.setProperty(hmUI.prop.VISIBLE, false);

				normal_altitude_imagecombo370 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 68,
					y: 214,
					font_array: ["0910.png","0911.png","0912.png","0913.png","0914.png","0915.png","0916.png","0917.png","0918.png","0919.png"],
					padding: false,
					h_space: 0,
					negative_image: '0920.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.ALTITUDE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_altitude_imagecombo370.setProperty(hmUI.prop.VISIBLE, false);

				normal_img372 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 87,
					y: 173,
					w: 24,
					h: 31,
					src: '0921.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img372.setProperty(hmUI.prop.VISIBLE, false);

				normal_humidity_imagecombo373 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 75,
					y: 214,
					font_array: ["0860.png","0861.png","0862.png","0863.png","0864.png","0865.png","0866.png","0867.png","0868.png","0869.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.HUMIDITY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_humidity_imagecombo373.setProperty(hmUI.prop.VISIBLE, false);

				normal_img375 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 79,
					y: 171,
					w: 42,
					h: 40,
					src: '0922.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img375.setProperty(hmUI.prop.VISIBLE, false);

				normal_wind_bearing_imageset376 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 79,
					y: 242,
					image_array: ["0923.png","0924.png","0925.png","0926.png","0927.png","0928.png","0929.png","0930.png"],
					image_length: 8,
					type: hmUI.data_type.WIND_DIRECTION,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_wind_bearing_imageset376.setProperty(hmUI.prop.VISIBLE, false);

				normal_wind_imagecombo377 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 83,
					y: 214,
					font_array: ["0871.png","0872.png","0873.png","0874.png","0875.png","0876.png","0877.png","0878.png","0879.png","0880.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WIND,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_wind_imagecombo377.setProperty(hmUI.prop.VISIBLE, false);

				normal_img379 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 84,
					y: 167,
					w: 30,
					h: 30,
					src: '0945.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img379.setProperty(hmUI.prop.VISIBLE, false);

				normal_img380 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 84,
					y: 245,
					w: 30,
					h: 30,
					src: '0946.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img380.setProperty(hmUI.prop.VISIBLE, false);

				normal_img381 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 97,
					y: 195,
					w: 4,
					h: 26,
					src: '0906.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img381.setProperty(hmUI.prop.VISIBLE, false);

				normal_img382 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 49,
					y: 221,
					w: 100,
					h: 1,
					src: '0947.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img382.setProperty(hmUI.prop.VISIBLE, false);

				normal_img383 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 97,
					y: 222,
					w: 4,
					h: 26,
					src: '0906.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img383.setProperty(hmUI.prop.VISIBLE, false);

				normal_sunrise_hours_high_imageset384 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 69,
					y: 195,
					w: 69,
					h: 195,
					src: '0898.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sunrise_hours_high_imageset384.setProperty(hmUI.prop.VISIBLE, false);

				normal_sunrise_hours_low_imageset385 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 83,
					y: 195,
					w: 83,
					h: 195,
					src: '0905.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sunrise_hours_low_imageset385.setProperty(hmUI.prop.VISIBLE, false);

				normal_sunrise_minutes_high_imageset386 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 102,
					y: 195,
					w: 102,
					h: 195,
					src: '0901.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sunrise_minutes_high_imageset386.setProperty(hmUI.prop.VISIBLE, false);

				normal_sunrise_minutes_low_imageset387 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 116,
					y: 195,
					w: 116,
					h: 195,
					src: '0905.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sunrise_minutes_low_imageset387.setProperty(hmUI.prop.VISIBLE, false);

				normal_sunset_hours_high_imageset388 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 69,
					y: 222,
					w: 69,
					h: 222,
					src: '0898.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sunset_hours_high_imageset388.setProperty(hmUI.prop.VISIBLE, false);

				normal_sunset_hours_low_imageset389 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 83,
					y: 222,
					w: 83,
					h: 222,
					src: '0905.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sunset_hours_low_imageset389.setProperty(hmUI.prop.VISIBLE, false);

				normal_sunset_minutes_high_imageset390 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 102,
					y: 222,
					w: 102,
					h: 222,
					src: '0901.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sunset_minutes_high_imageset390.setProperty(hmUI.prop.VISIBLE, false);

				normal_sunset_minutes_low_imageset391 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 116,
					y: 222,
					w: 116,
					h: 222,
					src: '0905.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sunset_minutes_low_imageset391.setProperty(hmUI.prop.VISIBLE, false);

				normal_img393 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 79,
					y: 173,
					w: 40,
					h: 40,
					src: '0932.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img393.setProperty(hmUI.prop.VISIBLE, false);

				normal_uvindex_imageset394 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 79,
					y: 214,
					image_array: ["0933.png","0934.png","0935.png","0936.png","0937.png","0938.png","0939.png","0940.png","0941.png","0942.png","0943.png"],
					image_length: 11,
					type: hmUI.data_type.UVI,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_uvindex_imageset394.setProperty(hmUI.prop.VISIBLE, false);

				normal_img395 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 81,
					y: 242,
					w: 35,
					h: 26,
					src: '0944.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img395.setProperty(hmUI.prop.VISIBLE, false);

				normal_img397 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 75,
					y: 169,
					w: 48,
					h: 48,
					src: '0948.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img397.setProperty(hmUI.prop.VISIBLE, false);

				normal_biocharge_imagecombo398 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 76,
					y: 214,
					font_array: ["0949.png","0950.png","0951.png","0952.png","0953.png","0954.png","0955.png","0956.png","0957.png","0958.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.BIO_CHARGE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_biocharge_imagecombo398.setProperty(hmUI.prop.VISIBLE, false);

				normal_week_imageset401 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 182,
					y: 391,
					week_en: ["0960.png","0961.png","0962.png","0963.png","0964.png","0965.png","0966.png"],
					week_tc: ["0960.png","0961.png","0962.png","0963.png","0964.png","0965.png","0966.png"],
					week_sc: ["0960.png","0961.png","0962.png","0963.png","0964.png","0965.png","0966.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_imagecombo402 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 254,
					day_startY: 391,
					day_sc_array: ["0967.png","0968.png","0969.png","0970.png","0971.png","0972.png","0973.png","0974.png","0975.png","0976.png"],
					day_tc_array: ["0967.png","0968.png","0969.png","0970.png","0971.png","0972.png","0973.png","0974.png","0975.png","0976.png"],
					day_en_array: ["0967.png","0968.png","0969.png","0970.png","0971.png","0972.png","0973.png","0974.png","0975.png","0976.png"],
					day_zero: false,
					day_space: 0,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_imageset404 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 130,
					y: 56,
					image_array: ["0977.png","0978.png","0979.png","0980.png","0981.png","0982.png","0983.png","0984.png","0985.png","0986.png","0984.png","0987.png","0988.png","0989.png","0990.png","0991.png","0992.png","0993.png","0994.png","0995.png","0996.png","0994.png","0993.png","0997.png","0994.png","0998.png","0999.png","0982.png","1000.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_imageset405 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 130,
					y: 116,
					image_array: ["1001.png","1002.png","1003.png","1004.png","1005.png","1006.png","1007.png","1008.png","1009.png","1010.png","1011.png","1012.png","1013.png","1014.png","1015.png","1016.png","1017.png","1018.png","1019.png","1020.png","1021.png","1022.png","1023.png","1024.png","1025.png","1026.png","1027.png","1028.png","1029.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_current_imagecombo406 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 192,
					y: 60,
					font_array: ["1030.png","1031.png","1032.png","1033.png","1034.png","1035.png","1036.png","1037.png","1038.png","1039.png"],
					padding: false,
					h_space: 0,
					unit_sc: ["1041.png"],
					unit_tc: ["1041.png"],
					unit_en: ["1041.png"],
					negative_image: ["1040.png"],
					invalid_image: ["1040.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_high_imagecombo407 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 314,
					y: 63,
					font_array: ["0949.png","0950.png","0951.png","0952.png","0953.png","0954.png","0955.png","0956.png","0957.png","0958.png"],
					padding: false,
					h_space: 0,
					unit_sc: ["1043.png"],
					unit_tc: ["1043.png"],
					unit_en: ["1043.png"],
					negative_image: ["1042.png"],
					invalid_image: ["1042.png"],
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.WEATHER_HIGH,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_low_imagecombo408 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 313,
					y: 93,
					font_array: ["0949.png","0950.png","0951.png","0952.png","0953.png","0954.png","0955.png","0956.png","0957.png","0958.png"],
					padding: false,
					h_space: 0,
					unit_sc: ["1043.png"],
					unit_tc: ["1043.png"],
					unit_en: ["1043.png"],
					negative_image: ["1042.png"],
					invalid_image: ["1042.png"],
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.WEATHER_LOW,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img409 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 301,
					y: 71,
					w: 10,
					h: 10,
					src: '1044.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img410 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 301,
					y: 100,
					w: 10,
					h: 10,
					src: '1045.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weatherplusone_imageset412 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 132,
					y: 72,
					w: 132,
					h: 72,
					src: '1069.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_weatherplusone_imageset412.setProperty(hmUI.prop.VISIBLE, false);

				normal_weatherplustwo_imageset413 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 192,
					y: 72,
					w: 192,
					h: 72,
					src: '1069.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_weatherplustwo_imageset413.setProperty(hmUI.prop.VISIBLE, false);

				normal_weatherplusthree_imageset414 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 252,
					y: 72,
					w: 252,
					h: 72,
					src: '1069.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_weatherplusthree_imageset414.setProperty(hmUI.prop.VISIBLE, false);

				normal_weatherplusfour_imageset415 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 312,
					y: 72,
					w: 312,
					h: 72,
					src: '1069.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_weatherplusfour_imageset415.setProperty(hmUI.prop.VISIBLE, false);

				normal_img416 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 176,
					y: 85,
					w: 12,
					h: 12,
					src: '1070.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img416.setProperty(hmUI.prop.VISIBLE, false);

				normal_img417 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 236,
					y: 85,
					w: 12,
					h: 12,
					src: '1070.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img417.setProperty(hmUI.prop.VISIBLE, false);

				normal_img418 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 296,
					y: 85,
					w: 12,
					h: 12,
					src: '1070.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img418.setProperty(hmUI.prop.VISIBLE, false);

				normal_img419 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 153,
					y: 117,
					w: 172,
					h: 26,
					src: '1071.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img419.setProperty(hmUI.prop.VISIBLE, false);

				normal_img420 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 136,
					y: 53,
					w: 211,
					h: 21,
					src: '1072.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img420.setProperty(hmUI.prop.VISIBLE, false);

				normal_img423 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 188,
					y: 188,
					w: 103,
					h: 103,
					src: '1074.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img425 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 210,
					y: 420,
					w: 34,
					h: 34,
					src: '1075.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img425.setProperty(hmUI.prop.VISIBLE, false);

				normal_biocharge_imagecombo426 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 239,
					y: 428,
					font_array: ["1076.png","1077.png","1078.png","1079.png","1080.png","1081.png","1082.png","1083.png","1084.png","1085.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.BIO_CHARGE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_biocharge_imagecombo426.setProperty(hmUI.prop.VISIBLE, false);

				normal_heart_shortcut430 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 190,
					y: 160,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stress_shortcut431 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 300,
					y: -80,
					w: 200,
					h: 200,
					src: '',
					type: hmUI.data_type.STRESS,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_shortcut432 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 300,
					y: 330,
					w: 200,
					h: 200,
					src: '',
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calories_shortcut433 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: -10,
					y: 330,
					w: 200,
					h: 200,
					src: '',
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_shortcut434 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: -40,
					y: -80,
					w: 200,
					h: 200,
					src: '',
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_shortcut435 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 130,
					y: 50,
					w: 225,
					h: 100,
					src: '',
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_minute_imagecombo437 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 255,
					minute_startY: 306,
					minute_array: ["1087.png","1088.png","1089.png","1090.png","1091.png","1092.png","1093.png","1094.png","1095.png","1096.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_hour_imagecombo438 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 143,
					hour_startY: 306,
					hour_array: ["1087.png","1088.png","1089.png","1090.png","1091.png","1092.png","1093.png","1094.png","1095.png","1096.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img439 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 235,
					y: 305,
					w: 14,
					h: 88,
					src: '1097.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img440 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -2,
					y: -1,
					w: 484,
					h: 483,
					src: '1098.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_date_imagecombo442 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 254,
					day_startY: 391,
					day_sc_array: ["0967.png","0968.png","0969.png","0970.png","0971.png","0972.png","0973.png","0974.png","0975.png","0976.png"],
					day_tc_array: ["0967.png","0968.png","0969.png","0970.png","0971.png","0972.png","0973.png","0974.png","0975.png","0976.png"],
					day_en_array: ["0967.png","0968.png","0969.png","0970.png","0971.png","0972.png","0973.png","0974.png","0975.png","0976.png"],
					day_zero: false,
					day_space: 0,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_week_imageset443 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 182,
					y: 391,
					week_en: ["0960.png","0961.png","0962.png","0963.png","0964.png","0965.png","0966.png"],
					week_tc: ["0960.png","0961.png","0962.png","0963.png","0964.png","0965.png","0966.png"],
					week_sc: ["0960.png","0961.png","0962.png","0963.png","0964.png","0965.png","0966.png"],
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_steps_imageset445 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 3,
					y: 4,
					image_array: ["0615.png","0616.png","0617.png","0618.png","0619.png","0620.png","0621.png","0622.png","0623.png","0624.png","0625.png","0626.png","0627.png","0628.png","0629.png","0630.png","0631.png","0632.png","0633.png","0634.png","0635.png","0636.png","0637.png","0638.png","0639.png","0640.png"],
					image_length: 26,
					type: hmUI.data_type.STEP,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_steps_first_imageset446 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 300,
					y: 442,
					w: 304,
					h: 444,
					src: '0650.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_steps_second_imageset447 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 287,
					y: 447,
					w: 290,
					h: 449,
					src: '0660.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_steps_third_imageset448 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 273,
					y: 452,
					w: 275,
					h: 453,
					src: '0670.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_steps_fourth_imageset449 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 257,
					y: 455,
					w: 258,
					h: 455,
					src: '0680.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_img450 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 271,
					y: 454,
					w: 6,
					h: 25,
					src: '0681.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_steps_fifth_imageset451 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 242,
					y: 456,
					w: 242,
					h: 456,
					src: '0691.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_calories_imageset453 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 0,
					y: 1,
					image_array: ["0692.png","0693.png","0694.png","0695.png","0696.png","0697.png","0698.png","0699.png","0700.png","0701.png","0702.png","0703.png","0704.png","0705.png","0706.png","0707.png","0708.png","0709.png","0710.png","0711.png","0712.png","0713.png","0714.png","0715.png","0716.png","0717.png"],
					image_length: 26,
					type: hmUI.data_type.CAL,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_calories_fourth_imageset454 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -1,
					y: 258,
					w: 6,
					h: 254,
					src: '0727.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_calories_third_imageset455 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 274,
					w: 7,
					h: 271,
					src: '0737.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_calories_second_imageset456 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 3,
					y: 290,
					w: 10,
					h: 287,
					src: '0747.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_calories_first_imageset457 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 8,
					y: 305,
					w: 15,
					h: 303,
					src: '0757.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_battery_imageset459 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 2,
					y: 2,
					image_array: ["0758.png","0759.png","0760.png","0761.png","0762.png","0763.png","0764.png","0765.png","0766.png","0767.png","0768.png","0769.png","0770.png","0771.png","0772.png","0773.png","0774.png","0775.png","0776.png","0777.png","0778.png","0779.png","0780.png","0781.png","0782.png","0783.png"],
					image_length: 26,
					type: hmUI.data_type.BATTERY,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_battery_third_imageset460 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 159,
					y: 11,
					w: 162,
					h: 13,
					src: '0784.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_battery_second_imageset461 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 174,
					y: 7,
					w: 177,
					h: 9,
					src: '0794.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_battery_first_imageset462 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 191,
					y: 4,
					w: 193,
					h: 5,
					src: '0804.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_img463 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 208,
					y: 0,
					w: 24,
					h: 28,
					src: '0805.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_stress_imageset465 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 4,
					y: 3,
					image_array: ["0806.png","0807.png","0808.png","0809.png","0810.png","0811.png","0812.png","0813.png","0814.png","0815.png","0816.png","0817.png","0818.png","0819.png","0820.png","0821.png","0822.png","0823.png","0824.png","0825.png","0826.png","0827.png","0828.png","0829.png","0830.png","0831.png"],
					image_length: 26,
					type: hmUI.data_type.STRESS,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_stress_first_imageset466 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 446,
					y: 191,
					w: 453,
					h: 188,
					src: '0737.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_stress_second_imageset467 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 442,
					y: 175,
					w: 449,
					h: 172,
					src: '0747.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_stress_third_imageset468 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 439,
					y: 158,
					w: 446,
					h: 156,
					src: '0833.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_img470 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 221,
					y: 260,
					w: 38,
					h: 38,
					src: '1099.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_heart_current_imagecombo471 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 203,
					y: 202,
					font_array: ["0834.png","0835.png","0836.png","0837.png","0838.png","0839.png","0840.png","0841.png","0842.png","0843.png"],
					padding: false,
					h_space: 0,
					invalid_image: '0844.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img473 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 301,
					y: 71,
					w: 10,
					h: 10,
					src: '1044.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img474 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 301,
					y: 100,
					w: 10,
					h: 10,
					src: '1045.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_temperature_low_imagecombo475 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 313,
					y: 93,
					font_array: ["0949.png","0950.png","0951.png","0952.png","0953.png","0954.png","0955.png","0956.png","0957.png","0958.png"],
					padding: false,
					h_space: 0,
					unit_sc: ["1043.png"],
					unit_tc: ["1043.png"],
					unit_en: ["1043.png"],
					negative_image: ["1042.png"],
					invalid_image: ["1042.png"],
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.WEATHER_LOW,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_temperature_high_imagecombo476 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 314,
					y: 63,
					font_array: ["0949.png","0950.png","0951.png","0952.png","0953.png","0954.png","0955.png","0956.png","0957.png","0958.png"],
					padding: false,
					h_space: 0,
					unit_sc: ["1043.png"],
					unit_tc: ["1043.png"],
					unit_en: ["1043.png"],
					negative_image: ["1042.png"],
					invalid_image: ["1042.png"],
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.WEATHER_HIGH,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_weather_imageset477 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 130,
					y: 116,
					image_array: ["1001.png","1002.png","1003.png","1004.png","1005.png","1006.png","1007.png","1008.png","1009.png","1010.png","1011.png","1012.png","1013.png","1014.png","1015.png","1016.png","1017.png","1018.png","1019.png","1020.png","1021.png","1022.png","1023.png","1024.png","1025.png","1026.png","1027.png","1028.png","1029.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_temperature_current_imagecombo478 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 192,
					y: 60,
					font_array: ["1030.png","1031.png","1032.png","1033.png","1034.png","1035.png","1036.png","1037.png","1038.png","1039.png"],
					padding: false,
					h_space: 0,
					unit_sc: ["1041.png"],
					unit_tc: ["1041.png"],
					unit_en: ["1041.png"],
					negative_image: ["1040.png"],
					invalid_image: ["1040.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_weather_imageset479 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 130,
					y: 56,
					image_array: ["0977.png","0978.png","0979.png","0980.png","0981.png","0982.png","0983.png","0984.png","0985.png","0986.png","0984.png","0987.png","0988.png","0989.png","0990.png","0991.png","0992.png","0993.png","0994.png","0995.png","0996.png","0994.png","0993.png","0997.png","0994.png","0998.png","0999.png","0982.png","1000.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_distance_units_imageset481 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 88,
					y: 244,
					w: 88,
					h: 244,
					src: idle_distance_units_imageset481_array[hmSetting.getMileageUnit()],
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_distance_imagecombo482 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 63,
					y: 214,
					font_array: ["0847.png","0848.png","0849.png","0850.png","0851.png","0852.png","0853.png","0854.png","0855.png","0856.png"],
					padding: false,
					h_space: 0,
					dot_image: '0857.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.DISTANCE,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img483 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 84,
					y: 177,
					w: 30,
					h: 30,
					src: '0858.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img485 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 356,
					y: 169,
					w: 48,
					h: 48,
					src: '0948.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_biocharge_imagecombo486 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 357,
					y: 214,
					font_array: ["0949.png","0950.png","0951.png","0952.png","0953.png","0954.png","0955.png","0956.png","0957.png","0958.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.BIO_CHARGE,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				container_1758240800721 = hmUI.createWidget(hmUI.widget.BUTTON, {
					x: 80,
					y: 300,
					w: 320,
					h: 100,
					text: "",
					normal_src: '0614.png',
					press_src: '0614.png',
					click_func: () => {
						container_1758240800721_selected = (container_1758240800721_selected+1 > container_1758240800721_customs.length-1) ? 0 : container_1758240800721_selected+1;
						for (let w = 0; w < container_1758240800721_customs.length; w++) {
							for (let z of container_1758240800721_customs[w].widgets) {
								eval(z).setProperty(hmUI.prop.VISIBLE, ((w == container_1758240800721_selected) ? true : false));
							}
						}
						hmUI.showToast({
							text: container_1758240800721_customs[container_1758240800721_selected].label.toString() + ' On'
						});
						vibrateSensor.stop();
						vibrateSensor.scene = 0;
						vibrateSensor.start();
					},
					show_level: hmUI.show_level.ONLY_NORMAL
				});

				container_1758386599609 = hmUI.createWidget(hmUI.widget.BUTTON, {
					x: 330,
					y: 171,
					w: 100,
					h: 100,
					text: "",
					normal_src: '0959.png',
					press_src: '0959.png',
					click_func: () => {
						container_1758386599609_selected = (container_1758386599609_selected+1 > container_1758386599609_customs.length-1) ? 0 : container_1758386599609_selected+1;
						for (let w = 0; w < container_1758386599609_customs.length; w++) {
							for (let z of container_1758386599609_customs[w].widgets) {
								eval(z).setProperty(hmUI.prop.VISIBLE, ((w == container_1758386599609_selected) ? true : false));
							}
						}
						hmUI.showToast({
							text: container_1758386599609_customs[container_1758386599609_selected].label.toString() + ' On'
						});
						vibrateSensor.stop();
						vibrateSensor.scene = 0;
						vibrateSensor.start();
					},
					show_level: hmUI.show_level.ONLY_NORMAL
				});

				container_1758386601789 = hmUI.createWidget(hmUI.widget.BUTTON, {
					x: 50,
					y: 171,
					w: 100,
					h: 100,
					text: "",
					normal_src: '0959.png',
					press_src: '0959.png',
					click_func: () => {
						container_1758386601789_selected = (container_1758386601789_selected+1 > container_1758386601789_customs.length-1) ? 0 : container_1758386601789_selected+1;
						for (let w = 0; w < container_1758386601789_customs.length; w++) {
							for (let z of container_1758386601789_customs[w].widgets) {
								eval(z).setProperty(hmUI.prop.VISIBLE, ((w == container_1758386601789_selected) ? true : false));
							}
						}
						hmUI.showToast({
							text: container_1758386601789_customs[container_1758386601789_selected].label.toString() + ' On'
						});
						vibrateSensor.stop();
						vibrateSensor.scene = 0;
						vibrateSensor.start();
					},
					show_level: hmUI.show_level.ONLY_NORMAL
				});

				container_1768268434367 = hmUI.createWidget(hmUI.widget.BUTTON, {
					x: 133,
					y: 43,
					w: 200,
					h: 100,
					text: "",
					normal_src: '1073.png',
					press_src: '1073.png',
					click_func: () => {
						container_1768268434367_selected = (container_1768268434367_selected+1 > container_1768268434367_customs.length-1) ? 0 : container_1768268434367_selected+1;
						for (let w = 0; w < container_1768268434367_customs.length; w++) {
							for (let z of container_1768268434367_customs[w].widgets) {
								eval(z).setProperty(hmUI.prop.VISIBLE, ((w == container_1768268434367_selected) ? true : false));
							}
						}
						hmUI.showToast({
							text: container_1768268434367_customs[container_1768268434367_selected].label.toString() + ' On'
						});
						vibrateSensor.stop();
						vibrateSensor.scene = 0;
						vibrateSensor.start();
					},
					show_level: hmUI.show_level.ONLY_NORMAL
				});

				container_1768268743618 = hmUI.createWidget(hmUI.widget.BUTTON, {
					x: 183,
					y: 408,
					w: 100,
					h: 30,
					text: "",
					normal_src: '1086.png',
					press_src: '1086.png',
					click_func: () => {
						container_1768268743618_selected = (container_1768268743618_selected+1 > container_1768268743618_customs.length-1) ? 0 : container_1768268743618_selected+1;
						for (let w = 0; w < container_1768268743618_customs.length; w++) {
							for (let z of container_1768268743618_customs[w].widgets) {
								eval(z).setProperty(hmUI.prop.VISIBLE, ((w == container_1768268743618_selected) ? true : false));
							}
						}
						hmUI.showToast({
							text: container_1768268743618_customs[container_1768268743618_selected].label.toString() + ' On'
						});
						vibrateSensor.stop();
						vibrateSensor.scene = 0;
						vibrateSensor.start();
					},
					show_level: hmUI.show_level.ONLY_NORMAL
				});

				function updateBattery() {
					normal_battery_third_imageset265.setProperty(hmUI.prop.MORE, {
						src: normal_battery_third_imageset265_array[batterySensor.current.toString().padStart(3, '0').charAt(0)]
					})
					normal_battery_second_imageset266.setProperty(hmUI.prop.MORE, {
						src: normal_battery_second_imageset266_array[batterySensor.current.toString().padStart(3, '0').charAt(1)]
					})
					normal_battery_first_imageset267.setProperty(hmUI.prop.MORE, {
						src: normal_battery_first_imageset267_array[batterySensor.current.toString().padStart(3, '0').charAt(2)]
					})
					idle_battery_third_imageset460.setProperty(hmUI.prop.MORE, {
						src: idle_battery_third_imageset460_array[batterySensor.current.toString().padStart(3, '0').charAt(0)]
					})
					idle_battery_second_imageset461.setProperty(hmUI.prop.MORE, {
						src: idle_battery_second_imageset461_array[batterySensor.current.toString().padStart(3, '0').charAt(1)]
					})
					idle_battery_first_imageset462.setProperty(hmUI.prop.MORE, {
						src: idle_battery_first_imageset462_array[batterySensor.current.toString().padStart(3, '0').charAt(2)]
					})
				}

				function updateSteps() {
					normal_steps_first_imageset251.setProperty(hmUI.prop.MORE, {
						src: normal_steps_first_imageset251_array[stepSensor.current.toString().padStart(5, '0').charAt(4)]
					})
					normal_steps_second_imageset252.setProperty(hmUI.prop.MORE, {
						src: normal_steps_second_imageset252_array[stepSensor.current.toString().padStart(5, '0').charAt(3)]
					})
					normal_steps_third_imageset253.setProperty(hmUI.prop.MORE, {
						src: normal_steps_third_imageset253_array[stepSensor.current.toString().padStart(5, '0').charAt(2)]
					})
					normal_steps_fourth_imageset254.setProperty(hmUI.prop.MORE, {
						src: normal_steps_fourth_imageset254_array[stepSensor.current.toString().padStart(5, '0').charAt(1)]
					})
					normal_steps_fifth_imageset256.setProperty(hmUI.prop.MORE, {
						src: normal_steps_fifth_imageset256_array[stepSensor.current.toString().padStart(5, '0').charAt(0)]
					})
					idle_steps_first_imageset446.setProperty(hmUI.prop.MORE, {
						src: idle_steps_first_imageset446_array[stepSensor.current.toString().padStart(5, '0').charAt(4)]
					})
					idle_steps_second_imageset447.setProperty(hmUI.prop.MORE, {
						src: idle_steps_second_imageset447_array[stepSensor.current.toString().padStart(5, '0').charAt(3)]
					})
					idle_steps_third_imageset448.setProperty(hmUI.prop.MORE, {
						src: idle_steps_third_imageset448_array[stepSensor.current.toString().padStart(5, '0').charAt(2)]
					})
					idle_steps_fourth_imageset449.setProperty(hmUI.prop.MORE, {
						src: idle_steps_fourth_imageset449_array[stepSensor.current.toString().padStart(5, '0').charAt(1)]
					})
					idle_steps_fifth_imageset451.setProperty(hmUI.prop.MORE, {
						src: idle_steps_fifth_imageset451_array[stepSensor.current.toString().padStart(5, '0').charAt(0)]
					})
				}

				function updateCalories() {
					normal_calories_fourth_imageset259.setProperty(hmUI.prop.MORE, {
						src: normal_calories_fourth_imageset259_array[calorieSensor.current.toString().padStart(4, '0').charAt(0)]
					})
					normal_calories_third_imageset260.setProperty(hmUI.prop.MORE, {
						src: normal_calories_third_imageset260_array[calorieSensor.current.toString().padStart(4, '0').charAt(1)]
					})
					normal_calories_second_imageset261.setProperty(hmUI.prop.MORE, {
						src: normal_calories_second_imageset261_array[calorieSensor.current.toString().padStart(4, '0').charAt(2)]
					})
					normal_calories_first_imageset262.setProperty(hmUI.prop.MORE, {
						src: normal_calories_first_imageset262_array[calorieSensor.current.toString().padStart(4, '0').charAt(3)]
					})
					idle_calories_fourth_imageset454.setProperty(hmUI.prop.MORE, {
						src: idle_calories_fourth_imageset454_array[calorieSensor.current.toString().padStart(4, '0').charAt(0)]
					})
					idle_calories_third_imageset455.setProperty(hmUI.prop.MORE, {
						src: idle_calories_third_imageset455_array[calorieSensor.current.toString().padStart(4, '0').charAt(1)]
					})
					idle_calories_second_imageset456.setProperty(hmUI.prop.MORE, {
						src: idle_calories_second_imageset456_array[calorieSensor.current.toString().padStart(4, '0').charAt(2)]
					})
					idle_calories_first_imageset457.setProperty(hmUI.prop.MORE, {
						src: idle_calories_first_imageset457_array[calorieSensor.current.toString().padStart(4, '0').charAt(3)]
					})
				}

				function updateDistance() {
					normal_distance_units_imageset277.setProperty(hmUI.prop.MORE, {
						src: normal_distance_units_imageset277_array[hmSetting.getMileageUnit()]
					})
					normal_distance_units_imageset339.setProperty(hmUI.prop.MORE, {
						src: normal_distance_units_imageset339_array[hmSetting.getMileageUnit()]
					})
					idle_distance_units_imageset481.setProperty(hmUI.prop.MORE, {
						src: idle_distance_units_imageset481_array[hmSetting.getMileageUnit()]
					})
				}

				function updateWeather() {
					let tideData = weatherSensor.getForecastWeather().tideData;
					normal_sunrise_hours_high_imageset323.setProperty(hmUI.prop.MORE, {
						src: normal_sunrise_hours_high_imageset323_array[tideData.data[0].sunrise.hour.toString().padStart(2, '0').charAt(0)]
					})
					normal_sunrise_hours_low_imageset324.setProperty(hmUI.prop.MORE, {
						src: normal_sunrise_hours_low_imageset324_array[tideData.data[0].sunrise.hour.toString().padStart(2, '0').charAt(1)]
					})
					normal_sunrise_minutes_high_imageset325.setProperty(hmUI.prop.MORE, {
						src: normal_sunrise_minutes_high_imageset325_array[tideData.data[0].sunrise.minute.toString().padStart(2, '0').charAt(0)]
					})
					normal_sunrise_minutes_low_imageset326.setProperty(hmUI.prop.MORE, {
						src: normal_sunrise_minutes_low_imageset326_array[tideData.data[0].sunrise.minute.toString().padStart(2, '0').charAt(1)]
					})
					normal_sunset_hours_high_imageset328.setProperty(hmUI.prop.MORE, {
						src: normal_sunset_hours_high_imageset328_array[tideData.data[0].sunset.hour.toString().padStart(2, '0').charAt(0)]
					})
					normal_sunset_hours_low_imageset329.setProperty(hmUI.prop.MORE, {
						src: normal_sunset_hours_low_imageset329_array[tideData.data[0].sunset.hour.toString().padStart(2, '0').charAt(1)]
					})
					normal_sunset_minutes_high_imageset331.setProperty(hmUI.prop.MORE, {
						src: normal_sunset_minutes_high_imageset331_array[tideData.data[0].sunset.minute.toString().padStart(2, '0').charAt(0)]
					})
					normal_sunset_minutes_low_imageset332.setProperty(hmUI.prop.MORE, {
						src: normal_sunset_minutes_low_imageset332_array[tideData.data[0].sunset.minute.toString().padStart(2, '0').charAt(1)]
					})
					normal_sunrise_hours_high_imageset384.setProperty(hmUI.prop.MORE, {
						src: normal_sunrise_hours_high_imageset384_array[tideData.data[0].sunrise.hour.toString().padStart(2, '0').charAt(0)]
					})
					normal_sunrise_hours_low_imageset385.setProperty(hmUI.prop.MORE, {
						src: normal_sunrise_hours_low_imageset385_array[tideData.data[0].sunrise.hour.toString().padStart(2, '0').charAt(1)]
					})
					normal_sunrise_minutes_high_imageset386.setProperty(hmUI.prop.MORE, {
						src: normal_sunrise_minutes_high_imageset386_array[tideData.data[0].sunrise.minute.toString().padStart(2, '0').charAt(0)]
					})
					normal_sunrise_minutes_low_imageset387.setProperty(hmUI.prop.MORE, {
						src: normal_sunrise_minutes_low_imageset387_array[tideData.data[0].sunrise.minute.toString().padStart(2, '0').charAt(1)]
					})
					normal_sunset_hours_high_imageset388.setProperty(hmUI.prop.MORE, {
						src: normal_sunset_hours_high_imageset388_array[tideData.data[0].sunset.hour.toString().padStart(2, '0').charAt(0)]
					})
					normal_sunset_hours_low_imageset389.setProperty(hmUI.prop.MORE, {
						src: normal_sunset_hours_low_imageset389_array[tideData.data[0].sunset.hour.toString().padStart(2, '0').charAt(1)]
					})
					normal_sunset_minutes_high_imageset390.setProperty(hmUI.prop.MORE, {
						src: normal_sunset_minutes_high_imageset390_array[tideData.data[0].sunset.minute.toString().padStart(2, '0').charAt(0)]
					})
					normal_sunset_minutes_low_imageset391.setProperty(hmUI.prop.MORE, {
						src: normal_sunset_minutes_low_imageset391_array[tideData.data[0].sunset.minute.toString().padStart(2, '0').charAt(1)]
					})
					let forecastData = weatherSensor.getForecastWeather().forecastData;
					normal_weatherplusone_imageset412.setProperty(hmUI.prop.MORE, {
						src: normal_weatherplusone_imageset412_array[typeof forecastData.data[1] != 'undefined' ? forecastData.data[1].index : 25]
					})
					normal_weatherplustwo_imageset413.setProperty(hmUI.prop.MORE, {
						src: normal_weatherplustwo_imageset413_array[typeof forecastData.data[2] != 'undefined' ? forecastData.data[2].index : 25]
					})
					normal_weatherplusthree_imageset414.setProperty(hmUI.prop.MORE, {
						src: normal_weatherplusthree_imageset414_array[typeof forecastData.data[3] != 'undefined' ? forecastData.data[3].index : 25]
					})
					normal_weatherplusfour_imageset415.setProperty(hmUI.prop.MORE, {
						src: normal_weatherplusfour_imageset415_array[typeof forecastData.data[4] != 'undefined' ? forecastData.data[4].index : 0]
					})
				}

				function updateStress() {
					normal_stress_first_imageset271.setProperty(hmUI.prop.MORE, {
						src: normal_stress_first_imageset271_array[stressSensor.current.toString().padStart(3, '0').charAt(2)]
					})
					normal_stress_second_imageset272.setProperty(hmUI.prop.MORE, {
						src: normal_stress_second_imageset272_array[stressSensor.current.toString().padStart(3, '0').charAt(1)]
					})
					normal_stress_third_imageset273.setProperty(hmUI.prop.MORE, {
						src: normal_stress_third_imageset273_array[stressSensor.current.toString().padStart(3, '0').charAt(0)]
					})
					idle_stress_first_imageset466.setProperty(hmUI.prop.MORE, {
						src: idle_stress_first_imageset466_array[stressSensor.current.toString().padStart(3, '0').charAt(2)]
					})
					idle_stress_second_imageset467.setProperty(hmUI.prop.MORE, {
						src: idle_stress_second_imageset467_array[stressSensor.current.toString().padStart(3, '0').charAt(1)]
					})
					idle_stress_third_imageset468.setProperty(hmUI.prop.MORE, {
						src: idle_stress_third_imageset468_array[stressSensor.current.toString().padStart(3, '0').charAt(0)]
					})
				}

				function updateSleep() {
					normal_sleep_hour_high_imageset295.setProperty(hmUI.prop.MORE, {
						src: normal_sleep_hour_high_imageset295_array[Math.floor(sleepSensor.getTotalTime() / 60).toString().padStart(2, '0').charAt(0)]
					})
					normal_sleep_hour_low_imageset296.setProperty(hmUI.prop.MORE, {
						src: normal_sleep_hour_low_imageset296_array[Math.floor(sleepSensor.getTotalTime() / 60).toString().padStart(2, '0').charAt(1)]
					})
					normal_sleep_minute_high_imageset297.setProperty(hmUI.prop.MORE, {
						src: normal_sleep_minute_high_imageset297_array[Math.floor(sleepSensor.getTotalTime() % 60).toString().padStart(2, '0').charAt(0)]
					})
					normal_sleep_minute_low_imageset298.setProperty(hmUI.prop.MORE, {
						src: normal_sleep_minute_low_imageset298_array[Math.floor(sleepSensor.getTotalTime() % 60).toString().padStart(2, '0').charAt(1)]
					})
					normal_sleep_hour_high_imageset357.setProperty(hmUI.prop.MORE, {
						src: normal_sleep_hour_high_imageset357_array[Math.floor(sleepSensor.getTotalTime() / 60).toString().padStart(2, '0').charAt(0)]
					})
					normal_sleep_hour_low_imageset358.setProperty(hmUI.prop.MORE, {
						src: normal_sleep_hour_low_imageset358_array[Math.floor(sleepSensor.getTotalTime() / 60).toString().padStart(2, '0').charAt(1)]
					})
					normal_sleep_minute_high_imageset359.setProperty(hmUI.prop.MORE, {
						src: normal_sleep_minute_high_imageset359_array[Math.floor(sleepSensor.getTotalTime() % 60).toString().padStart(2, '0').charAt(0)]
					})
					normal_sleep_minute_low_imageset360.setProperty(hmUI.prop.MORE, {
						src: normal_sleep_minute_low_imageset360_array[Math.floor(sleepSensor.getTotalTime() % 60).toString().padStart(2, '0').charAt(1)]
					})
				}

				batterySensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateBattery();
				});

				stepSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateSteps();
				});

				calorieSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateCalories();
				});

				distanceSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateDistance();
				});

				weatherSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateWeather();
				});

				stressSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateStress();
				});

				sleepSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateSleep();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateBattery();
						updateSteps();
						updateCalories();
						updateDistance();
						updateWeather();
						updateStress();
						updateSleep();
					}),
					pause_call: (function () {
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}