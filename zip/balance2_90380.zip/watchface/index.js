﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_humidity_text_text_img = ''
        let normal_wind_text_text_img = ''
        let normal_group_ForecastWeather = ''
        let normal_canvas1 = '';
        let normal_canvas2 = '';
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_hrv_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_day_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_altitude_target_text_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_linear_scale = ''
        let normal_step_linear_scale_pointer_img = ''
        let normal_step_target_text_img = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_sun_high_text_img = ''
        let idle_sun_low_text_img = ''
        let idle_sun_image_progress_img_level = ''
        let idle_moon_image_progress_img_level = ''
        let idle_humidity_text_text_img = ''
        let idle_wind_text_text_img = ''
        let idle_group_ForecastWeather = ''
        let idle_canvas1 = '';
        let idle_canvas2 = '';
        let idle_city_name_text = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_hrv_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_pai_weekly_text_img = ''
        let idle_pai_day_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_altitude_target_text_img = ''
        let idle_altimeter_text_text_img = ''
        let idle_battery_linear_scale = ''
        let idle_battery_text_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_step_linear_scale = ''
        let idle_step_linear_scale_pointer_img = ''
        let idle_step_target_text_img = ''
        let idle_step_current_text_img = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'background.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 404,
              y: 181,
              src: 'dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 433,
              y: 180,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 371,
              y: 179,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 145,
              y: 19,
              font_array: ["wx_0.png","wxs_1.png","wx_2.png","wx_3.png","wx_4.png","wx_5.png","wx_6.png","wx_7.png","wx_8.png","wx_9.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'dot.png',
              dot_image: 'wx_colon.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 269,
              y: 19,
              font_array: ["wx_0.png","wxs_1.png","wx_2.png","wx_3.png","wx_4.png","wx_5.png","wx_6.png","wx_7.png","wx_8.png","wx_9.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'dot.png',
              dot_image: 'wx_colon.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 155,
              y: 44,
              image_array: ["sun_1.png","sun_2.png","sun_3.png","sun_4.png","sun_5.png","sun_6.png","sun_7.png","sun_8.png","sun_9.png","sun_10.png"],
              image_length: 10,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 227,
              y: 10,
              image_array: ["Moon_1.png","Moon_2.png","Moon_3.png","Moon_4.png","Moon_5.png","Moon_6.png","Moon_7.png","Moon_8.png","Moon_9.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 227,
              y: 64,
              w: 44,
              font_array: ["wx_0.png","wx_1.png","wx_2.png","wx_3.png","wx_4.png","wx_5.png","wx_6.png","wx_7.png","wx_8.png","wx_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const normal_wind_text_text_img_ws = (typeof hmUI.data_type.WIND_SPEED !== 'undefined');
            if (normal_wind_text_text_img_ws) {
              normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 99,
              y: 64,
              w: 46,
              font_array: ["wx_0.png","wx_1.png","wx_2.png","wx_3.png","wx_4.png","wx_5.png","wx_6.png","wx_7.png","wx_8.png","wx_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND_SPEED,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            } else {
              // fallback: παλιός τρόπος (επίπεδα ανέμου) αν το σύστημα δεν υποστηρίζει WIND_SPEED
              normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 97,
              y: 64,
              image_array: ["blank.png","blank.png","blank.png","blank.png","blank.png","blank.png","blank.png","blank.png","blank.png","wx_1.png","wx_1.png","wx_1.png"],
              image_length: 12,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 104,
              y: 64,
              image_array: ["blank.png","wx_1.png","wx_2.png","wx_2.png","wx_3.png","wx_5.png","wx_6.png","wx_7.png","wx_8.png","blank.png","blank.png","blank.png"],
              image_length: 12,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 111,
              y: 64,
              image_array: ["wx_6.png","blank.png","blank.png","blank.png","blank.png","blank.png","blank.png","blank.png","blank.png","wx_0.png","wx_1.png","wx_2.png"],
              image_length: 12,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 118,
              y: 64,
              image_array: ["blank.png","wx_2.png","wx_0.png","wx_9.png","wx_9.png","wx_0.png","wx_2.png","wx_5.png","wx_9.png","blank.png","blank.png","blank.png"],
              image_length: 12,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 125,
              y: 64,
              image_array: ["blank.png","blank.png","blank.png","blank.png","blank.png","blank.png","blank.png","blank.png","blank.png","wx_3.png","wx_8.png","wx_0.png"],
              image_length: 12,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            }

            let screenType = hmSetting.getScreenType();            
            // normal_Weather_FewDays = hmUI.createWidget(hmUI.widget.FewDays, {
              // x: 243,
              // y: 96,
              // ColumnWidth: 30,
              // DaysCount: 7,
            // });
            
            normal_group_ForecastWeather = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 243,
              y: 96,
              h: 0,
              w: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            //#region draw
            function drawLine(canvas1, canvas2, x1, y1, x2, y2, color, line_width) {
              if (x1 > x2) {
                let temp_x = x1;
                let temp_y = y1;
                x1 = x2;
                y1 = y2;
                x2 = temp_x;
                y2 = temp_y;
              };
              canvas2.setPaint({ color: color, line_width: line_width });
              canvas2.drawLine({ x1: x1, y1: y1, x2: x2, y2: y2 });
            };
            
            function drawRect(canvas1, canvas2, x1, y1, x2, y2, color) {
              if (x1 > x2) {
                let temp_x = x1;
                let temp_y = y1;
                x1 = x2;
                y1 = y2;
                x2 = temp_x;
                y2 = temp_y;
              };
              
              canvas2.drawRect({ x1: x1, y1: y1, x2: x2, y2: y2, color: color });
            };
            
            function drawCircle(canvas1, canvas2, center_x, center_y, color, radius) {
              canvas2.drawCircle({ center_x: center_x, center_y: center_y, radius: radius, color: color });
            };
            
            function drawGraphPoint(canvas1, canvas2, x, y, color, pointSize, pointType) {
              switch (pointType) {
                case 1:
                  x -= pointSize/2;
                  y -= pointSize/2;
                  drawRect(canvas1, canvas2, x, y, x+pointSize, y+pointSize, color);
                  break;
                case 2:
                  let posX = x - pointSize/2;
                  let posY = y - pointSize/2;
                  drawRect(canvas1, canvas2, posX, posY, posX+pointSize, posY+pointSize, color );
                  posX = x - pointSize/4;
                  posY = y - pointSize/4;
                  drawRect(canvas1, canvas2, posX, posY, posX+pointSize/2, posY+pointSize/2, 0xffffff );
                  break;
                case 3:
                  drawCircle(canvas1, canvas2, x, y, color, pointSize/2 );
                  break;
                case 4:
                  drawCircle(canvas1, canvas2, x, y, color, pointSize/2 );
                  drawCircle(canvas1, canvas2, x, y, 0xffffff, pointSize/4 );
                  break;
              }
            };

            //#endregion
            

            //#region graphScale
            function graphScale(heightGraph, maxPointSize, minPointSize, forecastData, daysCount) {
              console.log(`function graphScale`);
              heightGraph -= (maxPointSize + minPointSize) / 2;
              let high = -300;
              let low = 300;
              for (let index = 0; index < daysCount; index++) {
                if (index < forecastData.length) {
                  let item = forecastData[index];
                  if (item.high > high) high = item.high;;
                  if (item.low < low) low = item.low; ;
                } // end if
              } // end for
              let delta = high - low;
              let scale = heightGraph / delta;
              console.log(`heightGraph: ${heightGraph}; high: ${high}; low : ${low}`);
              return {graphScale: scale, maximal_temp: high};
            };

            //#endregion

            //#region screenType
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              normal_canvas1 = normal_group_ForecastWeather.createWidget(hmUI.widget.CANVAS, {
                x: 0,
                y: 0,
                w: 0,
                h: 0,
              });

              normal_canvas2 = normal_group_ForecastWeather.createWidget(hmUI.widget.CANVAS, {
                x: -2,
                y: 0,
                w: 480,
                h: 480,
              });
            };
            //#endregion
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 86,
              y: 94,
              w: 147,
              h: 30,
              text_size: 24,
              font: 'Roboto-Bold.ttf',
              char_space: 0,
              alpha: 200,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 44,
              y: 129,
              image_array: ["weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 98,
              y: 133,
              font_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'pointer_2.png',
              unit_tc: 'pointer_2.png',
              unit_en: 'pointer_2.png',
              imperial_unit_sc: 'pointer_3.png',
              imperial_unit_tc: 'pointer_3.png',
              imperial_unit_en: 'pointer_3.png',
              negative_image: 'pointer_1.png',
              invalid_image: 'dot_1.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 98,
                y: 133,
                font_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
                padding: false,
                h_space: 1,
                unit_sc: 'pointer_3.png',
                unit_tc: 'pointer_3.png',
                unit_en: 'pointer_3.png',
                imperial_unit_sc: 'pointer_2.png',
                imperial_unit_tc: 'pointer_2.png',
                imperial_unit_en: 'pointer_2.png',
                negative_image: 'pointer_1.png',
                invalid_image: 'dot_1.png',
                align_h: hmUI.align.LEFT,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 380,
              month_startY: 127,
              month_sc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: (hmSetting.getLanguage() === 23) ? ["month_gr_1.png","month_gr_2.png","month_gr_3.png","month_gr_4.png","month_gr_5.png","month_gr_6.png","month_gr_7.png","month_gr_8.png","month_gr_9.png","month_gr_10.png","month_gr_11.png","month_gr_12.png"] : ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 328,
              day_startY: 133,
              day_sc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_tc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_en_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_zero: 0,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 254,
              y: 127,
              week_en: (hmSetting.getLanguage() === 23) ? ["day_gr_1.png","day_gr_2.png","day_gr_3.png","day_gr_4.png","day_gr_5.png","day_gr_6.png","day_gr_7.png"] : ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_hrv_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 382,
              y: 306,
              w: 48,
              h: 24,
              font_array: ["wx_0.png","wx_1.png","wx_2.png","wx_3.png","wx_4.png","wx_5.png","wx_6.png","wx_7.png","wx_8.png","wx_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'dot_1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HRV,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 196,
              y: 300,
              w: 52,
              h: 24,
              font_array: ["hr_b_0.png","hr_b_1.png","hr_b_2.png","hr_b_3.png","hr_b_4.png","hr_b_5.png","hr_b_6.png","hr_b_7.png","hr_b_8.png","hr_b_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'dot_1.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 20,
              y: 297,
              image_array: ["pulse_1.png","pulse_2.png","pulse_3.png","pulse_4.png","pulse_5.png","pulse_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 115,
              y: 341,
              font_array: ["wx_0.png","wx_1.png","wx_2.png","wx_3.png","wx_4.png","wx_5.png","wx_6.png","wx_7.png","wx_8.png","wx_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 69,
              y: 341,
              font_array: ["wx_0.png","wx_1.png","wx_2.png","wx_3.png","wx_4.png","wx_5.png","wx_6.png","wx_7.png","wx_8.png","wx_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 229,
              y: 341,
              font_array: ["wx_0.png","wx_1.png","wx_2.png","wx_3.png","wx_4.png","wx_5.png","wx_6.png","wx_7.png","wx_8.png","wx_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // flame icon + calorie number are positioned together with the PAI texts by updateRowLayout()
            const calSensor = hmSensor.createSensor(hmSensor.id.CALORIE);
            const flameNormal = hmUI.createWidget(hmUI.widget.IMG, { x: 205, y: 343, w: 18, h: 23, src: 'flame_cal.png', show_level: hmUI.show_level.ONLY_NORMAL });
            const flameIdle = hmUI.createWidget(hmUI.widget.IMG, { x: 205, y: 343, w: 18, h: 23, src: 'flame_cal.png', show_level: hmUI.show_level.ONLY_AOD });

            normal_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 302,
              w: 82,
              y: 341,
              font_array: ["wx_0.png","wx_1.png","wx_2.png","wx_3.png","wx_4.png","wx_5.png","wx_6.png","wx_7.png","wx_8.png","wx_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 298,
              y: 64,
              font_array: ["wx_0.png","wx_1.png","wx_2.png","wx_3.png","wx_4.png","wx_5.png","wx_6.png","wx_7.png","wx_8.png","wx_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 266,
              // start_y: 434,
              // color: 0xFF40FD91,
              // lenght: 56,
              // line_width: 22,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 135,
              y: 432,
              w: 60,
              font_array: ["wx_0.png","wx_1.png","wx_2.png","wx_3.png","wx_4.png","wx_5.png","wx_6.png","wx_7.png","wx_8.png","wx_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210,
              y: 376,
              font_array: ["wx_0.png","wx_1.png","wx_2.png","wx_3.png","wx_4.png","wx_5.png","wx_6.png","wx_7.png","wx_8.png","wx_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'dot.png',
              unit_tc: 'dot.png',
              unit_en: 'dot.png',
              imperial_unit_sc: 'dot.png',
              imperial_unit_tc: 'dot.png',
              imperial_unit_en: 'dot.png',
              dot_image: 'pointerp_6.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            normal_step_linear_scale_pointer_img = hmUI.createWidget(hmUI.widget.IMG);
            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 82,
              // start_y: 407,
              // color: 0xFFB0D8FF,
              // pointer: 'pointer_5.png',
              // lenght: 318,
              // line_width: 9,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 322,
              y: 376,
              font_array: ["wx_0.png","wx_1.png","wx_2.png","wx_3.png","wx_4.png","wx_5.png","wx_6.png","wx_7.png","wx_8.png","wx_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP_TARGET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 376,
              font_array: ["wx_0.png","wx_1.png","wx_2.png","wx_3.png","wx_4.png","wx_5.png","wx_6.png","wx_7.png","wx_8.png","wx_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // distance icon follows the distance text (right edge of text fixed at x=272)
            const distNormalIcon = hmUI.createWidget(hmUI.widget.IMG, { x: 201, y: 379, w: 18, h: 21, src: 'dist_icon.png', show_level: hmUI.show_level.ONLY_NORMAL });
            const distIdleIcon = hmUI.createWidget(hmUI.widget.IMG, { x: 201, y: 379, w: 18, h: 21, src: 'dist_icon.png', show_level: hmUI.show_level.ONLY_AOD });
            let distSensor = null;
            try { distSensor = hmSensor.createSensor(hmSensor.id.DISTANCE); } catch (e) { distSensor = null; }
            function updateDistIcon() {
              let km = -1;
              try { if (distSensor && typeof distSensor.current === 'number') km = distSensor.current / 1000; } catch (e) { km = -1; }
              if (km < 0) { try { km = step.current * 0.00077; } catch (e) { km = 0; } }
              let ints = Math.max(1, String(Math.floor(km)).length);
              let w = (ints + 2) * 14 + 6;
              let ix = 249 - w;
              distNormalIcon.setProperty(hmUI.prop.X, ix);
              distIdleIcon.setProperty(hmUI.prop.X, ix);
            }
            updateDistIcon();
            step.addEventListener(hmSensor.event.CHANGE, updateDistIcon);
            if (distSensor) { try { distSensor.addEventListener(hmSensor.event.CHANGE, updateDistIcon); } catch (e) {} }

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 15,
              hour_startY: 178,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_unit_sc: 'pointer_0.png',
              hour_unit_tc: 'pointer_0.png',
              hour_unit_en: 'pointer_0.png',
              hour_align: hmUI.align.RIGHT,

              minute_startX: 208,
              minute_startY: 178,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 377,
              second_startY: 228,
              second_array: ["sec_0.png","sec_1.png","sec_2.png","sec_3.png","sec_4.png","sec_5.png","sec_6.png","sec_7.png","sec_8.png","sec_9.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'background.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 404,
              y: 181,
              src: 'dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 433,
              y: 180,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 371,
              y: 179,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 145,
              y: 19,
              font_array: ["wx_0.png","wxs_1.png","wx_2.png","wx_3.png","wx_4.png","wx_5.png","wx_6.png","wx_7.png","wx_8.png","wx_9.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'dot.png',
              dot_image: 'wx_colon.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 269,
              y: 19,
              font_array: ["wx_0.png","wxs_1.png","wx_2.png","wx_3.png","wx_4.png","wx_5.png","wx_6.png","wx_7.png","wx_8.png","wx_9.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'dot.png',
              dot_image: 'wx_colon.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 155,
              y: 44,
              image_array: ["sun_1.png","sun_2.png","sun_3.png","sun_4.png","sun_5.png","sun_6.png","sun_7.png","sun_8.png","sun_9.png","sun_10.png"],
              image_length: 10,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 227,
              y: 10,
              image_array: ["Moon_1.png","Moon_2.png","Moon_3.png","Moon_4.png","Moon_5.png","Moon_6.png","Moon_7.png","Moon_8.png","Moon_9.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 227,
              y: 64,
              w: 44,
              font_array: ["wx_0.png","wx_1.png","wx_2.png","wx_3.png","wx_4.png","wx_5.png","wx_6.png","wx_7.png","wx_8.png","wx_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const idle_wind_text_text_img_ws = (typeof hmUI.data_type.WIND_SPEED !== 'undefined');
            if (idle_wind_text_text_img_ws) {
              idle_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 99,
              y: 64,
              w: 46,
              font_array: ["wx_0.png","wx_1.png","wx_2.png","wx_3.png","wx_4.png","wx_5.png","wx_6.png","wx_7.png","wx_8.png","wx_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND_SPEED,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            } else {
              // fallback: παλιός τρόπος (επίπεδα ανέμου) αν το σύστημα δεν υποστηρίζει WIND_SPEED
              idle_wind_text_text_img = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 97,
              y: 64,
              image_array: ["blank.png","blank.png","blank.png","blank.png","blank.png","blank.png","blank.png","blank.png","blank.png","wx_1.png","wx_1.png","wx_1.png"],
              image_length: 12,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 104,
              y: 64,
              image_array: ["blank.png","wx_1.png","wx_2.png","wx_2.png","wx_3.png","wx_5.png","wx_6.png","wx_7.png","wx_8.png","blank.png","blank.png","blank.png"],
              image_length: 12,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 111,
              y: 64,
              image_array: ["wx_6.png","blank.png","blank.png","blank.png","blank.png","blank.png","blank.png","blank.png","blank.png","wx_0.png","wx_1.png","wx_2.png"],
              image_length: 12,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 118,
              y: 64,
              image_array: ["blank.png","wx_2.png","wx_0.png","wx_9.png","wx_9.png","wx_0.png","wx_2.png","wx_5.png","wx_9.png","blank.png","blank.png","blank.png"],
              image_length: 12,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 125,
              y: 64,
              image_array: ["blank.png","blank.png","blank.png","blank.png","blank.png","blank.png","blank.png","blank.png","blank.png","wx_3.png","wx_8.png","wx_0.png"],
              image_length: 12,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            }
            
            // idle_Weather_FewDays = hmUI.createWidget(hmUI.widget.FewDays, {
              // x: 243,
              // y: 96,
              // ColumnWidth: 30,
              // DaysCount: 7,
            // });
            
            idle_group_ForecastWeather = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 243,
              y: 96,
              h: 0,
              w: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //#region screenType
            if (screenType == hmSetting.screen_type.AOD) {
              idle_canvas1 = idle_group_ForecastWeather.createWidget(hmUI.widget.CANVAS, {
                x: 0,
                y: 0,
                w: 0,
                h: 0,
              });

              idle_canvas2 = idle_group_ForecastWeather.createWidget(hmUI.widget.CANVAS, {
                x: -2,
                y: 0,
                w: 480,
                h: 480,
              });
            };
            //#endregion

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 86,
              y: 94,
              w: 147,
              h: 30,
              text_size: 24,
              font: 'Roboto-Bold.ttf',
              char_space: 0,
              alpha: 200,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 44,
              y: 129,
              image_array: ["weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 98,
              y: 133,
              font_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'pointer_2.png',
              unit_tc: 'pointer_2.png',
              unit_en: 'pointer_2.png',
              imperial_unit_sc: 'pointer_3.png',
              imperial_unit_tc: 'pointer_3.png',
              imperial_unit_en: 'pointer_3.png',
              negative_image: 'pointer_1.png',
              invalid_image: 'dot_1.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //#region temperatureUnit
            if (temperatureUnit == 1) {
              idle_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 98,
                y: 133,
                font_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
                padding: false,
                h_space: 1,
                unit_sc: 'pointer_3.png',
                unit_tc: 'pointer_3.png',
                unit_en: 'pointer_3.png',
                imperial_unit_sc: 'pointer_2.png',
                imperial_unit_tc: 'pointer_2.png',
                imperial_unit_en: 'pointer_2.png',
                negative_image: 'pointer_1.png',
                invalid_image: 'dot_1.png',
                align_h: hmUI.align.LEFT,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //#endregion

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 380,
              month_startY: 127,
              month_sc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: (hmSetting.getLanguage() === 23) ? ["month_gr_1.png","month_gr_2.png","month_gr_3.png","month_gr_4.png","month_gr_5.png","month_gr_6.png","month_gr_7.png","month_gr_8.png","month_gr_9.png","month_gr_10.png","month_gr_11.png","month_gr_12.png"] : ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 328,
              day_startY: 133,
              day_sc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_tc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_en_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_zero: 0,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 254,
              y: 127,
              week_en: (hmSetting.getLanguage() === 23) ? ["day_gr_1.png","day_gr_2.png","day_gr_3.png","day_gr_4.png","day_gr_5.png","day_gr_6.png","day_gr_7.png"] : ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_hrv_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 382,
              y: 306,
              w: 48,
              h: 24,
              font_array: ["wx_0.png","wx_1.png","wx_2.png","wx_3.png","wx_4.png","wx_5.png","wx_6.png","wx_7.png","wx_8.png","wx_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'dot_1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HRV,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 196,
              y: 300,
              w: 52,
              h: 24,
              font_array: ["hr_b_0.png","hr_b_1.png","hr_b_2.png","hr_b_3.png","hr_b_4.png","hr_b_5.png","hr_b_6.png","hr_b_7.png","hr_b_8.png","hr_b_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'dot_1.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 20,
              y: 297,
              image_array: ["pulse_1.png","pulse_2.png","pulse_3.png","pulse_4.png","pulse_5.png","pulse_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 115,
              y: 341,
              font_array: ["wx_0.png","wx_1.png","wx_2.png","wx_3.png","wx_4.png","wx_5.png","wx_6.png","wx_7.png","wx_8.png","wx_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 69,
              y: 341,
              font_array: ["wx_0.png","wx_1.png","wx_2.png","wx_3.png","wx_4.png","wx_5.png","wx_6.png","wx_7.png","wx_8.png","wx_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // PAI row: day value left-aligned next to icon, slash and weekly value follow its width
            const paiSlashNormal = hmUI.createWidget(hmUI.widget.IMG, { x: 90, y: 342, w: 10, h: 27, src: 'slash_pai.png', show_level: hmUI.show_level.ONLY_NORMAL });
            const paiSlashIdle = hmUI.createWidget(hmUI.widget.IMG, { x: 90, y: 342, w: 10, h: 27, src: 'slash_pai.png', show_level: hmUI.show_level.ONLY_AOD });
            let paiSensor = null;
            try { paiSensor = hmSensor.createSensor(hmSensor.id.PAI); } catch (e) { paiSensor = null; }


            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 229,
              y: 341,
              font_array: ["wx_0.png","wx_1.png","wx_2.png","wx_3.png","wx_4.png","wx_5.png","wx_6.png","wx_7.png","wx_8.png","wx_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // ===== One row: PAI (day / weekly) + flame + calories. All positions are computed together so nothing overlaps =====
            // Digit cell = 14px + h_space. The "kCal" label (background image) starts at x=271, PAI icon ends at x=64.
            const ACT_FONT = ["wx_0.png","wx_1.png","wx_2.png","wx_3.png","wx_4.png","wx_5.png","wx_6.png","wx_7.png","wx_8.png","wx_9.png"];
            function digitsOf(v) { v = Math.round(Number(v) || 0); if (v < 0) v = 0; return String(v).length; }
            function computeRowLayout(nd, nw, nc) {
              // tiers: normal spacing -> tighter spacing -> tighter spacing without the flame icon
              const tiers = [
                { h: 1, R: 266, gap: 6, flame: true },
                { h: 0, R: 265, gap: 3, flame: true },
                { h: 0, R: 265, gap: 0, flame: false },
              ];
              let L = null;
              for (let t = 0; t < tiers.length; t++) {
                const T = tiers[t];
                const cell = 14 + T.h;
                const slashX = 69 + 14 * nd + 3;
                const weeklyX = slashX + 11;
                const paiEnd = weeklyX + cell * nw;
                const numX = T.R - cell * nc;
                const flameX = numX - T.gap - 18;
                const left = T.flame ? flameX : numX;
                L = { h: T.h, slashX: slashX, weeklyX: weeklyX, numX: numX, flameX: flameX, flame: T.flame };
                if (left >= paiEnd + 3) break;
              }
              return L;
            }
            function updateRowLayout() {
              let nd = 2, nw = 3, nc = 2;
              try { if (paiSensor && typeof paiSensor.dailypai !== 'undefined') nd = digitsOf(paiSensor.dailypai); } catch (e) {}
              try { if (paiSensor && typeof paiSensor.totalpai !== 'undefined') nw = digitsOf(paiSensor.totalpai); } catch (e) {}
              try { nc = digitsOf(calSensor.current); } catch (e) {}
              const L = computeRowLayout(nd, nw, nc);
              paiSlashNormal.setProperty(hmUI.prop.MORE, { x: L.slashX - 1, y: 342, w: 10, h: 27, src: 'slash_pai.png' });
              paiSlashIdle.setProperty(hmUI.prop.MORE, { x: L.slashX - 1, y: 342, w: 10, h: 27, src: 'slash_pai.png' });
              normal_pai_weekly_text_img.setProperty(hmUI.prop.MORE, { x: L.weeklyX, y: 341, font_array: ACT_FONT, padding: false, h_space: L.h, align_h: hmUI.align.LEFT, type: hmUI.data_type.PAI_WEEKLY, show_level: hmUI.show_level.ONLY_NORMAL });
              idle_pai_weekly_text_img.setProperty(hmUI.prop.MORE, { x: L.weeklyX, y: 341, font_array: ACT_FONT, padding: false, h_space: L.h, align_h: hmUI.align.LEFT, type: hmUI.data_type.PAI_WEEKLY, show_level: hmUI.show_level.ONLY_AOD });
              normal_calorie_current_text_img.setProperty(hmUI.prop.MORE, { x: L.numX, y: 341, font_array: ACT_FONT, padding: false, h_space: L.h, align_h: hmUI.align.LEFT, type: hmUI.data_type.CAL, show_level: hmUI.show_level.ONLY_NORMAL });
              idle_calorie_current_text_img.setProperty(hmUI.prop.MORE, { x: L.numX, y: 341, font_array: ACT_FONT, padding: false, h_space: L.h, align_h: hmUI.align.LEFT, type: hmUI.data_type.CAL, show_level: hmUI.show_level.ONLY_AOD });
              flameNormal.setProperty(hmUI.prop.X, L.flameX);
              flameIdle.setProperty(hmUI.prop.X, L.flameX);
              flameNormal.setProperty(hmUI.prop.VISIBLE, L.flame);
              flameIdle.setProperty(hmUI.prop.VISIBLE, L.flame);
            }
            updateRowLayout();
            if (paiSensor) { try { paiSensor.addEventListener(hmSensor.event.CHANGE, updateRowLayout); } catch (e) {} }
            calSensor.addEventListener(hmSensor.event.CHANGE, updateRowLayout);

            // ===== Heart row: [graph] [heart + BPM] [max/min badge  max / min] ......... [HRv label + value] [HRv icon] =====
            // Heart icon, HRv label and the max/min badge are separate widgets (not baked into the background) so they can move with the digit count.
            // Digit cell of the small font = 14px + h_space, big BPM font cell = 22px + 1.
            const HR_X0 = 196;          // left edge of the BPM number (heart icon sits just before it, right after the graph)
            const HR_BIG_CELL = 16;
            const HRV_LEFT = 383;       // left edge of the HRv number (3 digits, centered on x=406 together with the HRv label)
            const heartIconN = hmUI.createWidget(hmUI.widget.IMG, { x: 174, y: 304, w: 20, h: 18, src: 'heart_hr.png', show_level: hmUI.show_level.ONLY_NORMAL });
            const heartIconA = hmUI.createWidget(hmUI.widget.IMG, { x: 174, y: 304, w: 20, h: 18, src: 'heart_hr.png', show_level: hmUI.show_level.ONLY_AOD });
            hmUI.createWidget(hmUI.widget.IMG, { x: 389, y: 290, w: 34, h: 11, src: 'hrv_label.png', show_level: hmUI.show_level.ONLY_NORMAL });
            hmUI.createWidget(hmUI.widget.IMG, { x: 389, y: 290, w: 34, h: 11, src: 'hrv_label.png', show_level: hmUI.show_level.ONLY_AOD });

            function mkMM(level) {
              return {
                icon: hmUI.createWidget(hmUI.widget.IMG, { x: 250, y: 299, w: 28, h: 26, src: 'hr_mm.png', show_level: level }),
                max: hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 280, y: 300, w: 48, h: 24, font_array: ACT_FONT, padding: false, h_space: 0, align_h: hmUI.align.LEFT, text: '0', show_level: level }),
                slash: hmUI.createWidget(hmUI.widget.IMG, { x: 330, y: 301, w: 10, h: 27, src: 'slash_pai.png', show_level: level }),
                min: hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 341, y: 300, w: 48, h: 24, font_array: ACT_FONT, padding: false, h_space: 0, align_h: hmUI.align.LEFT, text: '0', show_level: level }),
              };
            }
            const mmN = mkMM(hmUI.show_level.ONLY_NORMAL);
            const mmA = mkMM(hmUI.show_level.ONLY_AOD);

            let hrSensor = null;
            try { hrSensor = hmSensor.createSensor(hmSensor.id.HEART); } catch (e) { hrSensor = null; }

            function hrMinMax() {
              let mx = 0, mn = 0;
              try {
                const arr = hrSensor && hrSensor.today;
                if (arr && arr.length) {
                  mn = 999;
                  for (let i = 0; i < arr.length; i++) {
                    const v = arr[i];
                    if (v > 0 && v < 255) { if (v > mx) mx = v; if (v < mn) mn = v; }
                  }
                  if (mn === 999) mn = 0;
                }
              } catch (e) { mx = 0; mn = 0; }
              return { mx: mx, mn: mn };
            }

            function updateHrMinMax() {
              let nh = 2;
              try { if (hrSensor && hrSensor.last >= 100) nh = 3; } catch (e) {}
              const r = hrMinMax();
              const nmx = Math.max(2, digitsOf(r.mx)), nmn = Math.max(2, digitsOf(r.mn));
              const bigEnd = HR_X0 + HR_BIG_CELL * nh;
              const x0 = bigEnd + 7;
              // order: icon, MIN, slash, MAX. Widths use the visible ink (last digit ends ~2px before its cell).
              // The icon is dropped only if even a 3-digit HRv number (ink starts at ~386) would be touched.
              let useIcon = true;
              let end = x0 + 28 + 2 + 14 * nmn + 3 + 11 + 14 * nmx - 2;
              if (end > HRV_LEFT + 1) useIcon = false;
              const minX = useIcon ? x0 + 30 : x0 + 3;
              const slashX = minX + 14 * nmn + 3;
              const maxX = slashX + 11;
              [mmN, mmA].forEach(function (w) {
                const lvl = (w === mmN) ? hmUI.show_level.ONLY_NORMAL : hmUI.show_level.ONLY_AOD;
                w.icon.setProperty(hmUI.prop.X, x0);
                w.icon.setProperty(hmUI.prop.VISIBLE, useIcon);
                w.min.setProperty(hmUI.prop.MORE, { x: minX, y: 300, w: 14 * nmn + 4, h: 24, font_array: ACT_FONT, padding: false, h_space: 0, align_h: hmUI.align.LEFT, text: String(r.mn), show_level: lvl });
                w.slash.setProperty(hmUI.prop.X, slashX - 1);
                w.max.setProperty(hmUI.prop.MORE, { x: maxX, y: 300, w: 14 * nmx + 4, h: 24, font_array: ACT_FONT, padding: false, h_space: 0, align_h: hmUI.align.LEFT, text: String(r.mx), show_level: lvl });
              });
            }
            updateHrMinMax();
            if (hrSensor) { try { hrSensor.addEventListener(hmSensor.event.LAST, updateHrMinMax); } catch (e) {} }

            idle_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 302,
              w: 82,
              y: 341,
              font_array: ["wx_0.png","wx_1.png","wx_2.png","wx_3.png","wx_4.png","wx_5.png","wx_6.png","wx_7.png","wx_8.png","wx_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 298,
              y: 64,
              font_array: ["wx_0.png","wx_1.png","wx_2.png","wx_3.png","wx_4.png","wx_5.png","wx_6.png","wx_7.png","wx_8.png","wx_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 266,
              // start_y: 434,
              // color: 0xFF40FD91,
              // lenght: 56,
              // line_width: 22,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 135,
              y: 432,
              w: 60,
              font_array: ["wx_0.png","wx_1.png","wx_2.png","wx_3.png","wx_4.png","wx_5.png","wx_6.png","wx_7.png","wx_8.png","wx_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210,
              y: 376,
              font_array: ["wx_0.png","wx_1.png","wx_2.png","wx_3.png","wx_4.png","wx_5.png","wx_6.png","wx_7.png","wx_8.png","wx_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'dot.png',
              unit_tc: 'dot.png',
              unit_en: 'dot.png',
              imperial_unit_sc: 'dot.png',
              imperial_unit_tc: 'dot.png',
              imperial_unit_en: 'dot.png',
              dot_image: 'pointerp_6.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            idle_step_linear_scale_pointer_img = hmUI.createWidget(hmUI.widget.IMG);
            // idle_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 82,
              // start_y: 407,
              // color: 0xFFB0D8FF,
              // pointer: 'pointer_5.png',
              // lenght: 318,
              // line_width: 9,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 322,
              y: 376,
              font_array: ["wx_0.png","wx_1.png","wx_2.png","wx_3.png","wx_4.png","wx_5.png","wx_6.png","wx_7.png","wx_8.png","wx_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP_TARGET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 376,
              font_array: ["wx_0.png","wx_1.png","wx_2.png","wx_3.png","wx_4.png","wx_5.png","wx_6.png","wx_7.png","wx_8.png","wx_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 15,
              hour_startY: 178,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_unit_sc: 'pointer_0.png',
              hour_unit_tc: 'pointer_0.png',
              hour_unit_en: 'pointer_0.png',
              hour_align: hmUI.align.RIGHT,

              minute_startX: 208,
              minute_startY: 178,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 377,
              second_startY: 228,
              second_array: ["sec_0.png","sec_1.png","sec_2.png","sec_3.png","sec_4.png","sec_5.png","sec_6.png","sec_7.png","sec_8.png","sec_9.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 70,
              y: 371,
              w: 100,
              h: 35,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 70,
              y: 337,
              w: 100,
              h: 35,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PAI_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 170,
              y: 297,
              w: 210,
              h: 35,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 380,
              y: 297,
              w: 80,
              h: 35,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1047865, url: 'page/round/index' });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 370,
              y: 174,
              w: 32,
              h: 35,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 405,
              y: 174,
              w: 32,
              h: 35,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Sleep_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 250,
              y: 128,
              w: 202,
              h: 35,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 50,
              y: 131,
              w: 160,
              h: 35,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region weather_few_days
            function weather_few_days() {
              console.log('weather_few_days()');
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;
              let result = {graphScale: 1, maximal_temp: 0};
              let averageOldX = 0;

              if (screenType == hmSetting.screen_type.AOD) result = graphScale(28, 0, 0, forecastData.data, 7);
              if (screenType == hmSetting.screen_type.AOD) {
                idle_canvas1.clear({x: 0, y:0, w: 0, h: 0});
                idle_canvas2.clear({x: 0, y:0, w: 480, h: 480});
              };
              let idle_average_offsetX = 9;
              if (screenType == hmSetting.screen_type.AOD) averageOldX = idle_average_offsetX;
              if (screenType == hmSetting.screen_type.WATCHFACE) result = graphScale(28, 0, 0, forecastData.data, 7);
              let forecastGraphScale = result.graphScale;
              let maximal_temp = result.maximal_temp;
              console.log(`forecastGraphScale = ${forecastGraphScale}, maximal_temp = ${maximal_temp}`);

              if (screenType == hmSetting.screen_type.WATCHFACE) {
                normal_canvas1.clear({x: 0, y:0, w: 0, h: 0});
                normal_canvas2.clear({x: 0, y:0, w: 480, h: 480});
              };
              let normal_average_offsetX = 9;
              if (screenType == hmSetting.screen_type.WATCHFACE) averageOldX = normal_average_offsetX;
              let averageOldY = (maximal_temp - (forecastData.data[0].high + forecastData.data[0].low) / 2) * forecastGraphScale + 0;
              let endPointAverage = false;
              for (let i = 0; i < 7; i++) {
                // Graph
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (i < forecastData.count) {
                    let averageStartX = averageOldX;
                    let averageStartY = averageOldY;
                    averageOldX = normal_average_offsetX + i * 30;
                    averageOldY = (maximal_temp - (forecastData.data[i].high + forecastData.data[i].low) / 2) * forecastGraphScale + 0;
                    let averageEndX = averageOldX;
                    let averageEndY = averageOldY;
                    if (averageStartX != averageEndX) {
                      drawLine(normal_canvas1, normal_canvas2, averageStartX, averageStartY, averageEndX, averageEndY, 0xFFFFFFFF, 3)
                      drawGraphPoint(normal_canvas1, normal_canvas2, averageStartX, averageStartY, 0xFFFFFFFF, 12, 0)
                      endPointAverage = true;
                    };
                  
                  };
                };  // end screen_type
                
                // Graph
                if (screenType == hmSetting.screen_type.AOD) {
                  if (i < forecastData.count) {
                    let averageStartX = averageOldX;
                    let averageStartY = averageOldY;
                    averageOldX = idle_average_offsetX + i * 30;
                    averageOldY = (maximal_temp - (forecastData.data[i].high + forecastData.data[i].low) / 2) * forecastGraphScale + 0;
                    let averageEndX = averageOldX;
                    let averageEndY = averageOldY;
                    if (averageStartX != averageEndX) {
                      drawLine(idle_canvas1, idle_canvas2, averageStartX, averageStartY, averageEndX, averageEndY, 0xFFFFFFFF, 3)
                      drawGraphPoint(idle_canvas1, idle_canvas2, averageStartX, averageStartY, 0xFFFFFFFF, 12, 0)
                      endPointAverage = true;
                    };
                  
                  };
                };  // end screen_type
                
              };  // end for

              if (screenType == hmSetting.screen_type.WATCHFACE && endPointAverage) {
                drawGraphPoint(normal_canvas1, normal_canvas2, averageOldX, averageOldY, 0xFFFFFFFF, 12, 0)
              };
              if (screenType == hmSetting.screen_type.WATCHFACE && endPointAverage) {
                drawGraphPoint(normal_canvas1, normal_canvas2, averageOldX, averageOldY, 0xFFFFFFFF, 12, 0)
              };
            };
            //#endregion

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let normal_cityNameStr = weatherData.cityName;
              normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 252;
                  let start_y_normal_battery = 435;
                  let lenght_ls_normal_battery = 56;
                  let line_width_ls_normal_battery = 22;
                  let color_ls_normal_battery = 0xFF40FD91;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 82;
                  let start_y_normal_step = 407;
                  let lenght_ls_normal_step = 318;
                  let line_width_ls_normal_step = 9;
                  let color_ls_normal_step = 0xFFB0D8FF;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = lenght_ls_normal_step;
                  let line_width_ls_normal_step_draw = line_width_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    lenght_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_normal_step = 3;
                  let pointer_offset_y_ls_normal_step = 10;
                  normal_step_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step + lenght_ls_normal_step - pointer_offset_x_ls_normal_step,
                    y: start_y_normal_step_draw + line_width_ls_normal_step / 2 - pointer_offset_y_ls_normal_step,
                    src: 'pointer_5.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

              console.log('Weather city name');
              let idle_cityNameStr = weatherData.cityName;
              idle_city_name_text.setProperty(hmUI.prop.TEXT, idle_cityNameStr);

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 252;
                  let start_y_idle_battery = 435;
                  let lenght_ls_idle_battery = 56;
                  let line_width_ls_idle_battery = 22;
                  let color_ls_idle_battery = 0xFF40FD91;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

                console.log('update scales STEP');
                let progress_ls_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_linear_scale
                  // initial parameters
                  let start_x_idle_step = 82;
                  let start_y_idle_step = 407;
                  let lenght_ls_idle_step = 318;
                  let line_width_ls_idle_step = 9;
                  let color_ls_idle_step = 0xFFB0D8FF;
                  
                  // calculated parameters
                  let start_x_idle_step_draw = start_x_idle_step;
                  let start_y_idle_step_draw = start_y_idle_step;
                  lenght_ls_idle_step = lenght_ls_idle_step * progress_ls_idle_step;
                  let lenght_ls_idle_step_draw = lenght_ls_idle_step;
                  let line_width_ls_idle_step_draw = line_width_ls_idle_step;
                  if (lenght_ls_idle_step < 0){
                    lenght_ls_idle_step_draw = -lenght_ls_idle_step;
                    start_x_idle_step_draw = start_x_idle_step - lenght_ls_idle_step_draw;
                  };
                  
                  idle_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_step_draw,
                    y: start_y_idle_step_draw,
                    w: lenght_ls_idle_step_draw,
                    h: line_width_ls_idle_step_draw,
                    color: color_ls_idle_step,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_idle_step = 3;
                  let pointer_offset_y_ls_idle_step = 10;
                  idle_step_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_step + lenght_ls_idle_step - pointer_offset_x_ls_idle_step,
                    y: start_y_idle_step_draw + line_width_ls_idle_step / 2 - pointer_offset_y_ls_idle_step,
                    src: 'pointer_5.png',
                    show_level: hmUI.show_level.ONLY_AOD,
                  });
                };

            };

            //#region sun_bar_dynamic
            // Δυναμική μπάρα ημέρας/νύχτας: ολόκληρη η μπάρα = 24 ώρες.
            // Καφέ = από ανατολή έως δύση (υπολογίζεται κάθε μέρα), μαύρο = νύχτα.
            // Λευκός δείκτης = η τρέχουσα ώρα πάνω στην ίδια κλίμακα.
            const SUN_TRACK_X = 97;     // αρχή της μπάρας (00:00)
            const SUN_TRACK_W = 287;    // πλάτος της μπάρας (24 ώρες)
            const SUN_BAR_Y = 51;       // ύψος καφέ ζώνης
            const SUN_BAR_H = 8;
            const SUN_MARK_Y = 45;      // ύψος δείκτη
            const SUN_MARK_H = 19;
            const SUN_MARK_W = 4;
            const SUN_DAY_COLOR = 0xB0D8FF;   // ίδιο γαλάζιο με την κάτω μπάρα
            const SUN_MARK_COLOR = 0xFF1A1A;  // έντονο κόκκινο: φαίνεται και πάνω στο γαλάζιο και στο μαύρο
            const sunLevel = (screenType == hmSetting.screen_type.AOD) ? hmUI.show_level.ONLY_AOD : hmUI.show_level.ONLY_NORMAL;
            const sunTimeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let sunDayBand = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: SUN_TRACK_X, y: SUN_BAR_Y, w: 1, h: SUN_BAR_H,
              color: SUN_DAY_COLOR,
              show_level: sunLevel,
            });
            sunDayBand.setProperty(hmUI.prop.VISIBLE, false);
            let sunMarker = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: SUN_TRACK_X, y: SUN_MARK_Y, w: SUN_MARK_W, h: SUN_MARK_H,
              radius: 2,
              color: SUN_MARK_COLOR,
              show_level: sunLevel,
            });
            // Κρύβουμε την παλιά στατική εικόνα-δείκτη
            let sunBarOrig = (screenType == hmSetting.screen_type.AOD) ? idle_sun_image_progress_img_level : normal_sun_image_progress_img_level;
            try { if (sunBarOrig) sunBarOrig.setProperty(hmUI.prop.VISIBLE, false); } catch (e) {}

            function sunToX(minutes) {
              return SUN_TRACK_X + Math.round(minutes / 1440 * SUN_TRACK_W);
            }

            function updateSunBar() {
              try {
                let now = sunTimeSensor.hour * 60 + sunTimeSensor.minute;
                let mx = sunToX(now) - Math.floor(SUN_MARK_W / 2);
                sunMarker.setProperty(hmUI.prop.MORE, {
                  x: mx, y: SUN_MARK_Y, w: SUN_MARK_W, h: SUN_MARK_H, radius: 2, color: SUN_MARK_COLOR,
                });
                let wd = weatherSensor.getForecastWeather();
                let t = wd && wd.tideData && wd.tideData.data && wd.tideData.data[0];
                if (!t || !t.sunrise || !t.sunset) { sunDayBand.setProperty(hmUI.prop.VISIBLE, false); return; }
                let rise = t.sunrise.hour * 60 + t.sunrise.minute;
                let set = t.sunset.hour * 60 + t.sunset.minute;
                if (set <= rise) { sunDayBand.setProperty(hmUI.prop.VISIBLE, false); return; }
                let x1 = sunToX(rise);
                let x2 = sunToX(set);
                if (x2 - x1 < 1) x2 = x1 + 1;
                sunDayBand.setProperty(hmUI.prop.MORE, {
                  x: x1, y: SUN_BAR_Y, w: x2 - x1, h: SUN_BAR_H, color: SUN_DAY_COLOR,
                });
                sunDayBand.setProperty(hmUI.prop.VISIBLE, true);
              } catch (e) {
                console.log('updateSunBar error', e);
              }
            }
            //#region time_format_icon
            // Εικονίδιο ανάμεσα στη θερμοκρασία και την ημερομηνία: AM / PM (12ωρο) ή 24h (24ωρο)
            const TF_ICON_X = 177;
            const TF_ICON_Y = 130;
            let tfAm = hmUI.createWidget(hmUI.widget.IMG, { x: TF_ICON_X, y: TF_ICON_Y, src: 'tf_am.png', show_level: sunLevel });
            let tfPm = hmUI.createWidget(hmUI.widget.IMG, { x: TF_ICON_X, y: TF_ICON_Y, src: 'tf_pm.png', show_level: sunLevel });
            let tf24 = hmUI.createWidget(hmUI.widget.IMG, { x: TF_ICON_X, y: TF_ICON_Y, src: 'tf_24h.png', show_level: sunLevel });
            let tfIs24Cache = null;

            function timeIs24() {
              try {
                // Στις ώρες 0 και 13-23 το 12ωρο και το 24ωρο διαφέρουν, άρα η ένδειξη είναι σίγουρη
                let h = sunTimeSensor.hour;
                let f = sunTimeSensor.format_hour;
                if (typeof f === 'number' && (h === 0 || h > 12)) tfIs24Cache = (f === h);
              } catch (e) {}
              if (tfIs24Cache !== null) return tfIs24Cache;
              try {
                if (typeof hmSetting.getTimeFormat === 'function') return hmSetting.getTimeFormat() === 1;
              } catch (e) {}
              return true;
            }

            function updateTimeFormatIcon() {
              try {
                let is24 = timeIs24();
                let isPm = sunTimeSensor.hour >= 12;
                tf24.setProperty(hmUI.prop.VISIBLE, is24);
                tfAm.setProperty(hmUI.prop.VISIBLE, !is24 && !isPm);
                tfPm.setProperty(hmUI.prop.VISIBLE, !is24 && isPm);
              } catch (e) {
                console.log('updateTimeFormatIcon error', e);
              }
            }
            //#endregion

            updateTimeFormatIcon();
            updateSunBar();
            sunTimeSensor.addEventListener(sunTimeSensor.event.MINUTEEND, function () { updateSunBar(); updateTimeFormatIcon(); try { updateHrMinMax(); } catch (e) {} });
            //#endregion

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                updateSunBar();
                updateTimeFormatIcon();
                try { updateHrMinMax(); } catch (e) {}

                weather_few_days();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}