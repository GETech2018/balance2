﻿
    /*
    ** Watch_Face_Editor tool v 18.2
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start
      
        let normal_background_bg_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_image_img = ''
        let normal_step_current_text_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let idle_image_img = ''
        let idle_step_current_text_img = ''
        let idle_step_pointer_progress_img_pointer = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let image_top_img = ''

        // =====================================================
        // STEP POINTER - ANGLE SETTINGS
        // =====================================================

        // Starting angle when the step count is 0%
        // มุมเริ่มต้นของเข็มเมื่อจำนวนก้าวเท่ากับ 0%
        const STEP_START_ANGLE = 304;

        // Target angle when the step count reaches 100%
        // มุมของเข็มเมื่อเดินครบเป้าหมาย 100%
        const STEP_GOAL_ANGLE = 379;

        // Maximum angle when the step count reaches 140%
        // มุมสูงสุดของเข็มเมื่อเดินถึง 140% ของเป้าหมาย
        const STEP_MAX_ANGLE = 409;

        // Maximum progress ratio used for pointer calculation
        // กำหนดขีดจำกัดการคำนวณไว้ที่ 140% (1.4 เท่าของเป้าหมาย)
        const STEP_MAX_RATIO = 1.4;


        // =====================================================
        // STEP SENSOR AND EVENT VARIABLES
        // =====================================================

        // STEP Sensor instance
        // ตัวแปรสำหรับอ่านจำนวนก้าวปัจจุบันและเป้าหมายจำนวนก้าว
        let stepSensor = null;

        // STEP Sensor CHANGE Event Listener
        // ตัวแปรเก็บฟังก์ชันที่จะทำงานเมื่อข้อมูลจำนวนก้าวเปลี่ยนแปลง
        let stepChangeListener = null;


        // =====================================================
        // FUNCTION: CALCULATE STEP POINTER ANGLE
        // =====================================================

        // Calculate the pointer angle according to step progress
        // คำนวณมุมของเข็มตามเปอร์เซ็นต์ความคืบหน้าของจำนวนก้าว
        function getStepPointerAngle() {

            // Check whether the STEP Sensor has been created
            // หากยังไม่มี Sensor ให้คืนค่ามุมเริ่มต้น
            if (!stepSensor) {
                return STEP_START_ANGLE;
            }

            // Get the current step count
            // อ่านจำนวนก้าวปัจจุบัน
            const current = stepSensor.current || 0;

            // Get the target step count
            // อ่านจำนวนก้าวเป้าหมาย
            const target = stepSensor.target || 0;

            // Prevent division by zero
            // ป้องกันการหารด้วยศูนย์ หากเป้าหมายเป็น 0 ให้ใช้มุมเริ่มต้น
            if (target <= 0) {
                return STEP_START_ANGLE;
            }

            // Calculate step progress ratio
            // ตัวอย่าง 0.5 = 50%, 1.0 = 100%, 1.4 = 140%
            const progress = current / target;

            let angle;

            // -------------------------------------------------
            // STAGE 1: FROM 0% TO 100% STEP GOAL
            // -------------------------------------------------

            // Calculate the angle from 304° to 379°
            // เมื่อจำนวนก้าวเพิ่มขึ้น เข็มจะเคลื่อนตามสัดส่วนความคืบหน้า
            if (progress <= 1) {

                angle = STEP_START_ANGLE +
                    (STEP_GOAL_ANGLE - STEP_START_ANGLE) * progress;

            }

            // -------------------------------------------------
            // STAGE 2: ABOVE 100% UP TO 150% STEP GOAL
            // -------------------------------------------------

            // Continue moving the pointer beyond the 100% goal
            // เมื่อเดินเกินเป้าหมาย 100% เข็มจะเคลื่อนต่อไปจนถึง 150%
            else {

                // Calculate progress beyond the 100% goal
                //
                // 100% = 0
                // 125% = 0.5
                // 150% = 1
                //
                // Math.min() limits the maximum value to 1
                // จำกัดค่าสูงสุดไว้ที่ 1 เพื่อไม่ให้เข็มเกินมุม 397°
                const extraProgress = Math.min(
                    (progress - 1) / (STEP_MAX_RATIO - 1),
                    1
                );

                // Calculate the additional angle from 379° to 397°
                // คำนวณมุมเพิ่มเติมจาก 379° ไปจนถึง 397°
                angle = STEP_GOAL_ANGLE +
                    (STEP_MAX_ANGLE - STEP_GOAL_ANGLE) * extraProgress;
            }

            // Return the calculated pointer angle
            // ส่งคืนมุมที่คำนวณได้
            return angle;
        }


        // =====================================================
        // FUNCTION: UPDATE STEP POINTER POSITION
        // =====================================================

        // Update the STEP Pointer position
        // อัปเดตตำแหน่งเข็มตามจำนวนก้าวปัจจุบัน
        function updateStepPointer() {

            // Check whether the STEP Pointer Widget exists
            // ตรวจสอบว่า STEP Pointer ถูกสร้างแล้วหรือไม่
            if (!normal_step_pointer_progress_img_pointer) {
                return;
            }

            // Get the newly calculated pointer angle
            // เรียกฟังก์ชันคำนวณมุมของเข็ม
            const angle = getStepPointerAngle();

            // Update the IMG rotation angle without recreating the Widget
            // เปลี่ยนมุมของ IMG โดยไม่ต้องลบและสร้าง Widget ใหม่
            // hmUI.prop.MORE is used to update the angle property
            // ใช้ hmUI.prop.MORE เพื่ออัปเดตค่า angle
            normal_step_pointer_progress_img_pointer.setProperty(
                hmUI.prop.MORE,
                {
                    angle: angle
                }
            );

            // Display diagnostic information in the Console
            // แสดงข้อมูลสำหรับตรวจสอบการทำงานใน Console
            console.log(
                'STEP: ' + stepSensor.current +
                ' / ' + stepSensor.target +
                ' ANGLE: ' + angle
            );
        }


        //dynamic modify end


        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

            init_view() {
                //dynamic modify start                    
                
                console.log('Watch_Face.ScreenNormal');
                
                normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
                  x: 0,
                  y: 0,
                  w: 480,
                  h: 480,
                  src: 'Honda_70s.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
                  day_startX: 163,
                  day_startY: 57,
                  day_sc_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png"],
                  day_tc_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png"],
                  day_en_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png"],
                  day_zero: 1,
                  day_space: 0,
                  day_align: hmUI.align.CENTER_H,
                  day_is_character: false,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                  hour_startX: 215,
                  hour_startY: 57,
                  hour_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png"],
                  hour_zero: 1,
                  hour_space: 0,
                  hour_angle: 0,
                  hour_align: hmUI.align.CENTER_H,

                  minute_startX: 267,
                  minute_startY: 57,
                  minute_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png"],
                  minute_zero: 1,
                  minute_space: 0,
                  minute_angle: 0,
                  minute_follow: 0,
                  minute_align: hmUI.align.CENTER_H,

                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
                  x: 0,
                  y: 0,
                  src: 'Honda_70s2.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 138,
                  y: 271,
                  font_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png"],
                  padding: true,
                  h_space: 0,
                  align_h: hmUI.align.RIGHT,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // =====================================================
                // CREATE STEP SENSOR
                // =====================================================

                // Create the STEP Sensor
                // สร้าง STEP Sensor เพื่ออ่านจำนวนก้าวปัจจุบันและเป้าหมาย
                stepSensor = hmSensor.createSensor(hmSensor.id.STEP);


                // =====================================================
                // CREATE STEP POINTER USING IMG
                // =====================================================

                // Use IMG instead of IMG_POINTER
                // ใช้ IMG แทน IMG_POINTER เพื่อควบคุมมุมการหมุนด้วย angle
                //
                // x, y       = Widget starting position
                //              ตำแหน่งเริ่มต้นของ Widget
                // w, h       = Widget dimensions
                //              ขนาด Widget
                // pos_x      = Image horizontal position
                //              ตำแหน่งรูปภาพในแนวนอน
                // pos_y      = Image vertical position
                //              ตำแหน่งรูปภาพในแนวตั้ง
                // center_x   = Rotation center X coordinate
                //              จุดศูนย์กลางการหมุนในแนวนอน
                // center_y   = Rotation center Y coordinate
                //              จุดศูนย์กลางการหมุนในแนวตั้ง
                // src        = Pointer image file
                //              ไฟล์รูปภาพเข็ม
                // angle      = Initial rotation angle
                //              มุมเริ่มต้นที่คำนวณจาก STEP Sensor

                normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG, {                                       
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,

                    pos_x: 218 - 20,
                    pos_y: 360 - 230,

                    center_x: 218,
                    center_y: 360,

                    src: 'steps.png',
                    angle: getStepPointerAngle(),

                    show_level: hmUI.show_level.ONLY_NORMAL,                    
                });


                // =====================================================
                // STEP SENSOR CHANGE EVENT
                // =====================================================

                // Define the function to run when step data changes
                // กำหนดฟังก์ชันที่จะทำงานเมื่อข้อมูลจำนวนก้าวเปลี่ยนแปลง
                stepChangeListener = function () {

                    // Recalculate and update the pointer angle
                    // คำนวณมุมใหม่และอัปเดตตำแหน่งเข็ม
                    updateStepPointer();
                };

                // Register the CHANGE Event Listener
                // ลงทะเบียน Event เพื่อตรวจจับการเปลี่ยนแปลงของ STEP Sensor
                stepSensor.addEventListener(
                    hmSensor.event.CHANGE,
                    stepChangeListener
                );

                // Update the pointer immediately after Widget creation
                // อัปเดตตำแหน่งเข็มทันทีหลังสร้าง Widget
                // so the current step count is displayed without waiting
                // เพื่อแสดงจำนวนก้าวปัจจุบันโดยไม่ต้องรอ Event ครั้งแรก
                updateStepPointer();


                // =====================================================
                // BATTERY POINTER
                // =====================================================

                normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'bat.png',
                  center_x: 357,
                  center_y: 370,
                  x: 6,
                  y: 99,
                  start_angle: 324,
                  end_angle: 395,
                  invalid_visible: false,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });


                console.log('Watch_Face.ScreenAOD');
                
                idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
                  x: 0,
                  y: 0,
                  w: 480,
                  h: 480,
                  src: 'Honda_70s.png',
                  show_level: hmUI.show_level.ONLY_AOD,
                });

                idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
                  day_startX: 163,
                  day_startY: 57,
                  day_sc_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png"],
                  day_tc_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png"],
                  day_en_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png"],
                  day_zero: 1,
                  day_space: 0,
                  day_align: hmUI.align.CENTER_H,
                  day_is_character: false,
                  show_level: hmUI.show_level.ONLY_AOD,
                });

                idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                  hour_startX: 215,
                  hour_startY: 57,
                  hour_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png"],
                  hour_zero: 1,
                  hour_space: 0,
                  hour_angle: 0,
                  hour_align: hmUI.align.CENTER_H,

                  minute_startX: 267,
                  minute_startY: 57,
                  minute_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png"],
                  minute_zero: 1,
                  minute_space: 0,
                  minute_angle: 0,
                  minute_follow: 0,
                  minute_align: hmUI.align.CENTER_H,

                  show_level: hmUI.show_level.ONLY_AOD,
                });

                idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
                  x: 0,
                  y: 0,
                  src: 'Honda_70s2.png',
                  show_level: hmUI.show_level.ONLY_AOD,
                });

                idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 138,
                  y: 271,
                  font_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png"],
                  padding: true,
                  h_space: 0,
                  align_h: hmUI.align.RIGHT,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_AOD,
                });

                idle_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,

                    pos_x: 218 - 20,
                    pos_y: 360 - 193,

                    center_x: 218,
                    center_y: 360,

                    src: 'steps.png',
                    angle: getStepPointerAngle(),

                    show_level: hmUI.show_level.ONLY_AOD,
                });

                idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'bat.png',
                  center_x: 357,
                  center_y: 370,
                  x: 6,
                  y: 99,
                  start_angle: 324,
                  end_angle: 395,
                  invalid_visible: false,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_AOD,
                });

                image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
                  x: 0,
                  y: 0,
                  src: 'Honda_70s3.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });


                  
hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
    resume_call: function() {
        updateStepPointer();
    },

    pause_call: function() {
        // ...
    }
});
                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                
                // =====================================================
                // STEP SENSOR CLEANUP
                // =====================================================

                // Remove the CHANGE Event Listener when leaving the Watch Face
                // ยกเลิก Event Listener เมื่อออกจากหน้าปัด
                // to prevent callbacks after the page has been destroyed
                // ป้องกัน Sensor เรียกฟังก์ชันหลังจากหน้าปัดถูกทำลาย
                if (stepSensor && stepChangeListener) {
                    stepSensor.removeEventListener(
                        hmSensor.event.CHANGE,
                        stepChangeListener
                    );
                }
                
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}