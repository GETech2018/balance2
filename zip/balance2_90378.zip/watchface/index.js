    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        
        //dynamic modify start
        let __wf_dummy = 0;
        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
            const NORMAL = hmUI.show_level.ONLY_NORMAL;
            const AOD = hmUI.show_level.ONLY_AOD;
            const DIG = ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"];
            const BIG = ["digits_big=0.png","digits_big=1.png","digits_big=2.png","digits_big=3.png","digits_big=4.png","digits_big=5.png","digits_big=6.png","digits_big=7.png","digits_big=8.png","digits_big=9.png"];
            const AODBIG = ["aod_digits_big=0.png","aod_digits_big=1.png","aod_digits_big=2.png","aod_digits_big=3.png","aod_digits_big=4.png","aod_digits_big=5.png","aod_digits_big=6.png","aod_digits_big=7.png","aod_digits_big=8.png","aod_digits_big=9.png"];
            const WEEK = ["days_week=1.png","days_week=2.png","days_week=3.png","days_week=4.png","days_week=5.png","days_week=6.png","days_week=7.png"];
            const screenType = hmSetting.getScreenType();

            console.log('Watch_Face.ScreenNormal');
            hmUI.createWidget(hmUI.widget.IMG, { x: 0, y: 0, w: 480, h: 480, src: 'main_bg.png', show_level: NORMAL });

            // ---- 24h ring: 96 yellow segments (15 min each) that light up as the day goes by
            const RING_N = 96, RING_STEP = 360 / RING_N;
            const RING_POS = [[239,23],[253,24],[266,25],[280,27],[294,30],[307,34],[320,39],[333,45],[345,52],[357,59],[368,67],[379,76],[389,86],[399,96],[408,107],[416,119],[423,130],[430,143],[436,156],[441,169],[445,183],[448,197],[450,211],[452,225],[452,239],[450,253],[448,267],[445,280],[441,294],[436,307],[430,320],[423,333],[416,345],[408,357],[399,369],[389,379],[379,389],[369,399],[357,408],[345,416],[333,423],[320,430],[307,436],[294,441],[280,445],[266,448],[253,450],[239,452],[224,452],[210,450],[196,448],[183,445],[169,441],[156,436],[143,430],[130,423],[119,416],[107,408],[96,399],[86,389],[76,379],[67,368],[59,357],[52,345],[45,333],[39,320],[34,307],[30,294],[27,280],[25,267],[24,253],[23,239],[23,225],[24,211],[25,197],[27,183],[30,169],[34,156],[39,143],[45,131],[52,119],[59,107],[67,96],[76,86],[86,76],[96,67],[107,59],[119,52],[131,45],[143,39],[156,34],[169,30],[183,27],[196,25],[210,24],[224,23]];
            const ringSeg = [];
            for (let i = 0; i < RING_N; i++) {
              ringSeg.push(hmUI.createWidget(hmUI.widget.IMG, {
                x: RING_POS[i][0], y: RING_POS[i][1],
                src: 'ring_' + (i < 10 ? '0' + i : '' + i) + '.png', show_level: NORMAL,
              }));
            }
            let ringShown = RING_N;

            // yellow 24h arrow at the head of the ring (rotated from JS, see updateClock)
            const hourMarker = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0, y: 0, w: 480, h: 480, src: 'hour_marker.png',
              center_x: 240, center_y: 240, angle: 0, show_level: NORMAL,
            });

            // ---- battery (bolt + percent)
            hmUI.createWidget(hmUI.widget.IMG, { x: 193, y: 48, src: 'icon_graph=bolt.png', show_level: NORMAL });
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 224, y: 48, font_array: DIG, padding: false, h_space: 0,
              unit_sc: 'digits_small=procent.png', unit_tc: 'digits_small=procent.png', unit_en: 'digits_small=procent.png',
              align_h: hmUI.align.LEFT, type: hmUI.data_type.BATTERY, show_level: NORMAL,
            });

            // ---- weather
            hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 100, y: 85, image_array: ["icon_weather=_0.png","icon_weather=_1.png","icon_weather=_2.png","icon_weather=_3.png","icon_weather=_4.png","icon_weather=_5.png","icon_weather=_6.png","icon_weather=_7.png","icon_weather=_8.png","icon_weather=_9.png","icon_weather=_10.png","icon_weather=_11.png","icon_weather=_12.png","icon_weather=_13.png","icon_weather=_14.png","icon_weather=_15.png","icon_weather=_16.png","icon_weather=_17.png","icon_weather=_18.png","icon_weather=_19.png","icon_weather=_20.png","icon_weather=_21.png","icon_weather=_22.png","icon_weather=_23.png","icon_weather=_24.png","icon_weather=_25.png","icon_weather=_26.png","icon_weather=_27.png","icon_weather=_28.png"], image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT, show_level: NORMAL,
            });
            const temperature = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 140, y: 92, w: 86, h: 25, font_array: DIG, padding: false, h_space: 0,
              unit_sc: 'digits_small=celcium.png', unit_tc: 'digits_small=celcium.png', unit_en: 'digits_small=celcium.png',
              imperial_unit_sc: 'digits_small=faringate.png', imperial_unit_tc: 'digits_small=faringate.png', imperial_unit_en: 'digits_small=faringate.png',
              negative_image: 'digits_small=minus.png', invalid_image: 'digits_small=error.png',
              align_h: hmUI.align.RIGHT, type: hmUI.data_type.WEATHER_CURRENT, show_level: NORMAL,
            });
            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              temperature.setProperty(hmUI.prop.MORE, {
                x: 140, y: 92, w: 86, h: 25, font_array: DIG, padding: false, h_space: 0,
                unit_sc: 'digits_small=faringate.png', unit_tc: 'digits_small=faringate.png', unit_en: 'digits_small=faringate.png',
                imperial_unit_sc: 'digits_small=celcium.png', imperial_unit_tc: 'digits_small=celcium.png', imperial_unit_en: 'digits_small=celcium.png',
                negative_image: 'digits_small=minus.png', invalid_image: 'digits_small=error.png',
                align_h: hmUI.align.RIGHT, type: hmUI.data_type.WEATHER_CURRENT, show_level: NORMAL,
              });
            };
            //end of ignored block

            // ---- date
            hmUI.createWidget(hmUI.widget.IMG, { x: 94, y: 140, src: 'icon_graph=cal.png', show_level: NORMAL });
            hmUI.createWidget(hmUI.widget.IMG_WEEK, { x: 120, y: 140, week_en: WEEK, week_tc: WEEK, week_sc: WEEK, show_level: NORMAL });
            hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 191, day_startY: 140, day_sc_array: DIG, day_tc_array: DIG, day_en_array: DIG,
              day_zero: 0, day_space: 0, day_align: hmUI.align.LEFT, day_is_character: false, show_level: NORMAL,
            });

            // ---- heart rate (icon + bpm) and the heart-rate chart under it
            const heartPlain = hmUI.createWidget(hmUI.widget.IMG, { x: 256, y: 93, src: 'icon_graph=heart_plain.png', show_level: NORMAL });
            const heartZoneImgs = [];
            for (let i = 0; i < 6; i++) {
              const zi = hmUI.createWidget(hmUI.widget.IMG, { x: 256, y: 93, src: 'icon_graph=heart_z' + i + '.png', show_level: NORMAL });
              zi.setProperty(hmUI.prop.VISIBLE, false);
              heartZoneImgs.push(zi);
            }
            let maxHR = 190;
            try { const age = hmSetting.getUserData().age; if (age > 0 && age < 110) maxHR = 220 - age; } catch (e) {}
            let heartZoneShown = -2;
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 291, y: 92, font_array: DIG, padding: false, h_space: 0, invalid_image: 'digits_small=error.png',
              align_h: hmUI.align.LEFT, type: hmUI.data_type.HEART, show_level: NORMAL,
            });
            const CH_X0 = 259, CH_PITCH = 16.9, CH_W = 13, CH_BASE = 169, CH_MAX = 42;
            const chartBars = [];
            for (let i = 0; i < 8; i++) {
              chartBars.push(hmUI.createWidget(hmUI.widget.FILL_RECT, {
                x: Math.round(CH_X0 + i * CH_PITCH), y: CH_BASE - 3, w: CH_W, h: 3, color: 0xFFFFFFFF, show_level: NORMAL,
              }));
            }

            // ---- bluetooth / alarm
            hmUI.createWidget(hmUI.widget.IMG_STATUS, { x: 49, y: 202, src: 'icon_graph=bluetooth.png', type: hmUI.system_status.DISCONNECT, show_level: NORMAL });
            hmUI.createWidget(hmUI.widget.IMG_STATUS, { x: 400, y: 200, src: 'icon_graph=alarm.png', type: hmUI.system_status.CLOCK, show_level: NORMAL });

            // ---- AM/PM (12h) or 24H badge (24h)
            const badge24 = hmUI.createWidget(hmUI.widget.IMG, { x: 42, y: 253, src: 'icon_graph=24H.png', show_level: NORMAL });
            hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 42, am_y: 253, am_sc_path: 'icon_graph=AM.png', am_en_path: 'icon_graph=AM.png',
              pm_x: 42, pm_y: 253, pm_sc_path: 'icon_graph=PM.png', pm_en_path: 'icon_graph=PM.png',
              show_level: NORMAL,
            });

            // ---- main digital clock
            hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 98, hour_startY: 195, hour_array: BIG, hour_zero: 1, hour_space: -4, hour_angle: 0, hour_align: hmUI.align.CENTER_H,
              minute_startX: 250, minute_startY: 195, minute_array: BIG, minute_zero: 1, minute_space: -4, minute_angle: 0, minute_follow: 0, minute_align: hmUI.align.CENTER_H,
              second_startX: 397, second_startY: 252, second_array: DIG, second_zero: 1, second_space: -2, second_angle: 0, second_follow: 0, second_align: hmUI.align.LEFT,
              show_level: NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG, { x: 221, y: 193, src: 'digits_big=separation.png', show_level: NORMAL });

            // ---- PAI / stand hours / calories (the row under the clock)
            hmUI.createWidget(hmUI.widget.IMG, { x: 90, y: 299, src: 'icon_graph=PAI.png', show_level: NORMAL });
            hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 124, y: 300, font_array: DIG, padding: false, h_space: 0, invalid_image: 'digits_small=error.png', align_h: hmUI.align.LEFT, type: hmUI.data_type.PAI_WEEKLY, show_level: NORMAL });
            hmUI.createWidget(hmUI.widget.IMG, { x: 204, y: 301, src: 'icon_graph=stand.png', show_level: NORMAL });
            hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 237, y: 300, font_array: DIG, padding: false, h_space: 0, align_h: hmUI.align.LEFT, type: hmUI.data_type.STAND, show_level: NORMAL });
            hmUI.createWidget(hmUI.widget.IMG, { x: 319, y: 301, src: 'icon_graph=flame.png', show_level: NORMAL });
            hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 351, y: 300, font_array: DIG, padding: false, h_space: 0, align_h: hmUI.align.LEFT, type: hmUI.data_type.CAL, show_level: NORMAL });

            // ---- steps / sunrise <-> sunset (switches by itself)
            hmUI.createWidget(hmUI.widget.IMG, { x: 129, y: 347, src: 'icon_graph=steps.png', show_level: NORMAL });
            hmUI.createWidget(hmUI.widget.IMG, { x: 165, y: 351, src: 'icon_graph=label_steps.png', show_level: NORMAL });
            hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 108, y: 377, w: 148, h: 25, font_array: DIG, padding: false, h_space: 0, align_h: hmUI.align.CENTER_H, type: hmUI.data_type.STEP, show_level: NORMAL });
            const sunIconRise = hmUI.createWidget(hmUI.widget.IMG, { x: 257, y: 347, src: 'icon_graph=sunrise.png', show_level: NORMAL });
            const sunLabelRise = hmUI.createWidget(hmUI.widget.IMG, { x: 288, y: 351, src: 'icon_graph=label_rise.png', show_level: NORMAL });
            const sunTimeRise = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 257, y: 377, font_array: DIG, padding: false, h_space: 0, dot_image: 'digits_small=colon.png',
              align_h: hmUI.align.LEFT, type: hmUI.data_type.SUN_RISE, show_level: NORMAL,
            });
            const sunIconSet = hmUI.createWidget(hmUI.widget.IMG, { x: 257, y: 347, src: 'icon_graph=sunset.png', show_level: NORMAL });
            const sunLabelSet = hmUI.createWidget(hmUI.widget.IMG, { x: 288, y: 351, src: 'icon_graph=label_set.png', show_level: NORMAL });
            const sunTimeSet = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 257, y: 377, font_array: DIG, padding: false, h_space: 0, dot_image: 'digits_small=colon.png',
              align_h: hmUI.align.LEFT, type: hmUI.data_type.SUN_SET, show_level: NORMAL,
            });

            // ---- altitude (bottom centre, replaces the second clock)
            hmUI.createWidget(hmUI.widget.IMG, { x: 181, y: 413, src: 'icon_graph=altitude.png', show_level: NORMAL });
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 215, y: 413, w: 110, h: 25, font_array: DIG, padding: false, h_space: 0,
              unit_sc: 'digits_small=m.png', unit_tc: 'digits_small=m.png', unit_en: 'digits_small=m.png',
              negative_image: 'digits_small=minus.png', invalid_image: 'digits_small=error.png',
              align_h: hmUI.align.LEFT, type: hmUI.data_type.ALTITUDE, show_level: NORMAL,
            });

            // red seconds pointer, native rotation, goes once around the ring every minute
            hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_centerX: 240, second_centerY: 240, second_posX: 16, second_posY: 240,
              second_path: 'second_pointer.png', show_level: NORMAL,
            });

            // ================= AOD =================
            console.log('Watch_Face.ScreenAOD');
            hmUI.createWidget(hmUI.widget.IMG, { x: 0, y: 0, w: 480, h: 480, src: 'aod_main_bg.png', show_level: AOD });
            const aodIcon = hmUI.createWidget(hmUI.widget.IMG, { x: 94, y: 140, src: 'icon_graph=cal.png', show_level: AOD });
            aodIcon.setAlpha(150);
            const aodWeek = hmUI.createWidget(hmUI.widget.IMG_WEEK, { x: 120, y: 140, week_en: WEEK, week_tc: WEEK, week_sc: WEEK, show_level: AOD });
            aodWeek.setAlpha(150);
            const aodDay = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 191, day_startY: 140, day_sc_array: DIG, day_tc_array: DIG, day_en_array: DIG,
              day_zero: 0, day_space: 0, day_align: hmUI.align.LEFT, day_is_character: false, show_level: AOD,
            });
            aodDay.setAlpha(150);
            hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 42, am_y: 253, am_sc_path: 'icon_graph=AM.png', am_en_path: 'icon_graph=AM.png',
              pm_x: 42, pm_y: 253, pm_sc_path: 'icon_graph=PM.png', pm_en_path: 'icon_graph=PM.png',
              show_level: AOD,
            });
            const aodTime = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 98, hour_startY: 195, hour_array: AODBIG, hour_zero: 1, hour_space: -4, hour_angle: 0, hour_align: hmUI.align.CENTER_H,
              minute_startX: 250, minute_startY: 195, minute_array: AODBIG, minute_zero: 1, minute_space: -4, minute_angle: 0, minute_follow: 0, minute_align: hmUI.align.CENTER_H,
              show_level: AOD,
            });
            aodTime.setAlpha(150);
            const aodColon = hmUI.createWidget(hmUI.widget.IMG, { x: 221, y: 193, src: 'aod_digits_big=separation.png', show_level: AOD });
            aodColon.setAlpha(150);

            // ================= logic =================
            const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            const heart = hmSensor.createSensor(hmSensor.id.HEART);
            let weatherSensor = null;
            try { weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER); } catch (e) {}

            // 24h or 12h?  getTimeFormat() first, hour/format_hour as a cross-check where they differ
            function is24h() {
              try {
                const h = timeSensor.hour, fh = timeSensor.format_hour;
                if (h >= 13 || h === 0) return fh === h;
                return hmSetting.getTimeFormat() == 1;
              } catch (e) { return false; }
            }

            function updateClock() {
              const angle = ((timeSensor.hour + timeSensor.minute / 60) * 15) % 360;
              hourMarker.setProperty(hmUI.prop.MORE, {
                x: 0, y: 0, w: 480, h: 480, src: 'hour_marker.png',
                center_x: 240, center_y: 240, angle: angle, show_level: NORMAL,
              });
              badge24.setProperty(hmUI.prop.VISIBLE, is24h());
              // ring fill: segments before the arrow are visible, the rest hidden
              const n = Math.max(0, Math.min(RING_N, Math.floor(angle / RING_STEP + 0.5)));
              if (n > ringShown) { for (let i = ringShown; i < n; i++) ringSeg[i].setProperty(hmUI.prop.VISIBLE, true); }
              else if (n < ringShown) { for (let i = n; i < ringShown; i++) ringSeg[i].setProperty(hmUI.prop.VISIBLE, false); }
              ringShown = n;
            }

            // sunrise <-> sunset: show whichever comes next (between sunrise and sunset -> sunset)
            function updateSun() {
              let showSet = timeSensor.hour >= 12;
              try {
                if (weatherSensor) {
                  const t = weatherSensor.getForecastWeather().tideData.data[0];
                  const now = timeSensor.hour * 60 + timeSensor.minute;
                  const sr = t.sunrise.hour * 60 + t.sunrise.minute;
                  const ss = t.sunset.hour * 60 + t.sunset.minute;
                  showSet = now >= sr && now < ss;
                }
              } catch (e) {}
              sunIconRise.setProperty(hmUI.prop.VISIBLE, !showSet);
              sunLabelRise.setProperty(hmUI.prop.VISIBLE, !showSet);
              sunTimeRise.setProperty(hmUI.prop.VISIBLE, !showSet);
              sunIconSet.setProperty(hmUI.prop.VISIBLE, showSet);
              sunLabelSet.setProperty(hmUI.prop.VISIBLE, showSet);
              sunTimeSet.setProperty(hmUI.prop.VISIBLE, showSet);
            }

            // heart-rate chart: average bpm per 3 hour block, kept for the current day
            let hrLog = { day: -1, sum: [0, 0, 0, 0, 0, 0, 0, 0], cnt: [0, 0, 0, 0, 0, 0, 0, 0] };
            try {
              const saved = hmFS.SysProGetChars('ar_hr');
              if (saved) {
                const p = saved.split(',').map(Number);
                if (p.length >= 17) hrLog = { day: p[0], sum: p.slice(1, 9), cnt: p.slice(9, 17) };
              }
            } catch (e) {}
            function readHR() {
              let v = 0;
              try { v = heart.last; } catch (e) {}
              if (!(v > 0)) { try { v = heart.current; } catch (e) {} }
              return (v > 30 && v < 250) ? v : 0;
            }
            function blockValues() {
              let t = null;
              try { t = heart.today; } catch (e) {}
              const out = [];
              for (let b = 0; b < 8; b++) {
                let s = 0, c = 0;
                if (t && t.length >= 1440) {
                  for (let m = b * 180; m < (b + 1) * 180; m++) { const x = t[m]; if (x > 30 && x < 250) { s += x; c++; } }
                }
                if (c === 0) { s = hrLog.sum[b]; c = hrLog.cnt[b]; }
                out.push(c > 0 ? s / c : 0);
              }
              return out;
            }
            function drawChart() {
              const vals = blockValues();
              const mx = Math.max.apply(null, vals);
              const lo = 40, span = Math.max(20, mx - lo);
              const order = vals.map(function (v, i) { return i; })
                .filter(function (i) { return vals[i] > 0; })
                .sort(function (a, b) { return vals[b] - vals[a]; });
              const hot = order.slice(0, 2);
              for (let i = 0; i < 8; i++) {
                const hgt = vals[i] > 0 ? Math.min(CH_MAX, Math.max(4, Math.round(CH_MAX * (vals[i] - lo) / span))) : 3;
                chartBars[i].setProperty(hmUI.prop.MORE, {
                  x: Math.round(CH_X0 + i * CH_PITCH), y: CH_BASE - hgt, w: CH_W, h: hgt,
                  color: hot.indexOf(i) >= 0 ? 0xFFFFA500 : 0xFFFFFFFF, show_level: NORMAL,
                });
              }
            }
            function updateChart() {
              const today = timeSensor.month * 100 + timeSensor.day;
              if (hrLog.day !== today) {
                hrLog = { day: today, sum: [0, 0, 0, 0, 0, 0, 0, 0], cnt: [0, 0, 0, 0, 0, 0, 0, 0] };
              }
              const v = readHR();
              if (v > 0) {
                const b = Math.min(7, Math.floor(timeSensor.hour / 3));
                hrLog.sum[b] += v; hrLog.cnt[b] += 1;
              }
              try { hmFS.SysProSetChars('ar_hr', [hrLog.day].concat(hrLog.sum).concat(hrLog.cnt).join(',')); } catch (e) {}
              drawChart();
            }

            // heart icon colour = heart-rate zone (% of max HR), 6 zones
            function updateHeartZone() {
              const v = readHR();
              let z = -1;
              if (v > 0) {
                const pct = v / maxHR;
                z = pct < 0.5 ? 0 : pct < 0.6 ? 1 : pct < 0.7 ? 2 : pct < 0.8 ? 3 : pct < 0.9 ? 4 : 5;
              }
              if (z === heartZoneShown) return;
              heartZoneShown = z;
              heartPlain.setProperty(hmUI.prop.VISIBLE, z < 0);
              for (let i = 0; i < 6; i++) heartZoneImgs[i].setProperty(hmUI.prop.VISIBLE, i === z);
            }
            function onHeart() { drawChart(); updateHeartZone(); }

            function refreshAll() { updateClock(); updateSun(); updateChart(); updateHeartZone(); }
            function onMinute() { updateClock(); updateSun(); updateChart(); updateHeartZone(); }
            timeSensor.addEventListener(hmSensor.event.MINUTEEND, onMinute);
            timeSensor.addEventListener(hmSensor.event.DAYCHANGE, refreshAll);
            try { heart.addEventListener(hmSensor.event.LAST, onHeart); } catch (e) {}
            try { heart.addEventListener(hmSensor.event.CURRENT, onHeart); } catch (e) {}
            refreshAll();

            // ================= shortcuts =================
            console.log('Watch_Face.Shortcuts');
            function tapData(x, y, w, h, dataType) {
              hmUI.createWidget(hmUI.widget.IMG_CLICK, { x: x, y: y, w: w, h: h, src: 'trans.png', type: dataType, show_level: NORMAL });
            }
            tapData(245, 90, 160, 40, hmUI.data_type.HEART);       // heart rate
            tapData(245, 130, 160, 44, hmUI.data_type.HEART);      // heart-rate chart
            tapData(82, 292, 110, 44, hmUI.data_type.PAI_WEEKLY);  // PAI
            tapData(196, 292, 100, 44, hmUI.data_type.STAND);      // stand hours
            tapData(304, 292, 110, 44, hmUI.data_type.CAL);        // calories
            tapData(120, 345, 120, 60, hmUI.data_type.WALKING);    // steps
            tapData(250, 345, 130, 60, hmUI.data_type.SUN_RISE);   // sunrise / sunset
            tapData(171, 410, 130, 36, hmUI.data_type.ALTITUDE);   // altitude

            console.log('Watch_Face.Buttons');
            function tapArea(x, y, w, h, url) {
              hmUI.createWidget(hmUI.widget.BUTTON, {
                x: x, y: y, w: w, h: h, text: '', color: 0xFFFF8C00, text_size: 25,
                press_src: 'trans.png', normal_src: 'trans.png',
                click_func: function () { hmApp.startApp({ url: url, native: true }); },
                show_level: NORMAL,
              });
            }
            tapArea(141, 28, 198, 40, 'PowerSaveHintScreen');
            tapArea(96, 82, 144, 44, 'WeatherScreen');
            tapArea(96, 130, 144, 44, 'ScheduleCalScreen');
            tapArea(395, 190, 60, 90, 'AlarmInfoScreen');
            tapArea(85, 185, 60, 100, 'AlarmInfoScreen');

            hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: function () { refreshAll(); },
            });
                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}