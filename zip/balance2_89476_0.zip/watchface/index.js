﻿    /*
    ** Watch_Face_Editor tool v 18.0
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_pai_weekly_text_font = ''
        let normal_spo2_current_text_font = ''
        let normal_fat_burning_current_text_font = ''
        let normal_distance_current_text_font = ''
        let normal_vo2max_circle_scale = ''
        let normal_vo2max_circle_scale_mirror = ''
        let normal_vo2max_current_text_font = ''
        let normal_heart_rate_circle_scale_2 = ''
        let normal_heart_rate_circle_scale_mirror_2 = ''
        let normal_heart_rate_text_font = ''
        let normal_battery_circle_scale = ''
        let normal_battery_circle_scale_mirror = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_current_text_font = ''
        let normal_bio_charge_circle_scale = ''
        let normal_bio_charge_circle_scale_mirror = ''
        let normal_bio_charge_pointer_progress_img_pointer = ''
        let normal_bio_charge_current_text_font = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_circle_scale_mirror = ''
        let normal_calorie_pointer_progress_img_pointer = ''
        let normal_calorie_current_text_font = ''
        let normal_step_circle_scale = ''
        let normal_step_circle_scale_mirror = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_font = ''
        let normal_month_name_font = ''
        let normal_Month_Array = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC', ];
        let normal_day_text_font = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
        let normal_time_hour_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_time_minute_text_font = ''
        let normal_widget_text_2 = ''
        let normal_widget_text_12 = ''
        let normal_widget_text_15 = ''
        let normal_widget_text_16 = ''
        let normal_widget_text_17 = ''
        let normal_widget_text_18 = ''
        let idle_background_bg_img = ''
        let idle_month_name_font = ''
        let idle_Month_Array = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC', ];
        let idle_day_text_font = ''
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
        let idle_time_hour_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let idle_time_minute_text_font = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_vo2max_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: NoizeSportFreeVertionRegular-MVwye.ttf; FontSize: 25; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 30,
              h: 30,
              text_size: 25,
              char_space: 5,
              line_space: 0,
              font: 'fonts/NoizeSportFreeVertionRegular-MVwye.ttf',
              color: 0xFFF8E8BC,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: NoizeSportFreeVertionRegular-MVwye.ttf; FontSize: 95
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 1446,
              h: 136,
              text_size: 95,
              char_space: -5,
              line_space: 0,
              font: 'fonts/NoizeSportFreeVertionRegular-MVwye.ttf',
              color: 0xFFF8E8BC,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: NoizeSportFreeVertionRegular-MVwye.ttf; FontSize: 90
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 1358,
              h: 129,
              text_size: 90,
              char_space: -5,
              line_space: -18,
              font: 'fonts/NoizeSportFreeVertionRegular-MVwye.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'background.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 81,
              y: 81,
              w: 318,
              h: 318,
              text_size: 25,
              char_space: 1,
              color: 0xFFF4E1B5,
              // use_text_circle: true,
              start_angle: 0,
              end_angle: 88,
              mode: 0,
              // radius: 159,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 51,
              y: 51,
              w: 378,
              h: 378,
              text_size: 25,
              char_space: 1,
              color: 0xFFF1DAB8,
              // use_text_circle: true,
              start_angle: 0,
              end_angle: 88,
              mode: 0,
              // radius: 189,
              align_h: hmUI.align.RIGHT,
              unit_type: 1,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 22,
              y: 22,
              w: 436,
              h: 436,
              text_size: 25,
              char_space: 1,
              color: 0xFFEECCBB,
              // use_text_circle: true,
              start_angle: 0,
              end_angle: 88,
              mode: 0,
              // radius: 218,
              align_h: hmUI.align.RIGHT,
              unit_type: 2,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -6,
              y: -6,
              w: 492,
              h: 492,
              text_size: 25,
              char_space: 1,
              color: 0xFFE9C4C0,
              // use_text_circle: true,
              start_angle: 0,
              end_angle: 88,
              mode: 0,
              // radius: 246,
              align_h: hmUI.align.RIGHT,
              unit_type: 2,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_vo2max_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: -90,
              end_angle: -120,
              radius: 110,
              line_width: 20,
              corner_flag: 3,
              type: hmUI.data_type.VO2MAX,
              color: 0xFFAD3527,
              // mirror: True,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_vo2max_circle_scale_mirror = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: -90,
              end_angle: -60,
              radius: 110,
              line_width: 20,
              corner_flag: 3,
              type: hmUI.data_type.VO2MAX,
              color: 0xFFAD3527,
              // mirror: True,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_vo2max_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 138,
              y: 138,
              w: 204,
              h: 204,
              text_size: 25,
              char_space: 1,
              color: 0xFFAD3527,
              // use_text_circle: true,
              start_angle: -110,
              end_angle: -70,
              mode: 0,
              // radius: 102,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.VO2MAX,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_circle_scale_2 = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 90,
              end_angle: 120,
              radius: 110,
              line_width: 20,
              corner_flag: 2,
              type: hmUI.data_type.HEART,
              color: 0xFFAD3527,
              // mirror: True,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_circle_scale_mirror_2 = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 90,
              end_angle: 60,
              radius: 110,
              line_width: 20,
              corner_flag: 1,
              type: hmUI.data_type.HEART,
              color: 0xFFAD3527,
              // mirror: True,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 138,
              y: 138,
              w: 204,
              h: 204,
              text_size: 25,
              char_space: 1,
              color: 0xFFAD3527,
              // use_text_circle: true,
              start_angle: 70,
              end_angle: 110,
              mode: 0,
              // radius: 102,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: -139,
              // end_angle: -15,
              // radius: 150,
              // line_width: 20,
              // line_cap: Rounded,
              // color: 0xFFE8C97A,
              // mirror: True,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: -139,
              end_angle: -15,
              radius: 140,
              line_width: 20,
              corner_flag: 2,
              color: 0xFFE8C97A,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_circle_scale_mirror = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: -139,
              end_angle: -263,
              radius: 140,
              line_width: 20,
              corner_flag: 1,
              color: 0xFFE8C97A,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'battery.png',
              center_x: 240,
              center_y: 240,
              x: 240,
              y: 240,
              start_angle: -106,
              end_angle: 14,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 84,
              y: 84,
              w: 312,
              h: 312,
              text_size: 25,
              char_space: 1,
              color: 0xFFE8C97A,
              // use_text_circle: true,
              start_angle: -20,
              end_angle: 20,
              mode: 0,
              // radius: 156,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: -139,
              end_angle: -10,
              radius: 170,
              line_width: 20,
              corner_flag: 2,
              type: hmUI.data_type.BIO_CHARGE,
              color: 0xFFE1A45A,
              // mirror: True,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_circle_scale_mirror = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: -139,
              end_angle: -268,
              radius: 170,
              line_width: 20,
              corner_flag: 1,
              type: hmUI.data_type.BIO_CHARGE,
              color: 0xFFE1A45A,
              // mirror: True,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'biocharge.png',
              center_x: 240,
              center_y: 240,
              x: 240,
              y: 240,
              start_angle: -106,
              end_angle: 54,
              invalid_visible: false,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 54,
              y: 54,
              w: 372,
              h: 372,
              text_size: 25,
              char_space: 1,
              color: 0xFFE1A45A,
              // use_text_circle: true,
              start_angle: -20,
              end_angle: 20,
              mode: 0,
              // radius: 186,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: -139,
              // end_angle: -10,
              // radius: 210,
              // line_width: 20,
              // line_cap: Rounded,
              // color: 0xFFD97A4D,
              // mirror: True,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: -139,
              end_angle: -10,
              radius: 200,
              line_width: 20,
              corner_flag: 2,
              color: 0xFFD97A4D,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_circle_scale_mirror = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: -139,
              end_angle: -268,
              radius: 200,
              line_width: 20,
              corner_flag: 1,
              color: 0xFFD97A4D,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'calories.png',
              center_x: 240,
              center_y: 240,
              x: 240,
              y: 240,
              start_angle: -90,
              end_angle: 35,
              invalid_visible: false,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 24,
              y: 24,
              w: 432,
              h: 432,
              text_size: 25,
              char_space: 1,
              color: 0xFFD97A4D,
              // use_text_circle: true,
              start_angle: -20,
              end_angle: 20,
              mode: 0,
              // radius: 216,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: -139,
              // end_angle: -10,
              // radius: 240,
              // line_width: 20,
              // line_cap: Rounded,
              // color: 0xFFC2574A,
              // mirror: True,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: -139,
              end_angle: -10,
              radius: 230,
              line_width: 20,
              corner_flag: 2,
              color: 0xFFC2574A,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_circle_scale_mirror = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: -139,
              end_angle: -268,
              radius: 230,
              line_width: 20,
              corner_flag: 1,
              color: 0xFFC2574A,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'steps.png',
              center_x: 240,
              center_y: 240,
              x: 240,
              y: 240,
              start_angle: -73,
              end_angle: 52,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -6,
              y: -6,
              w: 492,
              h: 492,
              text_size: 25,
              char_space: 1,
              color: 0xFFC2574A,
              // use_text_circle: true,
              start_angle: -20,
              end_angle: 20,
              mode: 0,
              // radius: 246,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 110,
              y: 110,
              w: 260,
              h: 260,
              text_size: 25,
              char_space: 5,
              font: 'fonts/NoizeSportFreeVertionRegular-MVwye.ttf',
              color: 0xFFF8E8BC,
              // use_text_circle: true,
              start_angle: -165,
              end_angle: 165,
              mode: 1,
              // radius: 130,
              align_h: hmUI.align.LEFT,
              // unit_string: JAN, FEB, MAR, APR, MAY, JUN, JUL, AUG, SEP, OCT, NOV, DEC,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 110,
              y: 110,
              w: 260,
              h: 260,
              text_size: 25,
              char_space: 5,
              font: 'fonts/NoizeSportFreeVertionRegular-MVwye.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 160,
              end_angle: 200,
              mode: 1,
              // radius: 130,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 110,
              y: 110,
              w: 260,
              h: 260,
              text_size: 25,
              char_space: 5,
              font: 'fonts/NoizeSportFreeVertionRegular-MVwye.ttf',
              color: 0xFFF8E8BC,
              // use_text_circle: true,
              start_angle: -165,
              end_angle: 165,
              mode: 1,
              // radius: 130,
              align_h: hmUI.align.RIGHT,
              // unit_string: MON, TUE, WED, THU, FRI, SAT, SUN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 140,
              y: 130,
              w: 200,
              h: 100,
              text_size: 95,
              char_space: -5,
              font: 'fonts/NoizeSportFreeVertionRegular-MVwye.ttf',
              color: 0xFFF8E8BC,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 137,
              y: 210,
              w: 200,
              h: 100,
              text_size: 90,
              char_space: -5,
              font: 'fonts/NoizeSportFreeVertionRegular-MVwye.ttf',
              color: 0xFFFFFFFF,
              line_space: -18,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_2 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 81,
              y: 81,
              w: 318,
              h: 318,
              text_size: 25,
              char_space: 4,
              font: 'fonts/NoizeSportFreeVertionRegular-MVwye.ttf',
              color: 0xFFF1E1B8,
              // use_text_circle: true,
              start_angle: 18,
              end_angle: 200,
              mode: 0,
              // radius: 159,
              align_h: hmUI.align.LEFT,
              text: 'PAI:',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_12 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 22,
              y: 22,
              w: 436,
              h: 436,
              text_size: 25,
              char_space: -1,
              font: 'fonts/NoizeSportFreeVertionRegular-MVwye.ttf',
              color: 0xFFEECCBB,
              // use_text_circle: true,
              start_angle: 18,
              end_angle: 200,
              mode: 0,
              // radius: 218,
              align_h: hmUI.align.LEFT,
              text: 'FATBURN:',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_15 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: -6,
              y: -6,
              w: 492,
              h: 492,
              text_size: 25,
              char_space: -1,
              font: 'fonts/NoizeSportFreeVertionRegular-MVwye.ttf',
              color: 0xFFECC4BD,
              // use_text_circle: true,
              start_angle: 18,
              end_angle: 200,
              mode: 0,
              // radius: 246,
              align_h: hmUI.align.LEFT,
              text: 'DISTANCE:',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_16 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 112,
              y: 112,
              w: 256,
              h: 256,
              text_size: 25,
              char_space: 2,
              font: 'fonts/NoizeSportFreeVertionRegular-MVwye.ttf',
              color: 0xFF682017,
              // use_text_circle: true,
              start_angle: -85,
              end_angle: 270,
              mode: 0,
              // radius: 128,
              align_h: hmUI.align.CENTER_H,
              text: 'PULSE',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_17 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 114,
              y: 114,
              w: 252,
              h: 252,
              text_size: 25,
              char_space: 5,
              font: 'fonts/NoizeSportFreeVertionRegular-MVwye.ttf',
              color: 0xFF682017,
              // use_text_circle: true,
              start_angle: -269,
              end_angle: 90,
              mode: 0,
              // radius: 126,
              align_h: hmUI.align.CENTER_H,
              text: 'VO2',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_18 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 51,
              y: 51,
              w: 378,
              h: 378,
              text_size: 25,
              char_space: 4,
              font: 'fonts/NoizeSportFreeVertionRegular-MVwye.ttf',
              color: 0xFFF1DAB8,
              // use_text_circle: true,
              start_angle: 18,
              end_angle: 200,
              mode: 0,
              // radius: 189,
              align_h: hmUI.align.LEFT,
              text: 'SPO2:',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'background.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 110,
              y: 110,
              w: 260,
              h: 260,
              text_size: 25,
              char_space: 5,
              font: 'fonts/NoizeSportFreeVertionRegular-MVwye.ttf',
              color: 0xFFF8E8BC,
              // use_text_circle: true,
              start_angle: -165,
              end_angle: 165,
              mode: 1,
              // radius: 130,
              align_h: hmUI.align.LEFT,
              // unit_string: JAN, FEB, MAR, APR, MAY, JUN, JUL, AUG, SEP, OCT, NOV, DEC,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 110,
              y: 110,
              w: 260,
              h: 260,
              text_size: 25,
              char_space: 5,
              font: 'fonts/NoizeSportFreeVertionRegular-MVwye.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 160,
              end_angle: 200,
              mode: 1,
              // radius: 130,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 110,
              y: 110,
              w: 260,
              h: 260,
              text_size: 25,
              char_space: 5,
              font: 'fonts/NoizeSportFreeVertionRegular-MVwye.ttf',
              color: 0xFFF8E8BC,
              // use_text_circle: true,
              start_angle: -165,
              end_angle: 165,
              mode: 1,
              // radius: 130,
              align_h: hmUI.align.RIGHT,
              // unit_string: MON, TUE, WED, THU, FRI, SAT, SUN,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 140,
              y: 130,
              w: 200,
              h: 100,
              text_size: 95,
              char_space: -5,
              font: 'fonts/NoizeSportFreeVertionRegular-MVwye.ttf',
              color: 0xFFF8E8BC,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 137,
              y: 210,
              w: 200,
              h: 100,
              text_size: 90,
              char_space: -5,
              font: 'fonts/NoizeSportFreeVertionRegular-MVwye.ttf',
              color: 0xFFFFFFFF,
              line_space: -18,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 0,
              w: 100,
              h: 30,
              src: 'shortcut.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 32,
              w: 100,
              h: 50,
              src: 'shortcut.png',
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 315,
              y: 190,
              w: 45,
              h: 100,
              src: 'shortcut.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 280,
              y: 106,
              w: 50,
              h: 44,
              src: 'shortcut.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 86,
              w: 90,
              h: 30,
              src: 'shortcut.png',
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 329,
              y: 80,
              w: 55,
              h: 61,
              src: 'shortcut.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 175,
              y: 170,
              w: 130,
              h: 130,
              src: 'shortcut.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_vo2max_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 119,
              y: 190,
              w: 45,
              h: 100,
              src: 'shortcut.png',
              type: hmUI.data_type.VO2MAX,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 300,
              y: 20,
              w: 90,
              h: 60,
              src: 'shortcut.png',
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('month font');
              if (updateHour) {
                let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );
              };

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('hour font');
              if (updateHour) {
                let normal_hourStr = format_hour.toString();
                normal_hourStr = normal_hourStr.padStart(2, '0');
                normal_time_hour_text_font.setProperty(hmUI.prop.TEXT, normal_hourStr );
              };

              console.log('minute font');
              if (updateMinute) {
                let normal_minuteStr = minute.toString();
                normal_minuteStr = normal_minuteStr.padStart(2, '0');
                normal_time_minute_text_font.setProperty(hmUI.prop.TEXT, normal_minuteStr );
              };

              console.log('month font');
              if (updateHour) {
                let idle_Month_Str = idle_Month_Array[timeSensor.month-1];
                idle_month_name_font.setProperty(hmUI.prop.TEXT, idle_Month_Str );
              };

              console.log('day font');
              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_dayStr = idle_dayStr.padStart(2, '0');
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

              console.log('hour font');
              if (updateHour) {
                let idle_hourStr = format_hour.toString();
                idle_hourStr = idle_hourStr.padStart(2, '0');
                idle_time_hour_text_font.setProperty(hmUI.prop.TEXT, idle_hourStr );
              };

              console.log('minute font');
              if (updateMinute) {
                let idle_minuteStr = minute.toString();
                idle_minuteStr = idle_minuteStr.padStart(2, '0');
                idle_time_minute_text_font.setProperty(hmUI.prop.TEXT, idle_minuteStr );
              };

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: -139,
                      end_angle: -15,
                      radius: 140,
                      line_width: 20,
                      corner_flag: 2,
                      color: 0xFFE8C97A,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                  if (normal_battery_circle_scale_mirror) {
                    normal_battery_circle_scale_mirror.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: -139,
                      end_angle: -263,
                      radius: 140,
                      line_width: 20,
                      corner_flag: 1,
                      color: 0xFFE8C97A,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: -139,
                      end_angle: -10,
                      radius: 200,
                      line_width: 20,
                      corner_flag: 2,
                      color: 0xFFD97A4D,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                  if (normal_calorie_circle_scale_mirror) {
                    normal_calorie_circle_scale_mirror.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: -139,
                      end_angle: -268,
                      radius: 200,
                      line_width: 20,
                      corner_flag: 1,
                      color: 0xFFD97A4D,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: -139,
                      end_angle: -10,
                      radius: 230,
                      line_width: 20,
                      corner_flag: 2,
                      color: 0xFFC2574A,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                  if (normal_step_circle_scale_mirror) {
                    normal_step_circle_scale_mirror.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: -139,
                      end_angle: -268,
                      radius: 230,
                      line_width: 20,
                      corner_flag: 1,
                      color: 0xFFC2574A,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}