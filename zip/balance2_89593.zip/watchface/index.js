﻿    /*
    ** Watch_Face_Editor tool v 18.0
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_alarm_clock_icon_img = ''
        let normal_date_img_date_month_img = ''
        let normal_digital_clock_img_time = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_system_clock_img = ''
        let normal_system_disconnect_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_week_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let idle_background_bg_img = ''
        let idle_alarm_clock_icon_img = ''
        let idle_date_img_date_month_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_minute_separator_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_city_name_text = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_icon_img = ''
        let idle_step_current_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_calorie_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_icon_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_date_img_date_day = ''
        let idle_system_clock_img = ''
        let idle_system_disconnect_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_week_img = ''
        let idle_sun_high_text_img = ''
        let idle_sun_low_text_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let Button_12 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'sfondo.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 366,
              y: 374,
              src: 'sveglia_2_b_45x45_h0s100b75.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 252,
              month_startY: 365,
              month_sc_array: ["chars_8E7FA13A_000.png","chars_8E7FA13A_001.png","chars_8E7FA13A_002.png","chars_8E7FA13A_003.png","chars_8E7FA13A_004.png","chars_8E7FA13A_005.png","chars_8E7FA13A_006.png","chars_8E7FA13A_007.png","chars_8E7FA13A_008.png","chars_8E7FA13A_009.png","chars_8E7FA13A_010.png","chars_8E7FA13A_011.png"],
              month_tc_array: ["chars_8E7FA13A_000.png","chars_8E7FA13A_001.png","chars_8E7FA13A_002.png","chars_8E7FA13A_003.png","chars_8E7FA13A_004.png","chars_8E7FA13A_005.png","chars_8E7FA13A_006.png","chars_8E7FA13A_007.png","chars_8E7FA13A_008.png","chars_8E7FA13A_009.png","chars_8E7FA13A_010.png","chars_8E7FA13A_011.png"],
              month_en_array: ["chars_8E7FA13A_000.png","chars_8E7FA13A_001.png","chars_8E7FA13A_002.png","chars_8E7FA13A_003.png","chars_8E7FA13A_004.png","chars_8E7FA13A_005.png","chars_8E7FA13A_006.png","chars_8E7FA13A_007.png","chars_8E7FA13A_008.png","chars_8E7FA13A_009.png","chars_8E7FA13A_010.png","chars_8E7FA13A_011.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 16,
              hour_startY: 166,
              hour_array: ["chars_B2DF8975_000.png","chars_B2DF8975_001.png","chars_B2DF8975_002.png","chars_B2DF8975_003.png","chars_B2DF8975_004.png","chars_B2DF8975_005.png","chars_B2DF8975_006.png","chars_B2DF8975_007.png","chars_B2DF8975_008.png","chars_B2DF8975_009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 202,
              minute_startY: 166,
              minute_array: ["chars_DC0EBA3C_000.png","chars_DC0EBA3C_001.png","chars_DC0EBA3C_002.png","chars_DC0EBA3C_003.png","chars_DC0EBA3C_004.png","chars_DC0EBA3C_005.png","chars_DC0EBA3C_006.png","chars_DC0EBA3C_007.png","chars_DC0EBA3C_008.png","chars_DC0EBA3C_009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 384,
              second_startY: 227,
              second_array: ["chars_7829685A_000.png","chars_7829685A_001.png","chars_7829685A_002.png","chars_7829685A_003.png","chars_7829685A_004.png","chars_7829685A_005.png","chars_7829685A_006.png","chars_7829685A_007.png","chars_7829685A_008.png","chars_7829685A_009.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 192,
              y: 77,
              font_array: ["chars_D7967ED0_000.png","chars_D7967ED0_001.png","chars_D7967ED0_002.png","chars_D7967ED0_003.png","chars_D7967ED0_004.png","chars_D7967ED0_005.png","chars_D7967ED0_006.png","chars_D7967ED0_007.png","chars_D7967ED0_008.png","chars_D7967ED0_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'chars_D7967ED0_011.png',
              unit_tc: 'chars_D7967ED0_011.png',
              unit_en: 'chars_D7967ED0_011.png',
              negative_image: 'chars_D7967ED0_010.png',
              invalid_image: 'chars_D7967ED0_012.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 69,
              y: 64,
              image_array: ["set_5_88x88_meteo_1.png","set_5_88x88_meteo_2.png","set_5_88x88_meteo_3.png","set_5_88x88_meteo_4.png","set_5_88x88_meteo_5.png","set_5_88x88_meteo_6.png","set_5_88x88_meteo_7.png","set_5_88x88_meteo_8.png","set_5_88x88_meteo_9.png","set_5_88x88_meteo_10.png","set_5_88x88_meteo_11.png","set_5_88x88_meteo_12.png","set_5_88x88_meteo_13.png","set_5_88x88_meteo_14.png","set_5_88x88_meteo_15.png","set_5_88x88_meteo_16.png","set_5_88x88_meteo_17.png","set_5_88x88_meteo_18.png","set_5_88x88_meteo_19.png","set_5_88x88_meteo_20.png","set_5_88x88_meteo_21.png","set_5_88x88_meteo_22.png","set_5_88x88_meteo_23.png","set_5_88x88_meteo_24.png","set_5_88x88_meteo_25.png","set_5_88x88_meteo_26.png","set_5_88x88_meteo_27.png","set_5_88x88_meteo_28.png","set_5_88x88_meteo_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 146,
              y: 120,
              w: 148,
              h: 30,
              text_size: 20,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_type: 1,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 105,
              y: 325,
              font_array: ["chars_8684C2CC_000.png","chars_8684C2CC_001.png","chars_8684C2CC_002.png","chars_8684C2CC_003.png","chars_8684C2CC_004.png","chars_8684C2CC_005.png","chars_8684C2CC_006.png","chars_8684C2CC_007.png","chars_8684C2CC_008.png","chars_8684C2CC_009.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 395,
              y: 170,
              src: 'euro01.jpg3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 325,
              font_array: ["chars_8684C2CC_000.png","chars_8684C2CC_001.png","chars_8684C2CC_002.png","chars_8684C2CC_003.png","chars_8684C2CC_004.png","chars_8684C2CC_005.png","chars_8684C2CC_006.png","chars_8684C2CC_007.png","chars_8684C2CC_008.png","chars_8684C2CC_009.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 372,
              y: 325,
              font_array: ["chars_8684C2CC_000.png","chars_8684C2CC_001.png","chars_8684C2CC_002.png","chars_8684C2CC_003.png","chars_8684C2CC_004.png","chars_8684C2CC_005.png","chars_8684C2CC_006.png","chars_8684C2CC_007.png","chars_8684C2CC_008.png","chars_8684C2CC_009.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 123,
              y: 32,
              src: 'batt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 296,
              y: 27,
              font_array: ["chars_5DFBE4CA_000.png","chars_5DFBE4CA_001.png","chars_5DFBE4CA_002.png","chars_5DFBE4CA_003.png","chars_5DFBE4CA_004.png","chars_5DFBE4CA_005.png","chars_5DFBE4CA_006.png","chars_5DFBE4CA_007.png","chars_5DFBE4CA_008.png","chars_5DFBE4CA_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'percentuale.png',
              unit_tc: 'percentuale.png',
              unit_en: 'percentuale.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 250,
              y: 15,
              src: 'batt_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 122,
              y: 32,
              image_array: ["03.png","04.png","05.png","06.png","07.png","08.png","09.png","10.png","11.png","12.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 145,
              day_startY: 379,
              day_sc_array: ["chars_9E31016C_000.png","chars_9E31016C_001.png","chars_9E31016C_002.png","chars_9E31016C_003.png","chars_9E31016C_004.png","chars_9E31016C_005.png","chars_9E31016C_006.png","chars_9E31016C_007.png","chars_9E31016C_008.png","chars_9E31016C_009.png"],
              day_tc_array: ["chars_9E31016C_000.png","chars_9E31016C_001.png","chars_9E31016C_002.png","chars_9E31016C_003.png","chars_9E31016C_004.png","chars_9E31016C_005.png","chars_9E31016C_006.png","chars_9E31016C_007.png","chars_9E31016C_008.png","chars_9E31016C_009.png"],
              day_en_array: ["chars_9E31016C_000.png","chars_9E31016C_001.png","chars_9E31016C_002.png","chars_9E31016C_003.png","chars_9E31016C_004.png","chars_9E31016C_005.png","chars_9E31016C_006.png","chars_9E31016C_007.png","chars_9E31016C_008.png","chars_9E31016C_009.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 366,
              y: 374,
              src: 'sveglia_2_a.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 422,
              y: 129,
              src: 'bluetooth_1_b_28x28_h0s100b70.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 250,
              year_startY: 415,
              year_sc_array: ["chars_1BDD6EE0_000.png","chars_1BDD6EE0_001.png","chars_1BDD6EE0_002.png","chars_1BDD6EE0_003.png","chars_1BDD6EE0_004.png","chars_1BDD6EE0_005.png","chars_1BDD6EE0_006.png","chars_1BDD6EE0_007.png","chars_1BDD6EE0_008.png","chars_1BDD6EE0_009.png"],
              year_tc_array: ["chars_1BDD6EE0_000.png","chars_1BDD6EE0_001.png","chars_1BDD6EE0_002.png","chars_1BDD6EE0_003.png","chars_1BDD6EE0_004.png","chars_1BDD6EE0_005.png","chars_1BDD6EE0_006.png","chars_1BDD6EE0_007.png","chars_1BDD6EE0_008.png","chars_1BDD6EE0_009.png"],
              year_en_array: ["chars_1BDD6EE0_000.png","chars_1BDD6EE0_001.png","chars_1BDD6EE0_002.png","chars_1BDD6EE0_003.png","chars_1BDD6EE0_004.png","chars_1BDD6EE0_005.png","chars_1BDD6EE0_006.png","chars_1BDD6EE0_007.png","chars_1BDD6EE0_008.png","chars_1BDD6EE0_009.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 13,
              y: 279,
              week_en: ["chars_C3B6ED22_000.png","chars_C3B6ED22_001.png","chars_C3B6ED22_002.png","chars_C3B6ED22_003.png","chars_C3B6ED22_004.png","chars_C3B6ED22_005.png","chars_C3B6ED22_006.png"],
              week_tc: ["chars_C3B6ED22_000.png","chars_C3B6ED22_001.png","chars_C3B6ED22_002.png","chars_C3B6ED22_003.png","chars_C3B6ED22_004.png","chars_C3B6ED22_005.png","chars_C3B6ED22_006.png"],
              week_sc: ["chars_C3B6ED22_000.png","chars_C3B6ED22_001.png","chars_C3B6ED22_002.png","chars_C3B6ED22_003.png","chars_C3B6ED22_004.png","chars_C3B6ED22_005.png","chars_C3B6ED22_006.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 327,
              y: 80,
              font_array: ["chars_5DFBE4CA_000.png","chars_5DFBE4CA_001.png","chars_5DFBE4CA_002.png","chars_5DFBE4CA_003.png","chars_5DFBE4CA_004.png","chars_5DFBE4CA_005.png","chars_5DFBE4CA_006.png","chars_5DFBE4CA_007.png","chars_5DFBE4CA_008.png","chars_5DFBE4CA_009.png"],
              padding: false,
              h_space: 0,
              dot_image: 'chars_5DFBE4CA_011.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 327,
              y: 116,
              font_array: ["chars_5DFBE4CA_000.png","chars_5DFBE4CA_001.png","chars_5DFBE4CA_002.png","chars_5DFBE4CA_003.png","chars_5DFBE4CA_004.png","chars_5DFBE4CA_005.png","chars_5DFBE4CA_006.png","chars_5DFBE4CA_007.png","chars_5DFBE4CA_008.png","chars_5DFBE4CA_009.png"],
              padding: false,
              h_space: 0,
              dot_image: 'chars_5DFBE4CA_011.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'sfondo.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_alarm_clock_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 366,
              y: 374,
              src: 'sveglia_2_b_45x45_h0s100b75.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 252,
              month_startY: 365,
              month_sc_array: ["chars_8E7FA13A_000.png","chars_8E7FA13A_001.png","chars_8E7FA13A_002.png","chars_8E7FA13A_003.png","chars_8E7FA13A_004.png","chars_8E7FA13A_005.png","chars_8E7FA13A_006.png","chars_8E7FA13A_007.png","chars_8E7FA13A_008.png","chars_8E7FA13A_009.png","chars_8E7FA13A_010.png","chars_8E7FA13A_011.png"],
              month_tc_array: ["chars_8E7FA13A_000.png","chars_8E7FA13A_001.png","chars_8E7FA13A_002.png","chars_8E7FA13A_003.png","chars_8E7FA13A_004.png","chars_8E7FA13A_005.png","chars_8E7FA13A_006.png","chars_8E7FA13A_007.png","chars_8E7FA13A_008.png","chars_8E7FA13A_009.png","chars_8E7FA13A_010.png","chars_8E7FA13A_011.png"],
              month_en_array: ["chars_8E7FA13A_000.png","chars_8E7FA13A_001.png","chars_8E7FA13A_002.png","chars_8E7FA13A_003.png","chars_8E7FA13A_004.png","chars_8E7FA13A_005.png","chars_8E7FA13A_006.png","chars_8E7FA13A_007.png","chars_8E7FA13A_008.png","chars_8E7FA13A_009.png","chars_8E7FA13A_010.png","chars_8E7FA13A_011.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 16,
              hour_startY: 166,
              hour_array: ["chars_B2DF8975_000.png","chars_B2DF8975_001.png","chars_B2DF8975_002.png","chars_B2DF8975_003.png","chars_B2DF8975_004.png","chars_B2DF8975_005.png","chars_B2DF8975_006.png","chars_B2DF8975_007.png","chars_B2DF8975_008.png","chars_B2DF8975_009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 202,
              minute_startY: 166,
              minute_array: ["chars_DC0EBA3C_000.png","chars_DC0EBA3C_001.png","chars_DC0EBA3C_002.png","chars_DC0EBA3C_003.png","chars_DC0EBA3C_004.png","chars_DC0EBA3C_005.png","chars_DC0EBA3C_006.png","chars_DC0EBA3C_007.png","chars_DC0EBA3C_008.png","chars_DC0EBA3C_009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 384,
              y: 227,
              src: 'doppiozero.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 192,
              y: 77,
              font_array: ["chars_D7967ED0_000.png","chars_D7967ED0_001.png","chars_D7967ED0_002.png","chars_D7967ED0_003.png","chars_D7967ED0_004.png","chars_D7967ED0_005.png","chars_D7967ED0_006.png","chars_D7967ED0_007.png","chars_D7967ED0_008.png","chars_D7967ED0_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'chars_D7967ED0_011.png',
              unit_tc: 'chars_D7967ED0_011.png',
              unit_en: 'chars_D7967ED0_011.png',
              negative_image: 'chars_D7967ED0_010.png',
              invalid_image: 'chars_D7967ED0_012.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 69,
              y: 64,
              image_array: ["set_5_88x88_meteo_1.png","set_5_88x88_meteo_2.png","set_5_88x88_meteo_3.png","set_5_88x88_meteo_4.png","set_5_88x88_meteo_5.png","set_5_88x88_meteo_6.png","set_5_88x88_meteo_7.png","set_5_88x88_meteo_8.png","set_5_88x88_meteo_9.png","set_5_88x88_meteo_10.png","set_5_88x88_meteo_11.png","set_5_88x88_meteo_12.png","set_5_88x88_meteo_13.png","set_5_88x88_meteo_14.png","set_5_88x88_meteo_15.png","set_5_88x88_meteo_16.png","set_5_88x88_meteo_17.png","set_5_88x88_meteo_18.png","set_5_88x88_meteo_19.png","set_5_88x88_meteo_20.png","set_5_88x88_meteo_21.png","set_5_88x88_meteo_22.png","set_5_88x88_meteo_23.png","set_5_88x88_meteo_24.png","set_5_88x88_meteo_25.png","set_5_88x88_meteo_26.png","set_5_88x88_meteo_27.png","set_5_88x88_meteo_28.png","set_5_88x88_meteo_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 146,
              y: 120,
              w: 148,
              h: 30,
              text_size: 20,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_type: 1,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 105,
              y: 325,
              font_array: ["chars_8684C2CC_000.png","chars_8684C2CC_001.png","chars_8684C2CC_002.png","chars_8684C2CC_003.png","chars_8684C2CC_004.png","chars_8684C2CC_005.png","chars_8684C2CC_006.png","chars_8684C2CC_007.png","chars_8684C2CC_008.png","chars_8684C2CC_009.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 395,
              y: 170,
              src: 'euro01.jpg3.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 325,
              font_array: ["chars_8684C2CC_000.png","chars_8684C2CC_001.png","chars_8684C2CC_002.png","chars_8684C2CC_003.png","chars_8684C2CC_004.png","chars_8684C2CC_005.png","chars_8684C2CC_006.png","chars_8684C2CC_007.png","chars_8684C2CC_008.png","chars_8684C2CC_009.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 372,
              y: 325,
              font_array: ["chars_8684C2CC_000.png","chars_8684C2CC_001.png","chars_8684C2CC_002.png","chars_8684C2CC_003.png","chars_8684C2CC_004.png","chars_8684C2CC_005.png","chars_8684C2CC_006.png","chars_8684C2CC_007.png","chars_8684C2CC_008.png","chars_8684C2CC_009.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 123,
              y: 32,
              src: 'batt.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 296,
              y: 27,
              font_array: ["chars_5DFBE4CA_000.png","chars_5DFBE4CA_001.png","chars_5DFBE4CA_002.png","chars_5DFBE4CA_003.png","chars_5DFBE4CA_004.png","chars_5DFBE4CA_005.png","chars_5DFBE4CA_006.png","chars_5DFBE4CA_007.png","chars_5DFBE4CA_008.png","chars_5DFBE4CA_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'percentuale.png',
              unit_tc: 'percentuale.png',
              unit_en: 'percentuale.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 250,
              y: 15,
              src: 'batt_2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 122,
              y: 32,
              image_array: ["03.png","04.png","05.png","06.png","07.png","08.png","09.png","10.png","11.png","12.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 145,
              day_startY: 379,
              day_sc_array: ["chars_9E31016C_000.png","chars_9E31016C_001.png","chars_9E31016C_002.png","chars_9E31016C_003.png","chars_9E31016C_004.png","chars_9E31016C_005.png","chars_9E31016C_006.png","chars_9E31016C_007.png","chars_9E31016C_008.png","chars_9E31016C_009.png"],
              day_tc_array: ["chars_9E31016C_000.png","chars_9E31016C_001.png","chars_9E31016C_002.png","chars_9E31016C_003.png","chars_9E31016C_004.png","chars_9E31016C_005.png","chars_9E31016C_006.png","chars_9E31016C_007.png","chars_9E31016C_008.png","chars_9E31016C_009.png"],
              day_en_array: ["chars_9E31016C_000.png","chars_9E31016C_001.png","chars_9E31016C_002.png","chars_9E31016C_003.png","chars_9E31016C_004.png","chars_9E31016C_005.png","chars_9E31016C_006.png","chars_9E31016C_007.png","chars_9E31016C_008.png","chars_9E31016C_009.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 366,
              y: 374,
              src: 'sveglia_2_a.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 422,
              y: 129,
              src: 'bluetooth_1_b_28x28_h0s100b70.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 250,
              year_startY: 415,
              year_sc_array: ["chars_1BDD6EE0_000.png","chars_1BDD6EE0_001.png","chars_1BDD6EE0_002.png","chars_1BDD6EE0_003.png","chars_1BDD6EE0_004.png","chars_1BDD6EE0_005.png","chars_1BDD6EE0_006.png","chars_1BDD6EE0_007.png","chars_1BDD6EE0_008.png","chars_1BDD6EE0_009.png"],
              year_tc_array: ["chars_1BDD6EE0_000.png","chars_1BDD6EE0_001.png","chars_1BDD6EE0_002.png","chars_1BDD6EE0_003.png","chars_1BDD6EE0_004.png","chars_1BDD6EE0_005.png","chars_1BDD6EE0_006.png","chars_1BDD6EE0_007.png","chars_1BDD6EE0_008.png","chars_1BDD6EE0_009.png"],
              year_en_array: ["chars_1BDD6EE0_000.png","chars_1BDD6EE0_001.png","chars_1BDD6EE0_002.png","chars_1BDD6EE0_003.png","chars_1BDD6EE0_004.png","chars_1BDD6EE0_005.png","chars_1BDD6EE0_006.png","chars_1BDD6EE0_007.png","chars_1BDD6EE0_008.png","chars_1BDD6EE0_009.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 13,
              y: 279,
              week_en: ["chars_C3B6ED22_000.png","chars_C3B6ED22_001.png","chars_C3B6ED22_002.png","chars_C3B6ED22_003.png","chars_C3B6ED22_004.png","chars_C3B6ED22_005.png","chars_C3B6ED22_006.png"],
              week_tc: ["chars_C3B6ED22_000.png","chars_C3B6ED22_001.png","chars_C3B6ED22_002.png","chars_C3B6ED22_003.png","chars_C3B6ED22_004.png","chars_C3B6ED22_005.png","chars_C3B6ED22_006.png"],
              week_sc: ["chars_C3B6ED22_000.png","chars_C3B6ED22_001.png","chars_C3B6ED22_002.png","chars_C3B6ED22_003.png","chars_C3B6ED22_004.png","chars_C3B6ED22_005.png","chars_C3B6ED22_006.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 327,
              y: 80,
              font_array: ["chars_5DFBE4CA_000.png","chars_5DFBE4CA_001.png","chars_5DFBE4CA_002.png","chars_5DFBE4CA_003.png","chars_5DFBE4CA_004.png","chars_5DFBE4CA_005.png","chars_5DFBE4CA_006.png","chars_5DFBE4CA_007.png","chars_5DFBE4CA_008.png","chars_5DFBE4CA_009.png"],
              padding: false,
              h_space: 0,
              dot_image: 'chars_5DFBE4CA_011.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 327,
              y: 116,
              font_array: ["chars_5DFBE4CA_000.png","chars_5DFBE4CA_001.png","chars_5DFBE4CA_002.png","chars_5DFBE4CA_003.png","chars_5DFBE4CA_004.png","chars_5DFBE4CA_005.png","chars_5DFBE4CA_006.png","chars_5DFBE4CA_007.png","chars_5DFBE4CA_008.png","chars_5DFBE4CA_009.png"],
              padding: false,
              h_space: 0,
              dot_image: 'chars_5DFBE4CA_011.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 138,
              y: 16,
              w: 220,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'trasparente.png',
              normal_src: 'trasparente.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 64,
              y: 65,
              w: 220,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'trasparente.png',
              normal_src: 'trasparente.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 296,
              y: 65,
              w: 100,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'trasparente.png',
              normal_src: 'trasparente.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 152,
              y: 363,
              w: 200,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'trasparente.png',
              normal_src: 'trasparente.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 27,
              y: 169,
              w: 130,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'trasparente.png',
              normal_src: 'trasparente.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 216,
              y: 169,
              w: 130,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'trasparente.png',
              normal_src: 'trasparente.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 374,
              y: 160,
              w: 130,
              h: 72,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'trasparente.png',
              normal_src: 'trasparente.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ZeppPayScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 361,
              y: 364,
              w: 130,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'trasparente.png',
              normal_src: 'trasparente.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 35,
              y: 311,
              w: 130,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'trasparente.png',
              normal_src: 'trasparente.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 178,
              y: 311,
              w: 130,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'trasparente.png',
              normal_src: 'trasparente.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 321,
              y: 311,
              w: 130,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'trasparente.png',
              normal_src: 'trasparente.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'oneKeyAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_12 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 9,
              y: 364,
              w: 130,
              h: 90,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'trasparente.png',
              normal_src: 'trasparente.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let normal_cityNameStr = weatherData.cityName;
              normal_cityNameStr = normal_cityNameStr.toUpperCase();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);

              console.log('Weather city name');
              let idle_cityNameStr = weatherData.cityName;
              idle_cityNameStr = idle_cityNameStr.toUpperCase();
              idle_city_name_text.setProperty(hmUI.prop.TEXT, idle_cityNameStr);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}