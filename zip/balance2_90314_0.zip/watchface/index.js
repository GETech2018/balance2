﻿    /*
    ** Watch_Face_Editor tool v 18.1
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_widget_text_1 = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time = ''
        let normal_date_img_date_day = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_month_name_font = ''
        let normal_Month_Array = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC', ];
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
        let idle_background_bg = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_day = ''
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: conthrax.ttf; FontSize: 18
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 332,
              h: 25,
              text_size: 18,
              char_space: 0,
              line_space: 0,
              font: 'fonts/conthrax.ttf',
              color: 0xFFFA6501,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: conthrax.ttf; FontSize: 25; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 30,
              h: 30,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              font: 'fonts/conthrax.ttf',
              color: 0xFF999999,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_1 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 66,
              y: 84,
              w: 180,
              h: 180,
              text_size: 18,
              char_space: 0,
              font: 'fonts/conthrax.ttf',
              color: 0xFFFA6501,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'STEPS',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 222,
              y: 0,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 318,
              y: 418,
              src: 'Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -4,
              hour_startY: 135,
              hour_array: ["chars_B7F9C92D_000.png","chars_B7F9C92D_001.png","chars_B7F9C92D_002.png","chars_B7F9C92D_003.png","chars_B7F9C92D_004.png","chars_B7F9C92D_005.png","chars_B7F9C92D_006.png","chars_B7F9C92D_007.png","chars_B7F9C92D_008.png","chars_B7F9C92D_009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 256,
              minute_startY: 135,
              minute_array: ["chars_2D433802_000.png","chars_2D433802_001.png","chars_2D433802_002.png","chars_2D433802_003.png","chars_2D433802_004.png","chars_2D433802_005.png","chars_2D433802_006.png","chars_2D433802_007.png","chars_2D433802_008.png","chars_2D433802_009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 252,
              second_startY: 288,
              second_array: ["chars_5E6E68E5_000.png","chars_5E6E68E5_001.png","chars_5E6E68E5_002.png","chars_5E6E68E5_003.png","chars_5E6E68E5_004.png","chars_5E6E68E5_005.png","chars_5E6E68E5_006.png","chars_5E6E68E5_007.png","chars_5E6E68E5_008.png","chars_5E6E68E5_009.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 131,
              day_startY: 424,
              day_sc_array: ["chars_630BC283_000.png","chars_630BC283_001.png","chars_630BC283_002.png","chars_630BC283_003.png","chars_630BC283_004.png","chars_630BC283_005.png","chars_630BC283_006.png","chars_630BC283_007.png","chars_630BC283_008.png","chars_630BC283_009.png"],
              day_tc_array: ["chars_630BC283_000.png","chars_630BC283_001.png","chars_630BC283_002.png","chars_630BC283_003.png","chars_630BC283_004.png","chars_630BC283_005.png","chars_630BC283_006.png","chars_630BC283_007.png","chars_630BC283_008.png","chars_630BC283_009.png"],
              day_en_array: ["chars_630BC283_000.png","chars_630BC283_001.png","chars_630BC283_002.png","chars_630BC283_003.png","chars_630BC283_004.png","chars_630BC283_005.png","chars_630BC283_006.png","chars_630BC283_007.png","chars_630BC283_008.png","chars_630BC283_009.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 222,
              y: 81,
              font_array: ["chars_D88F15DE_000.png","chars_D88F15DE_001.png","chars_D88F15DE_002.png","chars_D88F15DE_003.png","chars_D88F15DE_004.png","chars_D88F15DE_005.png","chars_D88F15DE_006.png","chars_D88F15DE_007.png","chars_D88F15DE_008.png","chars_D88F15DE_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 223,
              y: 45,
              src: 'heart_6_32x32_h49s116b140.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 301,
              y: 82,
              font_array: ["chars_28006F74_000.png","chars_28006F74_001.png","chars_28006F74_002.png","chars_28006F74_003.png","chars_28006F74_004.png","chars_28006F74_005.png","chars_28006F74_006.png","chars_28006F74_007.png","chars_28006F74_008.png","chars_28006F74_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'chars_28006F74_011.png',
              unit_tc: 'chars_28006F74_011.png',
              unit_en: 'chars_28006F74_011.png',
              negative_image: 'chars_28006F74_010.png',
              invalid_image: 'chars_28006F74_012.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 295,
              y: 36,
              image_array: ["set_11_50x50_meteo_1.png","set_11_50x50_meteo_2.png","set_11_50x50_meteo_3.png","set_11_50x50_meteo_4.png","set_11_50x50_meteo_5.png","set_11_50x50_meteo_6.png","set_11_50x50_meteo_7.png","set_11_50x50_meteo_8.png","set_11_50x50_meteo_9.png","set_11_50x50_meteo_10.png","set_11_50x50_meteo_11.png","set_11_50x50_meteo_12.png","set_11_50x50_meteo_13.png","set_11_50x50_meteo_14.png","set_11_50x50_meteo_15.png","set_11_50x50_meteo_16.png","set_11_50x50_meteo_17.png","set_11_50x50_meteo_18.png","set_11_50x50_meteo_19.png","set_11_50x50_meteo_20.png","set_11_50x50_meteo_21.png","set_11_50x50_meteo_22.png","set_11_50x50_meteo_23.png","set_11_50x50_meteo_24.png","set_11_50x50_meteo_25.png","set_11_50x50_meteo_26.png","set_11_50x50_meteo_27.png","set_11_50x50_meteo_28.png","set_11_50x50_meteo_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 126,
              y: 55,
              font_array: ["chars_D88F15DE_000.png","chars_D88F15DE_001.png","chars_D88F15DE_002.png","chars_D88F15DE_003.png","chars_D88F15DE_004.png","chars_D88F15DE_005.png","chars_D88F15DE_006.png","chars_D88F15DE_007.png","chars_D88F15DE_008.png","chars_D88F15DE_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 117,
              y: 356,
              font_array: ["chars_46126422_000.png","chars_46126422_001.png","chars_46126422_002.png","chars_46126422_003.png","chars_46126422_004.png","chars_46126422_005.png","chars_46126422_006.png","chars_46126422_007.png","chars_46126422_008.png","chars_46126422_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'BAT.png',
              unit_tc: 'BAT.png',
              unit_en: 'BAT.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 68,
              y: 322,
              src: 'BAT1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 68,
              y: 321,
              image_array: ["set_38_180x70_h50s100b100_img_level_1.png","set_38_180x70_h50s100b100_img_level_2.png","set_38_180x70_h50s100b100_img_level_3.png","set_38_180x70_h50s100b100_img_level_4.png","set_38_180x70_h50s100b100_img_level_5.png","set_38_180x70_h50s100b100_img_level_6.png","set_38_180x70_h50s100b100_img_level_7.png","set_38_180x70_h50s100b100_img_level_8.png","set_38_180x70_h50s100b100_img_level_9.png","set_38_180x70_h50s100b100_img_level_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 200,
              y: 435,
              w: 95,
              h: 30,
              text_size: 25,
              char_space: 0,
              font: 'fonts/conthrax.ttf',
              color: 0xFF999999,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // unit_string: JAN, FEB, MAR, APR, MAY, JUN, JUL, AUG, SEP, OCT, NOV, DEC,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 200,
              y: 413,
              w: 150,
              h: 30,
              text_size: 25,
              char_space: 0,
              font: 'fonts/conthrax.ttf',
              color: 0xFFFA6501,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // unit_string: MON, TUE, WED, THU, FRI, SAT, SUN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 437,
              y: 264,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 221,
              y: 445,
              src: 'Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -4,
              hour_startY: 135,
              hour_array: ["chars_B7F9C92D_000.png","chars_B7F9C92D_001.png","chars_B7F9C92D_002.png","chars_B7F9C92D_003.png","chars_B7F9C92D_004.png","chars_B7F9C92D_005.png","chars_B7F9C92D_006.png","chars_B7F9C92D_007.png","chars_B7F9C92D_008.png","chars_B7F9C92D_009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 256,
              minute_startY: 135,
              minute_array: ["chars_5E6E68E5_000.png","chars_5E6E68E5_001.png","chars_5E6E68E5_002.png","chars_5E6E68E5_003.png","chars_5E6E68E5_004.png","chars_5E6E68E5_005.png","chars_5E6E68E5_006.png","chars_5E6E68E5_007.png","chars_5E6E68E5_008.png","chars_5E6E68E5_009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 207,
              y: 0,
              font_array: ["chars_46126422_000.png","chars_46126422_001.png","chars_46126422_002.png","chars_46126422_003.png","chars_46126422_004.png","chars_46126422_005.png","chars_46126422_006.png","chars_46126422_007.png","chars_46126422_008.png","chars_46126422_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'BAT.png',
              unit_tc: 'BAT.png',
              unit_en: 'BAT.png',
              // alpha: 200,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img.setAlpha(200);

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 359,
              day_startY: 269,
              day_sc_array: ["chars_630BC283_000.png","chars_630BC283_001.png","chars_630BC283_002.png","chars_630BC283_003.png","chars_630BC283_004.png","chars_630BC283_005.png","chars_630BC283_006.png","chars_630BC283_007.png","chars_630BC283_008.png","chars_630BC283_009.png"],
              day_tc_array: ["chars_630BC283_000.png","chars_630BC283_001.png","chars_630BC283_002.png","chars_630BC283_003.png","chars_630BC283_004.png","chars_630BC283_005.png","chars_630BC283_006.png","chars_630BC283_007.png","chars_630BC283_008.png","chars_630BC283_009.png"],
              day_en_array: ["chars_630BC283_000.png","chars_630BC283_001.png","chars_630BC283_002.png","chars_630BC283_003.png","chars_630BC283_004.png","chars_630BC283_005.png","chars_630BC283_006.png","chars_630BC283_007.png","chars_630BC283_008.png","chars_630BC283_009.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              // alpha: 130,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day.setAlpha(130);

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 236,
              y: 270,
              w: 150,
              h: 30,
              text_size: 25,
              char_space: 0,
              font: 'fonts/conthrax.ttf',
              color: 0xFF808080,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: MON, TUE, WED, THU, FRI, SAT, SUN,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 98,
              y: 24,
              w: 100,
              h: 100,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 201,
              y: 25,
              w: 86,
              h: 100,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 73,
              y: 334,
              w: 108,
              h: 78,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 290,
              y: 0,
              w: 100,
              h: 68,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 291,
              y: 73,
              w: 100,
              h: 54,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 277,
              y: 417,
              w: 100,
              h: 100,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 140,
              y: 415,
              w: 133,
              h: 51,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 22,
              y: 139,
              w: 200,
              h: 166,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1049670, url: 'page/wclk_showLayer' });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 255,
              y: 134,
              w: 200,
              h: 166,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AppListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 255,
              y: 305,
              w: 200,
              h: 106,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FindPhoneScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('month font');
              if (updateHour) {
                let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}