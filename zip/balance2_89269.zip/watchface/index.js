﻿    /*
    ** Watch_Face_Editor tool v 18.0
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_wind_icon_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_speed_text_font = ''
        let normal_widget_text_1 = ''
        let normal_alarm_clock_icon_img = ''
        let normal_alarm_clock_current_text_font = ''
        let normal_sun_icon_img = ''
        let normal_sun_high_text_font = ''
        let normal_sun_low_text_font = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_moon_icon_img = ''
        let normal_moon_high_text_font = ''
        let normal_moon_low_text_font = ''
        let normal_month_name_font = ''
        let normal_Month_Array = ['JAN', 'FEB', 'MÄR', 'APR', 'MAI', 'JUN', 'JUL', 'AUG', 'SEP', 'OKT', 'NOV', 'DEZ', ];
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['MON', 'DIE', 'MIT', 'DON', 'FRE', 'SAM', 'SON'];
        let normal_date_img_date_day = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_max_min_text_font = ''
        let normal_temperature_current_text_font = ''
        let normal_distance_current_text_font = ''
        let normal_spo2_icon_img = ''
        let normal_spo2_current_text_font = ''
        let normal_hrv_icon_img = ''
        let normal_hrv_current_text_font = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_font = ''
        let normal_step_image_progress_img_level = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_font = ''
        let normal_floor_icon_img = ''
        let normal_floor_current_text_font = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_font = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_current_text_font = ''
        let normal_altitude_target_text_font = ''
        let normal_altimeter_current_text_font = ''
        let normal_bio_charge_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let idle_month_name_font = ''
        let idle_Month_Array = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC', ];
        let idle_day_text_font = ''
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_current_text_font = ''
        let idle_digital_clock_img_time = ''
        let normal_cal_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_altitude_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: 1.ttf; FontSize: 32
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 370,
              h: 45,
              text_size: 32,
              char_space: 0,
              line_space: 0,
              font: 'fonts/1.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: 1.ttf; FontSize: 40
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 505,
              h: 55,
              text_size: 40,
              char_space: 2,
              line_space: 0,
              font: 'fonts/1.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: 1.ttf; FontSize: 30; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 36,
              h: 36,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/1.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: 1.ttf; FontSize: 24
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 370,
              h: 34,
              text_size: 24,
              char_space: 3,
              line_space: 0,
              font: 'fonts/1.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: 1.ttf; FontSize: 34
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 380,
              h: 46,
              text_size: 34,
              char_space: 0,
              line_space: 0,
              font: 'fonts/1.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: 1.ttf; FontSize: 36
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 441,
              h: 51,
              text_size: 36,
              char_space: 1,
              line_space: 0,
              font: 'fonts/1.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: 1.ttf; FontSize: 36; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 43,
              h: 43,
              text_size: 36,
              char_space: 1,
              line_space: 0,
              font: 'fonts/1.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: arialbd.ttf; FontSize: 34
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 444,
              h: 46,
              text_size: 34,
              char_space: 0,
              line_space: 0,
              font: 'fonts/arialbd.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: 1.ttf; FontSize: 45
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 506,
              h: 61,
              text_size: 45,
              char_space: 0,
              line_space: 0,
              font: 'fonts/1.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script_start.js');
            // start user_script_start.js

            let btn_zone1 = ''
            let zone1_num = 0
            function click_zone1() {
            
              zone1_num = (zone1_num + 1) % 3;
            
              if (zone1_num == 0) {
            
                normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
                normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
            
                normal_floor_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
                normal_floor_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            
                normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
                normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            
              } else if (zone1_num == 1) {
            
                normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            
                normal_floor_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
                normal_floor_icon_img.setProperty(hmUI.prop.VISIBLE, true);
            
                normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
                normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
              }
                else if (zone1_num == 2) {
            
                normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            
                normal_floor_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
                normal_floor_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            
                normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
                normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, true);
              }
            }

            let btn_zone2 = ''
            let zone2_num = 0
            function click_zone2() {
            
              zone2_num = (zone2_num + 1) % 3;
            
              if (zone2_num == 0) {
            
                normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, true);
                normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);
            
                normal_spo2_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
                normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            
                normal_hrv_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
                normal_hrv_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            
              } else if (zone2_num == 1) {
            
                normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            
                normal_spo2_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
                normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, true);
            
                normal_hrv_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
                normal_hrv_icon_img.setProperty(hmUI.prop.VISIBLE, false);
              }
                else if (zone2_num == 2) {
            
                normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            
                normal_spo2_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
                normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            
                normal_hrv_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
                normal_hrv_icon_img.setProperty(hmUI.prop.VISIBLE, true);
              }
            }
           let normal_sunset_jumpable_img_click = ''
           let normal_moonrise_jumpable_img_click = ''
let btn_sunmoon = ''
let sunmoon_mode = 0

function click_sunmoon() {

  sunmoon_mode = (sunmoon_mode + 1) % 2

  // ==========================================
  // SONNE
  // ==========================================
  if (sunmoon_mode == 0) {

    // Sonne anzeigen
    normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, true)
    normal_sun_high_text_font.setProperty(hmUI.prop.VISIBLE, true)
    normal_sun_low_text_font.setProperty(hmUI.prop.VISIBLE, true)

    // Mond ausblenden
    normal_moon_icon_img.setProperty(hmUI.prop.VISIBLE, false)
    normal_moon_high_text_font.setProperty(hmUI.prop.VISIBLE, false)
    normal_moon_low_text_font.setProperty(hmUI.prop.VISIBLE, false)

    // Sonnen-Verknüpfungen aktiv
    normal_sunrise_jumpable_img_click.setProperty(
      hmUI.prop.VISIBLE,
      true
    )
    normal_sunset_jumpable_img_click.setProperty(
      hmUI.prop.VISIBLE,
      true
    )
    // Mond-Verknüpfungen deaktivieren
    normal_moonrise_jumpable_img_click.setProperty(
      hmUI.prop.VISIBLE,
      false
    )
    normal_moon_jumpable_img_click.setProperty(
      hmUI.prop.VISIBLE,
      false
    )

  }

  // ==========================================
  // MOND
  // ==========================================
  else {

    // Sonne ausblenden
    normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false)
    normal_sun_high_text_font.setProperty(hmUI.prop.VISIBLE, false)
    normal_sun_low_text_font.setProperty(hmUI.prop.VISIBLE, false)

    // Mond anzeigen
    normal_moon_icon_img.setProperty(hmUI.prop.VISIBLE, true)
    normal_moon_high_text_font.setProperty(hmUI.prop.VISIBLE, true)
    normal_moon_low_text_font.setProperty(hmUI.prop.VISIBLE, true)

    // Sonnen-Verknüpfungen deaktivieren
    normal_sunrise_jumpable_img_click.setProperty(
      hmUI.prop.VISIBLE,
      false
    )
    normal_sunset_jumpable_img_click.setProperty(
      hmUI.prop.VISIBLE,
      false
    )

    // Mond-Verknüpfungen aktiv
    normal_moonrise_jumpable_img_click.setProperty(
      hmUI.prop.VISIBLE,
      true
    )
    normal_moon_jumpable_img_click.setProperty(
      hmUI.prop.VISIBLE,
      true
    )
  }
}

let btn_tempwind = ''
let tempwind_mode = 0

function click_tempwind() {

    tempwind_mode = (tempwind_mode + 1) % 2

    if (tempwind_mode == 0) {
    // Aktuelle Temperatur anzeigen
      normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, true)
    // Wind-Infos ausblenden
      normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, false)
      normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false)
      normal_wind_speed_text_font.setProperty(hmUI.prop.VISIBLE, false)

    } else {
    // Aktuelle Temperatur ausblenden
      normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, false)
    // Wind-Infos einblenden
      normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, true)
      normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true)
      normal_wind_speed_text_font.setProperty(hmUI.prop.VISIBLE, true)
    }
}
            // end user_script_start.js

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 233,
              y: 87,
              src: 'wind_my.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 280,
              y: 80,
              image_array: ["weather_icon_wind_1.png","weather_icon_wind_2.png","weather_icon_wind_3.png","weather_icon_wind_4.png","weather_icon_wind_5.png","weather_icon_wind_6.png","weather_icon_wind_7.png","weather_icon_wind_8.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_speed_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 230,
              y: 120,
              w: 150,
              h: 43,
              text_size: 30,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.WIND_SPEED,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_1 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 45,
              y: 326,
              w: 385,
              h: 32,
              text_size: 32,
              char_space: 0,
              font: 'fonts/1.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              text: 'Barometer     Altimeter      Distanz',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 340,
              y: 240,
              src: 'alarm32.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 379,
              y: 241,
              w: 90,
              h: 38,
              text_size: 40,
              char_space: 2,
              font: 'fonts/1.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 206,
              y: 12,
              src: 'sunupdown1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 120,
              y: 41,
              w: 84,
              h: 35,
              text_size: 32,
              char_space: 0,
              color: 0xFFF0B30F,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 285,
              y: 41,
              w: 81,
              h: 32,
              text_size: 32,
              char_space: 0,
              color: 0xFFF0B30F,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 360,
              y: 389,
              src: 'can.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 211,
              y: 42,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 206,
              y: 16,
              src: 'moonupdown.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 120,
              y: 41,
              w: 84,
              h: 35,
              text_size: 32,
              char_space: 0,
              color: 0xFFFF8C00,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.MOON_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 285,
              y: 41,
              w: 84,
              h: 35,
              text_size: 32,
              char_space: 0,
              color: 0xFFFF8C00,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.MOON_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 129,
              y: 119,
              w: 90,
              h: 40,
              text_size: 30,
              char_space: 0,
              font: 'fonts/1.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: JAN, FEB, MÄR, APR, MAI, JUN, JUL, AUG, SEP, OKT, NOV, DEZ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 129,
              y: 93,
              w: 90,
              h: 40,
              text_size: 30,
              char_space: 0,
              font: 'fonts/1.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: MON, DIE, MIT, DON, FRE, SAM, SON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 58,
              day_startY: 94,
              day_sc_array: ["clim0.png","clim1.png","clim2.png","clim3.png","clim4.png","clim5.png","clim6.png","clim7.png","clim8.png","clim9.png"],
              day_tc_array: ["clim0.png","clim1.png","clim2.png","clim3.png","clim4.png","clim5.png","clim6.png","clim7.png","clim8.png","clim9.png"],
              day_en_array: ["clim0.png","clim1.png","clim2.png","clim3.png","clim4.png","clim5.png","clim6.png","clim7.png","clim8.png","clim9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 352,
              y: 74,
              image_array: ["w00.png","w01.png","w02.png","w03.png","w04.png","w05.png","w06.png","w07.png","w08.png","w09.png","w10.png","w11.png","w12.png","w13.png","w14.png","w15.png","w16.png","w17.png","w18.png","w19.png","w20.png","w21.png","w22.png","w23.png","w24.png","w25.png","w26.png","w27.png","w28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_max_min_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 344,
              y: 138,
              w: 90,
              h: 30,
              text_size: 24,
              char_space: 3,
              font: 'fonts/1.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_HIGH_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 227,
              y: 79,
              w: 150,
              h: 87,
              text_size: 65,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 337,
              y: 353,
              w: 90,
              h: 34,
              text_size: 34,
              char_space: 0,
              font: 'fonts/1.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 24,
              y: 285,
              src: 'spo2_48.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 80,
              y: 280,
              w: 150,
              h: 36,
              text_size: 36,
              char_space: 1,
              font: 'fonts/1.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_hrv_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 23,
              y: 287,
              src: 'hrv_txt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_hrv_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 87,
              y: 280,
              w: 150,
              h: 36,
              text_size: 36,
              char_space: 1,
              font: 'fonts/1.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.HRV,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 23,
              y: 282,
              src: 'hrv.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 72,
              y: 280,
              w: 150,
              h: 41,
              text_size: 36,
              char_space: 1,
              font: 'fonts/1.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 240,
              y: 239,
              image_array: ["pa01.png","pa02.png","pa03.png","pa04.png","pa05.png","pa06.png","pa07.png","pa08.png","pa09.png","pa10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 420,
              y: 286,
              src: 'stepicon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 334,
              y: 280,
              w: 76,
              h: 36,
              text_size: 36,
              char_space: 0,
              font: 'fonts/1.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_floor_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 415,
              y: 282,
              src: 'floor.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_floor_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 334,
              y: 280,
              w: 76,
              h: 36,
              text_size: 36,
              char_space: 0,
              font: 'fonts/1.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.FLOOR,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 417,
              y: 283,
              src: 'cal_38.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 334,
              y: 280,
              w: 76,
              h: 36,
              text_size: 36,
              char_space: 0,
              font: 'fonts/1.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 182,
              y: 282,
              image_array: ["bat_10.png","bat_20.png","bat_30.png","bat_35.png","bat_40.png","bat_50.png","bat_60.png","bat_70.png","bat_80.png","bat_90.png","bat_100.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 221,
              y: 282,
              w: 150,
              h: 34,
              text_size: 34,
              char_space: 0,
              font: 'fonts/arialbd.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 207,
              y: 355,
              w: 69,
              h: 34,
              text_size: 34,
              char_space: 0,
              font: 'fonts/1.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 60,
              y: 355,
              w: 80,
              h: 34,
              text_size: 34,
              char_space: 0,
              font: 'fonts/1.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 3,
              y: 1,
              image_array: ["bi01.png","bi02.png","bi03.png","bi04.png","bi05.png","bi06.png","bi07.png","bi08.png","bi09.png","bi10.png"],
              image_length: 10,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 32,
              hour_startY: 177,
              hour_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 193,
              minute_startY: 177,
              minute_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 323,
              second_startY: 179,
              second_array: ["clim0.png","clim1.png","clim2.png","clim3.png","clim4.png","clim5.png","clim6.png","clim7.png","clim8.png","clim9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 235,
              y: 64,
              w: 150,
              h: 30,
              text_size: 30,
              char_space: 0,
              font: 'fonts/1.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: JAN, FEB, MAR, APR, MAY, JUN, JUL, AUG, SEP, OCT, NOV, DEC,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 215,
              y: 64,
              w: 50,
              h: 30,
              text_size: 30,
              char_space: 0,
              font: 'fonts/1.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 103,
              y: 64,
              w: 150,
              h: 30,
              text_size: 30,
              char_space: 0,
              font: 'fonts/1.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: MON, TUE, WED, THU, FRI, SAT, SUN,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 224,
              y: 389,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 225,
              y: 0,
              src: 'alar.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 162,
              y: 430,
              w: 150,
              h: 50,
              text_size: 45,
              char_space: 0,
              font: 'fonts/1.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 79,
              hour_startY: 92,
              hour_array: ["hour_0.png","hour_1.png","hour_2.png","hour_3.png","hour_4.png","hour_5.png","hour_6.png","hour_7.png","hour_8.png","hour_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 79,
              minute_startY: 238,
              minute_array: ["hour_0.png","hour_1.png","hour_2.png","hour_3.png","hour_4.png","hour_5.png","hour_6.png","hour_7.png","hour_8.png","hour_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('user_script_beforeShortcuts.js');
            // start user_script_beforeShortcuts.js

            normal_sunset_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 285,
              y: 32,
              w: 90,
              h: 43,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
           normal_moonrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 111,
              y: 32,
              w: 260,
              h: 43,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
            normal_floor_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
            normal_floor_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
            normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, true);
            normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_spo2_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
            normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_hrv_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
            normal_hrv_icon_img.setProperty(hmUI.prop.VISIBLE, false);

            btn_zone1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 315,
              y: 286,
              text: '',
              w: 150,
              h: 50,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
                click_zone1();
             },
              longpress_func: () => {
             hmApp.startApp({ url: "activityAppScreen", native: true });
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zone1.setProperty(hmUI.prop.VISIBLE, true);

            btn_zone2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 16,
              y: 275,
              text: '',
              w: 150,
              h: 50,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
                click_zone2();
             },
              longpress_func: () => {
             hmApp.startApp({ url: "activityAppScreen", native: true });
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zone2.setProperty(hmUI.prop.VISIBLE, true);
            
            // ==========================================
            // STARTZUSTAND = SONNE
            // ==========================================
            
            normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, true)
            normal_sun_high_text_font.setProperty(hmUI.prop.VISIBLE, true)
            normal_sun_low_text_font.setProperty(hmUI.prop.VISIBLE, true)
            
            normal_moon_icon_img.setProperty(hmUI.prop.VISIBLE, false)
            normal_moon_high_text_font.setProperty(hmUI.prop.VISIBLE, false)
            normal_moon_low_text_font.setProperty(hmUI.prop.VISIBLE, false)
            
            sunmoon_mode = 0
            
            // ==========================================
            // BUTTON NUR ÜBER MITTLEREM SYMBOL
            // ==========================================
            
            btn_sunmoon = hmUI.createWidget(hmUI.widget.BUTTON, {
            
              x: 205,
              y: 10,
              w: 70,
              h: 70,
            
              text: '',
            
              normal_src: 'transparent.png',
              press_src: 'transparent.png',
            
              click_func: () => {
                click_sunmoon()
              },
            
              show_level: hmUI.show_level.ONLY_NORMAL,
            })
           // ==========================================
           // STARTZUSTAND = TEMPERATUR
           // ==========================================
           
           normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, true)
           normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, false)
           normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false)
           normal_wind_speed_text_font.setProperty(hmUI.prop.VISIBLE, false)
           
           tempwind_mode = 0
           
           // ==========================================
           // BUTTON NUR ÜBER AKTUELLEM TEMPERATURBEREICH
           // ==========================================
           
           btn_tempwind = hmUI.createWidget(hmUI.widget.BUTTON, {
           
             x: 220,
             y: 80,
             w: 100,
             h: 80,
           
             text: '',
           
             normal_src: 'transparent.png',
             press_src: 'transparent.png',
           
             click_func: () => {
               click_tempwind()
             },
           
             show_level: hmUI.show_level.ONLY_NORMAL,
           })

            // end user_script_beforeShortcuts.js
            console.log('Watch_Face.Shortcuts');

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 326,
              y: 337,
              w: 125,
              h: 50,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 177,
              y: 278,
              w: 128,
              h: 57,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 111,
              y: 32,
              w: 90,
              h: 43,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 285,
              y: 32,
              w: 90,
              h: 43,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 32,
              y: 335,
              w: 125,
              h: 52,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 332,
              y: 235,
              w: 151,
              h: 49,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 177,
              y: 335,
              w: 130,
              h: 52,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 193,
              y: 390,
              w: 90,
              h: 72,
              text: '',
              color: 0xFFFFFFFF,
              text_size: 21,
              press_src: 'transparent.png',
              normal_src: 'comp_64.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CompassScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'OfflineMapScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 46,
              y: 76,
              w: 159,
              h: 90,
              text: '',
              color: 0xFFFF8000,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 346,
              y: 81,
              w: 90,
              h: 86,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 171,
              w: 159,
              h: 99,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1049670, url: 'page/wclk_showLayer' });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 182,
              y: 171,
              w: 130,
              h: 99,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 320,
              y: 171,
              w: 72,
              h: 62,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 102,
              y: 389,
              w: 85,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 23,
              press_src: 'phone_56.png',
              normal_src: 'phone_56.png',
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 284,
              y: 390,
              w: 77,
              h: 62,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'tools_48.png',
              normal_src: 'training_64.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'AppListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('month font');
              if (updateHour) {
                let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('month font');
              if (updateHour) {
                let idle_Month_Str = idle_Month_Array[timeSensor.month-1];
                idle_month_name_font.setProperty(hmUI.prop.TEXT, idle_Month_Str );
              };

              console.log('day font');
              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_dayStr = idle_dayStr.padStart(2, '0');
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}