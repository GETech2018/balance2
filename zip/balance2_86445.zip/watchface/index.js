﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_image_img = ''
        let normal_humidity_icon_img = ''
        let normal_humidity_text_text_img = ''
        let normal_humidity_image_progress_img_progress = ''
        let normal_altimeter_icon_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_wind_icon_img = ''
        let normal_wind_text_text_img = ''
        let normal_temperature_icon_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['LUN', 'MAR', 'MER', 'GIO', 'VEN', 'SAB', 'DOM'];
        let normal_date_img_date_day = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_smooth_second = ''
        let idle_background_bg = ''
        let idle_image_img = ''
        let idle_humidity_icon_img = ''
        let idle_humidity_text_text_img = ''
        let idle_humidity_image_progress_img_progress = ''
        let idle_altimeter_icon_img = ''
        let idle_altimeter_text_text_img = ''
        let idle_wind_icon_img = ''
        let idle_wind_text_text_img = ''
        let idle_temperature_icon_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_step_icon_img = ''
        let idle_step_current_text_img = ''
        let idle_calorie_icon_img = ''
        let idle_calorie_current_text_img = ''
        let idle_heart_rate_icon_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_date_img_date_month_img = ''
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['LUN', 'MAR', 'MER', 'GIO', 'VEN', 'SAB', 'DOM'];
        let idle_date_img_date_day = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_battery_text_text_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_Switch_BG_Color = ''

        let bgColorIndex = 0;
        let bgColorList = [0xFFFFFFFF, 0xFFFFFF00, 0xFFFF8000, 0xFF00FF00, 0xFFFF0000, 0xFF00FFFF, 0xFF0080FF, 0xFF808080];
        let bgColorToastList = ['Sfondo %s', 'Sfondo %s', 'Sfondo %s', 'Sfondo %s', 'Sfondo %s', 'Sfondo %s', 'Sfondo %s', 'Sfondo %s'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            //start of ignored block
            console.log('SwitchBG_Color');
            function switchBG_Color() {
              bgColorIndex++;
              if (bgColorIndex >= bgColorList.length) bgColorIndex = 0;
              hmFS.SysProSetInt(`bgColorIndex_${watchfaceId}`, bgColorIndex);
              let toastText = bgColorToastList[bgColorIndex].replace('%s', `${bgColorIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
              vibro(28);
            };
            //end of ignored block

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFFFFFFFF',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 263,
              y: 330,
              src: '0109.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 176,
              y: 418,
              font_array: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_image_progress_img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
              x: [222],
              y: [423],
              image_array: ["0110.png"],
              image_length: 1,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 270,
              y: 288,
              src: '0101.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 345,
              y: 274,
              font_array: ["0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 353,
              y: 247,
              src: '0065.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 394,
              y: 236,
              font_array: ["0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 264,
              y: 245,
              src: '0111.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 288,
              y: 236,
              font_array: ["0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0102.png',
              unit_tc: '0102.png',
              unit_en: '0102.png',
              negative_image: '0103.png',
              invalid_image: '0066.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 202,
              y: 247,
              image_array: ["0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0091_(2).png","0092.png","0093.png","0094.png","0095.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 299,
              y: 200,
              src: '0107.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 333,
              y: 190,
              font_array: ["0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 327,
              y: 152,
              src: '0108.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 362,
              y: 143,
              font_array: ["0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
              padding: false,
              h_space: -5,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 329,
              y: 106,
              src: '0106.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 359,
              y: 94,
              font_array: ["0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
              padding: false,
              h_space: -6,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 139,
              month_startY: 14,
              month_sc_array: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png"],
              month_tc_array: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png"],
              month_en_array: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 165,
              y: 106,
              w: 150,
              h: 50,
              text_size: 40,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: LUN,MAR,MER,GIO,VEN,SAB,DOM,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 211,
              day_startY: 52,
              day_sc_array: ["0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png"],
              day_tc_array: ["0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png"],
              day_en_array: ["0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0022.png',
              center_x: 104,
              center_y: 238,
              x: 12,
              y: 97,
              start_angle: 71,
              end_angle: 289,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 85,
              y: 172,
              font_array: ["0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 87,
              y: 343,
              src: '0091_(2).png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 265,
              y: 404,
              src: '0113.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 134,
              hour_startY: 310,
              hour_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 250,
              minute_startY: 310,
              minute_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 349,
              second_startY: 325,
              second_array: ["0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 234,
              y: 334,
              src: '0100.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 's0012.png',
              // center_x: 240,
              // center_y: 240,
              // x: 28,
              // y: 238,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_smooth_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 's0012.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 28,
              second_posY: 238,
              fresh_frequency: 25,
              fresh_freqency: 25,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 3,
              // fps: 25,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFFFFFFFF',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 263,
              y: 330,
              src: '0109.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 176,
              y: 418,
              font_array: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_image_progress_img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
              x: [222],
              y: [423],
              image_array: ["0110.png"],
              image_length: 1,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 270,
              y: 288,
              src: '0101.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 345,
              y: 274,
              font_array: ["0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 353,
              y: 247,
              src: '0065.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 394,
              y: 236,
              font_array: ["0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 264,
              y: 245,
              src: '0111.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 288,
              y: 236,
              font_array: ["0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0102.png',
              unit_tc: '0102.png',
              unit_en: '0102.png',
              negative_image: '0103.png',
              invalid_image: '0066.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 202,
              y: 247,
              image_array: ["0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0091_(2).png","0092.png","0093.png","0094.png","0095.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 299,
              y: 200,
              src: '0107.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 333,
              y: 190,
              font_array: ["0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 327,
              y: 152,
              src: '0108.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 362,
              y: 143,
              font_array: ["0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
              padding: false,
              h_space: -5,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 329,
              y: 106,
              src: '0106.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 359,
              y: 94,
              font_array: ["0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
              padding: false,
              h_space: -6,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 139,
              month_startY: 14,
              month_sc_array: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png"],
              month_tc_array: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png"],
              month_en_array: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 165,
              y: 106,
              w: 150,
              h: 50,
              text_size: 40,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: LUN,MAR,MER,GIO,VEN,SAB,DOM,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 211,
              day_startY: 52,
              day_sc_array: ["0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png"],
              day_tc_array: ["0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png"],
              day_en_array: ["0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0022.png',
              center_x: 104,
              center_y: 238,
              x: 12,
              y: 97,
              start_angle: 71,
              end_angle: 289,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 85,
              y: 172,
              font_array: ["0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 134,
              hour_startY: 310,
              hour_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 250,
              minute_startY: 310,
              minute_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 234,
              y: 334,
              src: '0100.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 87,
              y: 343,
              src: '0091_(2).png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 265,
              y: 404,
              src: '0113.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 307,
              y: 193,
              w: 120,
              h: 45,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 333,
              y: 106,
              w: 94,
              h: 40,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 327,
              y: 150,
              w: 100,
              h: 40,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 47,
              y: 190,
              w: 100,
              h: 100,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 189,
              y: 242,
              w: 100,
              h: 73,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 314,
              y: 280,
              w: 100,
              h: 40,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 133,
              y: 331,
              w: 100,
              h: 70,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 252,
              y: 331,
              w: 100,
              h: 70,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 260,
              y: 411,
              w: 50,
              h: 50,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 189,
              y: 71,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_empty.png',
              normal_src: '0_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 331,
              y: 46,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_empty.png',
              normal_src: '0_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneContactsScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('Watch_Face.SwitchBG_Color');
            // Button_Switch_BG_Color = hmUI.createWidget(hmUI.widget.SwitchBG_Color, {
              // x: 36,
              // y: 99,
              // w: 70,
              // h: 70,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // press_src: '0_empty.png',
              // normal_src: '0_empty.png',
              // color_list: 0xFFFFFFFF|0xFFFFFF00|0xFFFF8000|0xFF00FF00|0xFFFF0000|0xFF00FFFF|0xFF0080FF|0xFF808080,
              // toast_list: Sfondo %s|Sfondo %s|Sfondo %s|Sfondo %s|Sfondo %s|Sfondo %s|Sfondo %s|Sfondo %s,
              // use_crown: False,
              // use_in_AOD: True,
              // vibro: True,
            // });

            Button_Switch_BG_Color = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 36,
              y: 99,
              w: 70,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_empty.png',
              normal_src: '0_empty.png',
              click_func: (button_widget) => {
                switchBG_Color();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            // vibrate function
            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;

            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);

                //SwitchBgColor
                if (hmFS.SysProGetInt(`bgColorIndex_${watchfaceId}`) === undefined) {
                  bgColorIndex = 0;
                  hmFS.SysProSetInt(`bgColorIndex_${watchfaceId}`, bgColorIndex);
                } else {
                  bgColorIndex = hmFS.SysProGetInt(`bgColorIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg) normal_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
                if (screenType == hmSetting.screen_type.AOD && idle_background_bg) idle_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}