﻿/* Analogue face: the apostles dial, three gold hands.
 *
 * TIME_POINTER does the rotation itself - it takes the image, the point on
 * screen to turn around, and where to place the image's top-left corner. The
 * pivot inside each image is therefore (centre - pos), and the build computes
 * pos from the ring it found in each hand.
 *
 * The second hand is deliberately absent from AOD. The idle screen refreshes
 * about once a minute, so a second hand there would sit frozen at whatever
 * position it happened to hold - which reads as a stopped watch, not a
 * sleeping one. Hour and minute both stay.
 *
 * Carries the constraints established earlier: show_level on every visual
 * widget, BOM + pure-ASCII source, each widget's w/h equal to its asset's real
 * size so the runtime never rescales a tile.
 */
try {
(() => {
const __$$app$$__ = __$$hmAppManager$$__.currentApp;
function getApp() { return __$$app$$__.app; }
function getCurrentPage() { return __$$app$$__.current && __$$app$$__.current.module; }
const __$$module$$__ = __$$app$$__.current;
const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
const {px} = __$$app$$__.__globals__;
const CFG = {"maos":{"hora":{"w":32,"h":199,"posX":15,"posY":167},"minuto":{"w":32,"h":247,"posX":12,"posY":202},"segundo":{"w":32,"h":340,"posX":11,"posY":216}},"cx":240,"cy":240};

const NORMAL = hmUI.show_level.ONLY_NORMAL;
const AODLV = hmUI.show_level.ONLY_AOD;
const BOTH = NORMAL | AODLV;

__$$module$$__.module = DeviceRuntimeCore.WatchFace({
  init_view() {
    const M = CFG.maos;

    /* Ground first, always. */
    hmUI.createWidget(hmUI.widget.IMG, { x: 0, y: 0, w: 480, h: 480,
      src: 'dial.png', show_level: BOTH });

    hmUI.createWidget(hmUI.widget.TIME_POINTER, {
      hour_path: 'hora.png',
      hour_centerX: CFG.cx, hour_centerY: CFG.cy,
      hour_posX: M.hora.posX, hour_posY: M.hora.posY,
      show_level: BOTH });

    hmUI.createWidget(hmUI.widget.TIME_POINTER, {
      minute_path: 'minuto.png',
      minute_centerX: CFG.cx, minute_centerY: CFG.cy,
      minute_posX: M.minuto.posX, minute_posY: M.minuto.posY,
      show_level: BOTH });

    hmUI.createWidget(hmUI.widget.TIME_POINTER, {
      second_path: 'segundo.png',
      second_centerX: CFG.cx, second_centerY: CFG.cy,
      second_posX: M.segundo.posX, second_posY: M.segundo.posY,
      show_level: NORMAL });
  },
  onInit() {},
  build() { this.init_view(); },
  onDestroy() {}
});
})();
} catch (e) {
  console.log('Mini Program Error', e);
  e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
}
