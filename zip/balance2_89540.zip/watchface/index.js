﻿/* KIAA LCD Bordo - three bands, full AOD, seven tap targets.
 *
 * Top third: maroon ground, cream date and weekday. Middle third: the colours
 * swap, maroon hours on cream. Bottom third: brushed plate, coloured metrics.
 *
 * AOD shows all of it unchanged, so every widget is marked for both levels with
 * ONLY_NORMAL | ONLY_AOD - the pattern used by 675 widgets across the reference
 * watchfaces. One set means the two modes cannot drift apart.
 *
 * The four metric values are text over a bundled TTF, not image tiles. An SOMH
 * image must be a multiple of 16 wide, so building a value out of tiles made
 * the pitch jump from 18 to 34 the moment a digit needed more than 16px of ink,
 * which capped the values at font 30. Laying out with the font's own metrics
 * lifts that to 56 - nearly double the glyph height - and the colour becomes a
 * property, so the per-colour glyph sets are gone too.
 *
 * Two different widgets, though: temperature and hybrid charge are TEXT_FONT
 * bound to a data_type, while battery and sleep are TEXT filled from paint().
 * They are not interchangeable - see valueWidget below.
 *
 * All seven taps are BUTTON widgets with a transparent source and a click_func
 * opening a native screen, which is how the reference faces do it. The screen
 * names come from the ZeppOS watchface editor's own ButtonFunctions.resx.
 *
 * Carries the fixes the earlier builds needed:
 *   - the ground is created first; creating it later put it on top of
 *     everything made before it and erased the icons
 *   - ts.week is 1=Monday..7=Sunday, so the weekday array is indexed by week-1
 *   - show_level on every visual widget; omitting it leaves a black screen
 *   - BOM + pure-ASCII source; each IMG's w/h equals its asset's real size so
 *     the runtime never rescales a tile
 */
try {
(() => {
const __$$app$$__ = __$$hmAppManager$$__.currentApp;
function getApp() { return __$$app$$__.app; }
function getCurrentPage() { return __$$app$$__.current && __$$app$$__.current.module; }
const __$$module$$__ = __$$app$$__.current;
const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
const {px} = __$$app$$__.__globals__;
const CFG = {"dw":{"0":64,"1":48,"2":64,"3":64,"4":64,"5":64,"6":64,"7":64,"8":64,"9":64,"sl":48},"dink":{"0":53,"1":32,"2":50,"3":49,"4":52,"5":48,"6":48,"7":44,"8":49,"9":49,"sl":34},"dh":75,"diaw":[272,192,240,208,192,240,256],"diah":50,"dateCy":55,"weekCy":116,"icon":{"w":32,"h":32},"val":{"font":"fonts/barlow.ttf","size":53},"dig":{"w":128,"h":182,"ty":149,"h0":3,"h1":113,"m0":239,"m1":349},"sep":{"x":238,"y":196,"w":5,"h":88},"sepCol":4279513887,"datePre":["dw_","dw_","dw_","dw_","dw_"],"digPre":["d","d","d","d"],"valCol":{"temp":4289253517,"sono":4289253517,"hyb":4289253517,"bat":4289253517},"slots":{"temp":{"ix":84,"x":124,"y":357,"w":91,"h":64},"sono":{"ix":227,"x":267,"y":357,"w":136,"h":64},"hyb":{"ix":84,"x":124,"y":410,"w":82,"h":64},"bat":{"ix":227,"x":267,"y":410,"w":127,"h":64}},"taps":[{"x":100,"y":18,"w":280,"h":122,"screen":"ScheduleCalScreen"},{"x":7,"y":157,"w":230,"h":166,"screen":"StopWatchScreen"},{"x":243,"y":157,"w":230,"h":166,"screen":"CountdownAppScreen"},{"x":78,"y":331,"w":143,"h":52,"screen":"WeatherScreen"},{"x":78,"y":384,"w":134,"h":52,"screen":"BioChargeHomeScreen"},{"x":221,"y":331,"w":188,"h":52,"screen":"Sleep_HomeScreen"},{"x":221,"y":384,"w":179,"h":52,"screen":"Settings_batteryManagerScreen"}]};

const BOTH = hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD;
const GM = {'0':'0','1':'1','2':'2','3':'3','4':'4','5':'5','6':'6','7':'7','8':'8','9':'9',
            '/':'sl'};

let wH0, wH1, wM0, wM1, wWeek, wDate = [], wBat, wSleep;
let ts = null;

function t2(v) { return v < 10 ? '0' + v : '' + v; }

/* The date keeps its image tiles: it is large, it is only digits and a slash,
 * and the per-glyph placement is already exact. */
const DATE = [CFG.dw, CFG.dink, CFG.dh];

function strWidth(str, set) {
  let t = 0;
  for (let i = 0; i < str.length; i++) t += set[1][GM[str[i]]] + 1;
  return t;
}

/* `pre` is an array, one prefix per character position - that is what lets a
 * multicolour palette give every glyph its own colour without any runtime
 * tinting, which the widget layer cannot do for images. */
function drawStr(slots, str, x0, cy, pre, set) {
  let x = x0;
  for (let i = 0; i < slots.length; i++) {
    if (i < str.length) {
      const k = GM[str[i]];
      slots[i].setProperty(hmUI.prop.MORE, {
        x: Math.round(x - (set[0][k] - set[1][k]) / 2),
        y: Math.round(cy - set[2] / 2),
        w: set[0][k], h: set[2], src: pre[i] + k + '.png', show_level: BOTH
      });
      slots[i].setProperty(hmUI.prop.VISIBLE, true);
      x += set[1][k] + 1;
    } else {
      slots[i].setProperty(hmUI.prop.VISIBLE, false);
    }
  }
}

/* TEXT_FONT and TEXT are not interchangeable. TEXT_FONT is bound to a
 * data_type and the runtime fills it; TEXT holds free text set through
 * prop.TEXT. Building battery and sleep as TEXT_FONT left them blank on the
 * watch - the widget had no data_type to read from and ignored the text.
 * Both accept the same bundled font, size and colour. */
function valueWidget(slot, color, dtype) {
  const o = {
    x: slot.x, y: Math.round(slot.y - slot.h / 2), w: slot.w, h: slot.h,
    text_size: CFG.val.size, font: CFG.val.font, color: color,
    char_space: 0, line_space: 0,
    align_h: hmUI.align.LEFT, align_v: hmUI.align.CENTER_V,
    text_style: hmUI.text_style.NONE, show_level: BOTH
  };
  if (dtype !== null) {
    o.type = dtype;
    o.unit_type = 1;
    return hmUI.createWidget(hmUI.widget.TEXT_FONT, o);
  }
  o.text = '';
  return hmUI.createWidget(hmUI.widget.TEXT, o);
}

function paint() {
  if (!ts) ts = hmSensor.createSensor(hmSensor.id.TIME);
  /* 12-hour display, zero padded: 14:22 reads as 02:22. Forced rather than
   * read from ts.format_hour, which tracks the watch's own 12/24 setting - the
   * request was for this face to show 12-hour whatever the watch is set to. */
  let h12 = ts.hour % 12;
  if (h12 === 0) h12 = 12;
  const hh = t2(h12), mm = t2(ts.minute);
  const ds = t2(ts.day) + '/' + t2(ts.month);
  /* ts.week is 1=Monday..7=Sunday, so DIAS (which starts at SEGUNDA) is
   * indexed by week-1. */
  const dw = ts.week - 1;

  const P = CFG.digPre;
  wH0.setProperty(hmUI.prop.SRC, P[0] + hh[0] + '.png');
  wH1.setProperty(hmUI.prop.SRC, P[1] + hh[1] + '.png');
  wM0.setProperty(hmUI.prop.SRC, P[2] + mm[0] + '.png');
  wM1.setProperty(hmUI.prop.SRC, P[3] + mm[1] + '.png');

  drawStr(wDate, ds, 240 - strWidth(ds, DATE) / 2, CFG.dateCy, CFG.datePre, DATE);
  wWeek.setProperty(hmUI.prop.MORE, {
    x: Math.round(240 - CFG.diaw[dw] / 2), y: Math.round(CFG.weekCy - CFG.diah / 2),
    w: CFG.diaw[dw], h: CFG.diah, src: 'wk_' + dw + '.png', show_level: BOTH
  });

  /* Battery and sleep come from sensors: battery reports fine, and no
   * data_type carries sleep duration. */
  let batt = 0, sono = '--';
  try { batt = hmSensor.createSensor(hmSensor.id.BATTERY).current; } catch (e) {}
  try {
    const s = hmSensor.createSensor(hmSensor.id.SLEEP);
    if (s.updateInfo) s.updateInfo();
    const t = s.getTotalTime();
    if (t > 0) sono = Math.floor(t / 60) + 'h' + t2(t % 60);
  } catch (e) {}
  wBat.setProperty(hmUI.prop.TEXT, batt + '%');
  wSleep.setProperty(hmUI.prop.TEXT, sono);
}

__$$module$$__.module = DeviceRuntimeCore.WatchFace({
  init_view() {
    const D = CFG.dig, S = CFG.sep, SL = CFG.slots, IC = CFG.icon;

    /* Ground first, always. */
    hmUI.createWidget(hmUI.widget.IMG, { x: 0, y: 0, w: 480, h: 480,
      src: 'bg.png', show_level: BOTH });

    wH0 = hmUI.createWidget(hmUI.widget.IMG, { x: D.h0, y: D.ty, w: D.w, h: D.h,
      src: CFG.digPre[0] + '1.png', show_level: BOTH });
    wH1 = hmUI.createWidget(hmUI.widget.IMG, { x: D.h1, y: D.ty, w: D.w, h: D.h,
      src: CFG.digPre[1] + '0.png', show_level: BOTH });
    wM0 = hmUI.createWidget(hmUI.widget.IMG, { x: D.m0, y: D.ty, w: D.w, h: D.h,
      src: CFG.digPre[2] + '2.png', show_level: BOTH });
    wM1 = hmUI.createWidget(hmUI.widget.IMG, { x: D.m1, y: D.ty, w: D.w, h: D.h,
      src: CFG.digPre[3] + '0.png', show_level: BOTH });
    /* The separator replaces the colon: one thin bar, drawn not blitted. */
    hmUI.createWidget(hmUI.widget.FILL_RECT, { x: S.x, y: S.y, w: S.w, h: S.h,
      color: CFG.sepCol, show_level: BOTH });

    for (let i = 0; i < 5; i++)
      wDate.push(hmUI.createWidget(hmUI.widget.IMG, { x: 0, y: 0, w: 4, h: 4,
        src: CFG.datePre[0] + '0.png', show_level: BOTH }));
    wWeek = hmUI.createWidget(hmUI.widget.IMG, { x: 0, y: 0, w: 4, h: 4,
      src: 'wk_0.png', show_level: BOTH });

    ['temp', 'sono', 'hyb', 'bat'].forEach(function (k) {
      const s = SL[k];
      hmUI.createWidget(hmUI.widget.IMG, { x: s.ix, y: Math.round(s.y - IC.h / 2),
        w: IC.w, h: IC.h, src: 'i_' + k + '.png', show_level: BOTH });
    });

    valueWidget(SL.temp, CFG.valCol.temp, hmUI.data_type.WEATHER_CURRENT);
    valueWidget(SL.hyb, CFG.valCol.hyb, hmUI.data_type.BIO_CHARGE);
    wBat = valueWidget(SL.bat, CFG.valCol.bat, null);
    wSleep = valueWidget(SL.sono, CFG.valCol.sono, null);

    /* Tap targets, deliberately larger than what they cover. */
    CFG.taps.forEach(function (t) {
      hmUI.createWidget(hmUI.widget.BUTTON, {
        x: t.x, y: t.y, w: t.w, h: t.h, text: '',
        normal_src: 'clear.png', press_src: 'clear.png',
        click_func: function () { hmApp.startApp({ url: t.screen, native: true }); },
        show_level: hmUI.show_level.ONLY_NORMAL
      });
    });
    if (!ts) ts = hmSensor.createSensor(hmSensor.id.TIME);
    ts.addEventListener(ts.event.MINUTEEND, function () { paint(); });
    paint();

    hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
      resume_call: function () { paint(); }
    });
  },
  onInit() {},
  build() { this.init_view(); },
  onDestroy() {}
});
})();
} catch (e) {
  console.log('Mini Program Error', e);
  e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
}
