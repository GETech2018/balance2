try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface');
        
        // 存储秒针组件的变量
        let secondHandWidget = null;
        let updateTimer = null;
        
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 0,
                    y: 0,
                    anim_path: '',
                    anim_prefix: 'first_anim_akisq',
                    anim_ext: 'png',
                    anim_fps: 16,
                    anim_size: 10,
                    display_on_restart: false,
                    repeat_count: 0,
                    anim_status: hmUI.anim_status.START,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 0,
                    y: 0,
                    anim_path: '',
                    anim_prefix: 'second_anim_kaomo',
                    anim_ext: 'png',
                    anim_fps: 16,
                    anim_size: 10,
                    display_on_restart: false,
                    repeat_count: 0,
                    anim_status: hmUI.anim_status.START,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 0,
                    y: 0,
                    anim_path: '',
                    anim_prefix: 'third_anim_pfgki',
                    anim_ext: 'png',
                    anim_fps: 16,
                    anim_size: 23,
                    display_on_restart: true,
                    repeat_count: 1,
                    anim_status: hmUI.anim_status.START,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 67,
                    y: 131,
                    image_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png'
                    ],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 369,
                    y: 225,
                    type: hmUI.data_type.HEART,
                    font_array: [
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -18,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '42.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 390,
                    y: 168,
                    src: '43.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 63,
                    month_startY: 208,
                    month_sc_array: [
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png'
                    ],
                    month_tc_array: [
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png'
                    ],
                    month_en_array: [
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png'
                    ],
                    month_align: hmUI.align.CENTER_H,
                    month_zero: 0,
                    month_follow: 0,
                    month_space: -16,
                    month_is_character: false,
                    day_startX: 118,
                    day_startY: 209,
                    day_sc_array: [
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png'
                    ],
                    day_tc_array: [
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png'
                    ],
                    day_en_array: [
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png'
                    ],
                    day_align: hmUI.align.CENTER_H,
                    day_zero: 0,
                    day_follow: 0,
                    day_space: -17,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 321,
                    y: 168,
                    image_array: [
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png'
                    ],
                    image_length: 4,
                    type: hmUI.data_type.STRESS,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 300,
                    y: 223,
                    type: hmUI.data_type.STRESS,
                    font_array: [
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -18,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '48.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 25,
                    y: 258,
                    week_sc: [
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 294,
                    y: 94,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -18,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '56.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 258,
                    y: 93,
                    src: '57.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 121,
                    y: 76,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: -14,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '60.png',
                    unit_tc: '60.png',
                    unit_en: '60.png',
                    negative_image: '59.png',
                    invalid_image: '58.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '61.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 91,
                    y: 344,
                    image_array: [
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png'
                    ],
                    image_length: 10,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: '72.png',
                    center_x: 240,
                    center_y: 240,
                    x: 19,
                    y: 64,
                    type: hmUI.data_type.SUN_CURRENT,
                    start_angle: 180,
                    end_angle: 540,
                    cover_x: 0,
                    cover_y: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 219,
                    y: 264,
                    image_array: [
                        '73.png',
                        '74.png',
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png',
                        '79.png',
                        '80.png',
                        '81.png',
                        '82.png',
                        '83.png',
                        '84.png',
                        '85.png',
                        '86.png',
                        '87.png',
                        '88.png',
                        '89.png',
                        '90.png',
                        '91.png',
                        '92.png',
                        '93.png',
                        '94.png',
                        '95.png',
                        '96.png',
                        '97.png',
                        '98.png',
                        '99.png',
                        '100.png',
                        '101.png',
                        '102.png'
                    ],
                    image_length: 30,
                    type: hmUI.data_type.MOON,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                
                // 时针和分针保持原样
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 240,
                    hour_centerY: 240,
                    hour_posX: 29,
                    hour_posY: 143,
                    hour_path: '103.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 240,
                    minute_centerY: 240,
                    minute_posX: 25,
                    minute_posY: 206,
                    minute_path: '104.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    // 移除秒针配置，改用自定义实现
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                
                // 创建秒针的中心装饰图片
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 217,
                    y: 217,
                    src: '105.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                
                // 创建自定义秒针（使用 IMG_POINTER 实现扫秒）
                secondHandWidget = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 22,
                    y: 170,
                    src: '106.png',
                    center_x: 240 - 22,
                    center_y: 240 - 170,
                    angle: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                
                // 启动定时器更新秒针
                const updateSecondHand = () => {
                    const time = hmSensor.createSensor(hmSensor.id.TIME);
                    const second = time.second;
                    const utc = time.utc;
                    
                    // 计算精确的秒数（包含毫秒）
                    const millisInSecond = utc % 1000;
                    const preciseSecond = second + (millisInSecond / 1000);
                    
                    // 计算角度（每秒6度）
                    const angle = preciseSecond * 6;
                    
                    // 更新秒针角度
                    if (secondHandWidget) {
                        secondHandWidget.setProperty(hmUI.prop.ANGLE, angle);
                    }
                };
                
                // 初始更新
                updateSecondHand();
                
                // 设置定时器，每50ms更新一次（实现平滑扫秒）
                updateTimer = timer.createTimer(50, 50, () => {
                    updateSecondHand();
                });
                
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 167,
                    y: 30,
                    image_array: [
                        '107.png',
                        '108.png',
                        '109.png',
                        '110.png',
                        '111.png',
                        '112.png',
                        '113.png',
                        '114.png',
                        '115.png',
                        '116.png',
                        '117.png',
                        '118.png'
                    ],
                    image_length: 12,
                    type: hmUI.data_type.WIND,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '119.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 240,
                    hour_centerY: 240,
                    hour_posX: 29,
                    hour_posY: 143,
                    hour_path: '120.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 240,
                    minute_centerY: 240,
                    minute_posX: 25,
                    minute_posY: 206,
                    minute_path: '122.png',
                    minute_cover_path: '121.png',
                    minute_cover_x: 217,
                    minute_cover_y: 217,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 385,
                    y: 160,
                    w: 52,
                    h: 120,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 314,
                    y: 155,
                    w: 52,
                    h: 118,
                    type: hmUI.data_type.STRESS,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 257,
                    y: 88,
                    w: 172,
                    h: 51,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 129,
                    y: 67,
                    w: 104,
                    h: 100,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 82,
                    y: 367,
                    w: 121,
                    h: 72,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 204,
                    y: 191,
                    w: 73,
                    h: 102,
                    type: hmUI.data_type.SUN_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                // 清理定时器
                if (updateTimer) {
                    timer.stopTimer(updateTimer);
                }
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}