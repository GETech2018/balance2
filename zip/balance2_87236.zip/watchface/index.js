﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_alarm_clock_text_text_img = ''
        let normal_floor_text_text_img = ''
        let normal_system_clock_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_date_img_date_day = ''
        let normal_bio_charge_text_text_img = ''
        let normal_bio_charge_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 203,
              y: 452,
              font_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              padding: true,
              h_space: 0,
              dot_image: 'dian.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_floor_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 395,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.FLOOR,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 228,
              y: 423,
              src: 'clock.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 259,
              y: 395,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'null.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 259,
              y: 359,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 160,
              y: 358,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 1,
              dot_image: 'dian.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 124,
              day_startY: 300,
              day_sc_array: ["GIORNI_digit_01.png","GIORNI_digit_02.png","GIORNI_digit_03.png","GIORNI_digit_04.png","GIORNI_digit_05.png","GIORNI_digit_06.png","GIORNI_digit_07.png","GIORNI_digit_08.png","GIORNI_digit_09.png","GIORNI_digit_10.png"],
              day_tc_array: ["GIORNI_digit_01.png","GIORNI_digit_02.png","GIORNI_digit_03.png","GIORNI_digit_04.png","GIORNI_digit_05.png","GIORNI_digit_06.png","GIORNI_digit_07.png","GIORNI_digit_08.png","GIORNI_digit_09.png","GIORNI_digit_10.png"],
              day_en_array: ["GIORNI_digit_01.png","GIORNI_digit_02.png","GIORNI_digit_03.png","GIORNI_digit_04.png","GIORNI_digit_05.png","GIORNI_digit_06.png","GIORNI_digit_07.png","GIORNI_digit_08.png","GIORNI_digit_09.png","GIORNI_digit_10.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 185,
              y: 85,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'null.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 51,
              y: 16,
              image_array: ["biolvl_1.png","biolvl_2.png","biolvl_3.png","biolvl_4.png","biolvl_5.png","biolvl_6.png","biolvl_7.png","biolvl_8.png","biolvl_9.png","biolvl_10.png"],
              image_length: 10,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 249,
              y: 85,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'baifen.png',
              unit_tc: 'baifen.png',
              unit_en: 'baifen.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 261,
              y: 16,
              image_array: ["vo2lvl_1.png","vo2lvl_2.png","vo2lvl_3.png","vo2lvl_4.png","vo2lvl_5.png","vo2lvl_6.png","vo2lvl_7.png"],
              image_length: 7,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 140,
              y: 158,
              week_en: ["NGIO_digit_01.png","NGIO_digit_02.png","NGIO_digit_03.png","NGIO_digit_04.png","NGIO_digit_05.png","NGIO_digit_06.png","NGIO_digit_07.png"],
              week_tc: ["NGIO_digit_01.png","NGIO_digit_02.png","NGIO_digit_03.png","NGIO_digit_04.png","NGIO_digit_05.png","NGIO_digit_06.png","NGIO_digit_07.png"],
              week_sc: ["NGIO_digit_01.png","NGIO_digit_02.png","NGIO_digit_03.png","NGIO_digit_04.png","NGIO_digit_05.png","NGIO_digit_06.png","NGIO_digit_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 194,
              month_startY: 300,
              month_sc_array: ["mesi_other_01.png","mesi_other_02.png","mesi_other_03.png","mesi_other_04.png","mesi_other_05.png","mesi_other_06.png","mesi_other_07.png","mesi_other_08.png","mesi_other_09.png","mesi_other_10.png","mesi_other_11.png","mesi_other_12.png"],
              month_tc_array: ["mesi_other_01.png","mesi_other_02.png","mesi_other_03.png","mesi_other_04.png","mesi_other_05.png","mesi_other_06.png","mesi_other_07.png","mesi_other_08.png","mesi_other_09.png","mesi_other_10.png","mesi_other_11.png","mesi_other_12.png"],
              month_en_array: ["mesi_other_01.png","mesi_other_02.png","mesi_other_03.png","mesi_other_04.png","mesi_other_05.png","mesi_other_06.png","mesi_other_07.png","mesi_other_08.png","mesi_other_09.png","mesi_other_10.png","mesi_other_11.png","mesi_other_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 7,
              hour_startY: 204,
              hour_array: ["60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_unit_sc: 'special_01.png',
              hour_unit_tc: 'special_01.png',
              hour_unit_en: 'special_01.png',
              alpha: 252,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 168,
              minute_startY: 200,
              minute_array: ["75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_unit_sc: 'special_01.png',
              minute_unit_tc: 'special_01.png',
              minute_unit_en: 'special_01.png',
              // alpha: 252,
              minute_align: hmUI.align.RIGHT,

              second_startX: 326,
              second_startY: 200,
              second_array: ["75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 1,
              // alpha: 252,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 124,
              day_startY: 300,
              day_sc_array: ["GIORNI_digit_01.png","GIORNI_digit_02.png","GIORNI_digit_03.png","GIORNI_digit_04.png","GIORNI_digit_05.png","GIORNI_digit_06.png","GIORNI_digit_07.png","GIORNI_digit_08.png","GIORNI_digit_09.png","GIORNI_digit_10.png"],
              day_tc_array: ["GIORNI_digit_01.png","GIORNI_digit_02.png","GIORNI_digit_03.png","GIORNI_digit_04.png","GIORNI_digit_05.png","GIORNI_digit_06.png","GIORNI_digit_07.png","GIORNI_digit_08.png","GIORNI_digit_09.png","GIORNI_digit_10.png"],
              day_en_array: ["GIORNI_digit_01.png","GIORNI_digit_02.png","GIORNI_digit_03.png","GIORNI_digit_04.png","GIORNI_digit_05.png","GIORNI_digit_06.png","GIORNI_digit_07.png","GIORNI_digit_08.png","GIORNI_digit_09.png","GIORNI_digit_10.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 140,
              y: 158,
              week_en: ["NGIO_digit_01.png","NGIO_digit_02.png","NGIO_digit_03.png","NGIO_digit_04.png","NGIO_digit_05.png","NGIO_digit_06.png","NGIO_digit_07.png"],
              week_tc: ["NGIO_digit_01.png","NGIO_digit_02.png","NGIO_digit_03.png","NGIO_digit_04.png","NGIO_digit_05.png","NGIO_digit_06.png","NGIO_digit_07.png"],
              week_sc: ["NGIO_digit_01.png","NGIO_digit_02.png","NGIO_digit_03.png","NGIO_digit_04.png","NGIO_digit_05.png","NGIO_digit_06.png","NGIO_digit_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 194,
              month_startY: 300,
              month_sc_array: ["mesi_other_01.png","mesi_other_02.png","mesi_other_03.png","mesi_other_04.png","mesi_other_05.png","mesi_other_06.png","mesi_other_07.png","mesi_other_08.png","mesi_other_09.png","mesi_other_10.png","mesi_other_11.png","mesi_other_12.png"],
              month_tc_array: ["mesi_other_01.png","mesi_other_02.png","mesi_other_03.png","mesi_other_04.png","mesi_other_05.png","mesi_other_06.png","mesi_other_07.png","mesi_other_08.png","mesi_other_09.png","mesi_other_10.png","mesi_other_11.png","mesi_other_12.png"],
              month_en_array: ["mesi_other_01.png","mesi_other_02.png","mesi_other_03.png","mesi_other_04.png","mesi_other_05.png","mesi_other_06.png","mesi_other_07.png","mesi_other_08.png","mesi_other_09.png","mesi_other_10.png","mesi_other_11.png","mesi_other_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 94,
              hour_startY: 204,
              hour_array: ["60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_unit_sc: 'special_01.png',
              hour_unit_tc: 'special_01.png',
              hour_unit_en: 'special_01.png',
              alpha: 252,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 168,
              minute_startY: 200,
              minute_array: ["75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              // alpha: 252,
              minute_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 255,
              y: 352,
              w: 100,
              h: 40,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 130,
              y: 345,
              w: 100,
              h: 75,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 255,
              y: 391,
              w: 100,
              h: 32,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 256,
              y: 51,
              w: 100,
              h: 95,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 320,
              y: 189,
              w: 140,
              h: 147,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 164,
              y: 195,
              w: 144,
              h: 141,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 423,
              w: 100,
              h: 85,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}