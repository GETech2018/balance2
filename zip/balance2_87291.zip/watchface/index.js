﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_month = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_frame_animation_1 = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 216,
              y: 27,
              image_array: ["1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 410,
              y: 179,
              font_array: ["tmm_0.png","tmm_1.png","tmm_2.png","tmm_3.png","tmm_4.png","tmm_5.png","tmm_6.png","tmm_7.png","tmm_8.png","tmm_9.png"],
              padding: false,
              h_space: -4,
              unit_sc: 'tmm_11.png',
              unit_tc: 'tmm_11.png',
              unit_en: 'tmm_11.png',
              imperial_unit_sc: 'tmm_11.png',
              imperial_unit_tc: 'tmm_11.png',
              imperial_unit_en: 'tmm_11.png',
              negative_image: 'tmm_10.png',
              invalid_image: 'tmm_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_high_text_img.setProperty(hmUI.prop.MORE, {
                x: 410,
                y: 179,
                font_array: ["tmm_0.png","tmm_1.png","tmm_2.png","tmm_3.png","tmm_4.png","tmm_5.png","tmm_6.png","tmm_7.png","tmm_8.png","tmm_9.png"],
                padding: false,
                h_space: -4,
                unit_sc: 'tmm_11.png',
                unit_tc: 'tmm_11.png',
                unit_en: 'tmm_11.png',
                imperial_unit_sc: 'tmm_11.png',
                imperial_unit_tc: 'tmm_11.png',
                imperial_unit_en: 'tmm_11.png',
                negative_image: 'tmm_10.png',
                invalid_image: 'tmm_10.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_HIGH,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 410,
              y: 280,
              font_array: ["tmm_0.png","tmm_1.png","tmm_2.png","tmm_3.png","tmm_4.png","tmm_5.png","tmm_6.png","tmm_7.png","tmm_8.png","tmm_9.png"],
              padding: false,
              h_space: -4,
              unit_sc: 'tmm_11.png',
              unit_tc: 'tmm_11.png',
              unit_en: 'tmm_11.png',
              imperial_unit_sc: 'tmm_11.png',
              imperial_unit_tc: 'tmm_11.png',
              imperial_unit_en: 'tmm_11.png',
              negative_image: 'tmm_10.png',
              invalid_image: 'tmm_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_low_text_img.setProperty(hmUI.prop.MORE, {
                x: 410,
                y: 280,
                font_array: ["tmm_0.png","tmm_1.png","tmm_2.png","tmm_3.png","tmm_4.png","tmm_5.png","tmm_6.png","tmm_7.png","tmm_8.png","tmm_9.png"],
                padding: false,
                h_space: -4,
                unit_sc: 'tmm_11.png',
                unit_tc: 'tmm_11.png',
                unit_en: 'tmm_11.png',
                imperial_unit_sc: 'tmm_11.png',
                imperial_unit_tc: 'tmm_11.png',
                imperial_unit_en: 'tmm_11.png',
                negative_image: 'tmm_10.png',
                invalid_image: 'tmm_10.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_LOW,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 400,
              y: 217,
              font_array: ["temp_0.png","temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png","temp_6.png","temp_7.png","temp_8.png","temp_9.png"],
              padding: false,
              h_space: -14,
              unit_sc: 'temp_11.png',
              unit_tc: 'temp_11.png',
              unit_en: 'temp_11.png',
              imperial_unit_sc: 'temp_11.png',
              imperial_unit_tc: 'temp_11.png',
              imperial_unit_en: 'temp_11.png',
              negative_image: 'temp_10.png',
              invalid_image: 'temp_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 400,
                y: 217,
                font_array: ["temp_0.png","temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png","temp_6.png","temp_7.png","temp_8.png","temp_9.png"],
                padding: false,
                h_space: -14,
                unit_sc: 'temp_11.png',
                unit_tc: 'temp_11.png',
                unit_en: 'temp_11.png',
                imperial_unit_sc: 'temp_11.png',
                imperial_unit_tc: 'temp_11.png',
                imperial_unit_en: 'temp_11.png',
                negative_image: 'temp_10.png',
                invalid_image: 'temp_10.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 313,
              y: 400,
              font_array: ["call_0.png","call_1.png","call_2.png","call_3.png","call_4.png","call_5.png","call_6.png","call_7.png","call_8.png","call_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'call_11.png',
              unit_tc: 'call_11.png',
              unit_en: 'call_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 176,
              y: 400,
              font_array: ["step_0.png","step_1.png","step_2.png","step_3.png","step_4.png","step_5.png","step_6.png","step_7.png","step_8.png","step_9.png"],
              padding: false,
              h_space: -8,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 142,
              month_startY: 268,
              month_sc_array: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png","day_8.png","day_9.png"],
              month_tc_array: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png","day_8.png","day_9.png"],
              month_en_array: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png","day_8.png","day_9.png"],
              month_zero: 1,
              month_space: -7,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 20,
              y: 191,
              src: 'ampm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 97,
              y: 400,
              font_array: ["call_0.png","call_1.png","call_2.png","call_3.png","call_4.png","call_5.png","call_6.png","call_7.png","call_8.png","call_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 67,
              day_startY: 268,
              day_sc_array: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png","day_8.png","day_9.png"],
              day_tc_array: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png","day_8.png","day_9.png"],
              day_en_array: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png","day_8.png","day_9.png"],
              day_zero: 0,
              day_space: -7,
              day_unit_sc: 'day_10.png',
              day_unit_tc: 'day_10.png',
              day_unit_en: 'day_10.png',
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 81,
              y: 273,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 20,
              am_y: 191,
              am_sc_path: 'AM.png',
              am_en_path: 'AM.png',
              pm_x: 20,
              pm_y: 191,
              pm_sc_path: 'PM.png',
              pm_en_path: 'PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 78,
              hour_startY: 93,
              hour_array: ["hour_0.png","hour_1.png","hour_2.png","hour_3.png","hour_4.png","hour_5.png","hour_6.png","hour_7.png","hour_8.png","hour_9.png"],
              hour_zero: 1,
              hour_space: -10,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 253,
              minute_startY: 94,
              minute_array: ["hour_0.png","hour_1.png","hour_2.png","hour_3.png","hour_4.png","hour_5.png","hour_6.png","hour_7.png","hour_8.png","hour_9.png"],
              minute_zero: 1,
              minute_space: -10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 82,
              y: 242,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "a",
              anim_fps: 15,
              anim_size: 51,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bgAOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 78,
              hour_startY: 93,
              hour_array: ["hour_0.png","hour_1.png","hour_2.png","hour_3.png","hour_4.png","hour_5.png","hour_6.png","hour_7.png","hour_8.png","hour_9.png"],
              hour_zero: 1,
              hour_space: -10,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 253,
              minute_startY: 94,
              minute_array: ["hour_0.png","hour_1.png","hour_2.png","hour_3.png","hour_4.png","hour_5.png","hour_6.png","hour_7.png","hour_8.png","hour_9.png"],
              minute_zero: 1,
              minute_space: -10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 189,
              y: 373,
              w: 100,
              h: 100,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 84,
              y: 373,
              w: 100,
              h: 61,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 292,
              y: 373,
              w: 100,
              h: 61,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 397,
              y: 177,
              w: 66,
              h: 127,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 86,
              y: 269,
              w: 300,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'tap300.png',
              normal_src: 'tap300.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 6,
              y: 207,
              w: 70,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'tap70.png',
              normal_src: 'tap70.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}