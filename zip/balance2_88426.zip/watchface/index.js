﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_year = ''
        let normal_humidity_icon_img = ''
        let normal_sun_icon_img = ''
        let normal_date_img_date_month = ''
        let normal_calorie_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_icon_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_year = ''
        let idle_humidity_icon_img = ''
        let idle_sun_icon_img = ''
        let idle_date_img_date_month = ''
        let idle_calorie_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_icon_img = ''
        let idle_step_current_text_img = ''
        let idle_step_icon_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_4 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'image.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 72,
              y: 89,
              src: 'bt_on.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 364,
              y: 93,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 287,
              year_startY: 245,
              year_sc_array: ["bold_0.png","bold_1.png","bold_2.png","bold_3.png","bold_4.png","bold_5.png","bold_6.png","bold_7.png","bold_8.png","bold_9.png"],
              year_tc_array: ["bold_0.png","bold_1.png","bold_2.png","bold_3.png","bold_4.png","bold_5.png","bold_6.png","bold_7.png","bold_8.png","bold_9.png"],
              year_en_array: ["bold_0.png","bold_1.png","bold_2.png","bold_3.png","bold_4.png","bold_5.png","bold_6.png","bold_7.png","bold_8.png","bold_9.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 163,
              y: 25,
              src: '14.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 166,
              y: 384,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 232,
              month_startY: 245,
              month_sc_array: ["bold_0.png","bold_1.png","bold_2.png","bold_3.png","bold_4.png","bold_5.png","bold_6.png","bold_7.png","bold_8.png","bold_9.png"],
              month_tc_array: ["bold_0.png","bold_1.png","bold_2.png","bold_3.png","bold_4.png","bold_5.png","bold_6.png","bold_7.png","bold_8.png","bold_9.png"],
              month_en_array: ["bold_0.png","bold_1.png","bold_2.png","bold_3.png","bold_4.png","bold_5.png","bold_6.png","bold_7.png","bold_8.png","bold_9.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: '82.png',
              month_unit_tc: '82.png',
              month_unit_en: '82.png',
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 190,
              y: 52,
              src: '2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 253,
              y: 81,
              font_array: ["bold_10.png","bold_11.png","bold_12.png","bold_13.png","bold_14.png","bold_15.png","bold_16.png","bold_17.png","bold_18.png","bold_19.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'percent.png',
              unit_tc: 'percent.png',
              unit_en: 'percent.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 225,
              y: 386,
              font_array: ["bold_10.png","bold_11.png","bold_12.png","bold_13.png","bold_14.png","bold_15.png","bold_16.png","bold_17.png","bold_18.png","bold_19.png"],
              padding: false,
              h_space: 1,
              unit_sc: '12.png',
              unit_tc: '12.png',
              unit_en: '12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 395,
              y: 170,
              src: '3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 67,
              y: 206,
              font_array: ["bold_10.png","bold_11.png","bold_12.png","bold_13.png","bold_14.png","bold_15.png","bold_16.png","bold_17.png","bold_18.png","bold_19.png"],
              padding: false,
              h_space: -1,
              angle: -88,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 63,
              y: 220,
              src: '5.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 176,
              day_startY: 245,
              day_sc_array: ["bold_0.png","bold_1.png","bold_2.png","bold_3.png","bold_4.png","bold_5.png","bold_6.png","bold_7.png","bold_8.png","bold_9.png"],
              day_tc_array: ["bold_0.png","bold_1.png","bold_2.png","bold_3.png","bold_4.png","bold_5.png","bold_6.png","bold_7.png","bold_8.png","bold_9.png"],
              day_en_array: ["bold_0.png","bold_1.png","bold_2.png","bold_3.png","bold_4.png","bold_5.png","bold_6.png","bold_7.png","bold_8.png","bold_9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: '82.png',
              day_unit_tc: '82.png',
              day_unit_en: '82.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 97,
              hour_startY: 279,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 262,
              minute_startY: 279,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 208,
              y: 265,
              src: '13.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'image.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 72,
              y: 89,
              src: 'bt_on.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 364,
              y: 93,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 287,
              year_startY: 245,
              year_sc_array: ["bold_0.png","bold_1.png","bold_2.png","bold_3.png","bold_4.png","bold_5.png","bold_6.png","bold_7.png","bold_8.png","bold_9.png"],
              year_tc_array: ["bold_0.png","bold_1.png","bold_2.png","bold_3.png","bold_4.png","bold_5.png","bold_6.png","bold_7.png","bold_8.png","bold_9.png"],
              year_en_array: ["bold_0.png","bold_1.png","bold_2.png","bold_3.png","bold_4.png","bold_5.png","bold_6.png","bold_7.png","bold_8.png","bold_9.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 163,
              y: 25,
              src: '14.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 166,
              y: 384,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 232,
              month_startY: 245,
              month_sc_array: ["bold_0.png","bold_1.png","bold_2.png","bold_3.png","bold_4.png","bold_5.png","bold_6.png","bold_7.png","bold_8.png","bold_9.png"],
              month_tc_array: ["bold_0.png","bold_1.png","bold_2.png","bold_3.png","bold_4.png","bold_5.png","bold_6.png","bold_7.png","bold_8.png","bold_9.png"],
              month_en_array: ["bold_0.png","bold_1.png","bold_2.png","bold_3.png","bold_4.png","bold_5.png","bold_6.png","bold_7.png","bold_8.png","bold_9.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: '82.png',
              month_unit_tc: '82.png',
              month_unit_en: '82.png',
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 190,
              y: 52,
              src: '2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 253,
              y: 81,
              font_array: ["bold_10.png","bold_11.png","bold_12.png","bold_13.png","bold_14.png","bold_15.png","bold_16.png","bold_17.png","bold_18.png","bold_19.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'percent.png',
              unit_tc: 'percent.png',
              unit_en: 'percent.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 225,
              y: 386,
              font_array: ["bold_10.png","bold_11.png","bold_12.png","bold_13.png","bold_14.png","bold_15.png","bold_16.png","bold_17.png","bold_18.png","bold_19.png"],
              padding: false,
              h_space: 1,
              unit_sc: '12.png',
              unit_tc: '12.png',
              unit_en: '12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 395,
              y: 170,
              src: '3.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 67,
              y: 206,
              font_array: ["bold_10.png","bold_11.png","bold_12.png","bold_13.png","bold_14.png","bold_15.png","bold_16.png","bold_17.png","bold_18.png","bold_19.png"],
              padding: false,
              h_space: -1,
              angle: -88,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 63,
              y: 220,
              src: '5.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 176,
              day_startY: 245,
              day_sc_array: ["bold_0.png","bold_1.png","bold_2.png","bold_3.png","bold_4.png","bold_5.png","bold_6.png","bold_7.png","bold_8.png","bold_9.png"],
              day_tc_array: ["bold_0.png","bold_1.png","bold_2.png","bold_3.png","bold_4.png","bold_5.png","bold_6.png","bold_7.png","bold_8.png","bold_9.png"],
              day_en_array: ["bold_0.png","bold_1.png","bold_2.png","bold_3.png","bold_4.png","bold_5.png","bold_6.png","bold_7.png","bold_8.png","bold_9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: '82.png',
              day_unit_tc: '82.png',
              day_unit_en: '82.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 97,
              hour_startY: 279,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 262,
              minute_startY: 279,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 208,
              y: 265,
              src: '13.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 273,
              y: 282,
              w: 106,
              h: 80,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 56,
              y: 182,
              w: 49,
              h: 100,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 262,
              y: 373,
              w: 72,
              h: 57,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 381,
              y: 207,
              w: 52,
              h: 64,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 357,
              y: 82,
              w: 40,
              h: 52,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 134,
              y: 236,
              w: 199,
              h: 37,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 217,
              y: 52,
              w: 77,
              h: 61,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}