﻿    /*
    ** Watch_Face_Editor tool v 18.0
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_current_text_font = ''
        let normal_battery_icon_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_font = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_current_text_font = ''
        let normal_day_month_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_day_text_font = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
        let normal_digital_clock_img_time = ''
        let Button_Switch_BG = ''

        let backgroundIndex = 0;
        let backgroundList = ['bg1.png', 'bg2.png', 'bg3.png'];
        let backgroundToastList = ['Yellow', 'Green', 'Red'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;
        let timeSensor = '';

        // --- Bouton bascule widgets santé (coeur -> calories -> batterie) ---
        let Button_Switch_Widget = '';
        let widgetGroupIndex = 0;
        const widgetGroupToastList = ['Heart', 'Calorie', 'Battery'];

        // --- Bouton bascule infos date (jour+jour semaine <-> jour/mois) ---
        let Button_Switch_Date = '';
        let dateGroupIndex = 0;


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            //#region SwitchBackground
            console.log('SwitchBackground');
            function switchBackground() {
              backgroundIndex++;
              if (backgroundIndex >= backgroundList.length) backgroundIndex = 0;
              hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
              let toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);

              // Synchronise les jeux d'images heure/minute avec le fond sélectionné
              if (typeof HOUR_DIGITS_SETS !== 'undefined') {
                HOUR_DIGITS = HOUR_DIGITS_SETS[backgroundIndex];
                MINUTE_DIGITS = MINUTE_DIGITS_SETS[backgroundIndex];
                // Invalide le cache pour forcer le redessin immédiat de l'heure affichée
                lastHour = -1;
                lastMinute = -1;
                if (typeof updateDigitalTime === 'function') updateDigitalTime();
              }
            };
            //#endregion

            //#region SwitchWidgetGroup (coeur / calories / batterie)
            function updateWidgetGroupVisibility() {
              const groups = [
                [normal_heart_rate_icon_img, normal_heart_rate_pointer_progress_img_pointer, normal_heart_rate_text_font],
                [normal_calorie_icon_img, normal_calorie_circle_scale, normal_calorie_current_text_font],
                [normal_battery_circle_scale, normal_battery_current_text_font, normal_battery_icon_img],
              ];
              groups.forEach((widgets, idx) => {
                widgets.forEach((w) => {
                  if (w) w.setProperty(hmUI.prop.VISIBLE, idx === widgetGroupIndex);
                });
              });
            };

            function switchWidgetGroup() {
              widgetGroupIndex++;
              if (widgetGroupIndex >= 3) widgetGroupIndex = 0;
              hmFS.SysProSetInt(`widgetGroupIndex_${watchfaceId}`, widgetGroupIndex);
              hmUI.showToast({text: widgetGroupToastList[widgetGroupIndex]});
              updateWidgetGroupVisibility();
            };
            //#endregion

            //#region SwitchDateGroup (jour+jour semaine <-> jour/mois)
            function updateDateGroupVisibility() {
              const groups = [
                [normal_dow_text_font, normal_day_text_font],
                [normal_day_month_font],
              ];
              groups.forEach((widgets, idx) => {
                widgets.forEach((w) => {
                  if (w) w.setProperty(hmUI.prop.VISIBLE, idx === dateGroupIndex);
                });
              });
            };

            function switchDateGroup() {
              dateGroupIndex++;
              if (dateGroupIndex >= 2) dateGroupIndex = 0;
              hmFS.SysProSetInt(`dateGroupIndex_${watchfaceId}`, dateGroupIndex);
              updateDateGroupVisibility();
            };
            //#endregion

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 82,
              // center_y: 239,
              // start_angle: -146,
              // end_angle: 147,
              // radius: 42,
              // line_width: 8,
              // line_cap: Rounded,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // alpha: 180,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 82,
              center_y: 239,
              start_angle: 147,
              end_angle: -146,
              radius: 38,
              line_width: 8,
              corner_flag: 0,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_circle_scale.setAlpha(180);
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 7,
              y: 219,
              w: 150,
              h: 30,
              text_size: 25,
              char_space: 0,
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 70,
              y: 255,
              src: 'battery.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 70,
              y: 255,
              src: 'coeur.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pheart.png',
              center_x: 82,
              center_y: 239,
              x: 42,
              y: 6,
              start_angle: -52,
              end_angle: 230,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 7,
              y: 219,
              w: 150,
              h: 30,
              text_size: 25,
              char_space: 0,
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 70,
              y: 255,
              src: 'calorie.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 82,
              // center_y: 239,
              // start_angle: -146,
              // end_angle: 147,
              // radius: 42,
              // line_width: 8,
              // line_cap: Rounded,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // alpha: 180,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 82,
              center_y: 239,
              start_angle: 147,
              end_angle: -146,
              radius: 38,
              line_width: 8,
              corner_flag: 0,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_circle_scale.setAlpha(180);
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 7,
              y: 219,
              w: 150,
              h: 30,
              text_size: 25,
              char_space: 0,
              color: 0xFF170D00,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            normal_day_month_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 162,
              y: 400,
              w: 150,
              h: 35,
              text_size: 26,
              char_space: 0,
              color: 0xFF170D00,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 203,
              y: 400,
              w: 150,
              h: 35,
              text_size: 26,
              char_space: 0,
              color: 0xFF170D00,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 148,
              y: 401,
              w: 150,
              h: 30,
              text_size: 24,
              char_space: 0,
              color: 0xFF170D00,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // unit_string: LUN, MAR, MER, JEU, VEN, SAM, DIM,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

// ============================================================
// HEURE DIGITALE - 4 CHIFFRES INDEPENDANTS
// Effet ESCALIER : les unités sont plus basses que les dizaines
//
// Exemple :
//
//        0 2
//          4 4
//
// Les 4 chiffres sont indépendants afin de pouvoir contrôler
// séparément leur position X et Y.
// ============================================================

let hourTens = null;
let hourUnits = null;
let minuteTens = null;
let minuteUnits = null;

// ------------------------------------------------------------
// Images des chiffres
// ------------------------------------------------------------

// Un jeu d'images par fond (bg1=jaune, bg2=vert, bg3=rouge), 10 chiffres (0-9) par jeu.
// Adapte les noms de fichiers ci-dessous à ceux réellement présents dans tes assets.
const HOUR_DIGITS_SETS = [
  ["H00.png","H01.png","H02.png","H03.png","H04.png","H05.png","H06.png","H07.png","H08.png","H09.png"], // bg1 - jaune
  ["H10.png","H11.png","H12.png","H13.png","H14.png","H15.png","H16.png","H17.png","H18.png","H19.png"], // bg2 - vert
  ["H20.png","H21.png","H22.png","H23.png","H24.png","H25.png","H26.png","H27.png","H28.png","H29.png"], // bg3 - rouge
];

const MINUTE_DIGITS_SETS = [
  ["M00.png","M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png"], // bg1 - jaune
  ["M10.png","M11.png","M12.png","M13.png","M14.png","M15.png","M16.png","M17.png","M18.png","M19.png"], // bg2 - vert
  ["M20.png","M21.png","M22.png","M23.png","M24.png","M25.png","M26.png","M27.png","M28.png","M29.png"], // bg3 - rouge
];

// Jeu actif (réassigné par switchBackground() et à la reprise de l'écran)
let HOUR_DIGITS = HOUR_DIGITS_SETS[0];
let MINUTE_DIGITS = MINUTE_DIGITS_SETS[0];

// ------------------------------------------------------------
// POSITIONNEMENT
// ------------------------------------------------------------

// Position de la dizaine des heures
const HOUR_X = 149;
const HOUR_Y = 29;

// Position de la dizaine des minutes
const MINUTE_X = 147;
const MINUTE_Y = 231;

// Décalage horizontal entre dizaine et unité
const DIGIT_X_OFFSET = 95;

// Décalage vertical de l'unité
//
// 20 = léger
// 40 = moyen
// 60 = marqué
// 80 = très marqué
//
const STEP_Y = 60;


// ============================================================
// HEURE
// ============================================================

// Dizaine des heures
hourTens = hmUI.createWidget(hmUI.widget.IMG, {
  x: HOUR_X,
  y: HOUR_Y,
  src: HOUR_DIGITS[0],
  show_level: hmUI.show_level.ONLY_NORMAL,
});

// Unité des heures
// Décalée vers la droite ET vers le bas
hourUnits = hmUI.createWidget(hmUI.widget.IMG, {
  x: HOUR_X + DIGIT_X_OFFSET,
  y: HOUR_Y + STEP_Y,
  src: HOUR_DIGITS[0],
  show_level: hmUI.show_level.ONLY_NORMAL,
});


// ============================================================
// MINUTES
// ============================================================

// Dizaine des minutes
minuteTens = hmUI.createWidget(hmUI.widget.IMG, {
  x: MINUTE_X,
  y: MINUTE_Y,
  src: MINUTE_DIGITS[0],
  show_level: hmUI.show_level.ONLY_NORMAL,
});

// Unité des minutes
// Décalée vers la droite ET vers le bas
minuteUnits = hmUI.createWidget(hmUI.widget.IMG, {
  x: MINUTE_X + DIGIT_X_OFFSET,
  y: MINUTE_Y + STEP_Y,
  src: MINUTE_DIGITS[0],
  show_level: hmUI.show_level.ONLY_NORMAL,
});


// ============================================================
// MISE À JOUR DYNAMIQUE
// ============================================================

let lastHour = -1;
let lastMinute = -1;

function updateDigitalTime() {

  const now = new Date();

  const hours = now.getHours();
  const minutes = now.getMinutes();

  // Rien à faire si l'heure n'a pas changé
  if (hours === lastHour && minutes === lastMinute) {
    return;
  }

  lastHour = hours;
  lastMinute = minutes;

  // ----------------------------------------------------------
  // Séparation des dizaines et unités
  // ----------------------------------------------------------

  const hTens = Math.floor(hours / 10);
  const hUnits = hours % 10;

  const mTens = Math.floor(minutes / 10);
  const mUnits = minutes % 10;

  // ----------------------------------------------------------
  // Changement des images
  // ----------------------------------------------------------

  hourTens.setProperty(
    hmUI.prop.SRC,
    HOUR_DIGITS[hTens]
  );

  hourUnits.setProperty(
    hmUI.prop.SRC,
    HOUR_DIGITS[hUnits]
  );

  minuteTens.setProperty(
    hmUI.prop.SRC,
    MINUTE_DIGITS[mTens]
  );

  minuteUnits.setProperty(
    hmUI.prop.SRC,
    MINUTE_DIGITS[mUnits]
  );
}


// ============================================================
// PREMIÈRE MISE À JOUR
// ============================================================

updateDigitalTime();


// ============================================================
// TIMER
// ============================================================
//
// Vérification toutes les secondes.
// L'affichage graphique ne change réellement que lorsque
// l'heure ou la minute change.
//
// Zepp OS utilise bien un timer pour déclencher les mises
// à jour périodiques d'une watchface.
// ============================================================

const digitalTimeTimer = timer.createTimer(
  1000,
  1000,
  updateDigitalTime
);


            console.log('Watch_Face.SwitchBackground');
            // Button_Switch_BG = hmUI.createWidget(hmUI.widget.SwitchBackground, {
              // x: 372,
              // y: 317,
              // w: 95,
              // h: 60,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // press_src: 'dot.png',
              // normal_src: 'dot.png',
              // bg_list: bg1|bg2|bg3,
              // toast_list: Jaune|Vert|rouge,
              // use_crown: False,
              // use_in_AOD: False,
              // vibro: False,
            // });

            Button_Switch_BG = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 372,
              y: 294,
              w: 96,
              h: 94,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                switchBackground();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            // Bouton bascule coeur -> calories -> batterie (posé sur la zone qui se chevauche)
            Button_Switch_Widget = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 34,
              y: 194,
              w: 96,
              h: 86,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                switchWidgetGroup();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            // Bouton bascule (jour + jour de la semaine) <-> (jour/mois)
            Button_Switch_Date = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 137,
              y: 407,
              w: 109,
              h: 63,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                switchDateGroup();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day/month font');
              if (updateHour) {
                let normal_DayStr = timeSensor.day.toString();
                let normal_MonthStr = timeSensor.month.toString();
                normal_DayStr = normal_DayStr.padStart(2, '0');
                normal_MonthStr = normal_MonthStr.padStart(2, '0');
                let normal_DayMonthStr = '--';
                // Format forcé en jour/mois (JJ/MM), indépendamment du réglage système de la montre
                normal_DayMonthStr = normal_DayStr + '/' + normal_MonthStr;
                normal_day_month_font.setProperty(hmUI.prop.TEXT, normal_DayMonthStr );
              };

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 82,
                      center_y: 239,
                      start_angle: 147,
                      end_angle: -146,
                      radius: 38,
                      line_width: 8,
                      corner_flag: 0,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = 1 - progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 82,
                      center_y: 239,
                      start_angle: 147,
                      end_angle: -146,
                      radius: 38,
                      line_width: 8,
                      corner_flag: 0,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                //SwitchBackground
                if (hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`) === undefined) {
                  backgroundIndex = 0;
                  hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
                } else {
                  backgroundIndex = hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg_img) {
                  normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
                  // Resynchronise les chiffres heure/minute avec le fond restauré
                  HOUR_DIGITS = HOUR_DIGITS_SETS[backgroundIndex];
                  MINUTE_DIGITS = MINUTE_DIGITS_SETS[backgroundIndex];
                  lastHour = -1;
                  lastMinute = -1;
                  updateDigitalTime();
                };

                //SwitchWidgetGroup (coeur / calories / batterie)
                if (hmFS.SysProGetInt(`widgetGroupIndex_${watchfaceId}`) === undefined) {
                  widgetGroupIndex = 0;
                  hmFS.SysProSetInt(`widgetGroupIndex_${watchfaceId}`, widgetGroupIndex);
                } else {
                  widgetGroupIndex = hmFS.SysProGetInt(`widgetGroupIndex_${watchfaceId}`);
                };
                updateWidgetGroupVisibility();

                //SwitchDateGroup (jour+jour semaine / jour-mois)
                if (hmFS.SysProGetInt(`dateGroupIndex_${watchfaceId}`) === undefined) {
                  dateGroupIndex = 0;
                  hmFS.SysProSetInt(`dateGroupIndex_${watchfaceId}`, dateGroupIndex);
                } else {
                  dateGroupIndex = hmFS.SysProGetInt(`dateGroupIndex_${watchfaceId}`);
                };
                updateDateGroupVisibility();
              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}