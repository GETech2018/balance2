﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_linear_scale = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_digital_clock_img_time = ''
        let normal_pai_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_bodyTemp_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Back_01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 250,
              y: 95,
              src: 'Off_01.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 200,
              y: 96,
              src: 'Sveglia_01.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 288,
              y: 98,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Nr.Att_11.png',
              unit_tc: 'Nr.Att_11.png',
              unit_en: 'Nr.Att_11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 327,
              // start_y: 66,
              // color: 0xFF040200,
              // lenght: 47,
              // line_width: 20,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 179,
              y: 344,
              image_array: ["w0032.png","w0033.png","w0034.png","w0035.png","w0036.png","w0037.png","w0038.png","w0039.png","w0040.png","w0041.png","w0042.png","w0043.png","w0044.png","w0045.png","w0046.png","w0047.png","w0048.png","w0049.png","w0050.png","w0051.png","w0052.png","w0053.png","w0054.png","w0055.png","w0056.png","w0057.png","w0058.png","w0059.png","w0060.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 306,
              y: 375,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Nr.Att_12.png',
              unit_tc: 'Nr.Att_12.png',
              unit_en: 'Nr.Att_12.png',
              negative_image: 'Nr.Att_13.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 83,
              y: 375,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Nr.Att_12.png',
              unit_tc: 'Nr.Att_12.png',
              unit_en: 'Nr.Att_12.png',
              negative_image: 'Nr.Att_13.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 203,
              y: 429,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Nr.Att_12.png',
              unit_tc: 'Nr.Att_12.png',
              unit_en: 'Nr.Att_12.png',
              negative_image: 'Nr.Att_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 77,
              y: 98,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'Nr.Att_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 166,
              y: 55,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 404,
              y: 231,
              week_en: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_tc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_sc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 404,
              day_startY: 182,
              day_sc_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              day_tc_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              day_en_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              day_zero: 0,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 38,
              hour_startY: 163,
              hour_array: ["Nr.Ore_01.png","Nr.Ore_02.png","Nr.Ore_03.png","Nr.Ore_04.png","Nr.Ore_05.png","Nr.Ore_06.png","Nr.Ore_07.png","Nr.Ore_08.png","Nr.Ore_09.png","Nr.Ore_10.png"],
              hour_zero: 0,
              hour_space: 9,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 233,
              minute_startY: 163,
              minute_array: ["Nr.Ore_01.png","Nr.Ore_02.png","Nr.Ore_03.png","Nr.Ore_04.png","Nr.Ore_05.png","Nr.Ore_06.png","Nr.Ore_07.png","Nr.Ore_08.png","Nr.Ore_09.png","Nr.Ore_10.png"],
              minute_zero: 1,
              minute_space: 9,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 398,
              second_startY: 282,
              second_array: ["Nr.Sec_01.png","Nr.Sec_02.png","Nr.Sec_03.png","Nr.Sec_04.png","Nr.Sec_05.png","Nr.Sec_06.png","Nr.Sec_07.png","Nr.Sec_08.png","Nr.Sec_09.png","Nr.Sec_10.png"],
              second_zero: 1,
              second_space: 6,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 205,
              y: 165,
              src: 'Nr.Ore_11.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 52,
              hour_startY: 163,
              hour_array: ["Nr.01.png","Nr.02.png","Nr.03.png","Nr.04.png","Nr.05.png","Nr.06.png","Nr.07.png","Nr.08.png","Nr.09.png","Nr.10.png"],
              hour_zero: 0,
              hour_space: 10,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 260,
              minute_startY: 163,
              minute_array: ["Nr.01.png","Nr.02.png","Nr.03.png","Nr.04.png","Nr.05.png","Nr.06.png","Nr.07.png","Nr.08.png","Nr.09.png","Nr.10.png"],
              minute_zero: 1,
              minute_space: 10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 175,
              y: 5,
              w: 125,
              h: 85,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 400,
              y: 170,
              w: 100,
              h: 100,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bodyTemp_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 70,
              y: 43,
              w: 100,
              h: 100,
              type: hmUI.data_type.BODY_TEMP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 180,
              y: 350,
              w: 120,
              h: 120,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 45,
              y: 150,
              w: 150,
              h: 100,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 45,
              y: 245,
              w: 150,
              h: 100,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 250,
              y: 150,
              w: 150,
              h: 100,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 250,
              y: 245,
              w: 150,
              h: 100,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 327;
                  let start_y_normal_battery = 66;
                  let lenght_ls_normal_battery = 47;
                  let line_width_ls_normal_battery = 20;
                  let color_ls_normal_battery = 0xFF040200;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}