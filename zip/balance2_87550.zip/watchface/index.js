﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_sun_icon_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_sleep_icon_img = ''
        let normal_sleep_duration_total_font = ''
        let array_sleep_chart = []
        let normal_sleep_chart_group = ''
        let normal_sleep_chart_hr = ''
        let normal_stress_icon_img = ''
        let normal_stress_text_text_img = ''
        let normal_stress_image_progress_img_level = ''
        let normal_group_ForecastWeather = ''
        let normal_forecast_average_text_font = new Array(5);
        let normal_canvas1 = '';
        let normal_canvas2 = '';
        let normal_altimeter_text_text_img = ''
        let normal_altimeter_text_separator_img = ''
        let normal_humidity_text_text_img = ''
        let normal_humidity_text_separator_img = ''
        let normal_temperature_icon_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_low_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_wind_icon_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_aqi_image_progress_img_level = ''
        let normal_uvi_icon_img = ''
        let normal_uvi_image_progress_img_level = ''
        let normal_uvi_text_text_img = ''
        let normal_bio_charge_icon_img = ''
        let normal_bio_charge_text_text_img = ''
        let normal_spo2_icon_img = ''
        let normal_spo2_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_linear_scale = ''
        let normal_calorie_current_text_img = ''
        let normal_step_linear_scale = ''
        let normal_step_current_text_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_current_text_font = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_digital_clock_second_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_date_img_date_year = ''
        let normal_date_year_separator_img = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_time_pointer_smooth_second = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_year = ''
        let idle_date_year_separator_img = ''
        let idle_date_img_date_month = ''
        let idle_date_month_separator_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_analog_clock_pro_hour_pointer_img = ''
        let idle_analog_clock_pro_minute_pointer_img = ''
        let normal_battery_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let Button_12 = ''
        let Button_13 = ''
        let Button_14 = ''
        let Button_15 = ''
        let timeSensor = '';
        let sleepSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 330,
              y: 77,
              src: 'vz_03.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 366,
              y: 86,
              font_array: ["mini_00.png","mini_01.png","mini_02.png","mini_03.png","mini_04.png","mini_05.png","mini_06.png","mini_07.png","mini_08.png","mini_09.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'mini_13.png',
              dot_image: 'mini_14.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 366,
              y: 113,
              font_array: ["mini_00.png","mini_01.png","mini_02.png","mini_03.png","mini_04.png","mini_05.png","mini_06.png","mini_07.png","mini_08.png","mini_09.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'mini_13.png',
              dot_image: 'mini_14.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 323,
              y: 396,
              src: 'sleep.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_duration_total_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 349,
              y: 393,
              w: 60,
              h: 30,
              text_size: 20,
              char_space: 0,
              color: 0xFFA7AAC2,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_sleep_chart = hmUI.createWidget(hmUI.widget.SLEEP_CHART, {
              // x: 336,
              // y: 368,
              // w: 88,
              // h: 20,
              // radius: 0,
              // deep_stage_color: 0xFF743ED4,
              // light_stage_color: 0xFF6284EF,
              // rem_stage_color: 0xFF46C536,
              // wake_stage_color: 0xFFAE433B,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_sleep_chart_group = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 336,
              y: 368,
              w: 88,
              h: 20,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            normal_sleep_chart_hr = hmUI.createWidget(hmUI.widget.GRADKIENT_POLYLINE, {
              x: 336,
              y: 368,
              w: 88,
              h: 20,
              line_width: 1,
              line_color: 0xFFC42742,
              // type: hmUI.data_type.SLEEP_HR,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 297,
              y: 423,
              src: 'stress_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 319,
              y: 423,
              font_array: ["mini_00.png","mini_01.png","mini_02.png","mini_03.png","mini_04.png","mini_05.png","mini_06.png","mini_07.png","mini_08.png","mini_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 297,
              y: 423,
              image_array: ["stress_1.png","stress_2.png","stress_3.png","stress_4.png"],
              image_length: 4,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            // normal_Weather_FewDays = hmUI.createWidget(hmUI.widget.FewDays, {
              // x: 160,
              // y: 14,
              // ColumnWidth: 40,
              // DaysCount: 5,
            // });
            
            normal_group_ForecastWeather = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 160,
              y: 14,
              h: 0,
              w: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_forecast_average_text_font = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: -5,
              // y: -14,
              // w: 150,
              // h: 30,
              // text_size: 10,
              // char_space: 0,
              // line_space: 0,
              // alpha: 255,
              // color: 0xFF616161,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.LEFT,
              // align_v: hmUI.align.TOP,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_average_text_font,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //#region screenType
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 5; i++) {
                normal_forecast_average_text_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: -5 + i*40,
                  y: -14,
                  w: 150,
                  h: 30,
                  text_size: 10,
                  char_space: 0,
                  line_space: 0,
                  color: 0xFF616161,
                  align_h: hmUI.align.LEFT,
                  align_v: hmUI.align.TOP,
                  text_style: hmUI.text_style.ELLIPSIS,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //#endregion
            
            //#region draw
            function drawLine(canvas1, canvas2, x1, y1, x2, y2, color, line_width) {
              if (x1 > x2) {
                let temp_x = x1;
                let temp_y = y1;
                x1 = x2;
                y1 = y2;
                x2 = temp_x;
                y2 = temp_y;
              };
              canvas2.setPaint({ color: color, line_width: line_width });
              canvas2.drawLine({ x1: x1, y1: y1, x2: x2, y2: y2 });
            };
            
            function drawRect(canvas1, canvas2, x1, y1, x2, y2, color) {
              if (x1 > x2) {
                let temp_x = x1;
                let temp_y = y1;
                x1 = x2;
                y1 = y2;
                x2 = temp_x;
                y2 = temp_y;
              };
              
              canvas2.drawRect({ x1: x1, y1: y1, x2: x2, y2: y2, color: color });
            };
            
            function drawCircle(canvas1, canvas2, center_x, center_y, color, radius) {
              canvas2.drawCircle({ center_x: center_x, center_y: center_y, radius: radius, color: color });
            };
            
            function drawGraphPoint(canvas1, canvas2, x, y, color, pointSize, pointType) {
              switch (pointType) {
                case 1:
                  x -= pointSize/2;
                  y -= pointSize/2;
                  drawRect(canvas1, canvas2, x, y, x+pointSize, y+pointSize, color);
                  break;
                case 2:
                  let posX = x - pointSize/2;
                  let posY = y - pointSize/2;
                  drawRect(canvas1, canvas2, posX, posY, posX+pointSize, posY+pointSize, color );
                  posX = x - pointSize/4;
                  posY = y - pointSize/4;
                  drawRect(canvas1, canvas2, posX, posY, posX+pointSize/2, posY+pointSize/2, 0xffffff );
                  break;
                case 3:
                  drawCircle(canvas1, canvas2, x, y, color, pointSize/2 );
                  break;
                case 4:
                  drawCircle(canvas1, canvas2, x, y, color, pointSize/2 );
                  drawCircle(canvas1, canvas2, x, y, 0xffffff, pointSize/4 );
                  break;
              }
            };

            //#endregion
            

            //#region graphScale
            function graphScale(heightGraph, maxPointSize, minPointSize, forecastData, daysCount) {
              console.log(`function graphScale`);
              heightGraph -= (maxPointSize + minPointSize) / 2;
              let high = -300;
              let low = 300;
              for (let index = 0; index < daysCount; index++) {
                if (index < forecastData.length) {
                  let item = forecastData[index];
                  if (item.high > high) high = item.high;;
                  if (item.low < low) low = item.low; ;
                } // end if
              } // end for
              let delta = high - low;
              let scale = heightGraph / delta;
              console.log(`heightGraph: ${heightGraph}; high: ${high}; low : ${low}`);
              return {graphScale: scale, maximal_temp: high};
            };

            //#endregion

            //#region screenType
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              normal_canvas1 = normal_group_ForecastWeather.createWidget(hmUI.widget.CANVAS, {
                x: 0,
                y: 0,
                w: 0,
                h: 0,
              });

              normal_canvas2 = normal_group_ForecastWeather.createWidget(hmUI.widget.CANVAS, {
                x: -2,
                y: 0,
                w: 480,
                h: 480,
              });
            };
            //#endregion

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 291,
              y: 54,
              font_array: ["micro_0.png","micro_1.png","micro_2.png","micro_3.png","micro_4.png","micro_5.png","micro_6.png","micro_7.png","micro_8.png","micro_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 332,
              y: 43,
              src: 'hpa.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 292,
              y: 34,
              font_array: ["micro_0.png","micro_1.png","micro_2.png","micro_3.png","micro_4.png","micro_5.png","micro_6.png","micro_7.png","micro_8.png","micro_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '%.png',
              unit_tc: '%.png',
              unit_en: '%.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 307,
              y: 16,
              src: 'kaplya.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 169,
              y: 25,
              src: '0111.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 213,
              y: 10,
              image_array: ["w_01.png","w_02.png","w_03.png","w_04.png","w_05.png","w_06.png","w_07.png","w_08.png","w_09.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png","w_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 185,
              y: 26,
              font_array: ["micro_0.png","micro_1.png","micro_2.png","micro_3.png","micro_4.png","micro_5.png","micro_6.png","micro_7.png","micro_8.png","micro_9.png"],
              padding: false,
              h_space: 0,
              negative_image: 'micro_10.png',
              invalid_image: 'micro_10.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 185,
              y: 54,
              font_array: ["micro_0.png","micro_1.png","micro_2.png","micro_3.png","micro_4.png","micro_5.png","micro_6.png","micro_7.png","micro_8.png","micro_9.png"],
              padding: false,
              h_space: 0,
              negative_image: 'micro_10.png',
              invalid_image: 'micro_10.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 171,
              y: 52,
              src: 'Dn.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 103,
              y: 40,
              font_array: ["osn_00.png","osn_01.png","osn_02.png","osn_03.png","osn_04.png","osn_05.png","osn_06.png","osn_07.png","osn_08.png","osn_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'osn_13.png',
              unit_tc: 'osn_13.png',
              unit_en: 'osn_13.png',
              imperial_unit_sc: 'osn_13.png',
              imperial_unit_tc: 'osn_13.png',
              imperial_unit_en: 'osn_13.png',
              negative_image: 'osn_11.png',
              invalid_image: 'osn_11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 103,
                y: 40,
                font_array: ["osn_00.png","osn_01.png","osn_02.png","osn_03.png","osn_04.png","osn_05.png","osn_06.png","osn_07.png","osn_08.png","osn_09.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'osn_13.png',
                unit_tc: 'osn_13.png',
                unit_en: 'osn_13.png',
                imperial_unit_sc: 'osn_13.png',
                imperial_unit_tc: 'osn_13.png',
                imperial_unit_en: 'osn_13.png',
                negative_image: 'osn_11.png',
                invalid_image: 'osn_11.png',
                align_h: hmUI.align.RIGHT,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 92,
              y: 113,
              src: 'unlock.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 8,
              y: 240,
              image_array: ["veter_1.png","veter_2.png","veter_3.png","veter_4.png","veter_5.png","veter_6.png","veter_7.png","veter_8.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_aqi_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 15,
              y: 187,
              image_array: ["AQI_1.png","AQI_2.png","AQI_3.png","AQI_4.png","AQI_5.png","AQI_6.png"],
              image_length: 6,
              type: hmUI.data_type.AQI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 36,
              y: 130,
              src: 'UI_00.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 36,
              y: 130,
              image_array: ["UI_01.png","UI_02.png","UI_03.png","UI_04.png","UI_05.png"],
              image_length: 5,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 49,
              y: 147,
              font_array: ["mini_00.png","mini_01.png","mini_02.png","mini_03.png","mini_04.png","mini_05.png","mini_06.png","mini_07.png","mini_08.png","mini_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 356,
              y: 225,
              src: 'bio.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 387,
              y: 227,
              font_array: ["mini_00.png","mini_01.png","mini_02.png","mini_03.png","mini_04.png","mini_05.png","mini_06.png","mini_07.png","mini_08.png","mini_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 353,
              y: 332,
              src: 'SpO2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 393,
              y: 333,
              font_array: ["mini_00.png","mini_01.png","mini_02.png","mini_03.png","mini_04.png","mini_05.png","mini_06.png","mini_07.png","mini_08.png","mini_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 367,
              y: 301,
              font_array: ["osn_00.png","osn_01.png","osn_02.png","osn_03.png","osn_04.png","osn_05.png","osn_06.png","osn_07.png","osn_08.png","osn_09.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'osn_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 434,
              y: 312,
              image_array: ["zona_1.png","zona_2.png","zona_3.png","zona_4.png","zona_5.png","zona_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 331,
              y: 192,
              font_array: ["osn_00.png","osn_01.png","osn_02.png","osn_03.png","osn_04.png","osn_05.png","osn_06.png","osn_07.png","osn_08.png","osn_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'km.png',
              unit_tc: 'km.png',
              unit_en: 'km.png',
              dot_image: 'osn_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_calorie_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_calorie_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 350,
              // start_y: 290,
              // color: 0xFFEF7D32,
              // lenght: 93,
              // line_width: 1,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 362,
              y: 258,
              font_array: ["osn_00.png","osn_01.png","osn_02.png","osn_03.png","osn_04.png","osn_05.png","osn_06.png","osn_07.png","osn_08.png","osn_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 305,
              // start_y: 179,
              // color: 0xFF7DD9E6,
              // lenght: 138,
              // line_width: 1,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 324,
              y: 148,
              font_array: ["osn_00.png","osn_01.png","osn_02.png","osn_03.png","osn_04.png","osn_05.png","osn_06.png","osn_07.png","osn_08.png","osn_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 105,
              y: 81,
              src: 'bydilnik_off.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 180,
              // center_y: 293,
              // start_angle: 180,
              // end_angle: -30,
              // radius: 157,
              // line_width: 14,
              // line_cap: Flat,
              // color: 0xFF9FFF00,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 180,
              center_y: 293,
              start_angle: 180,
              end_angle: -30,
              radius: 150,
              line_width: 14,
              corner_flag: 3,
              color: 0xFF9FFF00,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 17,
              y: 130,
              w: 326,
              h: 326,
              text_size: 18,
              char_space: 0,
              color: 0xFF9FFF00,
              // use_text_circle: true,
              start_angle: 182,
              end_angle: 207,
              mode: 1,
              // radius: 163,
              align_h: hmUI.align.RIGHT,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 145,
              hour_startY: 85,
              hour_array: ["min_00.png","min_01.png","min_02.png","min_03.png","min_04.png","min_05.png","min_06.png","min_07.png","min_08.png","min_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 244,
              minute_startY: 85,
              minute_array: ["min_00.png","min_01.png","min_02.png","min_03.png","min_04.png","min_05.png","min_06.png","min_07.png","min_08.png","min_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 328,
              second_startY: 104,
              second_array: ["osn_00.png","osn_01.png","osn_02.png","osn_03.png","osn_04.png","osn_05.png","osn_06.png","osn_07.png","osn_08.png","osn_09.png"],
              second_zero: 0,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 22,
              y: 136,
              src: 'sdf_22136.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 225,
              y: 84,
              src: 'touch_100.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 72,
              y: 98,
              src: 'bt_on.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 39,
              am_y: 153,
              am_sc_path: 'AM39153_0.png',
              am_en_path: 'AM39153_0.png',
              pm_x: 39,
              pm_y: 153,
              pm_sc_path: 'PM39153_1.png',
              pm_en_path: 'PM39153_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 92,
              y: 113,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 72,
              y: 98,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 105,
              y: 81,
              src: 'bydilnik.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 145,
              y: 199,
              image_array: ["lun_1.png","lun_2.png","lun_3.png","lun_4.png","lun_5.png","lun_6.png","lun_7.png","lun_8.png","lun_9.png","lun_10.png","lun_11.png","lun_12.png","lun_13.png","lun_14.png","lun_15.png","lun_16.png","lun_17.png","lun_18.png","lun_19.png","lun_20.png","lun_21.png","lun_22.png","lun_23.png","lun_24.png","lun_25.png","lun_26.png","lun_27.png","lun_28.png","lun_29.png","lun_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 191,
              year_startY: 334,
              year_sc_array: ["bat_00.png","bat_01.png","bat_02.png","bat_03.png","bat_04.png","bat_05.png","bat_06.png","bat_07.png","bat_08.png","bat_09.png"],
              year_tc_array: ["bat_00.png","bat_01.png","bat_02.png","bat_03.png","bat_04.png","bat_05.png","bat_06.png","bat_07.png","bat_08.png","bat_09.png"],
              year_en_array: ["bat_00.png","bat_01.png","bat_02.png","bat_03.png","bat_04.png","bat_05.png","bat_06.png","bat_07.png","bat_08.png","bat_09.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_year_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 181,
              y: 334,
              src: 'bat_11.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 159,
              month_startY: 334,
              month_sc_array: ["bat_00.png","bat_01.png","bat_02.png","bat_03.png","bat_04.png","bat_05.png","bat_06.png","bat_07.png","bat_08.png","bat_09.png"],
              month_tc_array: ["bat_00.png","bat_01.png","bat_02.png","bat_03.png","bat_04.png","bat_05.png","bat_06.png","bat_07.png","bat_08.png","bat_09.png"],
              month_en_array: ["bat_00.png","bat_01.png","bat_02.png","bat_03.png","bat_04.png","bat_05.png","bat_06.png","bat_07.png","bat_08.png","bat_09.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 150,
              y: 334,
              src: 'bat_11.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 127,
              day_startY: 334,
              day_sc_array: ["bat_00.png","bat_01.png","bat_02.png","bat_03.png","bat_04.png","bat_05.png","bat_06.png","bat_07.png","bat_08.png","bat_09.png"],
              day_tc_array: ["bat_00.png","bat_01.png","bat_02.png","bat_03.png","bat_04.png","bat_05.png","bat_06.png","bat_07.png","bat_08.png","bat_09.png"],
              day_en_array: ["bat_00.png","bat_01.png","bat_02.png","bat_03.png","bat_04.png","bat_05.png","bat_06.png","bat_07.png","bat_08.png","bat_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 160,
              y: 361,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hhh_11_91.png',
              // center_x: 180,
              // center_y: 293,
              // x: 11,
              // y: 91,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 180 - 11,
              pos_y: 293 - 91,
              center_x: 180,
              center_y: 293,
              src: 'hhh_11_91.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'mmm_11_127.png',
              // center_x: 180,
              // center_y: 293,
              // x: 10,
              // y: 127,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 180 - 10,
              pos_y: 293 - 127,
              center_x: 180,
              center_y: 293,
              src: 'mmm_11_127.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'sss_5_135y.png',
              // center_x: 180,
              // center_y: 293,
              // x: 5,
              // y: 135,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_smooth_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sss_5_135y.png',
              second_centerX: 180,
              second_centerY: 293,
              second_posX: 5,
              second_posY: 135,
              fresh_frequency: 15,
              fresh_freqency: 15,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 3,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_3.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 191,
              year_startY: 334,
              year_sc_array: ["bat_00.png","bat_01.png","bat_02.png","bat_03.png","bat_04.png","bat_05.png","bat_06.png","bat_07.png","bat_08.png","bat_09.png"],
              year_tc_array: ["bat_00.png","bat_01.png","bat_02.png","bat_03.png","bat_04.png","bat_05.png","bat_06.png","bat_07.png","bat_08.png","bat_09.png"],
              year_en_array: ["bat_00.png","bat_01.png","bat_02.png","bat_03.png","bat_04.png","bat_05.png","bat_06.png","bat_07.png","bat_08.png","bat_09.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_year_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 181,
              y: 334,
              src: 'bat_11.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 159,
              month_startY: 334,
              month_sc_array: ["bat_00.png","bat_01.png","bat_02.png","bat_03.png","bat_04.png","bat_05.png","bat_06.png","bat_07.png","bat_08.png","bat_09.png"],
              month_tc_array: ["bat_00.png","bat_01.png","bat_02.png","bat_03.png","bat_04.png","bat_05.png","bat_06.png","bat_07.png","bat_08.png","bat_09.png"],
              month_en_array: ["bat_00.png","bat_01.png","bat_02.png","bat_03.png","bat_04.png","bat_05.png","bat_06.png","bat_07.png","bat_08.png","bat_09.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 150,
              y: 334,
              src: 'bat_11.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 127,
              day_startY: 334,
              day_sc_array: ["bat_00.png","bat_01.png","bat_02.png","bat_03.png","bat_04.png","bat_05.png","bat_06.png","bat_07.png","bat_08.png","bat_09.png"],
              day_tc_array: ["bat_00.png","bat_01.png","bat_02.png","bat_03.png","bat_04.png","bat_05.png","bat_06.png","bat_07.png","bat_08.png","bat_09.png"],
              day_en_array: ["bat_00.png","bat_01.png","bat_02.png","bat_03.png","bat_04.png","bat_05.png","bat_06.png","bat_07.png","bat_08.png","bat_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 160,
              y: 361,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hhh_11_91.png',
              // center_x: 180,
              // center_y: 293,
              // x: 11,
              // y: 91,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 180 - 11,
              pos_y: 293 - 91,
              center_x: 180,
              center_y: 293,
              src: 'hhh_11_91.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'mmm_11_127.png',
              // center_x: 180,
              // center_y: 293,
              // x: 10,
              // y: 127,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 180 - 10,
              pos_y: 293 - 127,
              center_x: 180,
              center_y: 293,
              src: 'mmm_11_127.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 133,
              y: 424,
              w: 70,
              h: 30,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 143,
              y: 199,
              w: 70,
              h: 70,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 114,
              y: 37,
              w: 100,
              h: 30,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'knopka_10030.png',
              normal_src: 'knopka_10030.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 133,
              y: 326,
              w: 100,
              h: 30,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'knopka_10030.png',
              normal_src: 'knopka_10030.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 370,
              y: 81,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'knopka_5050.png',
              normal_src: 'knopka_5050.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 342,
              y: 222,
              w: 100,
              h: 30,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'knopka_10030.png',
              normal_src: 'knopka_10030.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BioChargeHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 362,
              y: 189,
              w: 100,
              h: 30,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'knopka_10030.png',
              normal_src: 'knopka_10030.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'OfflineMapScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 285,
              y: 19,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'knopka_5050.png',
              normal_src: 'knopka_5050.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BaroAltimeterScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 317,
              y: 81,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'knopka_5050.png',
              normal_src: 'knopka_5050.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 92,
              y: 69,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'knopka_5050.png',
              normal_src: 'knopka_5050.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 209,
              y: 83,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'knopka_5050.png',
              normal_src: 'knopka_5050.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TomatoMainScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 310,
              y: 146,
              w: 100,
              h: 30,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'knopka_10030.png',
              normal_src: 'knopka_10030.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 351,
              y: 299,
              w: 100,
              h: 30,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'knopka_10030.png',
              normal_src: 'knopka_10030.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_12 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 351,
              y: 257,
              w: 100,
              h: 30,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'knopka_10030.png',
              normal_src: 'knopka_10030.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_13 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 260,
              y: 417,
              w: 100,
              h: 30,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'knopka_10030.png',
              normal_src: 'knopka_10030.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StressHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_14 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 310,
              y: 377,
              w: 100,
              h: 30,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'knopka_10030.png',
              normal_src: 'knopka_10030.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Sleep_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_15 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 341,
              y: 333,
              w: 100,
              h: 30,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'knopka_10030.png',
              normal_src: 'knopka_10030.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'spo_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
            //#region weather_few_days
            function weather_few_days() {
              console.log('weather_few_days()');
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;
              let result = {graphScale: 1, maximal_temp: 0};
              let maxOldX = 0;
              let averageOldX = 0;
              let minOldX = 0;

              if (screenType == hmSetting.screen_type.WATCHFACE) result = graphScale(62, 3, 3, forecastData.data, 5);
              let forecastGraphScale = result.graphScale;
              let maximal_temp = result.maximal_temp;
              console.log(`forecastGraphScale = ${forecastGraphScale}, maximal_temp = ${maximal_temp}`);

              if (screenType == hmSetting.screen_type.WATCHFACE) {
                normal_canvas1.clear({x: 0, y:0, w: 0, h: 0});
                normal_canvas2.clear({x: 0, y:0, w: 480, h: 480});
              };
              let normal_max_offsetX = 2;
              if (screenType == hmSetting.screen_type.WATCHFACE)  maxOldX = normal_max_offsetX;
              let maxOldY = (maximal_temp - forecastData.data[0].high) * forecastGraphScale + 2;
              let endPointMax = false;
              let normal_average_offsetX = 2;
              if (screenType == hmSetting.screen_type.WATCHFACE) averageOldX = normal_average_offsetX;
              let averageOldY = (maximal_temp - (forecastData.data[0].high + forecastData.data[0].low) / 2) * forecastGraphScale + 2;
              let endPointAverage = false;
              let normal_min_offsetX = 2;
              if (screenType == hmSetting.screen_type.WATCHFACE) minOldX = normal_min_offsetX;
              let minOldY = (maximal_temp - forecastData.data[0].low) * forecastGraphScale + 2;
              let endPointMin = false;
              for (let i = 0; i < 5; i++) {
                // Number_Font_Average
                let averageTemperature = '-';
                if (i < forecastData.count) averageTemperature = parseInt((forecastData.data[i].high + forecastData.data[i].low)/2).toString();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let normal_forecast_average_text_font_posY = (maximal_temp - (forecastData.data[i].high + forecastData.data[i].low)/2 ) * forecastGraphScale + -12;
                  normal_forecast_average_text_font[i].setProperty(hmUI.prop.Y, normal_forecast_average_text_font_posY);
                  normal_forecast_average_text_font[i].setProperty(hmUI.prop.TEXT, averageTemperature);
                };
                
                // Graph
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (i < forecastData.count) {
                    let maxStartX = maxOldX;
                    let maxStartY = maxOldY;
                    maxOldX = normal_max_offsetX + i * 40;
                    maxOldY = (maximal_temp - forecastData.data[i].high) * forecastGraphScale + 2;
                    let maxEndX = maxOldX;
                    let maxEndY = maxOldY;
                    if (maxStartX != maxEndX) {
                      drawLine(normal_canvas1, normal_canvas2, maxStartX, maxStartY, maxEndX, maxEndY, 0xFF7D0000, 1)
                      drawGraphPoint(normal_canvas1, normal_canvas2, maxStartX, maxStartY, 0xFF7D0000, 3, 4)
                      endPointMax = true;
                    };
                  
                    let averageStartX = averageOldX;
                    let averageStartY = averageOldY;
                    averageOldX = normal_average_offsetX + i * 40;
                    averageOldY = (maximal_temp - (forecastData.data[i].high + forecastData.data[i].low) / 2) * forecastGraphScale + 2;
                    let averageEndX = averageOldX;
                    let averageEndY = averageOldY;
                    if (averageStartX != averageEndX) {
                      drawLine(normal_canvas1, normal_canvas2, averageStartX, averageStartY, averageEndX, averageEndY, 0xFF5D5D5D, 1)
                      drawGraphPoint(normal_canvas1, normal_canvas2, averageStartX, averageStartY, 0xFF5D5D5D, 3, 3)
                      endPointAverage = true;
                    };
                  
                    let minStartX = minOldX;
                    let minStartY = minOldY;
                    minOldX = normal_min_offsetX + i * 40;
                    minOldY = (maximal_temp - forecastData.data[i].low) * forecastGraphScale + 2;
                    let minEndX = minOldX;
                    let minEndY = minOldY;
                    if (minStartX != minEndX) {
                      drawLine(normal_canvas1, normal_canvas2, minStartX, minStartY, minEndX, minEndY, 0xFF005380, 1)
                      drawGraphPoint(normal_canvas1, normal_canvas2, minStartX, minStartY, 0xFF005380, 3, 4)
                      endPointMin = true;
                    };
                  
                  };
                };  // end screen_type
                
              };  // end for

              if (screenType == hmSetting.screen_type.WATCHFACE && endPointMax) {
                drawGraphPoint(normal_canvas1, normal_canvas2, maxOldX, maxOldY, 0xFF7D0000, 3, 4)
              };
              if (screenType == hmSetting.screen_type.WATCHFACE && endPointAverage) {
                drawGraphPoint(normal_canvas1, normal_canvas2, averageOldX, averageOldY, 0xFF5D5D5D, 3, 3)
              };
              if (screenType == hmSetting.screen_type.WATCHFACE && endPointMin) {
                drawGraphPoint(normal_canvas1, normal_canvas2, minOldX, minOldY, 0xFF005380, 3, 4)
              };
            };
            //#endregion

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateMinute) { // Hour Pointer
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              if (updateMinute) { // Hour Pointer
                let idle_hour = hour;
                let idle_fullAngle_hour = 360;
                if (idle_hour > 11) idle_hour -= 12;
                let idle_angle_hour = 0 + idle_fullAngle_hour*idle_hour/12 + (idle_fullAngle_hour/12)*minute/60;
                if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
              };

              if (updateMinute) { // Minute Pointer
                let idle_fullAngle_minute = 360;
                let idle_angle_minute = 0 + idle_fullAngle_minute*minute/60;
                if (idle_analog_clock_pro_minute_pointer_img) idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_minute);
              };

            };

            //#endregion
            if (!sleepSensor) sleepSensor = hmSensor.createSensor(hmSensor.id.SLEEP);
            //#region sleep_update
            function sleep_update() {
              console.log('sleep_update()');

              console.log('sleep duration total time');
              let sleepDurationTotalTime = sleepSensor.getTotalTime();
              let sleepDurationTotalHour = Math.floor(sleepDurationTotalTime / 60);
              let sleepDurationTotalMin = sleepDurationTotalTime % 60;

              let normal_sleepDurationTotalHourStr = sleepDurationTotalHour.toString();
              let normal_sleepDurationTotalMinStr = sleepDurationTotalMin.toString().padStart(2, '0');
              let normal_SleepDurationStr = normal_sleepDurationTotalHourStr + ':' + normal_sleepDurationTotalMinStr;
              if (normal_sleep_duration_total_font) normal_sleep_duration_total_font.setProperty(hmUI.prop.TEXT, normal_SleepDurationStr);

              console.log('sleep chart');
              let normal_sleepColors = [0xFF743ED4, 0xFF6284EF, 0xFF46C536, 0xFFAE433B];
              let normal_sleppChartWidth = 88;
              let normal_sleppChartHeight = 20;
              let normal_sleepScaleX = normal_sleppChartWidth / sleepSensor.getTotalTime();
              let normal_sleepScaleY = normal_sleppChartHeight / 4;
              const modelData = sleepSensor.getSleepStageModel();
              let sleepStageArray = sleepSensor.getSleepStageData();
              let sleepChartStartTime = 0;
              if (array_sleep_chart.length > 0) {
                console.log('deleteWidget screen on');
                for (let i = 0; i < array_sleep_chart.length; i++) {
                  if (array_sleep_chart[i]) hmUI.deleteWidget(array_sleep_chart[i]);
                }
                array_sleep_chart = [];
              } // end if

              if (sleepStageArray != undefined && sleepStageArray.length > 0) sleepChartStartTime = sleepStageArray[0].start;
              // console.log('draw normal_sleep_chart');
              if (screenType == hmSetting.screen_type.WATCHFACE) {
                for (let i = 0; i < sleepStageArray.length; i++) { //ONLY_NORMAL
                  let data = sleepStageArray[i];
                  let normal_color = normal_sleepColors[0];
                  let normal_posY = 3 * normal_sleepScaleY;

                  switch (data.model) {
                    case modelData.WAKE_STAGE:
                      normal_color = normal_sleepColors[3];
                      normal_posY = 0;
                      break;
                    case modelData.REM_STAGE:
                      normal_color = normal_sleepColors[2];
                      normal_posY = normal_sleepScaleY; 
                      break;
                    case modelData.LIGHT_STAGE:
                      normal_color = normal_sleepColors[1];
                      normal_posY = 2 * normal_sleepScaleY; 
                      break;
                  };
                  let normal_x = (data.start - sleepChartStartTime) * normal_sleepScaleX;
                  let normal_w = (data.stop + 1 - data.start) * normal_sleepScaleX;
                  const fill_rect = normal_sleep_chart_group.createWidget(hmUI.widget.FILL_RECT, {
                    x: normal_x,
                    y: normal_posY,
                    w: normal_w < 2 ? 2 : normal_w,
                    h: normal_sleepScaleY,
                    radius: 0,
                    color: normal_color,
                  });
                  array_sleep_chart.push(fill_rect);
                }; // for
              }; // end screenType

              console.log('sleep HR chart');
              let sleepHrData = sleepSensor.getSleepHrData();
              const sleepHrData_replaced = sleepHrData.map(v => v === 255 ? 0 : v);
              let lineHrDatas = [];
              let maxHR = Math.max(...sleepHrData_replaced);
              let oldHR = Math.min(...sleepHrData);
              for (let i = 0; i < sleepHrData_replaced.length; i++) {
                if (sleepHrData_replaced[i] > 0) oldHR = sleepHrData_replaced[i];
                let y = 20 - (oldHR * (20 / maxHR));
                lineHrDatas.push({x: i * (88 / sleepHrData_replaced.length), y: y});
              };
              if (screenType == hmSetting.screen_type.WATCHFACE) {
                normal_sleep_chart_hr.clear();
                normal_sleep_chart_hr.addLine({
                  data: lineHrDatas,
                  count: lineHrDatas.length
                });
              };
            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_ls_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_linear_scale
                  // initial parameters
                  let start_x_normal_calorie = 350;
                  let start_y_normal_calorie = 290;
                  let lenght_ls_normal_calorie = 93;
                  let line_width_ls_normal_calorie = 1;
                  let color_ls_normal_calorie = 0xFFEF7D32;
                  
                  // calculated parameters
                  let start_x_normal_calorie_draw = start_x_normal_calorie;
                  let start_y_normal_calorie_draw = start_y_normal_calorie;
                  lenght_ls_normal_calorie = lenght_ls_normal_calorie * progress_ls_normal_calorie;
                  let lenght_ls_normal_calorie_draw = lenght_ls_normal_calorie;
                  let line_width_ls_normal_calorie_draw = line_width_ls_normal_calorie;
                  if (lenght_ls_normal_calorie < 0){
                    lenght_ls_normal_calorie_draw = -lenght_ls_normal_calorie;
                    start_x_normal_calorie_draw = start_x_normal_calorie - lenght_ls_normal_calorie_draw;
                  };
                  
                  normal_calorie_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_calorie_draw,
                    y: start_y_normal_calorie_draw,
                    w: lenght_ls_normal_calorie_draw,
                    h: line_width_ls_normal_calorie_draw,
                    color: color_ls_normal_calorie,
                  });
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 305;
                  let start_y_normal_step = 179;
                  let lenght_ls_normal_step = 138;
                  let line_width_ls_normal_step = 1;
                  let color_ls_normal_step = 0xFF7DD9E6;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = lenght_ls_normal_step;
                  let line_width_ls_normal_step_draw = line_width_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    lenght_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 180,
                      center_y: 293,
                      start_angle: 180,
                      end_angle: -30,
                      radius: 150,
                      line_width: 14,
                      corner_flag: 3,
                      color: 0xFF9FFF00,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                sleep_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                weather_few_days();
              }),
              pause_call: (function () {
                console.log('pause_call()');

                if (array_sleep_chart.length > 0) {
                console.log('deleteWidget screen off');
                  for (let i = 0; i < array_sleep_chart.length; i++) {
                    if (array_sleep_chart[i]) hmUI.deleteWidget(array_sleep_chart[i]);
                  }
                  array_sleep_chart = [];
                } // end if
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}