﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_moon_image_progress_img_level = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_alarm_clock_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_bio_charge_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_readiness_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 34,
              y: 124,
              src: 'icons8-sveglia-50.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 430,
              font_array: ["digit_90.png","digit_91.png","digit_92.png","digit_93.png","digit_94.png","digit_95.png","digit_96.png","digit_97.png","digit_98.png","digit_99.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'special_01.png',
              unit_tc: 'special_01.png',
              unit_en: 'special_01.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 159,
              y: 422,
              src: 'icons8-batteria-in-carica-48.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 326,
              year_startY: 294,
              year_sc_array: ["digit_90.png","digit_91.png","digit_92.png","digit_93.png","digit_94.png","digit_95.png","digit_96.png","digit_97.png","digit_98.png","digit_99.png"],
              year_tc_array: ["digit_90.png","digit_91.png","digit_92.png","digit_93.png","digit_94.png","digit_95.png","digit_96.png","digit_97.png","digit_98.png","digit_99.png"],
              year_en_array: ["digit_90.png","digit_91.png","digit_92.png","digit_93.png","digit_94.png","digit_95.png","digit_96.png","digit_97.png","digit_98.png","digit_99.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 88,
              month_startY: 294,
              month_sc_array: ["mese_01.png","mese_02.png","mese_03.png","mese_04.png","mese_05.png","mese_06.png","mese_07.png","mese_08.png","mese_09.png","mese_10.png","mese_11.png","mese_12.png"],
              month_tc_array: ["mese_01.png","mese_02.png","mese_03.png","mese_04.png","mese_05.png","mese_06.png","mese_07.png","mese_08.png","mese_09.png","mese_10.png","mese_11.png","mese_12.png"],
              month_en_array: ["mese_01.png","mese_02.png","mese_03.png","mese_04.png","mese_05.png","mese_06.png","mese_07.png","mese_08.png","mese_09.png","mese_10.png","mese_11.png","mese_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 20,
              day_startY: 294,
              day_sc_array: ["digit_90.png","digit_91.png","digit_92.png","digit_93.png","digit_94.png","digit_95.png","digit_96.png","digit_97.png","digit_98.png","digit_99.png"],
              day_tc_array: ["digit_90.png","digit_91.png","digit_92.png","digit_93.png","digit_94.png","digit_95.png","digit_96.png","digit_97.png","digit_98.png","digit_99.png"],
              day_en_array: ["digit_90.png","digit_91.png","digit_92.png","digit_93.png","digit_94.png","digit_95.png","digit_96.png","digit_97.png","digit_98.png","digit_99.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 298,
              y: 33,
              image_array: ["Moon11.png","Moon12.png","Moon13.png","Moon14.png","Moon15.png","Moon16.png","Moon17.png","Moon18.png","Moon19.png","Moon20.png","Moon21.png","Moon22.png","Moon23.png","Moon24.png","Moon25.png","Moon26.png","Moon27.png","Moon28.png","Moon29.png","Moon30.png","Moon31.png","Moon32.png","Moon33.png","Moon34.png","Moon35.png","Moon36.png","Moon37.png","Moon38.png","Moon39.png","Moon40.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 99,
              y: 41,
              image_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 154,
              y: 54,
              font_array: ["digit_11.png","digit_12.png","digit_13.png","digit_14.png","digit_15.png","digit_16.png","digit_17.png","digit_18.png","digit_19.png","digit_20.png"],
              padding: false,
              h_space: -10,
              unit_sc: 'special_13.png',
              unit_tc: 'special_13.png',
              unit_en: 'special_13.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 88,
              y: 135,
              font_array: ["digit_90.png","digit_91.png","digit_92.png","digit_93.png","digit_94.png","digit_95.png","digit_96.png","digit_97.png","digit_98.png","digit_99.png"],
              padding: true,
              h_space: -12,
              dot_image: 'special_12.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 203,
              y: 135,
              week_en: ["day_18.png","day_19.png","day_20.png","day_21.png","day_22.png","day_23.png","day_24.png"],
              week_tc: ["day_18.png","day_19.png","day_20.png","day_21.png","day_22.png","day_23.png","day_24.png"],
              week_sc: ["day_18.png","day_19.png","day_20.png","day_21.png","day_22.png","day_23.png","day_24.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 348,
              y: 360,
              font_array: ["digit_11.png","digit_12.png","digit_13.png","digit_14.png","digit_15.png","digit_16.png","digit_17.png","digit_18.png","digit_19.png","digit_20.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 66,
              y: 360,
              font_array: ["digit_11.png","digit_12.png","digit_13.png","digit_14.png","digit_15.png","digit_16.png","digit_17.png","digit_18.png","digit_19.png","digit_20.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 168,
              y: 360,
              font_array: ["digit_11.png","digit_12.png","digit_13.png","digit_14.png","digit_15.png","digit_16.png","digit_17.png","digit_18.png","digit_19.png","digit_20.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 4,
              hour_startY: 175,
              hour_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'special_11.png',
              hour_unit_tc: 'special_11.png',
              hour_unit_en: 'special_11.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_unit_sc: 'special_11.png',
              minute_unit_tc: 'special_11.png',
              minute_unit_en: 'special_11.png',
              minute_align: hmUI.align.LEFT,

              second_startX: 0,
              second_startY: 0,
              second_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 1,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 193,
              y: 430,
              font_array: ["digit_90.png","digit_91.png","digit_92.png","digit_93.png","digit_94.png","digit_95.png","digit_96.png","digit_97.png","digit_98.png","digit_99.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'special_01.png',
              unit_tc: 'special_01.png',
              unit_en: 'special_01.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 154,
              y: 422,
              src: 'icons8-batteria-in-carica-48.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 326,
              year_startY: 296,
              year_sc_array: ["digit_90.png","digit_91.png","digit_92.png","digit_93.png","digit_94.png","digit_95.png","digit_96.png","digit_97.png","digit_98.png","digit_99.png"],
              year_tc_array: ["digit_90.png","digit_91.png","digit_92.png","digit_93.png","digit_94.png","digit_95.png","digit_96.png","digit_97.png","digit_98.png","digit_99.png"],
              year_en_array: ["digit_90.png","digit_91.png","digit_92.png","digit_93.png","digit_94.png","digit_95.png","digit_96.png","digit_97.png","digit_98.png","digit_99.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 88,
              month_startY: 296,
              month_sc_array: ["mese_01.png","mese_02.png","mese_03.png","mese_04.png","mese_05.png","mese_06.png","mese_07.png","mese_08.png","mese_09.png","mese_10.png","mese_11.png","mese_12.png"],
              month_tc_array: ["mese_01.png","mese_02.png","mese_03.png","mese_04.png","mese_05.png","mese_06.png","mese_07.png","mese_08.png","mese_09.png","mese_10.png","mese_11.png","mese_12.png"],
              month_en_array: ["mese_01.png","mese_02.png","mese_03.png","mese_04.png","mese_05.png","mese_06.png","mese_07.png","mese_08.png","mese_09.png","mese_10.png","mese_11.png","mese_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 20,
              day_startY: 296,
              day_sc_array: ["digit_90.png","digit_91.png","digit_92.png","digit_93.png","digit_94.png","digit_95.png","digit_96.png","digit_97.png","digit_98.png","digit_99.png"],
              day_tc_array: ["digit_90.png","digit_91.png","digit_92.png","digit_93.png","digit_94.png","digit_95.png","digit_96.png","digit_97.png","digit_98.png","digit_99.png"],
              day_en_array: ["digit_90.png","digit_91.png","digit_92.png","digit_93.png","digit_94.png","digit_95.png","digit_96.png","digit_97.png","digit_98.png","digit_99.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 122,
              y: 132,
              week_en: ["day_18.png","day_19.png","day_20.png","day_21.png","day_22.png","day_23.png","day_24.png"],
              week_tc: ["day_18.png","day_19.png","day_20.png","day_21.png","day_22.png","day_23.png","day_24.png"],
              week_sc: ["day_18.png","day_19.png","day_20.png","day_21.png","day_22.png","day_23.png","day_24.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 82,
              hour_startY: 177,
              hour_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'special_11.png',
              hour_unit_tc: 'special_11.png',
              hour_unit_en: 'special_11.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 167,
              y: 344,
              w: 147,
              h: 74,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 62,
              y: 345,
              w: 90,
              h: 73,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 159,
              y: 425,
              w: 161,
              h: 43,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 269,
              y: 37,
              w: 130,
              h: 80,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 103,
              y: 37,
              w: 100,
              h: 80,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 265,
              y: 195,
              w: 197,
              h: 100,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 20,
              y: 193,
              w: 198,
              h: 100,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 35,
              y: 125,
              w: 155,
              h: 61,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_readiness_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 329,
              y: 345,
              w: 97,
              h: 73,
              type: hmUI.data_type.READINESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}