﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_spo2_text_text_img = ''
        let normal_spo2_text_separator_img = ''
        let normal_altitude_target_text_img = ''
        let normal_altitude_target_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_stress_text_text_img = ''
        let normal_stress_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_altitude_jumpable_img_click = ''
        let Button_1 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 227,
              y: 19,
              src: 'battery outside.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 175,
              y: 21,
              font_array: ["white_0.png","white_1.png","white_2.png","white_3.png","white_4.png","white_5.png","white_6.png","white_7.png","white_8.png","white_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 233,
              y: 25,
              image_array: ["battery_0.png","battery_1.png","battery_2.png","battery_3.png","battery_4.png","battery_5.png","battery_6.png","battery_7.png","battery_8.png","battery_9.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 54,
              y: 244,
              font_array: ["s20.png","s21.png","s22.png","s23.png","s24.png","s25.png","s26.png","s27.png","s28.png","s29.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Batt_Unit.png',
              unit_tc: 'Batt_Unit.png',
              unit_en: 'Batt_Unit.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 10,
              y: 242,
              src: 'blood_oxy 44x37.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 52,
              y: 178,
              font_array: ["s20.png","s21.png","s22.png","s23.png","s24.png","s25.png","s26.png","s27.png","s28.png","s29.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 18,
              y: 179,
              src: 'Altitude_30x26.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 215,
              y: 430,
              font_array: ["s20.png","s21.png","s22.png","s23.png","s24.png","s25.png","s26.png","s27.png","s28.png","s29.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 172,
              y: 424,
              src: 'pointer_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 135,
              y: 322,
              font_array: ["s20.png","s21.png","s22.png","s23.png","s24.png","s25.png","s26.png","s27.png","s28.png","s29.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 98,
              y: 281,
              image_array: ["92.png","93.png","94.png","95.png","96.png","97.png"],
              image_length: 6,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 338,
              y: 309,
              font_array: ["heart_1.4x_0.png","heart_1.4x_1.png","heart_1.4x_2.png","heart_1.4x_3.png","heart_1.4x_4.png","heart_1.4x_5.png","heart_1.4x_6.png","heart_1.4x_7.png","heart_1.4x_8.png","heart_1.4x_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 270,
              y: 313,
              src: 'heart_52x46.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 317,
              y: 90,
              week_en: ["week_1.1x_0.png","week_1.1x_1.png","week_1.1x_2.png","week_1.1x_3.png","week_1.1x_4.png","week_1.1x_5.png","week_1.1x_6.png"],
              week_tc: ["week_1.1x_0.png","week_1.1x_1.png","week_1.1x_2.png","week_1.1x_3.png","week_1.1x_4.png","week_1.1x_5.png","week_1.1x_6.png"],
              week_sc: ["week_1.1x_0.png","week_1.1x_1.png","week_1.1x_2.png","week_1.1x_3.png","week_1.1x_4.png","week_1.1x_5.png","week_1.1x_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 262,
              day_startY: 95,
              day_sc_array: ["s20.png","s21.png","s22.png","s23.png","s24.png","s25.png","s26.png","s27.png","s28.png","s29.png"],
              day_tc_array: ["s20.png","s21.png","s22.png","s23.png","s24.png","s25.png","s26.png","s27.png","s28.png","s29.png"],
              day_en_array: ["s20.png","s21.png","s22.png","s23.png","s24.png","s25.png","s26.png","s27.png","s28.png","s29.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 196,
              month_startY: 95,
              month_sc_array: ["s20.png","s21.png","s22.png","s23.png","s24.png","s25.png","s26.png","s27.png","s28.png","s29.png"],
              month_tc_array: ["s20.png","s21.png","s22.png","s23.png","s24.png","s25.png","s26.png","s27.png","s28.png","s29.png"],
              month_en_array: ["s20.png","s21.png","s22.png","s23.png","s24.png","s25.png","s26.png","s27.png","s28.png","s29.png"],
              month_zero: 0,
              month_space: 3,
              month_unit_sc: 'point_1.png',
              month_unit_tc: 'point_1.png',
              month_unit_en: 'point_1.png',
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 146,
              hour_startY: 123,
              hour_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 317,
              minute_startY: 123,
              minute_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 272,
              y: 153,
              src: 'colon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 150,
              y: 413,
              w: 191,
              h: 100,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 258,
              y: 285,
              w: 184,
              h: 85,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 133,
              y: 0,
              w: 223,
              h: 70,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: -2,
              y: 227,
              w: 136,
              h: 58,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 97,
              y: 285,
              w: 141,
              h: 84,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: -1,
              y: 160,
              w: 135,
              h: 67,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 201,
              y: 81,
              w: 248,
              h: 58,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}