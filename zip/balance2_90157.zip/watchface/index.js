﻿    /*
    ** Watch_Face_Editor tool v 18.0
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_readiness_icon_img = ''
        let normal_readiness_circle_scale = ''
        let normal_readiness_pointer_progress_img_pointer = ''
        let normal_bio_charge_icon_img = ''
        let normal_bio_charge_circle_scale = ''
        let normal_bio_charge_pointer_progress_img_pointer = ''
        let normal_fat_burning_icon_img = ''
        let normal_fat_burning_current_text_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_pointer_progress_img_pointer = ''
        let normal_calorie_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_step_circle_scale = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_circle_scale_2 = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let idle_background_bg_img = ''
        let idle_readiness_icon_img = ''
        let idle_readiness_circle_scale = ''
        let idle_readiness_pointer_progress_img_pointer = ''
        let idle_bio_charge_icon_img = ''
        let idle_bio_charge_circle_scale = ''
        let idle_bio_charge_pointer_progress_img_pointer = ''
        let idle_fat_burning_icon_img = ''
        let idle_fat_burning_current_text_img = ''
        let idle_calorie_icon_img = ''
        let idle_calorie_circle_scale = ''
        let idle_calorie_pointer_progress_img_pointer = ''
        let idle_calorie_current_text_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_battery_icon_img = ''
        let idle_battery_circle_scale = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_step_current_text_img = ''
        let idle_step_current_separator_img = ''
        let idle_step_circle_scale = ''
        let idle_step_pointer_progress_img_pointer = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_icon_img = ''
        let idle_heart_rate_circle_scale_2 = ''
        let idle_heart_rate_pointer_progress_img_pointer = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_image_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'background.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_readiness_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 332,
              y: 321,
              src: 'icon-readiness.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_readiness_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 124,
              end_angle: 177,
              radius: 202,
              line_width: 26,
              corner_flag: 3,
              type: hmUI.data_type.READINESS,
              color: 0xFF009E00,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_readiness_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'm.png',
              center_x: 240,
              center_y: 240,
              x: 20,
              y: 243,
              start_angle: 124,
              end_angle: 177,
              invalid_visible: false,
              type: hmUI.data_type.READINESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 125,
              y: 321,
              src: 'icon-biocharge.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 184,
              end_angle: 240,
              radius: 200,
              line_width: 26,
              corner_flag: 3,
              type: hmUI.data_type.BIO_CHARGE,
              color: 0xFF009E00,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'm.png',
              center_x: 240,
              center_y: 240,
              x: 20,
              y: 241,
              start_angle: 184,
              end_angle: 240,
              invalid_visible: false,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 239,
              y: 143,
              src: 'icon-fat.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 198,
              y: 178,
              font_array: ["chars_3405E921_000.png","chars_3405E921_001.png","chars_3405E921_002.png","chars_3405E921_003.png","chars_3405E921_004.png","chars_3405E921_005.png","chars_3405E921_006.png","chars_3405E921_007.png","chars_3405E921_008.png","chars_3405E921_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 97,
              y: 166,
              src: 'icon-calories.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 244,
              // end_angle: 296,
              // radius: 212,
              // line_width: 26,
              // line_cap: Flat,
              // color: 0xFF009E00,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 244,
              end_angle: 296,
              radius: 199,
              line_width: 26,
              corner_flag: 3,
              color: 0xFF009E00,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'm.png',
              center_x: 240,
              center_y: 240,
              x: 20,
              y: 240,
              start_angle: 244,
              end_angle: 296,
              invalid_visible: false,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 121,
              y: 178,
              font_array: ["chars_3405E921_000.png","chars_3405E921_001.png","chars_3405E921_002.png","chars_3405E921_003.png","chars_3405E921_004.png","chars_3405E921_005.png","chars_3405E921_006.png","chars_3405E921_007.png","chars_3405E921_008.png","chars_3405E921_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 271,
              y: 178,
              font_array: ["chars_3405E921_000.png","chars_3405E921_001.png","chars_3405E921_002.png","chars_3405E921_003.png","chars_3405E921_004.png","chars_3405E921_005.png","chars_3405E921_006.png","chars_3405E921_007.png","chars_3405E921_008.png","chars_3405E921_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 359,
              y: 179,
              src: 'chars_4C9C1940_000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 355,
              y: 170,
              src: 'icon-battery.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 65,
              // end_angle: 115,
              // radius: 214,
              // line_width: 26,
              // line_cap: Flat,
              // color: 0xFF009E00,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 65,
              end_angle: 115,
              radius: 201,
              line_width: 26,
              corner_flag: 3,
              color: 0xFF009E00,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'm.png',
              center_x: 240,
              center_y: 240,
              x: 20,
              y: 242,
              start_angle: 65,
              end_angle: 115,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 98,
              hour_startY: 220,
              hour_array: ["chars_169523AD_000.png","chars_169523AD_001.png","chars_169523AD_002.png","chars_169523AD_003.png","chars_169523AD_004.png","chars_169523AD_005.png","chars_169523AD_006.png","chars_169523AD_007.png","chars_169523AD_008.png","chars_169523AD_009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 257,
              minute_startY: 220,
              minute_array: ["chars_169523AD_000.png","chars_169523AD_001.png","chars_169523AD_002.png","chars_169523AD_003.png","chars_169523AD_004.png","chars_169523AD_005.png","chars_169523AD_006.png","chars_169523AD_007.png","chars_169523AD_008.png","chars_169523AD_009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 240,
              am_y: 212,
              am_sc_path: 'chars_4FB20583_000.png',
              am_en_path: 'chars_4FB20583_000.png',
              pm_x: 240,
              pm_y: 212,
              pm_sc_path: 'chars_4FB20583_000.png',
              pm_en_path: 'chars_4FB20583_000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 130,
              y: 120,
              font_array: ["chars_D5152416_000.png","chars_D5152416_001.png","chars_D5152416_002.png","chars_D5152416_003.png","chars_D5152416_004.png","chars_D5152416_005.png","chars_D5152416_006.png","chars_D5152416_007.png","chars_D5152416_008.png","chars_D5152416_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 181,
              y: 68,
              src: 'custom_icon_1791287703862_1791288985900_66x66_h0s100b0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 304,
              // end_angle: 356,
              // radius: 212,
              // line_width: 26,
              // line_cap: Flat,
              // color: 0xFF009E00,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 304,
              end_angle: 356,
              radius: 199,
              line_width: 26,
              corner_flag: 3,
              color: 0xFF009E00,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'm.png',
              center_x: 240,
              center_y: 240,
              x: 20,
              y: 240,
              start_angle: 304,
              end_angle: 356,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 269,
              y: 120,
              font_array: ["chars_D5152416_000.png","chars_D5152416_001.png","chars_D5152416_002.png","chars_D5152416_003.png","chars_D5152416_004.png","chars_D5152416_005.png","chars_D5152416_006.png","chars_D5152416_007.png","chars_D5152416_008.png","chars_D5152416_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 258,
              y: 89,
              src: 'heart_1_31x31.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_circle_scale_2 = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 4,
              end_angle: 59,
              radius: 200,
              line_width: 26,
              corner_flag: 3,
              type: hmUI.data_type.HEART,
              color: 0xFF009E00,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'm.png',
              center_x: 240,
              center_y: 240,
              x: 20,
              y: 240,
              start_angle: 4,
              end_angle: 59,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 113,
              day_startY: 286,
              day_sc_array: ["chars_3405E921_000.png","chars_3405E921_001.png","chars_3405E921_002.png","chars_3405E921_003.png","chars_3405E921_004.png","chars_3405E921_005.png","chars_3405E921_006.png","chars_3405E921_007.png","chars_3405E921_008.png","chars_3405E921_009.png"],
              day_tc_array: ["chars_3405E921_000.png","chars_3405E921_001.png","chars_3405E921_002.png","chars_3405E921_003.png","chars_3405E921_004.png","chars_3405E921_005.png","chars_3405E921_006.png","chars_3405E921_007.png","chars_3405E921_008.png","chars_3405E921_009.png"],
              day_en_array: ["chars_3405E921_000.png","chars_3405E921_001.png","chars_3405E921_002.png","chars_3405E921_003.png","chars_3405E921_004.png","chars_3405E921_005.png","chars_3405E921_006.png","chars_3405E921_007.png","chars_3405E921_008.png","chars_3405E921_009.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 174,
              y: 283,
              week_en: ["chars_597E25A1_000.png","chars_597E25A1_001.png","chars_597E25A1_002.png","chars_597E25A1_003.png","chars_597E25A1_004.png","chars_597E25A1_005.png","chars_597E25A1_006.png"],
              week_tc: ["chars_597E25A1_000.png","chars_597E25A1_001.png","chars_597E25A1_002.png","chars_597E25A1_003.png","chars_597E25A1_004.png","chars_597E25A1_005.png","chars_597E25A1_006.png"],
              week_sc: ["chars_597E25A1_000.png","chars_597E25A1_001.png","chars_597E25A1_002.png","chars_597E25A1_003.png","chars_597E25A1_004.png","chars_597E25A1_005.png","chars_597E25A1_006.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 231,
              y: 340,
              font_array: ["chars_3405E921_000.png","chars_3405E921_001.png","chars_3405E921_002.png","chars_3405E921_003.png","chars_3405E921_004.png","chars_3405E921_005.png","chars_3405E921_006.png","chars_3405E921_007.png","chars_3405E921_008.png","chars_3405E921_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'chars_3405E921_011.png',
              unit_tc: 'chars_3405E921_011.png',
              unit_en: 'chars_3405E921_011.png',
              negative_image: 'chars_3405E921_010.png',
              invalid_image: 'chars_3405E921_012.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 155,
              y: 315,
              image_array: ["set_6_82x82_meteo_1.png","set_6_82x82_meteo_2.png","set_6_82x82_meteo_3.png","set_6_82x82_meteo_4.png","set_6_82x82_meteo_5.png","set_6_82x82_meteo_6.png","set_6_82x82_meteo_7.png","set_6_82x82_meteo_8.png","set_6_82x82_meteo_9.png","set_6_82x82_meteo_10.png","set_6_82x82_meteo_11.png","set_6_82x82_meteo_12.png","set_6_82x82_meteo_13.png","set_6_82x82_meteo_14.png","set_6_82x82_meteo_15.png","set_6_82x82_meteo_16.png","set_6_82x82_meteo_17.png","set_6_82x82_meteo_18.png","set_6_82x82_meteo_19.png","set_6_82x82_meteo_20.png","set_6_82x82_meteo_21.png","set_6_82x82_meteo_22.png","set_6_82x82_meteo_23.png","set_6_82x82_meteo_24.png","set_6_82x82_meteo_25.png","set_6_82x82_meteo_26.png","set_6_82x82_meteo_27.png","set_6_82x82_meteo_28.png","set_6_82x82_meteo_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hh.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 20,
              hour_posY: 239,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'mm.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 20,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'background.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_readiness_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 332,
              y: 321,
              src: 'icon-readiness.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_readiness_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 124,
              end_angle: 177,
              radius: 202,
              line_width: 26,
              corner_flag: 3,
              type: hmUI.data_type.READINESS,
              color: 0xFF009E00,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_readiness_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'm.png',
              center_x: 240,
              center_y: 240,
              x: 20,
              y: 243,
              start_angle: 124,
              end_angle: 177,
              invalid_visible: false,
              type: hmUI.data_type.READINESS,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_bio_charge_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 125,
              y: 321,
              src: 'icon-biocharge.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_bio_charge_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 184,
              end_angle: 240,
              radius: 200,
              line_width: 26,
              corner_flag: 3,
              type: hmUI.data_type.BIO_CHARGE,
              color: 0xFF009E00,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_bio_charge_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'm.png',
              center_x: 240,
              center_y: 240,
              x: 20,
              y: 241,
              start_angle: 184,
              end_angle: 240,
              invalid_visible: false,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 239,
              y: 143,
              src: 'icon-fat.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 198,
              y: 178,
              font_array: ["chars_3405E921_000.png","chars_3405E921_001.png","chars_3405E921_002.png","chars_3405E921_003.png","chars_3405E921_004.png","chars_3405E921_005.png","chars_3405E921_006.png","chars_3405E921_007.png","chars_3405E921_008.png","chars_3405E921_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 97,
              y: 166,
              src: 'icon-calories.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 244,
              // end_angle: 296,
              // radius: 212,
              // line_width: 26,
              // line_cap: Flat,
              // color: 0xFF009E00,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 244,
              end_angle: 296,
              radius: 199,
              line_width: 26,
              corner_flag: 3,
              color: 0xFF009E00,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'm.png',
              center_x: 240,
              center_y: 240,
              x: 20,
              y: 240,
              start_angle: 244,
              end_angle: 296,
              invalid_visible: false,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 121,
              y: 178,
              font_array: ["chars_3405E921_000.png","chars_3405E921_001.png","chars_3405E921_002.png","chars_3405E921_003.png","chars_3405E921_004.png","chars_3405E921_005.png","chars_3405E921_006.png","chars_3405E921_007.png","chars_3405E921_008.png","chars_3405E921_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 271,
              y: 178,
              font_array: ["chars_3405E921_000.png","chars_3405E921_001.png","chars_3405E921_002.png","chars_3405E921_003.png","chars_3405E921_004.png","chars_3405E921_005.png","chars_3405E921_006.png","chars_3405E921_007.png","chars_3405E921_008.png","chars_3405E921_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 359,
              y: 179,
              src: 'chars_4C9C1940_000.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 355,
              y: 170,
              src: 'icon-battery.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 65,
              // end_angle: 115,
              // radius: 214,
              // line_width: 26,
              // line_cap: Flat,
              // color: 0xFF009E00,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 65,
              end_angle: 115,
              radius: 201,
              line_width: 26,
              corner_flag: 3,
              color: 0xFF009E00,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'm.png',
              center_x: 240,
              center_y: 240,
              x: 20,
              y: 242,
              start_angle: 65,
              end_angle: 115,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 98,
              hour_startY: 220,
              hour_array: ["chars_169523AD_000.png","chars_169523AD_001.png","chars_169523AD_002.png","chars_169523AD_003.png","chars_169523AD_004.png","chars_169523AD_005.png","chars_169523AD_006.png","chars_169523AD_007.png","chars_169523AD_008.png","chars_169523AD_009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 257,
              minute_startY: 220,
              minute_array: ["chars_169523AD_000.png","chars_169523AD_001.png","chars_169523AD_002.png","chars_169523AD_003.png","chars_169523AD_004.png","chars_169523AD_005.png","chars_169523AD_006.png","chars_169523AD_007.png","chars_169523AD_008.png","chars_169523AD_009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 240,
              am_y: 212,
              am_sc_path: 'chars_4FB20583_000.png',
              am_en_path: 'chars_4FB20583_000.png',
              pm_x: 240,
              pm_y: 212,
              pm_sc_path: 'chars_4FB20583_000.png',
              pm_en_path: 'chars_4FB20583_000.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 130,
              y: 120,
              font_array: ["chars_D5152416_000.png","chars_D5152416_001.png","chars_D5152416_002.png","chars_D5152416_003.png","chars_D5152416_004.png","chars_D5152416_005.png","chars_D5152416_006.png","chars_D5152416_007.png","chars_D5152416_008.png","chars_D5152416_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 181,
              y: 68,
              src: 'custom_icon_1791287703862_1791288985900_66x66_h0s100b0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 304,
              // end_angle: 356,
              // radius: 212,
              // line_width: 26,
              // line_cap: Flat,
              // color: 0xFF009E00,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 304,
              end_angle: 356,
              radius: 199,
              line_width: 26,
              corner_flag: 3,
              color: 0xFF009E00,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'm.png',
              center_x: 240,
              center_y: 240,
              x: 20,
              y: 240,
              start_angle: 304,
              end_angle: 356,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 269,
              y: 120,
              font_array: ["chars_D5152416_000.png","chars_D5152416_001.png","chars_D5152416_002.png","chars_D5152416_003.png","chars_D5152416_004.png","chars_D5152416_005.png","chars_D5152416_006.png","chars_D5152416_007.png","chars_D5152416_008.png","chars_D5152416_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 258,
              y: 89,
              src: 'heart_1_31x31.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_circle_scale_2 = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 4,
              end_angle: 59,
              radius: 200,
              line_width: 26,
              corner_flag: 3,
              type: hmUI.data_type.HEART,
              color: 0xFF009E00,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'm.png',
              center_x: 240,
              center_y: 240,
              x: 20,
              y: 240,
              start_angle: 4,
              end_angle: 59,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 113,
              day_startY: 286,
              day_sc_array: ["chars_3405E921_000.png","chars_3405E921_001.png","chars_3405E921_002.png","chars_3405E921_003.png","chars_3405E921_004.png","chars_3405E921_005.png","chars_3405E921_006.png","chars_3405E921_007.png","chars_3405E921_008.png","chars_3405E921_009.png"],
              day_tc_array: ["chars_3405E921_000.png","chars_3405E921_001.png","chars_3405E921_002.png","chars_3405E921_003.png","chars_3405E921_004.png","chars_3405E921_005.png","chars_3405E921_006.png","chars_3405E921_007.png","chars_3405E921_008.png","chars_3405E921_009.png"],
              day_en_array: ["chars_3405E921_000.png","chars_3405E921_001.png","chars_3405E921_002.png","chars_3405E921_003.png","chars_3405E921_004.png","chars_3405E921_005.png","chars_3405E921_006.png","chars_3405E921_007.png","chars_3405E921_008.png","chars_3405E921_009.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 174,
              y: 283,
              week_en: ["chars_597E25A1_000.png","chars_597E25A1_001.png","chars_597E25A1_002.png","chars_597E25A1_003.png","chars_597E25A1_004.png","chars_597E25A1_005.png","chars_597E25A1_006.png"],
              week_tc: ["chars_597E25A1_000.png","chars_597E25A1_001.png","chars_597E25A1_002.png","chars_597E25A1_003.png","chars_597E25A1_004.png","chars_597E25A1_005.png","chars_597E25A1_006.png"],
              week_sc: ["chars_597E25A1_000.png","chars_597E25A1_001.png","chars_597E25A1_002.png","chars_597E25A1_003.png","chars_597E25A1_004.png","chars_597E25A1_005.png","chars_597E25A1_006.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 231,
              y: 340,
              font_array: ["chars_3405E921_000.png","chars_3405E921_001.png","chars_3405E921_002.png","chars_3405E921_003.png","chars_3405E921_004.png","chars_3405E921_005.png","chars_3405E921_006.png","chars_3405E921_007.png","chars_3405E921_008.png","chars_3405E921_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'chars_3405E921_011.png',
              unit_tc: 'chars_3405E921_011.png',
              unit_en: 'chars_3405E921_011.png',
              negative_image: 'chars_3405E921_010.png',
              invalid_image: 'chars_3405E921_012.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 155,
              y: 315,
              image_array: ["set_6_82x82_meteo_1.png","set_6_82x82_meteo_2.png","set_6_82x82_meteo_3.png","set_6_82x82_meteo_4.png","set_6_82x82_meteo_5.png","set_6_82x82_meteo_6.png","set_6_82x82_meteo_7.png","set_6_82x82_meteo_8.png","set_6_82x82_meteo_9.png","set_6_82x82_meteo_10.png","set_6_82x82_meteo_11.png","set_6_82x82_meteo_12.png","set_6_82x82_meteo_13.png","set_6_82x82_meteo_14.png","set_6_82x82_meteo_15.png","set_6_82x82_meteo_16.png","set_6_82x82_meteo_17.png","set_6_82x82_meteo_18.png","set_6_82x82_meteo_19.png","set_6_82x82_meteo_20.png","set_6_82x82_meteo_21.png","set_6_82x82_meteo_22.png","set_6_82x82_meteo_23.png","set_6_82x82_meteo_24.png","set_6_82x82_meteo_25.png","set_6_82x82_meteo_26.png","set_6_82x82_meteo_27.png","set_6_82x82_meteo_28.png","set_6_82x82_meteo_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hh.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 20,
              hour_posY: 239,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'mm.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 20,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'aod.png',
              // alpha: 100,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img.setAlpha(100);

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 244,
                      end_angle: 296,
                      radius: 199,
                      line_width: 26,
                      corner_flag: 3,
                      color: 0xFF009E00,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 65,
                      end_angle: 115,
                      radius: 201,
                      line_width: 26,
                      corner_flag: 3,
                      color: 0xFF009E00,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 304,
                      end_angle: 356,
                      radius: 199,
                      line_width: 26,
                      corner_flag: 3,
                      color: 0xFF009E00,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                let progress_cs_idle_calorie = progressCalories;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_calorie * 100);
                  if (idle_calorie_circle_scale) {
                    idle_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 244,
                      end_angle: 296,
                      radius: 199,
                      line_width: 26,
                      corner_flag: 3,
                      color: 0xFF009E00,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_battery * 100);
                  if (idle_battery_circle_scale) {
                    idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 65,
                      end_angle: 115,
                      radius: 201,
                      line_width: 26,
                      corner_flag: 3,
                      color: 0xFF009E00,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                let progress_cs_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_step * 100);
                  if (idle_step_circle_scale) {
                    idle_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 304,
                      end_angle: 356,
                      radius: 199,
                      line_width: 26,
                      corner_flag: 3,
                      color: 0xFF009E00,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}