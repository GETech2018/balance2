try {
(() => {
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    function getApp() { return __$$app$$__.app; }
    function getCurrentPage() { return __$$app$$__.current && __$$app$$__.current.module; }
    const __$$module$$__ = __$$app$$__.current;
    const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
    const {px} = __$$app$$__.__globals__;
    const logger = DeviceRuntimeCore.HmLogger.getLogger('carbon_watchface');

    const BOTH = hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD;
    const FONT = 'fonts/gsflex.ttf';

    // green overlay positions [x, y, w, h]
    const DW = [[84,41,80,68],[123,21,64,64],[165,10,64,58],[214,10,48,50],[249,10,64,56],[285,18,80,64],[323,37,80,72]];
    const DM = [[96,359,80,68],[138,382,64,64],[186,398,64,56],[236,398,64,56],[279,382,64,64],[315,358,80,68],[74,381,80,75],[120,408,80,73],[180,427,64,61],[233,428,64,61],[280,409,80,71],[328,381,80,77]];
    const CLKW = ['clkw0.png','clkw1.png','clkw2.png','clkw3.png','clkw4.png','clkw5.png','clkw6.png','clkw7.png','clkw8.png','clkw9.png'];
    const CLKR = ['clkr0.png','clkr1.png','clkr2.png','clkr3.png','clkr4.png','clkr5.png','clkr6.png','clkr7.png','clkr8.png','clkr9.png'];
    const DD = ['dd0.png','dd1.png','dd2.png','dd3.png','dd4.png','dd5.png','dd6.png','dd7.png','dd8.png','dd9.png'];
    const DPX = [176,202,246,272];  // 4 date digit x positions (DD/MM)
    const SLX = [228]; const DDY = 341;             // slash x position, date row y

    let dateDigits = [], dayHL = '', monthHL = '', cityTxt = '', weather = null, tmr = undefined;
    function pad(n){ return n < 10 ? '0' + n : '' + n; }

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
        init_view() {
            // preload font glyphs for normal + AOD
            [27, 31, 32, 34].forEach(function (sz) {
                hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 480, y: 480, w: 30, h: 30, text_size: sz, font: FONT, color: 0xFF000000,
                    align_h: hmUI.align.CENTER_H, align_v: hmUI.align.CENTER_V,
                    text: '0123456789/%°', show_level: BOTH,
                });
            });

            // background (carbon + baked names/icons/weather/scrims)
            hmUI.createWidget(hmUI.widget.IMG, { x: 0, y: 0, w: 480, h: 480, src: 'bg.png', show_level: BOTH });

            // current day / month green highlight
            const now0 = new Date();
            const di = (now0.getDay() + 6) % 7, mi = now0.getMonth();
            dayHL = hmUI.createWidget(hmUI.widget.IMG, { x: DW[di][0], y: DW[di][1], w: DW[di][2], h: DW[di][3], src: 'dw' + di + '.png', show_level: BOTH });
            monthHL = hmUI.createWidget(hmUI.widget.IMG, { x: DM[mi][0], y: DM[mi][1], w: DM[mi][2], h: DM[mi][3], src: 'dm' + mi + '.png', show_level: BOTH });

            // central clock - stacked hour over minute (silver serif digit images)
            hmUI.createWidget(hmUI.widget.IMG_TIME, {
                hour_startX: 161, hour_startY: 148, hour_array: CLKW,
                hour_zero: 1, hour_space: -2, hour_align: hmUI.align.LEFT, show_level: BOTH,
            });
            hmUI.createWidget(hmUI.widget.IMG_TIME, {
                minute_startX: 161, minute_startY: 244, minute_array: CLKR,
                minute_zero: 1, minute_space: -2, minute_align: hmUI.align.LEFT, show_level: BOTH,
            });

            // date DD/MM/AAAA built from white carbon digit images + slashes
            SLX.forEach(function (sx) {
                hmUI.createWidget(hmUI.widget.IMG, { x: sx, y: DDY, src: 'dslash.png', show_level: BOTH });
            });
            for (let i = 0; i < 4; i++) {
                dateDigits[i] = hmUI.createWidget(hmUI.widget.IMG, { x: DPX[i], y: DDY, src: 'dd0.png', show_level: BOTH });
            }

            // live metric values
            function tf(x, y, w, hh, size, color, type, unit) {
                return hmUI.createWidget(hmUI.widget.TEXT_FONT, {
                    x: x, y: y, w: w, h: hh, text_size: size, font: FONT, color: color,
                    align_h: hmUI.align.CENTER_H, align_v: hmUI.align.CENTER_V,
                    char_space: 0, line_space: 0, text_style: hmUI.text_style.NONE,
                    type: type, unit_type: unit, show_level: BOTH,
                });
            }
            tf(20, 199, 92, 46, 34, 0xFFE84848, hmUI.data_type.HEART, 0);       // BPM red
            tf(20, 271, 92, 46, 34, 0xFF78CD50, hmUI.data_type.BATTERY, 1);     // battery green %
            tf(354, 199, 120, 46, 34, 0xFF489CEC, hmUI.data_type.STEP, 0);      // steps blue (same size as others)
            tf(368, 271, 92, 46, 34, 0xFFF08C28, hmUI.data_type.BIO_CHARGE, 0); // biocharge orange
            // weather temp (left-aligned after baked icon)
            hmUI.createWidget(hmUI.widget.TEXT_FONT, {
                x: 247, y: 64, w: 90, h: 44, text_size: 31, font: FONT, color: 0xFFEBEEF5,
                align_h: hmUI.align.LEFT, align_v: hmUI.align.CENTER_V,
                char_space: 0, line_space: 0, text_style: hmUI.text_style.NONE,
                type: hmUI.data_type.WEATHER_CURRENT, unit_type: 1, show_level: BOTH,
            });

            // dynamic city name (read from weather) - plain text, any city/accent
            weather = hmSensor.createSensor(hmSensor.id.WEATHER);
            cityTxt = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 40, y: 110, w: 400, h: 28, text_size: 20, font: FONT, color: 0xFFF0F2F6,
                align_h: hmUI.align.CENTER_H, align_v: hmUI.align.CENTER_V,
                text_style: hmUI.text_style.NONE, char_space: 0, line_space: 0, text: '', show_level: BOTH,
            });

            // tappable shortcuts -> system apps (auto-routed by data_type)
            console.log('Watch_Face.Shortcuts');
            function tap(x, y, w, hh, type) {
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: x, y: y, w: w, h: hh, type: type, show_level: hmUI.show_level.ONLY_NORMAL,
                });
            }
            tap(178, 56, 132, 74, hmUI.data_type.WEATHER_CURRENT);  // weather icon + temp -> weather
            tap(168, 336, 144, 48, hmUI.data_type.CAL);            // date -> calendar
            tap(22, 166, 90, 82, hmUI.data_type.HEART);            // BPM -> heart rate
            tap(22, 250, 90, 72, hmUI.data_type.BATTERY);          // battery -> battery
            tap(352, 166, 122, 82, hmUI.data_type.STEP);           // steps -> steps
            tap(356, 250, 116, 72, hmUI.data_type.BIO_CHARGE);     // biocharge -> bio charge

            const refresh = function () {
                const d = new Date();
                const ds = pad(d.getDate()) + pad(d.getMonth() + 1);  // 4 digit chars (DD/MM)
                for (let i = 0; i < 4; i++) dateDigits[i].setProperty(hmUI.prop.SRC, DD[Number(ds[i])]);
                try { const wd = weather.getForecastWeather(); if (wd && wd.cityName) cityTxt.setProperty(hmUI.prop.TEXT, ('' + wd.cityName).toUpperCase()); } catch (e) {}
                const di2 = (d.getDay() + 6) % 7, mi2 = d.getMonth();
                dayHL.setProperty(hmUI.prop.MORE, { x: DW[di2][0], y: DW[di2][1], w: DW[di2][2], h: DW[di2][3], src: 'dw' + di2 + '.png', show_level: BOTH });
                monthHL.setProperty(hmUI.prop.MORE, { x: DM[mi2][0], y: DM[mi2][1], w: DM[mi2][2], h: DM[mi2][3], src: 'dm' + mi2 + '.png', show_level: BOTH });
            };
            refresh();
            tmr = timer.createTimer(0, 60000, refresh, {});
        },
        onInit() { logger.log('carbon watchface init'); },
        build() { this.init_view(); },
        onDestroy() { if (tmr) timer.stopTimer(tmr); }
    });
})();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
}
