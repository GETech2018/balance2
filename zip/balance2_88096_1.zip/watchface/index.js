﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_system_lock_img = ''
        let normal_system_clock_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_icon_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_sun_icon_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_high_separator_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_low_separator_img = ''
        let normal_frame_animation_1 = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_altitude_target_text_img = ''
        let normal_altitude_target_separator_img = ''
        let normal_uvi_text_text_img = ''
        let normal_uvi_text_separator_img = ''
        let normal_humidity_text_text_img = ''
        let normal_humidity_text_separator_img = ''
        let normal_wind_icon_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_temperature_icon_img = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_current_separator_img = ''
        let normal_compass_icon_img = ''
        let normal_compass_direction_pointer_img = ''
        let normal_compass_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_second_separator_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_altitude_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 57,
              y: 310,
              src: 'Blocco.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 57,
              y: 134,
              src: 'Svglia_attiva.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 192,
              y: 380,
              src: 'Calorie.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 229,
              y: 391,
              font_array: ["num_piccolo_0.png","num_piccolo_1.png","num_piccolo_2.png","num_piccolo_3.png","num_piccolo_4.png","num_piccolo_5.png","num_piccolo_6.png","num_piccolo_7.png","num_piccolo_8.png","num_piccolo_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'kilokal.png',
              unit_tc: 'kilokal.png',
              unit_en: 'kilokal.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 186,
              y: 407,
              src: 'distanza.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 229,
              y: 420,
              font_array: ["num_piccolo_0.png","num_piccolo_1.png","num_piccolo_2.png","num_piccolo_3.png","num_piccolo_4.png","num_piccolo_5.png","num_piccolo_6.png","num_piccolo_7.png","num_piccolo_8.png","num_piccolo_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'km_piccol.png',
              unit_tc: 'km_piccol.png',
              unit_en: 'km_piccol.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 105,
              y: 327,
              src: 'cont_data_step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 123,
              y: 380,
              font_array: ["num_piccolo_0.png","num_piccolo_1.png","num_piccolo_2.png","num_piccolo_3.png","num_piccolo_4.png","num_piccolo_5.png","num_piccolo_6.png","num_piccolo_7.png","num_piccolo_8.png","num_piccolo_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 121,
              y: 366,
              image_array: ["st_0.png","st_1.png","st_2.png","st_3.png","st_4.png","st_5.png","st_6.png","st_7.png","st_8.png","st_9.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 385,
              y: 134,
              image_array: ["Luna_0.png","Luna_1.png","Luna_2.png","Luna_3.png","Luna_4.png","Luna_5.png","Luna_6.png","Luna_7.png","Luna_8.png","Luna_9.png","Luna_10.png","Luna_11.png","Luna_12.png","Luna_13.png","Luna_14.png","Luna_15.png","Luna_16.png","Luna_17.png","Luna_18.png","Luna_19.png","Luna_20.png","Luna_21.png","Luna_22.png","Luna_23.png","Luna_24.png","Luna_25.png","Luna_26.png","Luna_27.png","Luna_28.png","Luna_29.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 365,
              y: 189,
              src: 'cont_data_diviso.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 384,
              y: 213,
              font_array: ["num_piccolo_0.png","num_piccolo_1.png","num_piccolo_2.png","num_piccolo_3.png","num_piccolo_4.png","num_piccolo_5.png","num_piccolo_6.png","num_piccolo_7.png","num_piccolo_8.png","num_piccolo_9.png"],
              padding: false,
              h_space: 1,
              dot_image: 'dupunti.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 391,
              y: 184,
              src: 'alba.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 384,
              y: 233,
              font_array: ["num_piccolo_0.png","num_piccolo_1.png","num_piccolo_2.png","num_piccolo_3.png","num_piccolo_4.png","num_piccolo_5.png","num_piccolo_6.png","num_piccolo_7.png","num_piccolo_8.png","num_piccolo_9.png"],
              padding: false,
              h_space: 1,
              dot_image: 'dupunti.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 391,
              y: 240,
              src: 'tramonto.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 304,
              y: 347,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "c",
              anim_fps: 15,
              anim_size: 10,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 289,
              y: 327,
              src: 'cont_data.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 318,
              y: 363,
              font_array: ["num_piccolo_0.png","num_piccolo_1.png","num_piccolo_2.png","num_piccolo_3.png","num_piccolo_4.png","num_piccolo_5.png","num_piccolo_6.png","num_piccolo_7.png","num_piccolo_8.png","num_piccolo_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 48,
              year_startY: 198,
              year_sc_array: ["num_piccolo_0.png","num_piccolo_1.png","num_piccolo_2.png","num_piccolo_3.png","num_piccolo_4.png","num_piccolo_5.png","num_piccolo_6.png","num_piccolo_7.png","num_piccolo_8.png","num_piccolo_9.png"],
              year_tc_array: ["num_piccolo_0.png","num_piccolo_1.png","num_piccolo_2.png","num_piccolo_3.png","num_piccolo_4.png","num_piccolo_5.png","num_piccolo_6.png","num_piccolo_7.png","num_piccolo_8.png","num_piccolo_9.png"],
              year_en_array: ["num_piccolo_0.png","num_piccolo_1.png","num_piccolo_2.png","num_piccolo_3.png","num_piccolo_4.png","num_piccolo_5.png","num_piccolo_6.png","num_piccolo_7.png","num_piccolo_8.png","num_piccolo_9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 36,
              y: 243,
              week_en: ["gs_1.png","gs_2.png","gs_3.png","gs_4.png","gs_5.png","gs_6.png","gs_7.png"],
              week_tc: ["gs_1.png","gs_2.png","gs_3.png","gs_4.png","gs_5.png","gs_6.png","gs_7.png"],
              week_sc: ["gs_1.png","gs_2.png","gs_3.png","gs_4.png","gs_5.png","gs_6.png","gs_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 67,
              month_startY: 218,
              month_sc_array: ["mese_0.png","mese_1.png","mese_2.png","mese_3.png","mese_4.png","mese_5.png","mese_6.png","mese_7.png","mese_8.png","mese_9.png","mese_10.png","mese_11.png"],
              month_tc_array: ["mese_0.png","mese_1.png","mese_2.png","mese_3.png","mese_4.png","mese_5.png","mese_6.png","mese_7.png","mese_8.png","mese_9.png","mese_10.png","mese_11.png"],
              month_en_array: ["mese_0.png","mese_1.png","mese_2.png","mese_3.png","mese_4.png","mese_5.png","mese_6.png","mese_7.png","mese_8.png","mese_9.png","mese_10.png","mese_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 32,
              day_startY: 218,
              day_sc_array: ["gm_0.png","gm_1.png","gm_2.png","gm_3.png","gm_4.png","gm_5.png","gm_6.png","gm_7.png","gm_8.png","gm_9.png"],
              day_tc_array: ["gm_0.png","gm_1.png","gm_2.png","gm_3.png","gm_4.png","gm_5.png","gm_6.png","gm_7.png","gm_8.png","gm_9.png"],
              day_en_array: ["gm_0.png","gm_1.png","gm_2.png","gm_3.png","gm_4.png","gm_5.png","gm_6.png","gm_7.png","gm_8.png","gm_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 25,
              y: 194,
              src: 'cont_data.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 226,
              y: 283,
              src: 'battria_baz.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213,
              y: 324,
              font_array: ["bat2_0.png","bat2_1.png","bat2_2.png","bat2_4.png","bat2_5.png","bat2_6.png","bat2_7.png","bat2_8.png","bat2_9.png","bateria_perc.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'bateria_perc.png',
              unit_tc: 'bateria_perc.png',
              unit_en: 'bateria_perc.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 225,
              y: 282,
              image_array: ["bat_0.png","bat_01.png","bat_2.png","bat_3.png","bat_4.png","bat_5.png","bat_6.png","bat_7.png","bat_8.png","bat_9.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 321,
              y: 119,
              font_array: ["num_piccolo_0.png","num_piccolo_1.png","num_piccolo_2.png","num_piccolo_3.png","num_piccolo_4.png","num_piccolo_5.png","num_piccolo_6.png","num_piccolo_7.png","num_piccolo_8.png","num_piccolo_9.png"],
              padding: false,
              h_space: 0,
              negative_image: 'temp_min_12.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 300,
              y: 119,
              src: 'altitude_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 292,
              y: 93,
              font_array: ["num_piccolo_0.png","num_piccolo_1.png","num_piccolo_2.png","num_piccolo_3.png","num_piccolo_4.png","num_piccolo_5.png","num_piccolo_6.png","num_piccolo_7.png","num_piccolo_8.png","num_piccolo_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 313,
              y: 94,
              src: 'UV_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 354,
              y: 93,
              font_array: ["num_piccolo_0.png","num_piccolo_1.png","num_piccolo_2.png","num_piccolo_3.png","num_piccolo_4.png","num_piccolo_5.png","num_piccolo_6.png","num_piccolo_7.png","num_piccolo_8.png","num_piccolo_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 337,
              y: 94,
              src: 'Umidita_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 289,
              y: 62,
              src: 'cont_data.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 310,
              y: 72,
              image_array: ["Vento_1.png","Vento_2.png","Vento_3.png","Vento_4.png","Vento_5.png","Vento_6.png","Vento_7.png","Vento_8.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 337,
              y: 71,
              font_array: ["num_piccolo_0.png","num_piccolo_1.png","num_piccolo_2.png","num_piccolo_3.png","num_piccolo_4.png","num_piccolo_5.png","num_piccolo_6.png","num_piccolo_7.png","num_piccolo_8.png","num_piccolo_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 130,
              y: 123,
              src: 'temperature_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 125,
              y: 163,
              w: 241,
              h: 30,
              text_size: 20,
              char_space: 0,
              color: 0xFFFF8C00,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 203,
              y: 86,
              image_array: ["METEO_1.png","METEO_2.png","METEO_3.png","METEO_4.png","METEO_5.png","METEO_6.png","METEO_7.png","METEO_8.png","METEO_9.png","METEO_10.png","METEO_11.png","METEO_12.png","METEO_13.png","METEO_14.png","METEO_15.png","METEO_16.png","METEO_17.png","METEO_18.png","METEO_19.png","METEO_20.png","METEO_21.png","METEO_22.png","METEO_23.png","METEO_24.png","METEO_25.png","METEO_26.png","METEO_27.png","METEO_28.png","METEO_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 108,
              y: 98,
              font_array: ["temp_max_0.png","temp_max_1.png","temp_max_2.png","temp_max_3.png","temp_max_4.png","temp_max_5.png","temp_max_6.png","temp_max_7.png","temp_max_8.png","temp_max_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'temp_max_11.png',
              unit_tc: 'temp_max_11.png',
              unit_en: 'temp_max_11.png',
              imperial_unit_sc: 'temp_max_11.png',
              imperial_unit_tc: 'temp_max_11.png',
              imperial_unit_en: 'temp_max_11.png',
              negative_image: 'temp_max_10.png',
              invalid_image: 'temp_max_12.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_high_text_img.setProperty(hmUI.prop.MORE, {
                x: 108,
                y: 98,
                font_array: ["temp_max_0.png","temp_max_1.png","temp_max_2.png","temp_max_3.png","temp_max_4.png","temp_max_5.png","temp_max_6.png","temp_max_7.png","temp_max_8.png","temp_max_9.png"],
                padding: false,
                h_space: 1,
                unit_sc: 'temp_max_11.png',
                unit_tc: 'temp_max_11.png',
                unit_en: 'temp_max_11.png',
                imperial_unit_sc: 'temp_max_11.png',
                imperial_unit_tc: 'temp_max_11.png',
                imperial_unit_en: 'temp_max_11.png',
                negative_image: 'temp_max_10.png',
                invalid_image: 'temp_max_12.png',
                align_h: hmUI.align.LEFT,
                type: hmUI.data_type.WEATHER_HIGH,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 143,
              y: 98,
              font_array: ["temp_min_0.png","temp_min_1.png","temp_min_2.png","temp_min_3.png","temp_min_4.png","temp_min_5.png","temp_min_6.png","temp_min_7.png","temp_min_8.png","temp_min_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'temp_min_11.png',
              unit_tc: 'temp_min_11.png',
              unit_en: 'temp_min_11.png',
              imperial_unit_sc: 'temp_min_11.png',
              imperial_unit_tc: 'temp_min_11.png',
              imperial_unit_en: 'temp_min_11.png',
              negative_image: 'temp_min_10.png',
              invalid_image: 'temp_min_12.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_low_text_img.setProperty(hmUI.prop.MORE, {
                x: 143,
                y: 98,
                font_array: ["temp_min_0.png","temp_min_1.png","temp_min_2.png","temp_min_3.png","temp_min_4.png","temp_min_5.png","temp_min_6.png","temp_min_7.png","temp_min_8.png","temp_min_9.png"],
                padding: false,
                h_space: 1,
                unit_sc: 'temp_min_11.png',
                unit_tc: 'temp_min_11.png',
                unit_en: 'temp_min_11.png',
                imperial_unit_sc: 'temp_min_11.png',
                imperial_unit_tc: 'temp_min_11.png',
                imperial_unit_en: 'temp_min_11.png',
                negative_image: 'temp_min_10.png',
                invalid_image: 'temp_min_12.png',
                align_h: hmUI.align.RIGHT,
                type: hmUI.data_type.WEATHER_LOW,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 122,
              y: 68,
              font_array: ["temp_0.png","temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png","temp_6.png","temp_7.png","temp_8.png","temp_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'temp_11.png',
              unit_tc: 'temp_11.png',
              unit_en: 'temp_11.png',
              imperial_unit_sc: 'temp_11.png',
              imperial_unit_tc: 'temp_11.png',
              imperial_unit_en: 'temp_11.png',
              negative_image: 'temp_10.png',
              invalid_image: 'temp_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 105,
              y: 62,
              src: 'cont_data.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 122,
                y: 68,
                font_array: ["temp_0.png","temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png","temp_6.png","temp_7.png","temp_8.png","temp_9.png"],
                padding: false,
                h_space: 1,
                unit_sc: 'temp_11.png',
                unit_tc: 'temp_11.png',
                unit_en: 'temp_11.png',
                imperial_unit_sc: 'temp_11.png',
                imperial_unit_tc: 'temp_11.png',
                imperial_unit_en: 'temp_11.png',
                negative_image: 'temp_10.png',
                invalid_image: 'temp_12.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_compass_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 238,
              y: 27,
              src: 'riferimento_bussola.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            
            // normal_compass_custom_pointer_img = hmUI.createWidget(hmUI.widget.CUSTOM_POINTER, {
              // src: 'QUADRANTE_MOD_COMPASS_NEW.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.COMPASS,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            //#region Compass_Pointer
            normal_compass_direction_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 'QUADRANTE_MOD_COMPASS_NEW.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //#endregion

            normal_compass_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 185,
              y: 53,
              font_array: ["aodfontbig_0.png","aodfontbig_1.png","aodfontbig_2.png","aodfontbig_3.png","aodfontbig_4.png","aodfontbig_5.png","aodfontbig_6.png","aodfontbig_7.png","aodfontbig_8.png","aodfontbig_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'aoddu.png',
              unit_tc: 'aoddu.png',
              unit_en: 'aoddu.png',
              align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.COMPASS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 119,
              hour_startY: 193,
              hour_array: ["HM_0.png","HM_1.png","HM_2.png","HM_3.png","HM_4.png","HM_5.png","HM_6.png","HM_7.png","HM_8.png","HM_9.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 258,
              minute_startY: 193,
              minute_array: ["HM_0.png","HM_1.png","HM_2.png","HM_3.png","HM_4.png","HM_5.png","HM_6.png","HM_7.png","HM_8.png","HM_9.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 227,
              second_startY: 226,
              second_array: ["temp_0.png","temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png","temp_6.png","temp_7.png","temp_8.png","temp_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 230,
              y: 187,
              src: 'duepunti.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'aoddu.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 105,
              y: 327,
              w: 90,
              h: 90,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 289,
              y: 327,
              w: 91,
              h: 91,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 226,
              y: 283,
              w: 30,
              h: 66,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 365,
              y: 189,
              w: 85,
              h: 91,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 385,
              y: 135,
              w: 35,
              h: 39,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 105,
              y: 62,
              w: 91,
              h: 90,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 200,
              y: 86,
              w: 86,
              h: 79,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 57,
              y: 134,
              w: 35,
              h: 36,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 290,
              y: 62,
              w: 91,
              h: 91,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            //#region compass_update
            console.log('compass_update()');
            if (screenType == hmSetting.screen_type.WATCHFACE){
              compass = hmSensor.createSensor(hmSensor.id.COMPASS);
              compass.start();

              if (compass.direction_angle && compass.direction  && compass.direction_angle != 'INVALID') { // initial data
                // Compass Pointer
                let compass_direction_angle = parseInt(compass.direction_angle);
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);
                // Compass Number
                let normal_compass_direction_angle_text = compass_direction_angle.toString();
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_text);

              } else { // error data
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, '-');

              }

              compass.addEventListener(hmSensor.event.CHANGE, function (compass_res) { // change values when changing direction

                if (compass_res.calibration_status) {
                  // Compass Pointer
                  let compass_direction_angle = parseInt(compass_res.direction_angle);
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);
                  // Compass Number
                  let normal_compass_direction_angle_text = compass_direction_angle.toString();
                  normal_compass_text_img.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_text);

                } else { // error data
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
                  normal_compass_text_img.setProperty(hmUI.prop.TEXT, '-');

                }

              }); // Listener end

            };
            //#endregion

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let normal_cityNameStr = weatherData.cityName;
              normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                if (compass && screenType == hmSetting.screen_type.WATCHFACE) compass.start();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                if (compass) compass.stop();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}