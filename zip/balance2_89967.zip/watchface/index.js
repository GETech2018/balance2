    /*
    ** Watch_Face_Editor tool v 18.1
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_widget_text_1 = ''
        let normal_image_img = ''
        let normal_dow_text_font = ''
        const mxDOW = {
  2:  ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY', 'SUNDAY'],
  3:  ['LUNES', 'MARTES', 'MIÉRCOLES', 'JUEVES', 'VIERNES', 'SÁBADO', 'DOMINGO'],
  6:  ['LUNDI', 'MARDI', 'MERCREDI', 'JEUDI', 'VENDREDI', 'SAMEDI', 'DIMANCHE'],
  7:  ['MONTAG', 'DIENSTAG', 'MITTWOCH', 'DONNERSTAG', 'FREITAG', 'SAMSTAG', 'SONNTAG'],
  9:  ['PONIEDZIAŁEK', 'WTOREK', 'ŚRODA', 'CZWARTEK', 'PIĄTEK', 'SOBOTA', 'NIEDZIELA'],
  10: ['LUNEDÌ', 'MARTEDÌ', 'MERCOLEDÌ', 'GIOVEDÌ', 'VENERDÌ', 'SABATO', 'DOMENICA'],
  15: ['SEGUNDA', 'TERÇA', 'QUARTA', 'QUINTA', 'SEXTA', 'SÁBADO', 'DOMINGO'],
  16: ['MAANDAG', 'DINSDAG', 'WOENSDAG', 'DONDERDAG', 'VRIJDAG', 'ZATERDAG', 'ZONDAG'],
  20: ['SEGUNDA', 'TERÇA', 'QUARTA', 'QUINTA', 'SEXTA', 'SÁBADO', 'DOMINGO'],
  22: ['PONDĚLÍ', 'ÚTERÝ', 'STŘEDA', 'ČTVRTEK', 'PÁTEK', 'SOBOTA', 'NEDĚLE'],
  32: ['PONDELOK', 'UTOROK', 'STREDA', 'ŠTVRTOK', 'PIATOK', 'SOBOTA', 'NEDEĽA']
};

const mxLanguage = hmSetting.getLanguage();
let normal_DOW_Array = mxDOW[mxLanguage] || mxDOW[2];
        let normal_day_month_year_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_battery_icon_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_current_text_font = ''
        let normal_step_icon_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_font = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_pro_second_cover_pointer_img = ''
        let normal_time_hour_text_font = ''
        let normal_time_minute_text_font = ''
        let idle_image_img = ''
        let idle_battery_icon_img = ''
        let idle_battery_current_text_font = ''
        let idle_time_hour_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let idle_time_minute_text_font = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: 3rd_Man.ttf; FontSize: 60; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 72,
              h: 72,
              text_size: 60,
              char_space: 0,
              line_space: 0,
              font: 'fonts/3rd_Man.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: 3rd_Man.ttf; FontSize: 40
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 360,
              h: 51,
              text_size: 40,
              char_space: 0,
              line_space: 0,
              font: 'fonts/3rd_Man.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: 3rd_Man.ttf; FontSize: 130
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 1176,
              h: 166,
              text_size: 130,
              char_space: 0,
              line_space: 0,
              font: 'fonts/3rd_Man.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');

            /* =====================================================
               MX BIG NUMBERS v13_final
               NATIVE EDITABLE COLOR THEMES
               ===================================================== */

            const mxThemeEditor = hmUI.createWidget(
              hmUI.widget.WATCHFACE_EDIT_GROUP,
              {
                edit_id: 101,

                x: 190,
                y: 190,
                w: 100,
                h: 100,

                select_image: 'edit_select.png',
                un_select_image: 'edit_unselect.png',

                default_type: 0,

                optional_types: [
                  { type: 0, preview: 'edit_white.png' },
                  { type: 1, preview: 'edit_red.png' },
                  { type: 2, preview: 'edit_blue.png' },
                  { type: 3, preview: 'edit_green.png' },
                  { type: 4, preview: 'edit_violet.png' },
                  { type: 5, preview: 'edit_orange.png' }
                ],

                count: 6,

                tips_BG: 0x000000,
                tips_x: 40,
                tips_y: 360,
                tips_width: 400,
                tips_margin: 10
              }
            );


            let mxThemeType = mxThemeEditor.getProperty(
              hmUI.prop.CURRENT_TYPE
            );


            if (
              mxThemeType !== 0 &&
              mxThemeType !== 1 &&
              mxThemeType !== 2 &&
              mxThemeType !== 3 &&
              mxThemeType !== 4 &&
              mxThemeType !== 5
            ) {
              mxThemeType = 0;
            }



            /* =====================================================
               MX BIG NUMBERS v13 FINAL EDIT UI
               ===================================================== */

            const mxEditInstructions = {

              2: {
                top: 'Tap to select\na color',
                bottom: 'Confirm by pressing\nthe upper watch button'
              },

              3: {
                top: 'Toque para elegir\nel color',
                bottom: 'Confirme con el botón\nsuperior del reloj'
              },

              6: {
                top: 'Touchez pour choisir\nla couleur',
                bottom: 'Confirmez avec le bouton\nsupérieur de la montre'
              },

              7: {
                top: 'Tippen, um die Farbe\nzu wählen',
                bottom: 'Mit der oberen Uhrentaste\nbestätigen'
              },

              9: {
                top: 'Dotknij, aby wybrać\nkolor',
                bottom: 'Potwierdź górnym\nprzyciskiem zegarka'
              },

              10: {
                top: 'Tocca per scegliere\nil colore',
                bottom: "Conferma con il pulsante\nsuperiore dell'orologio"
              },

              15: {
                top: 'Toque para escolher\na cor',
                bottom: 'Confirme com o botão\nsuperior do relógio'
              },

              16: {
                top: 'Tik om de kleur\nte kiezen',
                bottom: 'Bevestig met de bovenste\nknop van het horloge'
              },

              20: {
                top: 'Toque para escolher\na cor',
                bottom: 'Confirme com o botão\nsuperior do relógio'
              },

              22: {
                top: 'Vyberte barvu\nkliknutím',
                bottom: 'Potvrďte volbu stiskem\nhorního tlačítka hodinek'
              },

              32: {
                top: 'Vyberte farbu\nkliknutím',
                bottom: 'Potvrďte voľbu stlačením\nhorného tlačidla hodiniek'
              }
            };


            const mxEditInstructionLanguage =
              mxEditInstructions[mxLanguage] ||
              mxEditInstructions[2];


            /*
             * HORNI INSTRUKCE
             */

            hmUI.createWidget(
              hmUI.widget.TEXT,
              {
                x: 25,
                y: 92,
                w: 430,
                h: 80,

                text:
                  mxEditInstructionLanguage.top,

                text_size: 32,
                color: 0xFFFFFFFF,

                align_h:
                  hmUI.align.CENTER_H,

                align_v:
                  hmUI.align.CENTER_V,

                text_style:
                  hmUI.text_style.NONE,

                show_level:
                  hmUI.show_level.ONLY_EDIT
              }
            );


            /*
             * SPODNI INSTRUKCE
             */

            hmUI.createWidget(
              hmUI.widget.TEXT,
              {
                x: 25,
                y: 315,
                w: 430,
                h: 90,

                text:
                  mxEditInstructionLanguage.bottom,

                text_size: 26,
                color: 0xFFFFFFFF,

                align_h:
                  hmUI.align.CENTER_H,

                align_v:
                  hmUI.align.CENTER_V,

                text_style:
                  hmUI.text_style.NONE,

                show_level:
                  hmUI.show_level.ONLY_EDIT
              }
            );


            /*
             * VERZE
             *
             * Pouze v editoru motivu.
             * Verejny nazev je pouze MX Big Numbers.
             */

            hmUI.createWidget(
              hmUI.widget.TEXT,
              {
                x: 40,
                y: 437,
                w: 400,
                h: 24,

                text:
                  'MX Big Numbers • v13',

                text_size: 14,
                color: 0xFF888888,

                align_h:
                  hmUI.align.CENTER_H,

                align_v:
                  hmUI.align.CENTER_V,

                text_style:
                  hmUI.text_style.NONE,

                show_level:
                  hmUI.show_level.ONLY_EDIT
              }
            );


            /* END MX BIG NUMBERS v13 FINAL EDIT UI */


            const mxThemes = [

              {
                name: 'WHITE',
                color: 0xFFFFFFFF,
                background: '01_background_01_white.png',
                battery: '02_battery_icon_01_white.png',
                steps: '03_steps_icon_01_white.png',
                smallHand: '04_small_hand_01_white.png',
                second: '06_second_hand_inward_01_white.png',
                ticks: '05_outer_ticks_01_white.png'
              },

              {
                name: 'RED',
                color: 0xFFF4062C,
                background: '01_background_02_red.png',
                battery: '02_battery_icon_02_red.png',
                steps: '03_steps_icon_02_red.png',
                smallHand: '04_small_hand_02_red.png',
                second: '06_second_hand_inward_02_red.png',
                ticks: '05_outer_ticks_02_red.png'
              },

              {
                name: 'BLUE',
                color: 0xFF314DB2,
                background: '01_background_03_blue.png',
                battery: '02_battery_icon_03_blue.png',
                steps: '03_steps_icon_03_blue.png',
                smallHand: '04_small_hand_03_blue.png',
                second: '06_second_hand_inward_03_blue.png',
                ticks: '05_outer_ticks_03_blue.png'
              },

              {
                name: 'GREEN',
                color: 0xFF91C83C,
                background: '01_background_04_green.png',
                battery: '02_battery_icon_04_green.png',
                steps: '03_steps_icon_04_green.png',
                smallHand: '04_small_hand_04_green.png',
                second: '06_second_hand_inward_04_green.png',
                ticks: '05_outer_ticks_04_green.png'
              },

              {
                name: 'VIOLET',
                color: 0xFF8D25B8,
                background: '01_background_05_violet.png',
                battery: '02_battery_icon_05_violet.png',
                steps: '03_steps_icon_05_violet.png',
                smallHand: '04_small_hand_05_violet.png',
                second: '06_second_hand_inward_05_violet.png',
                ticks: '05_outer_ticks_05_violet.png'
              },

              {
                name: 'ORANGE',
                color: 0xFFFB6707,
                background: '01_background_06_orange.png',
                battery: '02_battery_icon_06_orange.png',
                steps: '03_steps_icon_06_orange.png',
                smallHand: '04_small_hand_06_orange.png',
                second: '06_second_hand_inward_06_orange.png',
                ticks: '05_outer_ticks_06_orange.png'
              }

            ];


            const mxTheme = mxThemes[mxThemeType];

            console.log(
              'MX v13_final THEME: ' +
              mxTheme.name +
              ' / ' +
              mxThemeType
            );

            /* END MX BIG NUMBERS v13_final THEME */

            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: mxTheme.background,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_1 =

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 210,
              y: 30,
              src: '00_ii_logo_01_orange.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 220,
              y: 190,
              w: 220,
              h: 60,
              text_size: 60,
              char_space: 0,
              font: 'fonts/3rd_Man.ttf',
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // unit_string: PONDĚLÍ, ÚTERÝ, STŘEDA, ČTVRTEK, PÁTEK, SOBOTA, NEDĚLE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            normal_day_month_year_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 260,
              y: 235,
              w: 180,
              h: 70,
              text_size: 60,
              char_space: 0,
              font: 'fonts/3rd_Man.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              // unit_type: 1,
              // unit_string: .,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 287,
              y: 95,
              src: '02_battery_icon_01_white.png',
              // alpha: 125,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img.setAlpha(125);

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '04_small_hand_01_white.png',
              center_x: 302,
              center_y: 130,
              x: 12,
              y: 45,
              start_angle: -123,
              end_angle: 123,
              invalid_visible: false,
              cover_path: '07_small_dial_01_white.png',
              cover_x: 250,
              cover_y: 80,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 278,
              y: 138,
              w: 50,
              h: 40,
              text_size: 40,
              char_space: 0,
              font: 'fonts/3rd_Man.ttf',
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 287,
              y: 330,
              src: '03_steps_icon_01_white.png',
              // alpha: 125,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img.setAlpha(125);

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '04_small_hand_01_white.png',
              center_x: 302,
              center_y: 364,
              x: 12,
              y: 45,
              start_angle: -123,
              end_angle: 123,
              invalid_visible: false,
              cover_path: '07_small_dial_01_white.png',
              cover_x: 250,
              cover_y: 315,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 255,
              y: 370,
              w: 100,
              h: 40,
              text_size: 40,
              char_space: 0,
              font: 'fonts/3rd_Man.ttf',
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '06_second_hand_inward_01_white.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // cover_path: '05_outer_ticks_01_white.png',
              // cover_x: 0,
              // cover_y: 0,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: mxTheme.second,
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_pro_second_cover_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '05_outer_ticks_01_white.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 35,
              y: 120,
              w: 150,
              h: 130,
              text_size: 130,
              char_space: 0,
              font: 'fonts/3rd_Man.ttf',
              color: mxTheme.color,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 35,
              y: 230,
              w: 150,
              h: 130,
              text_size: 130,
              char_space: 0,
              font: 'fonts/3rd_Man.ttf',
              color: 0xFF808080,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 210,
              y: 30,
              src: '00_ii_logo_02_white.png',
              // alpha: 125,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img.setAlpha(125);

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 225,
              y: 390,
              src: '02_battery_icon_01_white.png',
              // alpha: 125,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img.setAlpha(125);

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 215,
              y: 420,
              w: 50,
              h: 40,
              text_size: 40,
              char_space: 0,
              font: 'fonts/3rd_Man.ttf',
              color: 0xFF808080,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 165,
              y: 120,
              w: 150,
              h: 130,
              text_size: 130,
              char_space: 0,
              font: 'fonts/3rd_Man.ttf',
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 165,
              y: 230,
              w: 150,
              h: 130,
              text_size: 130,
              char_space: 0,
              font: 'fonts/3rd_Man.ttf',
              color: 0xFF808080,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('day/month/year font');
              if (updateHour) {
                let normal_DayStr = timeSensor.day.toString();
                let normal_MonthStr = timeSensor.month.toString();
                let normal_YearStr = timeSensor.year.toString();
                normal_DayStr = normal_DayStr.padStart(2, '0');
                normal_MonthStr = normal_MonthStr.padStart(2, '0');
                let normal_DayMonthYearStr = '--';
                const dateFormat = hmSetting.getDateFormat();
                if (dateFormat == 0) {
                  normal_DayMonthYearStr = normal_YearStr + '.' + normal_MonthStr + '.' + normal_DayStr;
                }
                if (dateFormat == 1) {
                  normal_DayMonthYearStr = normal_DayStr + '.' + normal_MonthStr + '.' + normal_YearStr;
                }
                if (dateFormat == 2) {
                  normal_DayMonthYearStr = normal_MonthStr + '.' + normal_DayStr + '.' + normal_YearStr;
                }
                normal_day_month_year_font.setProperty(hmUI.prop.TEXT, normal_DayMonthYearStr );
              };

              // Second Pointer
              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*second/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

              console.log('hour font');
              if (updateHour) {
                let normal_hourStr = format_hour.toString();
                normal_hourStr = normal_hourStr.padStart(2, '0');
                normal_time_hour_text_font.setProperty(hmUI.prop.TEXT, normal_hourStr );
              };

              console.log('minute font');
              if (updateMinute) {
                let normal_minuteStr = minute.toString();
                normal_minuteStr = normal_minuteStr.padStart(2, '0');
                normal_time_minute_text_font.setProperty(hmUI.prop.TEXT, normal_minuteStr );
              };

              console.log('hour font');
              if (updateHour) {
                let idle_hourStr = format_hour.toString();
                idle_hourStr = idle_hourStr.padStart(2, '0');
                idle_time_hour_text_font.setProperty(hmUI.prop.TEXT, idle_hourStr );
              };

              console.log('minute font');
              if (updateMinute) {
                let idle_minuteStr = minute.toString();
                idle_minuteStr = idle_minuteStr.padStart(2, '0');
                idle_time_minute_text_font.setProperty(hmUI.prop.TEXT, idle_minuteStr );
              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}