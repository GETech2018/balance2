/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v3.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_img1 = '';
		let normal_img3 = '';
		let normal_img5 = '';
		let normal_img7 = '';
		let normal_img9 = '';
		let normal_img11 = '';
		let normal_img13 = '';
		let normal_img15 = '';
		let normal_img17 = '';
		let normal_img19 = '';
		let normal_img21 = '';
		let normal_img23 = '';
		let normal_img25 = '';
		let normal_img27 = '';
		let normal_img29 = '';
		let normal_img31 = '';
		let normal_img33 = '';
		let normal_img35 = '';
		let normal_img37 = '';
		let normal_img39 = '';
		let normal_img41 = '';
		let normal_img43 = '';
		let normal_img45 = '';
		let normal_img47 = '';
		let normal_img49 = '';
		let normal_img51 = '';
		let normal_heart_rate_imageset54 = '';
		let normal_stress_imageset56 = '';
		let normal_battery_imageset58 = '';
		let normal_humidity_imageset60 = '';
		let normal_biocharge_imageset62 = '';
		let normal_biocharge_imageset63 = '';
		let normal_img65 = '';
		let normal_img66 = '';
		let normal_img67 = '';
		let normal_img69 = '';
		let normal_img71 = '';
		let normal_img73 = '';
		let normal_img75 = '';
		let normal_img77 = '';
		let normal_img79 = '';
		let normal_img81 = '';
		let normal_img83 = '';
		let normal_img85 = '';
		let normal_img87 = '';
		let normal_img89 = '';
		let normal_img91 = '';
		let normal_img93 = '';
		let normal_img95 = '';
		let normal_img97 = '';
		let normal_img99 = '';
		let normal_img101 = '';
		let normal_img103 = '';
		let normal_img105 = '';
		let normal_img107 = '';
		let normal_img109 = '';
		let normal_img111 = '';
		let normal_img113 = '';
		let normal_img115 = '';
		let normal_img117 = '';
		let normal_img119 = '';
		let normal_img122 = '';
		let normal_img124 = '';
		let normal_img126 = '';
		let normal_img128 = '';
		let normal_img130 = '';
		let normal_img132 = '';
		let normal_img134 = '';
		let normal_img136 = '';
		let normal_img138 = '';
		let normal_img140 = '';
		let normal_img142 = '';
		let normal_img144 = '';
		let normal_img146 = '';
		let normal_img148 = '';
		let normal_img150 = '';
		let normal_img152 = '';
		let normal_img154 = '';
		let normal_img156 = '';
		let normal_img158 = '';
		let normal_img160 = '';
		let normal_img162 = '';
		let normal_img164 = '';
		let normal_img166 = '';
		let normal_img168 = '';
		let normal_img170 = '';
		let normal_img172 = '';
		let normal_img174 = '';
		let normal_heart_rate_first_imageset177 = '';
		let normal_heart_rate_first_imageset177_array = ['0177.png','0178.png','0179.png','0180.png','0181.png','0182.png','0183.png','0184.png','0185.png','0186.png'];
		let normal_heart_rate_second_imageset178 = '';
		let normal_heart_rate_second_imageset178_array = ['0187.png','0188.png','0189.png','0190.png','0191.png','0192.png','0193.png','0194.png','0195.png','0196.png'];
		let normal_heart_rate_third_imageset179 = '';
		let normal_heart_rate_third_imageset179_array = ['0197.png','0198.png','0199.png'];
		let normal_img180 = '';
		let normal_img182 = '';
		let normal_stress_second_imageset183 = '';
		let normal_stress_second_imageset183_array = ['0202.png','0203.png','0204.png','0205.png','0206.png','0207.png','0208.png','0209.png','0210.png','0211.png'];
		let normal_stress_first_imageset184 = '';
		let normal_stress_first_imageset184_array = ['0212.png','0213.png','0214.png','0215.png','0216.png','0217.png','0218.png','0219.png','0220.png','0221.png'];
		let normal_stress_third_imageset185 = '';
		let normal_stress_third_imageset185_array = ['0222.png','0223.png'];
		let normal_battery_first_imageset187 = '';
		let normal_battery_first_imageset187_array = ['0224.png','0225.png','0226.png','0227.png','0228.png','0229.png','0230.png','0231.png','0232.png','0233.png'];
		let normal_battery_third_imageset188 = '';
		let normal_battery_third_imageset188_array = ['0234.png','0235.png','0236.png','0237.png','0238.png','0239.png','0240.png','0241.png','0242.png','0243.png'];
		let normal_battery_second_imageset189 = '';
		let normal_battery_second_imageset189_array = ['0244.png','0245.png','0246.png','0247.png','0248.png','0249.png','0250.png','0251.png','0252.png','0253.png'];
		let normal_img190 = '';
		let normal_img191 = '';
		let normal_humidity_imageset193 = '';
		let normal_humidity_imageset194 = '';
		let normal_img195 = '';
		let normal_humidity_imageset196 = '';
		let normal_img197 = '';
		let normal_img198 = '';
		let normal_img200 = '';
		let normal_img201 = '';
		let normal_img202 = '';
		let normal_img203 = '';
		let normal_img204 = '';
		let normal_img205 = '';
		let normal_img206 = '';
		let normal_img207 = '';
		let normal_hour_imagecombo209 = '';
		let normal_img210 = '';
		let normal_img211 = '';
		let normal_img212 = '';
		let normal_img213 = '';
		let normal_img214 = '';
		let normal_img215 = '';
		let normal_minute_imagecombo216 = '';
		let normal_img217 = '';
		let normal_img219 = '';
		let normal_hour_imagecombo220 = '';
		let normal_img221 = '';
		let normal_img222 = '';
		let normal_img223 = '';
		let normal_img224 = '';
		let normal_img225 = '';
		let normal_img226 = '';
		let normal_img227 = '';
		let normal_img228 = '';
		let normal_img229 = '';
		let normal_img230 = '';
		let normal_img231 = '';
		let normal_img232 = '';
		let normal_minute_imagecombo233 = '';
		let normal_month_imageset236 = '';
		let normal_week_imageset237 = '';
		let timeInterval;
		let normal_date_high_imageset238 = '';
		let normal_date_high_imageset238_array = ['0342.png','0343.png','0344.png','0345.png'];
		let normal_date_low_imageset239 = '';
		let normal_date_low_imageset239_array = ['0346.png','0347.png','0348.png','0349.png','0350.png','0351.png','0352.png','0353.png','0354.png','0355.png'];
		let normal_week_imageset240 = '';
		let normal_week_imageset241 = '';
		let normal_week_imageset242 = '';
		let normal_week_imageset243 = '';
		let normal_week_imageset244 = '';
		let normal_temperature_current_imagecombo246 = '';
		let normal_weather_imageset247 = '';
		let normal_calories_imagecombo249 = '';
		let normal_img250 = '';
		let normal_img251 = '';
		let normal_img253 = '';
		let normal_distance_imagecombo254 = '';
		let normal_img255 = '';
		let normal_img257 = '';
		let normal_blood_oxygen_imagecombo258 = '';
		let normal_img259 = '';
		let normal_img261 = '';
		let normal_vo2max_imagecombo262 = '';
		let normal_img263 = '';
		let normal_img265 = '';
		let normal_img266 = '';
		let normal_pai_weekly_imagecombo267 = '';
		let normal_img269 = '';
		let normal_sleep_hour_high_imageset270 = '';
		let normal_sleep_hour_high_imageset270_array = ['0443.png','0444.png','0445.png'];
		let normal_sleep_hour_low_imageset271 = '';
		let normal_sleep_hour_low_imageset271_array = ['0443.png','0444.png','0445.png','0446.png','0447.png','0448.png','0449.png','0450.png','0451.png','0452.png'];
		let normal_sleep_minute_high_imageset272 = '';
		let normal_sleep_minute_high_imageset272_array = ['0443.png','0444.png','0445.png','0446.png','0447.png','0448.png'];
		let normal_sleep_minute_low_imageset273 = '';
		let normal_sleep_minute_low_imageset273_array = ['0443.png','0444.png','0445.png','0446.png','0447.png','0448.png','0449.png','0450.png','0451.png','0452.png'];
		let normal_img274 = '';
		let normal_img275 = '';
		let normal_img277 = '';
		let normal_airpressure_imagecombo278 = '';
		let normal_img279 = '';
		let normal_altitude_imagecombo281 = '';
		let normal_img282 = '';
		let normal_img283 = '';
		let normal_img285 = '';
		let normal_img286 = '';
		let normal_wind_imagecombo287 = '';
		let normal_wind_bearing_imageset288 = '';
		let normal_img290 = '';
		let normal_uvindex_imageset291 = '';
		let normal_img292 = '';
		let normal_img294 = '';
		let normal_steps_imagecombo295 = '';
		let normal_img296 = '';
		let normal_steps_imagecombo299 = '';
		let normal_img300 = '';
		let normal_img301 = '';
		let normal_img303 = '';
		let normal_calories_imagecombo304 = '';
		let normal_img305 = '';
		let normal_img307 = '';
		let normal_distance_imagecombo308 = '';
		let normal_img309 = '';
		let normal_img311 = '';
		let normal_blood_oxygen_imagecombo312 = '';
		let normal_img313 = '';
		let normal_img315 = '';
		let normal_vo2max_imagecombo316 = '';
		let normal_img317 = '';
		let normal_img319 = '';
		let normal_pai_weekly_imagecombo320 = '';
		let normal_img321 = '';
		let normal_img323 = '';
		let normal_sleep_hour_high_imageset324 = '';
		let normal_sleep_hour_high_imageset324_array = ['0443.png','0444.png','0445.png'];
		let normal_sleep_hour_low_imageset325 = '';
		let normal_sleep_hour_low_imageset325_array = ['0443.png','0444.png','0445.png','0446.png','0447.png','0448.png','0449.png','0450.png','0451.png','0452.png'];
		let normal_sleep_minute_high_imageset326 = '';
		let normal_sleep_minute_high_imageset326_array = ['0443.png','0444.png','0445.png','0446.png','0447.png','0448.png'];
		let normal_sleep_minute_low_imageset327 = '';
		let normal_sleep_minute_low_imageset327_array = ['0443.png','0444.png','0445.png','0446.png','0447.png','0448.png','0449.png','0450.png','0451.png','0452.png'];
		let normal_img328 = '';
		let normal_img329 = '';
		let normal_img331 = '';
		let normal_airpressure_imagecombo332 = '';
		let normal_img333 = '';
		let normal_altitude_imagecombo335 = '';
		let normal_img336 = '';
		let normal_img337 = '';
		let normal_img339 = '';
		let normal_wind_imagecombo340 = '';
		let normal_wind_bearing_imageset341 = '';
		let normal_img342 = '';
		let normal_img344 = '';
		let normal_uvindex_imageset345 = '';
		let normal_img346 = '';
		let normal_img349 = '';
		let normal_distance_imagecombo350 = '';
		let normal_img351 = '';
		let normal_img353 = '';
		let normal_blood_oxygen_imagecombo354 = '';
		let normal_img355 = '';
		let normal_img357 = '';
		let normal_vo2max_imagecombo358 = '';
		let normal_img359 = '';
		let normal_img361 = '';
		let normal_pai_weekly_imagecombo362 = '';
		let normal_img363 = '';
		let normal_img365 = '';
		let normal_sleep_hour_low_imageset366 = '';
		let normal_sleep_hour_low_imageset366_array = ['0443.png','0444.png','0445.png','0446.png','0447.png','0448.png','0449.png','0450.png','0451.png','0452.png'];
		let normal_sleep_minute_high_imageset367 = '';
		let normal_sleep_minute_high_imageset367_array = ['0443.png','0444.png','0445.png','0446.png','0447.png','0448.png'];
		let normal_sleep_minute_low_imageset368 = '';
		let normal_sleep_minute_low_imageset368_array = ['0443.png','0444.png','0445.png','0446.png','0447.png','0448.png','0449.png','0450.png','0451.png','0452.png'];
		let normal_sleep_hour_high_imageset369 = '';
		let normal_sleep_hour_high_imageset369_array = ['0443.png','0444.png','0445.png'];
		let normal_img370 = '';
		let normal_img371 = '';
		let normal_img373 = '';
		let normal_airpressure_imagecombo374 = '';
		let normal_img375 = '';
		let normal_img377 = '';
		let normal_altitude_imagecombo378 = '';
		let normal_img379 = '';
		let normal_img381 = '';
		let normal_wind_imagecombo382 = '';
		let normal_wind_bearing_imageset383 = '';
		let normal_img384 = '';
		let normal_img386 = '';
		let normal_uvindex_imageset387 = '';
		let normal_img388 = '';
		let normal_img390 = '';
		let normal_steps_imagecombo391 = '';
		let normal_img392 = '';
		let normal_img394 = '';
		let normal_calories_imagecombo395 = '';
		let normal_img396 = '';
		let normal_img399 = '';
		let normal_weather_imageset400 = '';
		let normal_temperature_current_imagecombo401 = '';
		let normal_img403 = '';
		let normal_weather_imageset404 = '';
		let normal_temperature_current_imagecombo405 = '';
		let normal_temperature_high_imagecombo406 = '';
		let normal_temperature_low_imagecombo407 = '';
		let normal_img408 = '';
		let normal_img409 = '';
		let normal_weatherplusone_imageset411 = '';
		let normal_weatherplusone_imageset411_array = ['0575.png','0576.png','0577.png','0578.png','0579.png','0580.png','0581.png','0582.png','0583.png','0584.png','0585.png','0586.png','0587.png','0588.png','0589.png','0590.png','0591.png','0592.png','0593.png','0594.png','0595.png','0596.png','0597.png','0598.png','0599.png','0600.png','0601.png','0602.png','0603.png'];
		let normal_weatherplustwo_imageset412 = '';
		let normal_weatherplustwo_imageset412_array = ['0604.png','0605.png','0606.png','0607.png','0608.png','0609.png','0610.png','0611.png','0612.png','0613.png','0614.png','0615.png','0616.png','0617.png','0618.png','0619.png','0620.png','0621.png','0622.png','0623.png','0624.png','0625.png','0626.png','0627.png','0628.png','0629.png','0630.png','0631.png','0632.png'];
		let normal_weatherplusthree_imageset413 = '';
		let normal_weatherplusthree_imageset413_array = ['0633.png','0634.png','0635.png','0636.png','0637.png','0638.png','0639.png','0640.png','0641.png','0642.png','0643.png','0644.png','0645.png','0646.png','0647.png','0648.png','0649.png','0650.png','0651.png','0652.png','0653.png','0654.png','0655.png','0656.png','0657.png','0658.png','0659.png','0660.png','0661.png'];
		let normal_weatherplusfour_imageset414 = '';
		let normal_weatherplusfour_imageset414_array = ['0662.png','0663.png','0664.png','0665.png','0666.png','0667.png','0668.png','0669.png','0670.png','0671.png','0672.png','0673.png','0674.png','0675.png','0676.png','0677.png','0678.png','0679.png','0680.png','0681.png','0682.png','0683.png','0684.png','0685.png','0686.png','0687.png','0688.png','0689.png','0690.png'];
		let normal_img415 = '';
		let normal_img416 = '';
		let normal_img417 = '';
		let normal_img418 = '';
		let normal_img420 = '';
		let normal_sunrise_hours_high_imageset421 = '';
		let normal_sunrise_hours_high_imageset421_array = ['0693.png','0694.png','0695.png'];
		let normal_sunrise_hours_low_imageset422 = '';
		let normal_sunrise_hours_low_imageset422_array = ['0693.png','0694.png','0695.png','0696.png','0697.png','0698.png','0699.png','0700.png','0701.png','0702.png'];
		let normal_sunrise_minutes_high_imageset423 = '';
		let normal_sunrise_minutes_high_imageset423_array = ['0693.png','0694.png','0695.png','0696.png','0697.png','0698.png'];
		let normal_sunrise_minutes_low_imageset424 = '';
		let normal_sunrise_minutes_low_imageset424_array = ['0693.png','0694.png','0695.png','0696.png','0697.png','0698.png','0699.png','0700.png','0701.png','0702.png'];
		let normal_img425 = '';
		let normal_img426 = '';
		let normal_sunset_hours_high_imageset427 = '';
		let normal_sunset_hours_high_imageset427_array = ['0693.png','0694.png','0695.png'];
		let normal_sunset_hours_low_imageset428 = '';
		let normal_sunset_hours_low_imageset428_array = ['0693.png','0694.png','0695.png','0696.png','0697.png','0698.png','0699.png','0700.png','0701.png','0702.png'];
		let normal_sunset_minutes_high_imageset429 = '';
		let normal_sunset_minutes_high_imageset429_array = ['0693.png','0694.png','0695.png','0696.png','0697.png','0698.png'];
		let normal_sunset_minutes_low_imageset430 = '';
		let normal_sunset_minutes_low_imageset430_array = ['0693.png','0694.png','0695.png','0696.png','0697.png','0698.png','0699.png','0700.png','0701.png','0702.png'];
		let normal_img431 = '';
		let normal_img432 = '';
		let normal_img435 = '';
		let normal_bt_status436 = '';
		let normal_img437 = '';
		let normal_alarm_status438 = '';
		let normal_img440 = '';
		let normal_biocharge_imagecombo441 = '';
		let normal_img443 = '';
		let normal_biocharge_imagecombo444 = '';
		let normal_img445 = '';
		let normal_img447 = '';
		let normal_second_imagecombo448 = '';
		let normal_img450 = '';
		let normal_ampm24_imageset453 = '';
		let normal_ampm24_imageset453_array = ['0745.png','0746.png','0747.png'];
		let normal_heart_shortcut456 = '';
		let normal_weather_shortcut457 = '';
		let normal_stress_shortcut458 = '';
		let normal_battery_shortcut459 = '';
		let idle_img461 = '';
		let idle_stress_imageset462 = '';
		let idle_heart_rate_imageset464 = '';
		let idle_humidity_imageset466 = '';
		let idle_battery_imageset468 = '';
		let idle_img470 = '';
		let idle_img471 = '';
		let idle_img472 = '';
		let idle_img473 = '';
		let idle_img474 = '';
		let idle_img475 = '';
		let idle_img476 = '';
		let idle_minute_imagecombo477 = '';
		let idle_hour_imagecombo478 = '';
		let idle_ampm24_imageset479 = '';
		let idle_ampm24_imageset479_array = ['0745.png','0746.png','0747.png'];
		let idle_steps_imagecombo481 = '';
		let idle_calories_imagecombo483 = '';
		let idle_distance_imagecombo485 = '';
		let idle_weather_imageset487 = '';
		let idle_temperature_current_imagecombo488 = '';
		let idle_stress_second_imageset490 = '';
		let idle_stress_second_imageset490_array = ['0202.png','0203.png','0204.png','0205.png','0206.png','0207.png','0208.png','0209.png','0210.png','0211.png'];
		let idle_stress_first_imageset491 = '';
		let idle_stress_first_imageset491_array = ['0212.png','0213.png','0214.png','0215.png','0216.png','0217.png','0218.png','0219.png','0220.png','0221.png'];
		let idle_stress_third_imageset492 = '';
		let idle_stress_third_imageset492_array = ['0222.png','0223.png'];
		let idle_heart_rate_first_imageset494 = '';
		let idle_heart_rate_first_imageset494_array = ['0177.png','0178.png','0179.png','0180.png','0181.png','0182.png','0183.png','0184.png','0185.png','0186.png'];
		let idle_heart_rate_second_imageset495 = '';
		let idle_heart_rate_second_imageset495_array = ['0187.png','0188.png','0189.png','0190.png','0191.png','0192.png','0193.png','0194.png','0195.png','0196.png'];
		let idle_heart_rate_third_imageset496 = '';
		let idle_heart_rate_third_imageset496_array = ['0197.png','0198.png','0199.png'];
		let idle_humidity_imageset498 = '';
		let idle_humidity_imageset499 = '';
		let idle_img500 = '';
		let idle_humidity_imageset501 = '';
		let idle_img502 = '';
		let idle_battery_first_imageset504 = '';
		let idle_battery_first_imageset504_array = ['0224.png','0225.png','0226.png','0227.png','0228.png','0229.png','0230.png','0231.png','0232.png','0233.png'];
		let idle_battery_third_imageset505 = '';
		let idle_battery_third_imageset505_array = ['0234.png','0235.png','0236.png','0237.png','0238.png','0239.png','0240.png','0241.png','0242.png','0243.png'];
		let idle_battery_second_imageset506 = '';
		let idle_battery_second_imageset506_array = ['0244.png','0245.png','0246.png','0247.png','0248.png','0249.png','0250.png','0251.png','0252.png','0253.png'];
		let idle_img507 = '';
		let idle_month_imageset509 = '';
		let idle_week_imageset510 = '';
		let idle_date_high_imageset511 = '';
		let idle_date_high_imageset511_array = ['0772.png','0773.png','0774.png','0775.png'];
		let idle_date_low_imageset512 = '';
		let idle_date_low_imageset512_array = ['0776.png','0777.png','0778.png','0779.png','0780.png','0781.png','0782.png','0783.png','0784.png','0785.png'];
		let idle_img514 = '';
		let idle_biocharge_imagecombo515 = '';
		let idle_img517 = '';
		let idle_img518 = '';
		let idle_bt_status519 = '';
		let idle_alarm_status520 = '';
		let idle_img522 = '';
		let idle_img523 = '';
		let idle_img524 = '';
		let idle_img525 = '';
		let idle_img526 = '';
		let idle_img527 = '';
		let container_1752984972990 = '';
		let container_1752984972990_customs = [
			{
				label: 'White',
				widgets: [
					'normal_img1',
				]
			},
			{
				label: 'Red',
				widgets: [
					'normal_img3',
				]
			},
			{
				label: 'Light Red',
				widgets: [
					'normal_img5',
				]
			},
			{
				label: 'Orange',
				widgets: [
					'normal_img7',
				]
			},
			{
				label: 'Orange #2',
				widgets: [
					'normal_img9',
				]
			},
			{
				label: 'Yellow',
				widgets: [
					'normal_img11',
				]
			},
			{
				label: 'Yellow #2',
				widgets: [
					'normal_img13',
				]
			},
			{
				label: 'Electric Yellow',
				widgets: [
					'normal_img15',
				]
			},
			{
				label: 'Light Yellow',
				widgets: [
					'normal_img17',
				]
			},
			{
				label: 'Electric Green',
				widgets: [
					'normal_img19',
				]
			},
			{
				label: 'Green',
				widgets: [
					'normal_img21',
				]
			},
			{
				label: 'Light Green',
				widgets: [
					'normal_img23',
				]
			},
			{
				label: 'Light Teal',
				widgets: [
					'normal_img25',
				]
			},
			{
				label: 'Teal',
				widgets: [
					'normal_img27',
				]
			},
			{
				label: 'Neon Blue',
				widgets: [
					'normal_img29',
				]
			},
			{
				label: 'Sky Blue',
				widgets: [
					'normal_img31',
				]
			},
			{
				label: 'Blue',
				widgets: [
					'normal_img33',
				]
			},
			{
				label: 'Blue #2',
				widgets: [
					'normal_img35',
				]
			},
			{
				label: 'Light Blue',
				widgets: [
					'normal_img37',
				]
			},
			{
				label: 'Beige',
				widgets: [
					'normal_img39',
				]
			},
			{
				label: 'Pink',
				widgets: [
					'normal_img41',
				]
			},
			{
				label: 'Magenta',
				widgets: [
					'normal_img43',
				]
			},
			{
				label: 'Heliotrope',
				widgets: [
					'normal_img45',
				]
			},
			{
				label: 'Purple',
				widgets: [
					'normal_img47',
				]
			},
			{
				label: 'Light Purple',
				widgets: [
					'normal_img49',
				]
			},
			{
				label: 'Grey',
				widgets: [
					'normal_img51',
				]
			},
		];
		let container_1752984972990_selected = 1;
		let container_1753929349836 = '';
		let container_1753929349836_customs = [
			{
				label: 'Transparent',
				widgets: [
					'normal_img67',
				]
			},
			{
				label: 'White',
				widgets: [
					'normal_img69',
				]
			},
			{
				label: 'Red',
				widgets: [
					'normal_img71',
				]
			},
			{
				label: 'Light Red',
				widgets: [
					'normal_img73',
				]
			},
			{
				label: 'Orange ',
				widgets: [
					'normal_img75',
				]
			},
			{
				label: 'Orange #2',
				widgets: [
					'normal_img77',
				]
			},
			{
				label: 'Yellow',
				widgets: [
					'normal_img79',
				]
			},
			{
				label: 'Yellow #2',
				widgets: [
					'normal_img81',
				]
			},
			{
				label: 'Electric Yellow',
				widgets: [
					'normal_img83',
				]
			},
			{
				label: 'Light Yellow',
				widgets: [
					'normal_img85',
				]
			},
			{
				label: 'Electric Green',
				widgets: [
					'normal_img87',
				]
			},
			{
				label: 'Green',
				widgets: [
					'normal_img89',
				]
			},
			{
				label: 'Light Green',
				widgets: [
					'normal_img91',
				]
			},
			{
				label: 'Light Teal',
				widgets: [
					'normal_img93',
				]
			},
			{
				label: 'Teal',
				widgets: [
					'normal_img95',
				]
			},
			{
				label: 'Neon Blue',
				widgets: [
					'normal_img97',
				]
			},
			{
				label: 'Sky Blue',
				widgets: [
					'normal_img99',
				]
			},
			{
				label: 'Blue',
				widgets: [
					'normal_img101',
				]
			},
			{
				label: 'Blue #2',
				widgets: [
					'normal_img103',
				]
			},
			{
				label: 'Light Blue',
				widgets: [
					'normal_img105',
				]
			},
			{
				label: 'Beige',
				widgets: [
					'normal_img107',
				]
			},
			{
				label: 'Pink',
				widgets: [
					'normal_img109',
				]
			},
			{
				label: 'Magenta',
				widgets: [
					'normal_img111',
				]
			},
			{
				label: 'Heliotrope',
				widgets: [
					'normal_img113',
				]
			},
			{
				label: 'Purple',
				widgets: [
					'normal_img115',
				]
			},
			{
				label: 'Light Purple',
				widgets: [
					'normal_img117',
				]
			},
			{
				label: 'Grey',
				widgets: [
					'normal_img119',
				]
			},
		];
		let container_1753929349836_selected = 0;
		let container_1752930086541 = '';
		let container_1752930086541_customs = [
			{
				label: 'Transparent',
				widgets: [
					'normal_img122',
				]
			},
			{
				label: 'White',
				widgets: [
					'normal_img124',
				]
			},
			{
				label: 'Red',
				widgets: [
					'normal_img126',
				]
			},
			{
				label: 'Light Red',
				widgets: [
					'normal_img128',
				]
			},
			{
				label: 'Orange',
				widgets: [
					'normal_img130',
				]
			},
			{
				label: 'Orange #2',
				widgets: [
					'normal_img132',
				]
			},
			{
				label: 'Yellow',
				widgets: [
					'normal_img134',
				]
			},
			{
				label: 'Yellow #2',
				widgets: [
					'normal_img136',
				]
			},
			{
				label: 'Electric Yellow',
				widgets: [
					'normal_img138',
				]
			},
			{
				label: 'Light Yellow',
				widgets: [
					'normal_img140',
				]
			},
			{
				label: 'Electric Green',
				widgets: [
					'normal_img142',
				]
			},
			{
				label: 'Green',
				widgets: [
					'normal_img144',
				]
			},
			{
				label: 'Light Green',
				widgets: [
					'normal_img146',
				]
			},
			{
				label: 'Light Teal',
				widgets: [
					'normal_img148',
				]
			},
			{
				label: 'Teal',
				widgets: [
					'normal_img150',
				]
			},
			{
				label: 'Neon Blue',
				widgets: [
					'normal_img152',
				]
			},
			{
				label: 'Sky Blue',
				widgets: [
					'normal_img154',
				]
			},
			{
				label: 'Blue',
				widgets: [
					'normal_img156',
				]
			},
			{
				label: 'Blue #2',
				widgets: [
					'normal_img158',
				]
			},
			{
				label: 'Light Blue',
				widgets: [
					'normal_img160',
				]
			},
			{
				label: 'Beige',
				widgets: [
					'normal_img162',
				]
			},
			{
				label: 'Pink',
				widgets: [
					'normal_img164',
				]
			},
			{
				label: 'Magenta',
				widgets: [
					'normal_img166',
				]
			},
			{
				label: 'Heliotrope',
				widgets: [
					'normal_img168',
				]
			},
			{
				label: 'Purple',
				widgets: [
					'normal_img170',
				]
			},
			{
				label: 'Light Purple',
				widgets: [
					'normal_img172',
				]
			},
			{
				label: 'Grey',
				widgets: [
					'normal_img174',
				]
			},
		];
		let container_1752930086541_selected = 1;
		let container_1762045954004 = '';
		let container_1762045954004_customs = [
			{
				label: 'Digital Dial',
				widgets: [
					'normal_hour_imagecombo209',
					'normal_img210',
					'normal_img211',
					'normal_img212',
					'normal_img213',
					'normal_img214',
					'normal_img215',
					'normal_minute_imagecombo216',
					'normal_img217',
				]
			},
			{
				label: 'Digital Dial',
				widgets: [
					'normal_img219',
					'normal_hour_imagecombo220',
					'normal_img221',
					'normal_img222',
					'normal_img223',
					'normal_img224',
					'normal_img225',
					'normal_img226',
					'normal_img227',
					'normal_img228',
					'normal_img229',
					'normal_img230',
					'normal_img231',
					'normal_img232',
					'normal_minute_imagecombo233',
				]
			},
		];
		let container_1762045954004_selected = 0;
		let container_1762060414232 = '';
		let container_1762060414232_customs = [
			{
				label: 'Calories',
				widgets: [
					'normal_calories_imagecombo249',
					'normal_img250',
					'normal_img251',
				]
			},
			{
				label: 'Distance',
				widgets: [
					'normal_img253',
					'normal_distance_imagecombo254',
					'normal_img255',
				]
			},
			{
				label: 'SPO2',
				widgets: [
					'normal_img257',
					'normal_blood_oxygen_imagecombo258',
					'normal_img259',
				]
			},
			{
				label: 'VO2Max',
				widgets: [
					'normal_img261',
					'normal_vo2max_imagecombo262',
					'normal_img263',
				]
			},
			{
				label: 'PAI',
				widgets: [
					'normal_img265',
					'normal_img266',
					'normal_pai_weekly_imagecombo267',
				]
			},
			{
				label: 'Sleep',
				widgets: [
					'normal_img269',
					'normal_sleep_hour_high_imageset270',
					'normal_sleep_hour_low_imageset271',
					'normal_sleep_minute_high_imageset272',
					'normal_sleep_minute_low_imageset273',
					'normal_img274',
					'normal_img275',
				]
			},
			{
				label: 'Atmospheric pressure',
				widgets: [
					'normal_img277',
					'normal_airpressure_imagecombo278',
					'normal_img279',
				]
			},
			{
				label: 'Altitude',
				widgets: [
					'normal_altitude_imagecombo281',
					'normal_img282',
					'normal_img283',
				]
			},
			{
				label: 'Wind',
				widgets: [
					'normal_img285',
					'normal_img286',
					'normal_wind_imagecombo287',
					'normal_wind_bearing_imageset288',
				]
			},
			{
				label: 'UV Index',
				widgets: [
					'normal_img290',
					'normal_uvindex_imageset291',
					'normal_img292',
				]
			},
			{
				label: 'Steps',
				widgets: [
					'normal_img294',
					'normal_steps_imagecombo295',
					'normal_img296',
				]
			},
		];
		let container_1762060414232_selected = 0;
		let container_1762060412254 = '';
		let container_1762060412254_customs = [
			{
				label: 'Steps',
				widgets: [
					'normal_steps_imagecombo299',
					'normal_img300',
					'normal_img301',
				]
			},
			{
				label: 'Calories',
				widgets: [
					'normal_img303',
					'normal_calories_imagecombo304',
					'normal_img305',
				]
			},
			{
				label: 'Distance',
				widgets: [
					'normal_img307',
					'normal_distance_imagecombo308',
					'normal_img309',
				]
			},
			{
				label: 'SPO2',
				widgets: [
					'normal_img311',
					'normal_blood_oxygen_imagecombo312',
					'normal_img313',
				]
			},
			{
				label: 'VO2Max',
				widgets: [
					'normal_img315',
					'normal_vo2max_imagecombo316',
					'normal_img317',
				]
			},
			{
				label: 'PAI',
				widgets: [
					'normal_img319',
					'normal_pai_weekly_imagecombo320',
					'normal_img321',
				]
			},
			{
				label: 'Sleep',
				widgets: [
					'normal_img323',
					'normal_sleep_hour_high_imageset324',
					'normal_sleep_hour_low_imageset325',
					'normal_sleep_minute_high_imageset326',
					'normal_sleep_minute_low_imageset327',
					'normal_img328',
					'normal_img329',
				]
			},
			{
				label: 'Atmospheric pressure',
				widgets: [
					'normal_img331',
					'normal_airpressure_imagecombo332',
					'normal_img333',
				]
			},
			{
				label: 'Altitude',
				widgets: [
					'normal_altitude_imagecombo335',
					'normal_img336',
					'normal_img337',
				]
			},
			{
				label: 'Wind',
				widgets: [
					'normal_img339',
					'normal_wind_imagecombo340',
					'normal_wind_bearing_imageset341',
					'normal_img342',
				]
			},
			{
				label: 'UV Index',
				widgets: [
					'normal_img344',
					'normal_uvindex_imageset345',
					'normal_img346',
				]
			},
		];
		let container_1762060412254_selected = 0;
		let container_1762060416564 = '';
		let container_1762060416564_customs = [
			{
				label: 'Distance',
				widgets: [
					'normal_img349',
					'normal_distance_imagecombo350',
					'normal_img351',
				]
			},
			{
				label: 'SPO2',
				widgets: [
					'normal_img353',
					'normal_blood_oxygen_imagecombo354',
					'normal_img355',
				]
			},
			{
				label: 'VO2Max',
				widgets: [
					'normal_img357',
					'normal_vo2max_imagecombo358',
					'normal_img359',
				]
			},
			{
				label: 'PAI',
				widgets: [
					'normal_img361',
					'normal_pai_weekly_imagecombo362',
					'normal_img363',
				]
			},
			{
				label: 'Sleep',
				widgets: [
					'normal_img365',
					'normal_sleep_hour_low_imageset366',
					'normal_sleep_minute_high_imageset367',
					'normal_sleep_minute_low_imageset368',
					'normal_sleep_hour_high_imageset369',
					'normal_img370',
					'normal_img371',
				]
			},
			{
				label: 'Atmospheric pressure',
				widgets: [
					'normal_img373',
					'normal_airpressure_imagecombo374',
					'normal_img375',
				]
			},
			{
				label: 'Altitude',
				widgets: [
					'normal_img377',
					'normal_altitude_imagecombo378',
					'normal_img379',
				]
			},
			{
				label: 'Wind',
				widgets: [
					'normal_img381',
					'normal_wind_imagecombo382',
					'normal_wind_bearing_imageset383',
					'normal_img384',
				]
			},
			{
				label: 'UV Index',
				widgets: [
					'normal_img386',
					'normal_uvindex_imageset387',
					'normal_img388',
				]
			},
			{
				label: 'Steps',
				widgets: [
					'normal_img390',
					'normal_steps_imagecombo391',
					'normal_img392',
				]
			},
			{
				label: 'Calories',
				widgets: [
					'normal_img394',
					'normal_calories_imagecombo395',
					'normal_img396',
				]
			},
		];
		let container_1762060416564_selected = 0;
		let container_1762061459828 = '';
		let container_1762061459828_customs = [
			{
				label: 'Weather',
				widgets: [
					'normal_img399',
					'normal_weather_imageset400',
					'normal_temperature_current_imagecombo401',
				]
			},
			{
				label: 'Weather Max/Min',
				widgets: [
					'normal_img403',
					'normal_weather_imageset404',
					'normal_temperature_current_imagecombo405',
					'normal_temperature_high_imagecombo406',
					'normal_temperature_low_imagecombo407',
					'normal_img408',
					'normal_img409',
				]
			},
			{
				label: 'Forecast',
				widgets: [
					'normal_weatherplusone_imageset411',
					'normal_weatherplustwo_imageset412',
					'normal_weatherplusthree_imageset413',
					'normal_weatherplusfour_imageset414',
					'normal_img415',
					'normal_img416',
					'normal_img417',
					'normal_img418',
				]
			},
			{
				label: 'Sunrise and Sunset',
				widgets: [
					'normal_img420',
					'normal_sunrise_hours_high_imageset421',
					'normal_sunrise_hours_low_imageset422',
					'normal_sunrise_minutes_high_imageset423',
					'normal_sunrise_minutes_low_imageset424',
					'normal_img425',
					'normal_img426',
					'normal_sunset_hours_high_imageset427',
					'normal_sunset_hours_low_imageset428',
					'normal_sunset_minutes_high_imageset429',
					'normal_sunset_minutes_low_imageset430',
					'normal_img431',
					'normal_img432',
				]
			},
		];
		let container_1762061459828_selected = 0;
		let container_1762305733715 = '';
		let container_1762305733715_customs = [
			{
				label: 'BioCharge1',
				widgets: [
					'normal_img440',
					'normal_biocharge_imagecombo441',
				]
			},
			{
				label: 'BioCharge2',
				widgets: [
					'normal_img443',
					'normal_biocharge_imagecombo444',
					'normal_img445',
				]
			},
			{
				label: 'Seconds',
				widgets: [
					'normal_img447',
					'normal_second_imagecombo448',
				]
			},
			{
				label: 'None',
				widgets: [
					'normal_img450',
				]
			},
		];
		let container_1762305733715_selected = 0;
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				const batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
				const heartSensor = hmSensor.createSensor(hmSensor.id.HEART);
				const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
				const stressSensor = hmSensor.createSensor(hmSensor.id.STRESS);
				const vibrateSensor = hmSensor.createSensor(hmSensor.id.VIBRATE);
				const sleepSensor = hmSensor.createSensor(hmSensor.id.SLEEP);
				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 481,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img1 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0003.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img1.setProperty(hmUI.prop.VISIBLE, false);

				normal_img3 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0004.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img5 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0005.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img5.setProperty(hmUI.prop.VISIBLE, false);

				normal_img7 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0006.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img7.setProperty(hmUI.prop.VISIBLE, false);

				normal_img9 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0007.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img9.setProperty(hmUI.prop.VISIBLE, false);

				normal_img11 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0008.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img11.setProperty(hmUI.prop.VISIBLE, false);

				normal_img13 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0009.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img13.setProperty(hmUI.prop.VISIBLE, false);

				normal_img15 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0010.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img15.setProperty(hmUI.prop.VISIBLE, false);

				normal_img17 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0011.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img17.setProperty(hmUI.prop.VISIBLE, false);

				normal_img19 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0012.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img19.setProperty(hmUI.prop.VISIBLE, false);

				normal_img21 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0013.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img21.setProperty(hmUI.prop.VISIBLE, false);

				normal_img23 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0014.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img23.setProperty(hmUI.prop.VISIBLE, false);

				normal_img25 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0015.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img25.setProperty(hmUI.prop.VISIBLE, false);

				normal_img27 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0016.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img27.setProperty(hmUI.prop.VISIBLE, false);

				normal_img29 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0017.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img29.setProperty(hmUI.prop.VISIBLE, false);

				normal_img31 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0018.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img31.setProperty(hmUI.prop.VISIBLE, false);

				normal_img33 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0019.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img33.setProperty(hmUI.prop.VISIBLE, false);

				normal_img35 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0020.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img35.setProperty(hmUI.prop.VISIBLE, false);

				normal_img37 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0021.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img37.setProperty(hmUI.prop.VISIBLE, false);

				normal_img39 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0022.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img39.setProperty(hmUI.prop.VISIBLE, false);

				normal_img41 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0023.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img41.setProperty(hmUI.prop.VISIBLE, false);

				normal_img43 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0024.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img43.setProperty(hmUI.prop.VISIBLE, false);

				normal_img45 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0025.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img45.setProperty(hmUI.prop.VISIBLE, false);

				normal_img47 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0026.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img47.setProperty(hmUI.prop.VISIBLE, false);

				normal_img49 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0027.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img49.setProperty(hmUI.prop.VISIBLE, false);

				normal_img51 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0028.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img51.setProperty(hmUI.prop.VISIBLE, false);

				normal_heart_rate_imageset54 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 72,
					y: 397,
					image_array: ["0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png"],
					image_length: 11,
					type: hmUI.data_type.HEART,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stress_imageset56 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: -1,
					y: 127,
					image_array: ["0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png"],
					image_length: 11,
					type: hmUI.data_type.STRESS,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_imageset58 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 71,
					y: 0,
					image_array: ["0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0040.png"],
					image_length: 11,
					type: hmUI.data_type.BATTERY,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_humidity_imageset60 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 425,
					y: 126,
					image_array: ["0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0051.png"],
					image_length: 11,
					type: hmUI.data_type.HUMIDITY,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_biocharge_imageset62 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 165,
					y: 380,
					image_array: ["0072.png","0072.png","0072.png","0072.png","0072.png","0072.png","0072.png","0072.png","0072.png","0072.png","0072.png"],
					image_length: 11,
					type: hmUI.data_type.BIO_CHARGE,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_biocharge_imageset63 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 165,
					y: 384,
					image_array: ["0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0072.png"],
					image_length: 50,
					type: hmUI.data_type.BIO_CHARGE,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img65 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 481,
					src: '0122.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img66 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 152,
					y: 29,
					w: 301,
					h: 425,
					src: '0123.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img67 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 190,
					y: 190,
					w: 100,
					h: 100,
					src: '0124.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img69 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 258,
					y: 181,
					w: 138,
					h: 95,
					src: '0125.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img69.setProperty(hmUI.prop.VISIBLE, false);

				normal_img71 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 258,
					y: 181,
					w: 138,
					h: 95,
					src: '0126.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img71.setProperty(hmUI.prop.VISIBLE, false);

				normal_img73 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 258,
					y: 181,
					w: 138,
					h: 95,
					src: '0127.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img73.setProperty(hmUI.prop.VISIBLE, false);

				normal_img75 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 258,
					y: 181,
					w: 138,
					h: 95,
					src: '0128.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img75.setProperty(hmUI.prop.VISIBLE, false);

				normal_img77 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 258,
					y: 181,
					w: 138,
					h: 95,
					src: '0129.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img77.setProperty(hmUI.prop.VISIBLE, false);

				normal_img79 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 258,
					y: 181,
					w: 138,
					h: 95,
					src: '0130.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img79.setProperty(hmUI.prop.VISIBLE, false);

				normal_img81 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 258,
					y: 181,
					w: 138,
					h: 95,
					src: '0131.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img81.setProperty(hmUI.prop.VISIBLE, false);

				normal_img83 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 258,
					y: 181,
					w: 138,
					h: 95,
					src: '0132.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img83.setProperty(hmUI.prop.VISIBLE, false);

				normal_img85 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 258,
					y: 181,
					w: 138,
					h: 95,
					src: '0133.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img85.setProperty(hmUI.prop.VISIBLE, false);

				normal_img87 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 258,
					y: 181,
					w: 138,
					h: 95,
					src: '0134.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img87.setProperty(hmUI.prop.VISIBLE, false);

				normal_img89 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 258,
					y: 181,
					w: 138,
					h: 95,
					src: '0135.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img89.setProperty(hmUI.prop.VISIBLE, false);

				normal_img91 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 258,
					y: 181,
					w: 138,
					h: 95,
					src: '0136.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img91.setProperty(hmUI.prop.VISIBLE, false);

				normal_img93 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 258,
					y: 181,
					w: 138,
					h: 95,
					src: '0137.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img93.setProperty(hmUI.prop.VISIBLE, false);

				normal_img95 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 258,
					y: 181,
					w: 138,
					h: 95,
					src: '0138.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img95.setProperty(hmUI.prop.VISIBLE, false);

				normal_img97 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 258,
					y: 181,
					w: 138,
					h: 95,
					src: '0139.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img97.setProperty(hmUI.prop.VISIBLE, false);

				normal_img99 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 258,
					y: 181,
					w: 138,
					h: 95,
					src: '0140.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img99.setProperty(hmUI.prop.VISIBLE, false);

				normal_img101 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 258,
					y: 181,
					w: 138,
					h: 95,
					src: '0141.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img101.setProperty(hmUI.prop.VISIBLE, false);

				normal_img103 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 258,
					y: 181,
					w: 138,
					h: 95,
					src: '0142.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img103.setProperty(hmUI.prop.VISIBLE, false);

				normal_img105 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 258,
					y: 181,
					w: 138,
					h: 95,
					src: '0143.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img105.setProperty(hmUI.prop.VISIBLE, false);

				normal_img107 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 258,
					y: 181,
					w: 138,
					h: 95,
					src: '0144.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img107.setProperty(hmUI.prop.VISIBLE, false);

				normal_img109 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 258,
					y: 181,
					w: 138,
					h: 95,
					src: '0145.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img109.setProperty(hmUI.prop.VISIBLE, false);

				normal_img111 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 258,
					y: 181,
					w: 138,
					h: 95,
					src: '0146.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img111.setProperty(hmUI.prop.VISIBLE, false);

				normal_img113 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 258,
					y: 181,
					w: 138,
					h: 95,
					src: '0147.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img113.setProperty(hmUI.prop.VISIBLE, false);

				normal_img115 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 258,
					y: 181,
					w: 138,
					h: 95,
					src: '0148.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img115.setProperty(hmUI.prop.VISIBLE, false);

				normal_img117 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 258,
					y: 181,
					w: 138,
					h: 95,
					src: '0149.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img117.setProperty(hmUI.prop.VISIBLE, false);

				normal_img119 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 258,
					y: 181,
					w: 138,
					h: 95,
					src: '0150.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img119.setProperty(hmUI.prop.VISIBLE, false);

				normal_img122 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 190,
					y: 190,
					w: 100,
					h: 100,
					src: '0124.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img122.setProperty(hmUI.prop.VISIBLE, false);

				normal_img124 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 86,
					y: 181,
					w: 167,
					h: 95,
					src: '0151.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img126 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 86,
					y: 181,
					w: 167,
					h: 95,
					src: '0152.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img126.setProperty(hmUI.prop.VISIBLE, false);

				normal_img128 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 86,
					y: 181,
					w: 167,
					h: 95,
					src: '0153.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img128.setProperty(hmUI.prop.VISIBLE, false);

				normal_img130 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 86,
					y: 181,
					w: 167,
					h: 95,
					src: '0154.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img130.setProperty(hmUI.prop.VISIBLE, false);

				normal_img132 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 86,
					y: 181,
					w: 167,
					h: 95,
					src: '0155.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img132.setProperty(hmUI.prop.VISIBLE, false);

				normal_img134 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 86,
					y: 181,
					w: 167,
					h: 95,
					src: '0156.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img134.setProperty(hmUI.prop.VISIBLE, false);

				normal_img136 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 88,
					y: 181,
					w: 164,
					h: 95,
					src: '0157.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img136.setProperty(hmUI.prop.VISIBLE, false);

				normal_img138 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 86,
					y: 181,
					w: 167,
					h: 95,
					src: '0158.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img138.setProperty(hmUI.prop.VISIBLE, false);

				normal_img140 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 86,
					y: 181,
					w: 167,
					h: 95,
					src: '0159.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img140.setProperty(hmUI.prop.VISIBLE, false);

				normal_img142 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 86,
					y: 181,
					w: 167,
					h: 95,
					src: '0160.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img142.setProperty(hmUI.prop.VISIBLE, false);

				normal_img144 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 86,
					y: 181,
					w: 167,
					h: 95,
					src: '0161.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img144.setProperty(hmUI.prop.VISIBLE, false);

				normal_img146 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 86,
					y: 181,
					w: 167,
					h: 95,
					src: '0162.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img146.setProperty(hmUI.prop.VISIBLE, false);

				normal_img148 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 86,
					y: 181,
					w: 167,
					h: 95,
					src: '0163.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img148.setProperty(hmUI.prop.VISIBLE, false);

				normal_img150 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 86,
					y: 181,
					w: 167,
					h: 95,
					src: '0164.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img150.setProperty(hmUI.prop.VISIBLE, false);

				normal_img152 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 86,
					y: 181,
					w: 167,
					h: 95,
					src: '0165.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img152.setProperty(hmUI.prop.VISIBLE, false);

				normal_img154 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 86,
					y: 181,
					w: 167,
					h: 95,
					src: '0166.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img154.setProperty(hmUI.prop.VISIBLE, false);

				normal_img156 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 86,
					y: 181,
					w: 167,
					h: 95,
					src: '0167.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img156.setProperty(hmUI.prop.VISIBLE, false);

				normal_img158 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 86,
					y: 181,
					w: 167,
					h: 95,
					src: '0168.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img158.setProperty(hmUI.prop.VISIBLE, false);

				normal_img160 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 86,
					y: 181,
					w: 167,
					h: 95,
					src: '0169.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img160.setProperty(hmUI.prop.VISIBLE, false);

				normal_img162 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 86,
					y: 181,
					w: 167,
					h: 95,
					src: '0170.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img162.setProperty(hmUI.prop.VISIBLE, false);

				normal_img164 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 86,
					y: 181,
					w: 167,
					h: 95,
					src: '0171.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img164.setProperty(hmUI.prop.VISIBLE, false);

				normal_img166 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 86,
					y: 181,
					w: 167,
					h: 95,
					src: '0172.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img166.setProperty(hmUI.prop.VISIBLE, false);

				normal_img168 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 86,
					y: 181,
					w: 167,
					h: 95,
					src: '0173.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img168.setProperty(hmUI.prop.VISIBLE, false);

				normal_img170 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 86,
					y: 181,
					w: 167,
					h: 95,
					src: '0174.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img170.setProperty(hmUI.prop.VISIBLE, false);

				normal_img172 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 86,
					y: 181,
					w: 167,
					h: 95,
					src: '0175.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img172.setProperty(hmUI.prop.VISIBLE, false);

				normal_img174 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 86,
					y: 181,
					w: 167,
					h: 95,
					src: '0176.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img174.setProperty(hmUI.prop.VISIBLE, false);

				normal_heart_rate_first_imageset177 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 304,
					y: 419,
					w: 307,
					h: 421,
					src: '0186.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_heart_rate_second_imageset178 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 293,
					y: 424,
					w: 296,
					h: 425,
					src: '0196.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_heart_rate_third_imageset179 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 281,
					y: 429,
					w: 284,
					h: 430,
					src: '0199.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_img180 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 25,
					y: 49,
					w: 435,
					h: 435,
					src: '0200.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img182 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 29,
					y: 31,
					w: 420,
					h: 420,
					src: '0201.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stress_second_imageset183 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 38,
					y: 160,
					w: 44,
					h: 159,
					src: '0211.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_stress_first_imageset184 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 43,
					y: 147,
					w: 49,
					h: 147,
					src: '0221.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_stress_third_imageset185 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 33,
					y: 173,
					w: 39,
					h: 171,
					src: '0223.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_battery_first_imageset187 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 294,
					y: 35,
					w: 297,
					h: 36,
					src: '0233.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_battery_third_imageset188 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 272,
					y: 29,
					w: 273,
					h: 30,
					src: '0243.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_battery_second_imageset189 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 283,
					y: 31,
					w: 285,
					h: 32,
					src: '0253.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_img190 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 305,
					y: 38,
					w: 22,
					h: 25,
					src: '0254.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img191 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 5,
					y: 6,
					w: 468,
					h: 468,
					src: '0255.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_humidity_imageset193 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 428,
					y: 273,
					image_array: ["0256.png","0257.png","0258.png","0259.png","0260.png","0261.png","0262.png","0263.png","0264.png","0265.png","0256.png"],
					image_length: 11,
					type: hmUI.data_type.HUMIDITY,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_humidity_imageset194 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 430,
					y: 262,
					image_array: ["0266.png","0266.png","0266.png","0266.png","0266.png","0266.png","0266.png","0266.png","0266.png","0266.png","0267.png"],
					image_length: 11,
					type: hmUI.data_type.HUMIDITY,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img195 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 418,
					y: 296,
					w: 25,
					h: 21,
					src: '0268.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_humidity_imageset196 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 433,
					y: 259,
					image_array: ["0269.png","0269.png","0269.png","0269.png","0269.png","0269.png","0269.png","0269.png","0269.png","0269.png","0270.png"],
					image_length: 11,
					type: hmUI.data_type.HUMIDITY,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img197 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 425,
					y: 285,
					w: 21,
					h: 14,
					src: '0271.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img198 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -3,
					y: -3,
					w: 487,
					h: 487,
					src: '0272.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img200 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 230,
					y: 181,
					w: 22,
					h: 23,
					src: '0273.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img201 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 200,
					y: 124,
					w: 10,
					h: 40,
					src: '0274.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img202 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 244,
					y: 124,
					w: 8,
					h: 40,
					src: '0275.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img203 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 225,
					y: 124,
					w: 3,
					h: 40,
					src: '0276.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img204 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 202,
					y: 121,
					w: 48,
					h: 8,
					src: '0277.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img205 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 202,
					y: 155,
					w: 48,
					h: 8,
					src: '0277.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img206 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 230,
					y: 257,
					w: 22,
					h: 19,
					src: '0278.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img207 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 81,
					y: 173,
					w: 319,
					h: 10,
					src: '0279.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo209 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 95,
					hour_startY: 175,
					hour_array: ["0280.png","0281.png","0282.png","0283.png","0284.png","0285.png","0286.png","0287.png","0288.png","0289.png"],
					hour_zero: true,
					hour_space: 4,
					hour_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img210 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 394,
					y: 181,
					w: 8,
					h: 95,
					src: '0290.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img211 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 249,
					y: 181,
					w: 9,
					h: 95,
					src: '0291.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img212 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 324,
					y: 177,
					w: 5,
					h: 101,
					src: '0292.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img213 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 157,
					y: 181,
					w: 9,
					h: 95,
					src: '0291.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img214 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 233,
					y: 204,
					w: 16,
					h: 53,
					src: '0293.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img215 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 234,
					y: 204,
					w: 16,
					h: 53,
					src: '0294.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo216 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 258,
					minute_startY: 175,
					minute_array: ["0280.png","0281.png","0282.png","0283.png","0284.png","0285.png","0286.png","0287.png","0288.png","0289.png"],
					minute_zero: true,
					minute_space: 4,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img217 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 86,
					y: 181,
					w: 10,
					h: 95,
					src: '0295.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img219 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 233,
					y: 204,
					w: 16,
					h: 53,
					src: '0296.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img219.setProperty(hmUI.prop.VISIBLE, false);

				normal_hour_imagecombo220 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 96,
					hour_startY: 177,
					hour_array: ["0297.png","0298.png","0299.png","0300.png","0301.png","0302.png","0303.png","0304.png","0305.png","0306.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo220.setProperty(hmUI.prop.VISIBLE, false);

				normal_img221 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 85,
					y: 181,
					w: 11,
					h: 95,
					src: '0307.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img221.setProperty(hmUI.prop.VISIBLE, false);

				normal_img222 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 161,
					y: 181,
					w: 4,
					h: 95,
					src: '0308.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img222.setProperty(hmUI.prop.VISIBLE, false);

				normal_img223 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 248,
					y: 181,
					w: 10,
					h: 95,
					src: '0295.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img223.setProperty(hmUI.prop.VISIBLE, false);

				normal_img224 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 246,
					y: 186,
					w: 9,
					h: 19,
					src: '0309.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img224.setProperty(hmUI.prop.VISIBLE, false);

				normal_img225 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 246,
					y: 220,
					w: 9,
					h: 21,
					src: '0310.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img225.setProperty(hmUI.prop.VISIBLE, false);

				normal_img226 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 246,
					y: 256,
					w: 9,
					h: 19,
					src: '0309.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img226.setProperty(hmUI.prop.VISIBLE, false);

				normal_img227 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 225,
					y: 186,
					w: 9,
					h: 19,
					src: '0309.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img227.setProperty(hmUI.prop.VISIBLE, false);

				normal_img228 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 225,
					y: 220,
					w: 9,
					h: 21,
					src: '0310.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img228.setProperty(hmUI.prop.VISIBLE, false);

				normal_img229 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 225,
					y: 256,
					w: 9,
					h: 19,
					src: '0309.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img229.setProperty(hmUI.prop.VISIBLE, false);

				normal_img230 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 227,
					y: 181,
					w: 6,
					h: 95,
					src: '0311.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img230.setProperty(hmUI.prop.VISIBLE, false);

				normal_img231 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 160,
					y: 181,
					w: 3,
					h: 95,
					src: '0312.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img231.setProperty(hmUI.prop.VISIBLE, false);

				normal_img232 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 391,
					y: 181,
					w: 6,
					h: 95,
					src: '0311.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img232.setProperty(hmUI.prop.VISIBLE, false);

				normal_minute_imagecombo233 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 257,
					minute_startY: 177,
					minute_array: ["0313.png","0314.png","0315.png","0316.png","0317.png","0318.png","0319.png","0320.png","0321.png","0322.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo233.setProperty(hmUI.prop.VISIBLE, false);

				normal_month_imageset236 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 131,
					month_startY: 130,
					month_sc_array: ["0323.png","0324.png","0325.png","0326.png","0327.png","0328.png","0329.png","0330.png","0331.png","0332.png","0333.png","0334.png"],
					month_tc_array: ["0323.png","0324.png","0325.png","0326.png","0327.png","0328.png","0329.png","0330.png","0331.png","0332.png","0333.png","0334.png"],
					month_en_array: ["0323.png","0324.png","0325.png","0326.png","0327.png","0328.png","0329.png","0330.png","0331.png","0332.png","0333.png","0334.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset237 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 286,
					y: 129,
					week_en: ["0335.png","0336.png","0337.png","0338.png","0339.png","0340.png","0341.png"],
					week_tc: ["0335.png","0336.png","0337.png","0338.png","0339.png","0340.png","0341.png"],
					week_sc: ["0335.png","0336.png","0337.png","0338.png","0339.png","0340.png","0341.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_high_imageset238 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 209,
					y: 128,
					w: 209,
					h: 128,
					src: '0345.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_date_low_imageset239 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 227,
					y: 128,
					w: 227,
					h: 128,
					src: '0355.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_week_imageset240 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 125,
					y: 65,
					week_en: ["0356.png","0357.png","0358.png","0359.png","0360.png","0361.png","0362.png"],
					week_tc: ["0356.png","0357.png","0358.png","0359.png","0360.png","0361.png","0362.png"],
					week_sc: ["0356.png","0357.png","0358.png","0359.png","0360.png","0361.png","0362.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset241 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 231,
					y: 65,
					week_en: ["0358.png","0359.png","0360.png","0361.png","0362.png","0356.png","0357.png"],
					week_tc: ["0358.png","0359.png","0360.png","0361.png","0362.png","0356.png","0357.png"],
					week_sc: ["0358.png","0359.png","0360.png","0361.png","0362.png","0356.png","0357.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset242 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 283,
					y: 66,
					week_en: ["0359.png","0360.png","0361.png","0362.png","0356.png","0357.png","0358.png"],
					week_tc: ["0359.png","0360.png","0361.png","0362.png","0356.png","0357.png","0358.png"],
					week_sc: ["0359.png","0360.png","0361.png","0362.png","0356.png","0357.png","0358.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset243 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 336,
					y: 66,
					week_en: ["0360.png","0361.png","0362.png","0356.png","0357.png","0358.png","0359.png"],
					week_tc: ["0360.png","0361.png","0362.png","0356.png","0357.png","0358.png","0359.png"],
					week_sc: ["0360.png","0361.png","0362.png","0356.png","0357.png","0358.png","0359.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset244 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 178,
					y: 65,
					week_en: ["0357.png","0358.png","0359.png","0360.png","0361.png","0362.png","0356.png"],
					week_tc: ["0357.png","0358.png","0359.png","0360.png","0361.png","0362.png","0356.png"],
					week_sc: ["0357.png","0358.png","0359.png","0360.png","0361.png","0362.png","0356.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_current_imagecombo246 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 119,
					y: 103,
					font_array: ["0363.png","0364.png","0365.png","0366.png","0367.png","0368.png","0369.png","0370.png","0371.png","0372.png"],
					padding: false,
					h_space: 0,
					unit_sc: ["0374.png"],
					unit_tc: ["0374.png"],
					unit_en: ["0374.png"],
					negative_image: ["0373.png"],
					invalid_image: ["0375.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_imageset247 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 125,
					y: 76,
					image_array: ["0376.png","0377.png","0378.png","0379.png","0380.png","0381.png","0382.png","0383.png","0384.png","0385.png","0386.png","0387.png","0388.png","0389.png","0390.png","0391.png","0392.png","0393.png","0394.png","0395.png","0396.png","0397.png","0398.png","0399.png","0400.png","0401.png","0402.png","0403.png","0404.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calories_imagecombo249 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 313,
					y: 323,
					font_array: ["0405.png","0406.png","0407.png","0408.png","0409.png","0410.png","0411.png","0412.png","0413.png","0414.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img250 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 304,
					y: 288,
					w: 87,
					h: 30,
					src: '0415.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img251 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 326,
					y: 295,
					w: 43,
					h: 22,
					src: '0416.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img253 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 304,
					y: 288,
					w: 87,
					h: 30,
					src: '0415.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img253.setProperty(hmUI.prop.VISIBLE, false);

				normal_distance_imagecombo254 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 309,
					y: 323,
					font_array: ["0405.png","0406.png","0407.png","0408.png","0409.png","0410.png","0411.png","0412.png","0413.png","0417.png"],
					padding: false,
					h_space: 0,
					dot_image: '0418.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.DISTANCE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_distance_imagecombo254.setProperty(hmUI.prop.VISIBLE, false);

				normal_img255 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 326,
					y: 295,
					w: 39,
					h: 22,
					src: '0419.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img255.setProperty(hmUI.prop.VISIBLE, false);

				normal_img257 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 304,
					y: 288,
					w: 87,
					h: 30,
					src: '0415.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img257.setProperty(hmUI.prop.VISIBLE, false);

				normal_blood_oxygen_imagecombo258 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 322,
					y: 323,
					font_array: ["0420.png","0421.png","0422.png","0423.png","0424.png","0425.png","0426.png","0427.png","0428.png","0429.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.SPO2,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_blood_oxygen_imagecombo258.setProperty(hmUI.prop.VISIBLE, false);

				normal_img259 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 325,
					y: 295,
					w: 46,
					h: 22,
					src: '0430.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img259.setProperty(hmUI.prop.VISIBLE, false);

				normal_img261 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 304,
					y: 288,
					w: 87,
					h: 30,
					src: '0415.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img261.setProperty(hmUI.prop.VISIBLE, false);

				normal_vo2max_imagecombo262 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 331,
					y: 323,
					font_array: ["0431.png","0432.png","0433.png","0434.png","0435.png","0436.png","0437.png","0438.png","0439.png","0440.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.VO2MAX,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_vo2max_imagecombo262.setProperty(hmUI.prop.VISIBLE, false);

				normal_img263 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 311,
					y: 295,
					w: 71,
					h: 22,
					src: '0441.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img263.setProperty(hmUI.prop.VISIBLE, false);

				normal_img265 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 304,
					y: 288,
					w: 87,
					h: 30,
					src: '0415.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img265.setProperty(hmUI.prop.VISIBLE, false);

				normal_img266 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 331,
					y: 292,
					w: 33,
					h: 22,
					src: '0442.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img266.setProperty(hmUI.prop.VISIBLE, false);

				normal_pai_weekly_imagecombo267 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 322,
					y: 323,
					font_array: ["0420.png","0421.png","0422.png","0423.png","0424.png","0425.png","0426.png","0427.png","0428.png","0429.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.PAI_WEEKLY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_pai_weekly_imagecombo267.setProperty(hmUI.prop.VISIBLE, false);

				normal_img269 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 304,
					y: 288,
					w: 87,
					h: 30,
					src: '0415.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img269.setProperty(hmUI.prop.VISIBLE, false);

				normal_sleep_hour_high_imageset270 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 311,
					y: 323,
					w: 311,
					h: 323,
					src: '0445.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sleep_hour_high_imageset270.setProperty(hmUI.prop.VISIBLE, false);

				normal_sleep_hour_low_imageset271 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 327,
					y: 323,
					w: 327,
					h: 323,
					src: '0452.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sleep_hour_low_imageset271.setProperty(hmUI.prop.VISIBLE, false);

				normal_sleep_minute_high_imageset272 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 353,
					y: 323,
					w: 353,
					h: 323,
					src: '0448.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sleep_minute_high_imageset272.setProperty(hmUI.prop.VISIBLE, false);

				normal_sleep_minute_low_imageset273 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 370,
					y: 323,
					w: 370,
					h: 323,
					src: '0452.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sleep_minute_low_imageset273.setProperty(hmUI.prop.VISIBLE, false);

				normal_img274 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 344,
					y: 323,
					w: 7,
					h: 31,
					src: '0453.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img274.setProperty(hmUI.prop.VISIBLE, false);

				normal_img275 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 321,
					y: 292,
					w: 53,
					h: 22,
					src: '0454.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img275.setProperty(hmUI.prop.VISIBLE, false);

				normal_img277 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 304,
					y: 288,
					w: 87,
					h: 30,
					src: '0415.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img277.setProperty(hmUI.prop.VISIBLE, false);

				normal_airpressure_imagecombo278 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 314,
					y: 323,
					font_array: ["0405.png","0406.png","0407.png","0408.png","0409.png","0410.png","0411.png","0412.png","0413.png","0417.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.ALTIMETER,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_airpressure_imagecombo278.setProperty(hmUI.prop.VISIBLE, false);

				normal_img279 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 331,
					y: 292,
					w: 38,
					h: 22,
					src: '0455.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img279.setProperty(hmUI.prop.VISIBLE, false);

				normal_altitude_imagecombo281 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 315,
					y: 323,
					font_array: ["0456.png","0457.png","0458.png","0459.png","0460.png","0461.png","0462.png","0463.png","0464.png","0465.png"],
					padding: false,
					h_space: 0,
					negative_image: '0466.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.ALTITUDE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_altitude_imagecombo281.setProperty(hmUI.prop.VISIBLE, false);

				normal_img282 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 304,
					y: 288,
					w: 87,
					h: 30,
					src: '0415.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img282.setProperty(hmUI.prop.VISIBLE, false);

				normal_img283 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 331,
					y: 292,
					w: 35,
					h: 22,
					src: '0467.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img283.setProperty(hmUI.prop.VISIBLE, false);

				normal_img285 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 304,
					y: 288,
					w: 87,
					h: 30,
					src: '0415.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img285.setProperty(hmUI.prop.VISIBLE, false);

				normal_img286 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 326,
					y: 294,
					w: 45,
					h: 22,
					src: '0468.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img286.setProperty(hmUI.prop.VISIBLE, false);

				normal_wind_imagecombo287 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 331,
					y: 323,
					font_array: ["0431.png","0432.png","0433.png","0434.png","0435.png","0436.png","0437.png","0438.png","0439.png","0440.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WIND,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_wind_imagecombo287.setProperty(hmUI.prop.VISIBLE, false);

				normal_wind_bearing_imageset288 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 333,
					y: 353,
					image_array: ["0470.png","0471.png","0472.png","0473.png","0474.png","0475.png","0476.png","0477.png"],
					image_length: 8,
					type: hmUI.data_type.WIND_DIRECTION,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_wind_bearing_imageset288.setProperty(hmUI.prop.VISIBLE, false);

				normal_img290 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 304,
					y: 288,
					w: 87,
					h: 30,
					src: '0415.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img290.setProperty(hmUI.prop.VISIBLE, false);

				normal_uvindex_imageset291 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 323,
					y: 322,
					image_array: ["0478.png","0479.png","0480.png","0481.png","0482.png","0483.png","0484.png","0485.png","0486.png","0487.png","0488.png"],
					image_length: 11,
					type: hmUI.data_type.UVI,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_uvindex_imageset291.setProperty(hmUI.prop.VISIBLE, false);

				normal_img292 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 331,
					y: 292,
					w: 35,
					h: 22,
					src: '0489.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img292.setProperty(hmUI.prop.VISIBLE, false);

				normal_img294 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 304,
					y: 288,
					w: 87,
					h: 30,
					src: '0415.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img294.setProperty(hmUI.prop.VISIBLE, false);

				normal_steps_imagecombo295 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 305,
					y: 323,
					font_array: ["0456.png","0457.png","0458.png","0459.png","0460.png","0461.png","0462.png","0463.png","0464.png","0465.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imagecombo295.setProperty(hmUI.prop.VISIBLE, false);

				normal_img296 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 321,
					y: 295,
					w: 52,
					h: 22,
					src: '0490.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img296.setProperty(hmUI.prop.VISIBLE, false);

				normal_steps_imagecombo299 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 197,
					y: 323,
					font_array: ["0456.png","0457.png","0458.png","0459.png","0460.png","0461.png","0462.png","0463.png","0464.png","0465.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img300 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 196,
					y: 288,
					w: 87,
					h: 30,
					src: '0415.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img301 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 214,
					y: 295,
					w: 52,
					h: 22,
					src: '0490.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img303 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 196,
					y: 288,
					w: 87,
					h: 30,
					src: '0415.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img303.setProperty(hmUI.prop.VISIBLE, false);

				normal_calories_imagecombo304 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 205,
					y: 323,
					font_array: ["0405.png","0406.png","0407.png","0408.png","0409.png","0410.png","0411.png","0412.png","0413.png","0417.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calories_imagecombo304.setProperty(hmUI.prop.VISIBLE, false);

				normal_img305 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 218,
					y: 295,
					w: 43,
					h: 22,
					src: '0416.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img305.setProperty(hmUI.prop.VISIBLE, false);

				normal_img307 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 196,
					y: 288,
					w: 87,
					h: 30,
					src: '0415.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img307.setProperty(hmUI.prop.VISIBLE, false);

				normal_distance_imagecombo308 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 201,
					y: 323,
					font_array: ["0405.png","0406.png","0407.png","0408.png","0409.png","0410.png","0411.png","0412.png","0413.png","0417.png"],
					padding: false,
					h_space: 0,
					dot_image: '0418.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.DISTANCE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_distance_imagecombo308.setProperty(hmUI.prop.VISIBLE, false);

				normal_img309 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 218,
					y: 295,
					w: 39,
					h: 22,
					src: '0419.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img309.setProperty(hmUI.prop.VISIBLE, false);

				normal_img311 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 196,
					y: 288,
					w: 87,
					h: 30,
					src: '0415.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img311.setProperty(hmUI.prop.VISIBLE, false);

				normal_blood_oxygen_imagecombo312 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 214,
					y: 323,
					font_array: ["0420.png","0421.png","0422.png","0423.png","0424.png","0425.png","0426.png","0427.png","0428.png","0429.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.SPO2,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_blood_oxygen_imagecombo312.setProperty(hmUI.prop.VISIBLE, false);

				normal_img313 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 218,
					y: 295,
					w: 46,
					h: 22,
					src: '0430.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img313.setProperty(hmUI.prop.VISIBLE, false);

				normal_img315 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 196,
					y: 288,
					w: 87,
					h: 30,
					src: '0415.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img315.setProperty(hmUI.prop.VISIBLE, false);

				normal_vo2max_imagecombo316 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 223,
					y: 323,
					font_array: ["0431.png","0432.png","0433.png","0434.png","0435.png","0436.png","0437.png","0438.png","0439.png","0440.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.VO2MAX,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_vo2max_imagecombo316.setProperty(hmUI.prop.VISIBLE, false);

				normal_img317 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 203,
					y: 295,
					w: 71,
					h: 22,
					src: '0441.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img317.setProperty(hmUI.prop.VISIBLE, false);

				normal_img319 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 196,
					y: 288,
					w: 87,
					h: 30,
					src: '0415.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img319.setProperty(hmUI.prop.VISIBLE, false);

				normal_pai_weekly_imagecombo320 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 214,
					y: 323,
					font_array: ["0420.png","0421.png","0422.png","0423.png","0424.png","0425.png","0426.png","0427.png","0428.png","0429.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.PAI_WEEKLY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_pai_weekly_imagecombo320.setProperty(hmUI.prop.VISIBLE, false);

				normal_img321 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 225,
					y: 295,
					w: 31,
					h: 22,
					src: '0492.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img321.setProperty(hmUI.prop.VISIBLE, false);

				normal_img323 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 196,
					y: 288,
					w: 87,
					h: 30,
					src: '0415.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img323.setProperty(hmUI.prop.VISIBLE, false);

				normal_sleep_hour_high_imageset324 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 202,
					y: 323,
					w: 202,
					h: 323,
					src: '0445.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sleep_hour_high_imageset324.setProperty(hmUI.prop.VISIBLE, false);

				normal_sleep_hour_low_imageset325 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 219,
					y: 323,
					w: 219,
					h: 323,
					src: '0452.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sleep_hour_low_imageset325.setProperty(hmUI.prop.VISIBLE, false);

				normal_sleep_minute_high_imageset326 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 245,
					y: 323,
					w: 245,
					h: 323,
					src: '0448.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sleep_minute_high_imageset326.setProperty(hmUI.prop.VISIBLE, false);

				normal_sleep_minute_low_imageset327 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 262,
					y: 323,
					w: 262,
					h: 323,
					src: '0452.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sleep_minute_low_imageset327.setProperty(hmUI.prop.VISIBLE, false);

				normal_img328 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 236,
					y: 323,
					w: 7,
					h: 31,
					src: '0453.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img328.setProperty(hmUI.prop.VISIBLE, false);

				normal_img329 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 213,
					y: 295,
					w: 52,
					h: 22,
					src: '0493.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img329.setProperty(hmUI.prop.VISIBLE, false);

				normal_img331 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 196,
					y: 288,
					w: 87,
					h: 30,
					src: '0415.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img331.setProperty(hmUI.prop.VISIBLE, false);

				normal_airpressure_imagecombo332 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 206,
					y: 323,
					font_array: ["0405.png","0406.png","0407.png","0408.png","0409.png","0410.png","0411.png","0412.png","0413.png","0417.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.ALTIMETER,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_airpressure_imagecombo332.setProperty(hmUI.prop.VISIBLE, false);

				normal_img333 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 225,
					y: 295,
					w: 35,
					h: 22,
					src: '0494.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img333.setProperty(hmUI.prop.VISIBLE, false);

				normal_altitude_imagecombo335 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 207,
					y: 323,
					font_array: ["0456.png","0457.png","0458.png","0459.png","0460.png","0461.png","0462.png","0463.png","0464.png","0465.png"],
					padding: false,
					h_space: 0,
					negative_image: '0466.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.ALTITUDE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_altitude_imagecombo335.setProperty(hmUI.prop.VISIBLE, false);

				normal_img336 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 196,
					y: 288,
					w: 87,
					h: 30,
					src: '0415.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img336.setProperty(hmUI.prop.VISIBLE, false);

				normal_img337 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 225,
					y: 295,
					w: 31,
					h: 22,
					src: '0495.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img337.setProperty(hmUI.prop.VISIBLE, false);

				normal_img339 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 196,
					y: 288,
					w: 87,
					h: 30,
					src: '0415.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img339.setProperty(hmUI.prop.VISIBLE, false);

				normal_wind_imagecombo340 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 223,
					y: 323,
					font_array: ["0431.png","0432.png","0433.png","0434.png","0435.png","0436.png","0437.png","0438.png","0439.png","0440.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WIND,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_wind_imagecombo340.setProperty(hmUI.prop.VISIBLE, false);

				normal_wind_bearing_imageset341 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 225,
					y: 353,
					image_array: ["0470.png","0471.png","0472.png","0473.png","0474.png","0475.png","0476.png","0477.png"],
					image_length: 8,
					type: hmUI.data_type.WIND_DIRECTION,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_wind_bearing_imageset341.setProperty(hmUI.prop.VISIBLE, false);

				normal_img342 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 218,
					y: 295,
					w: 45,
					h: 22,
					src: '0468.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img342.setProperty(hmUI.prop.VISIBLE, false);

				normal_img344 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 196,
					y: 288,
					w: 87,
					h: 30,
					src: '0415.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img344.setProperty(hmUI.prop.VISIBLE, false);

				normal_uvindex_imageset345 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 215,
					y: 322,
					image_array: ["0478.png","0479.png","0480.png","0481.png","0482.png","0483.png","0484.png","0485.png","0486.png","0487.png","0488.png"],
					image_length: 11,
					type: hmUI.data_type.UVI,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_uvindex_imageset345.setProperty(hmUI.prop.VISIBLE, false);

				normal_img346 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 225,
					y: 295,
					w: 32,
					h: 22,
					src: '0496.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img346.setProperty(hmUI.prop.VISIBLE, false);

				normal_img349 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 95,
					y: 288,
					w: 87,
					h: 30,
					src: '0415.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_distance_imagecombo350 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 100,
					y: 323,
					font_array: ["0405.png","0406.png","0407.png","0408.png","0409.png","0410.png","0411.png","0412.png","0413.png","0417.png"],
					padding: false,
					h_space: 0,
					dot_image: '0418.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.DISTANCE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img351 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 115,
					y: 295,
					w: 39,
					h: 22,
					src: '0419.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img353 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 95,
					y: 288,
					w: 87,
					h: 30,
					src: '0415.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img353.setProperty(hmUI.prop.VISIBLE, false);

				normal_blood_oxygen_imagecombo354 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 113,
					y: 323,
					font_array: ["0420.png","0421.png","0422.png","0423.png","0424.png","0425.png","0426.png","0427.png","0428.png","0429.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.SPO2,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_blood_oxygen_imagecombo354.setProperty(hmUI.prop.VISIBLE, false);

				normal_img355 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 116,
					y: 295,
					w: 46,
					h: 22,
					src: '0430.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img355.setProperty(hmUI.prop.VISIBLE, false);

				normal_img357 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 95,
					y: 288,
					w: 87,
					h: 30,
					src: '0415.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img357.setProperty(hmUI.prop.VISIBLE, false);

				normal_vo2max_imagecombo358 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 122,
					y: 323,
					font_array: ["0431.png","0432.png","0433.png","0434.png","0435.png","0436.png","0437.png","0438.png","0439.png","0440.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.VO2MAX,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_vo2max_imagecombo358.setProperty(hmUI.prop.VISIBLE, false);

				normal_img359 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 102,
					y: 295,
					w: 71,
					h: 22,
					src: '0441.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img359.setProperty(hmUI.prop.VISIBLE, false);

				normal_img361 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 95,
					y: 288,
					w: 87,
					h: 30,
					src: '0415.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img361.setProperty(hmUI.prop.VISIBLE, false);

				normal_pai_weekly_imagecombo362 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 113,
					y: 323,
					font_array: ["0420.png","0421.png","0422.png","0423.png","0424.png","0425.png","0426.png","0427.png","0428.png","0429.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.PAI_WEEKLY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_pai_weekly_imagecombo362.setProperty(hmUI.prop.VISIBLE, false);

				normal_img363 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 123,
					y: 295,
					w: 31,
					h: 22,
					src: '0492.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img363.setProperty(hmUI.prop.VISIBLE, false);

				normal_img365 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 95,
					y: 288,
					w: 87,
					h: 30,
					src: '0415.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img365.setProperty(hmUI.prop.VISIBLE, false);

				normal_sleep_hour_low_imageset366 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 118,
					y: 323,
					w: 118,
					h: 323,
					src: '0452.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sleep_hour_low_imageset366.setProperty(hmUI.prop.VISIBLE, false);

				normal_sleep_minute_high_imageset367 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 144,
					y: 323,
					w: 144,
					h: 323,
					src: '0448.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sleep_minute_high_imageset367.setProperty(hmUI.prop.VISIBLE, false);

				normal_sleep_minute_low_imageset368 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 161,
					y: 323,
					w: 161,
					h: 323,
					src: '0452.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sleep_minute_low_imageset368.setProperty(hmUI.prop.VISIBLE, false);

				normal_sleep_hour_high_imageset369 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 101,
					y: 323,
					w: 101,
					h: 323,
					src: '0445.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sleep_hour_high_imageset369.setProperty(hmUI.prop.VISIBLE, false);

				normal_img370 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 135,
					y: 323,
					w: 7,
					h: 31,
					src: '0453.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img370.setProperty(hmUI.prop.VISIBLE, false);

				normal_img371 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 113,
					y: 295,
					w: 52,
					h: 22,
					src: '0493.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img371.setProperty(hmUI.prop.VISIBLE, false);

				normal_img373 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 95,
					y: 288,
					w: 87,
					h: 30,
					src: '0415.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img373.setProperty(hmUI.prop.VISIBLE, false);

				normal_airpressure_imagecombo374 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 105,
					y: 323,
					font_array: ["0405.png","0406.png","0407.png","0408.png","0409.png","0410.png","0411.png","0412.png","0413.png","0417.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.ALTIMETER,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_airpressure_imagecombo374.setProperty(hmUI.prop.VISIBLE, false);

				normal_img375 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 123,
					y: 295,
					w: 35,
					h: 22,
					src: '0494.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img375.setProperty(hmUI.prop.VISIBLE, false);

				normal_img377 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 95,
					y: 288,
					w: 87,
					h: 30,
					src: '0415.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img377.setProperty(hmUI.prop.VISIBLE, false);

				normal_altitude_imagecombo378 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 106,
					y: 323,
					font_array: ["0456.png","0457.png","0458.png","0459.png","0460.png","0461.png","0462.png","0463.png","0464.png","0465.png"],
					padding: false,
					h_space: 0,
					negative_image: '0466.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.ALTITUDE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_altitude_imagecombo378.setProperty(hmUI.prop.VISIBLE, false);

				normal_img379 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 123,
					y: 295,
					w: 31,
					h: 22,
					src: '0495.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img379.setProperty(hmUI.prop.VISIBLE, false);

				normal_img381 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 95,
					y: 288,
					w: 87,
					h: 30,
					src: '0415.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img381.setProperty(hmUI.prop.VISIBLE, false);

				normal_wind_imagecombo382 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 122,
					y: 323,
					font_array: ["0431.png","0432.png","0433.png","0434.png","0435.png","0436.png","0437.png","0438.png","0439.png","0440.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WIND,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_wind_imagecombo382.setProperty(hmUI.prop.VISIBLE, false);

				normal_wind_bearing_imageset383 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 124,
					y: 353,
					image_array: ["0470.png","0471.png","0472.png","0473.png","0474.png","0475.png","0476.png","0477.png"],
					image_length: 8,
					type: hmUI.data_type.WIND_DIRECTION,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_wind_bearing_imageset383.setProperty(hmUI.prop.VISIBLE, false);

				normal_img384 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 117,
					y: 295,
					w: 45,
					h: 22,
					src: '0468.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img384.setProperty(hmUI.prop.VISIBLE, false);

				normal_img386 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 95,
					y: 288,
					w: 87,
					h: 30,
					src: '0415.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img386.setProperty(hmUI.prop.VISIBLE, false);

				normal_uvindex_imageset387 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 116,
					y: 324,
					image_array: ["0497.png","0498.png","0499.png","0500.png","0501.png","0502.png","0503.png","0504.png","0505.png","0506.png","0507.png"],
					image_length: 11,
					type: hmUI.data_type.UVI,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_uvindex_imageset387.setProperty(hmUI.prop.VISIBLE, false);

				normal_img388 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 123,
					y: 295,
					w: 32,
					h: 22,
					src: '0496.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img388.setProperty(hmUI.prop.VISIBLE, false);

				normal_img390 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 95,
					y: 288,
					w: 87,
					h: 30,
					src: '0415.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img390.setProperty(hmUI.prop.VISIBLE, false);

				normal_steps_imagecombo391 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 96,
					y: 323,
					font_array: ["0456.png","0457.png","0458.png","0459.png","0460.png","0461.png","0462.png","0463.png","0464.png","0465.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imagecombo391.setProperty(hmUI.prop.VISIBLE, false);

				normal_img392 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 113,
					y: 295,
					w: 52,
					h: 22,
					src: '0490.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img392.setProperty(hmUI.prop.VISIBLE, false);

				normal_img394 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 95,
					y: 288,
					w: 87,
					h: 30,
					src: '0415.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img394.setProperty(hmUI.prop.VISIBLE, false);

				normal_calories_imagecombo395 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 104,
					y: 323,
					font_array: ["0405.png","0406.png","0407.png","0408.png","0409.png","0410.png","0411.png","0412.png","0413.png","0417.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calories_imagecombo395.setProperty(hmUI.prop.VISIBLE, false);

				normal_img396 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 116,
					y: 295,
					w: 43,
					h: 22,
					src: '0416.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img396.setProperty(hmUI.prop.VISIBLE, false);

				normal_img399 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 109,
					y: 62,
					w: 264,
					h: 60,
					src: '0508.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_imageset400 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 190,
					y: 70,
					image_array: ["0509.png","0510.png","0511.png","0512.png","0513.png","0514.png","0515.png","0516.png","0517.png","0518.png","0519.png","0520.png","0521.png","0522.png","0523.png","0524.png","0525.png","0526.png","0527.png","0528.png","0529.png","0530.png","0531.png","0532.png","0533.png","0534.png","0535.png","0536.png","0537.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_current_imagecombo401 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 242,
					y: 76,
					font_array: ["0538.png","0539.png","0540.png","0541.png","0542.png","0543.png","0544.png","0545.png","0546.png","0547.png"],
					padding: false,
					h_space: 0,
					unit_sc: ["0549.png"],
					unit_tc: ["0549.png"],
					unit_en: ["0549.png"],
					negative_image: ["0548.png"],
					invalid_image: ["0548.png"],
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img403 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 109,
					y: 62,
					w: 264,
					h: 60,
					src: '0508.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img403.setProperty(hmUI.prop.VISIBLE, false);

				normal_weather_imageset404 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 138,
					y: 70,
					image_array: ["0509.png","0510.png","0511.png","0512.png","0513.png","0514.png","0515.png","0516.png","0517.png","0518.png","0519.png","0520.png","0521.png","0522.png","0523.png","0524.png","0525.png","0526.png","0527.png","0528.png","0529.png","0530.png","0531.png","0532.png","0533.png","0534.png","0535.png","0536.png","0537.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_imageset404.setProperty(hmUI.prop.VISIBLE, false);

				normal_temperature_current_imagecombo405 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 190,
					y: 76,
					font_array: ["0538.png","0539.png","0540.png","0541.png","0542.png","0543.png","0544.png","0545.png","0546.png","0547.png"],
					padding: false,
					h_space: 0,
					unit_sc: ["0549.png"],
					unit_tc: ["0549.png"],
					unit_en: ["0549.png"],
					negative_image: ["0548.png"],
					invalid_image: ["0548.png"],
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_current_imagecombo405.setProperty(hmUI.prop.VISIBLE, false);

				normal_temperature_high_imagecombo406 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 288,
					y: 70,
					font_array: ["0550.png","0551.png","0552.png","0553.png","0554.png","0555.png","0556.png","0557.png","0558.png","0559.png"],
					padding: false,
					h_space: 0,
					unit_sc: ["0561.png"],
					unit_tc: ["0561.png"],
					unit_en: ["0561.png"],
					negative_image: ["0560.png"],
					invalid_image: ["0560.png"],
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.WEATHER_HIGH,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_high_imagecombo406.setProperty(hmUI.prop.VISIBLE, false);

				normal_temperature_low_imagecombo407 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 288,
					y: 91,
					font_array: ["0562.png","0563.png","0564.png","0565.png","0566.png","0567.png","0568.png","0569.png","0570.png","0571.png"],
					padding: false,
					h_space: 0,
					unit_sc: ["0572.png"],
					unit_tc: ["0572.png"],
					unit_en: ["0572.png"],
					negative_image: ["0375.png"],
					invalid_image: ["0375.png"],
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.WEATHER_LOW,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_low_imagecombo407.setProperty(hmUI.prop.VISIBLE, false);

				normal_img408 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 269,
					y: 76,
					w: 10,
					h: 10,
					src: '0573.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img408.setProperty(hmUI.prop.VISIBLE, false);

				normal_img409 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 269,
					y: 98,
					w: 10,
					h: 10,
					src: '0574.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img409.setProperty(hmUI.prop.VISIBLE, false);

				normal_weatherplusone_imageset411 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 170,
					y: 76,
					w: 170,
					h: 76,
					src: '0603.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_weatherplusone_imageset411.setProperty(hmUI.prop.VISIBLE, false);

				normal_weatherplustwo_imageset412 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 223,
					y: 76,
					w: 223,
					h: 76,
					src: '0632.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_weatherplustwo_imageset412.setProperty(hmUI.prop.VISIBLE, false);

				normal_weatherplusthree_imageset413 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 275,
					y: 77,
					w: 275,
					h: 77,
					src: '0661.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_weatherplusthree_imageset413.setProperty(hmUI.prop.VISIBLE, false);

				normal_weatherplusfour_imageset414 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 328,
					y: 77,
					w: 328,
					h: 77,
					src: '0690.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_weatherplusfour_imageset414.setProperty(hmUI.prop.VISIBLE, false);

				normal_img415 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 161,
					y: 85,
					w: 7,
					h: 7,
					src: '0691.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img415.setProperty(hmUI.prop.VISIBLE, false);

				normal_img416 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 213,
					y: 85,
					w: 7,
					h: 7,
					src: '0691.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img416.setProperty(hmUI.prop.VISIBLE, false);

				normal_img417 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 265,
					y: 85,
					w: 7,
					h: 7,
					src: '0691.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img417.setProperty(hmUI.prop.VISIBLE, false);

				normal_img418 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 318,
					y: 86,
					w: 7,
					h: 7,
					src: '0691.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img418.setProperty(hmUI.prop.VISIBLE, false);

				normal_img420 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 109,
					y: 62,
					w: 264,
					h: 15,
					src: '0692.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img420.setProperty(hmUI.prop.VISIBLE, false);

				normal_sunrise_hours_high_imageset421 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 185,
					y: 76,
					w: 185,
					h: 76,
					src: '0695.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sunrise_hours_high_imageset421.setProperty(hmUI.prop.VISIBLE, false);

				normal_sunrise_hours_low_imageset422 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 201,
					y: 76,
					w: 201,
					h: 76,
					src: '0702.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sunrise_hours_low_imageset422.setProperty(hmUI.prop.VISIBLE, false);

				normal_sunrise_minutes_high_imageset423 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 225,
					y: 76,
					w: 225,
					h: 76,
					src: '0698.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sunrise_minutes_high_imageset423.setProperty(hmUI.prop.VISIBLE, false);

				normal_sunrise_minutes_low_imageset424 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 241,
					y: 76,
					w: 241,
					h: 76,
					src: '0702.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sunrise_minutes_low_imageset424.setProperty(hmUI.prop.VISIBLE, false);

				normal_img425 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 160,
					y: 78,
					w: 22,
					h: 22,
					src: '0703.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img425.setProperty(hmUI.prop.VISIBLE, false);

				normal_img426 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 261,
					y: 78,
					w: 20,
					h: 20,
					src: '0704.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img426.setProperty(hmUI.prop.VISIBLE, false);

				normal_sunset_hours_high_imageset427 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 284,
					y: 76,
					w: 284,
					h: 76,
					src: '0695.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sunset_hours_high_imageset427.setProperty(hmUI.prop.VISIBLE, false);

				normal_sunset_hours_low_imageset428 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 300,
					y: 76,
					w: 300,
					h: 76,
					src: '0702.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sunset_hours_low_imageset428.setProperty(hmUI.prop.VISIBLE, false);

				normal_sunset_minutes_high_imageset429 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 324,
					y: 76,
					w: 324,
					h: 76,
					src: '0698.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sunset_minutes_high_imageset429.setProperty(hmUI.prop.VISIBLE, false);

				normal_sunset_minutes_low_imageset430 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 340,
					y: 76,
					w: 340,
					h: 76,
					src: '0702.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sunset_minutes_low_imageset430.setProperty(hmUI.prop.VISIBLE, false);

				normal_img431 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 217,
					y: 76,
					w: 7,
					h: 29,
					src: '0705.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img431.setProperty(hmUI.prop.VISIBLE, false);

				normal_img432 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 316,
					y: 76,
					w: 7,
					h: 29,
					src: '0705.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img432.setProperty(hmUI.prop.VISIBLE, false);

				normal_img435 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 341,
					y: 380,
					w: 30,
					h: 30,
					src: '0707.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_bt_status436 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 341,
					y: 380,
					w: 30,
					h: 30,
					type: hmUI.system_status.DISCONNECT,
					src: '0708.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img437 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 109,
					y: 380,
					w: 32,
					h: 30,
					src: '0709.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_alarm_status438 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 109,
					y: 380,
					w: 33,
					h: 31,
					type: hmUI.system_status.CLOCK,
					src: '0710.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img440 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 168,
					y: 377,
					w: 107,
					h: 20,
					src: '0711.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_biocharge_imagecombo441 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 281,
					y: 376,
					font_array: ["0712.png","0713.png","0714.png","0715.png","0716.png","0717.png","0718.png","0719.png","0720.png","0721.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.BIO_CHARGE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img443 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 163,
					y: 380,
					w: 154,
					h: 25,
					src: '0722.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img443.setProperty(hmUI.prop.VISIBLE, false);

				normal_biocharge_imagecombo444 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 239,
					y: 378,
					font_array: ["0723.png","0724.png","0725.png","0726.png","0727.png","0728.png","0729.png","0730.png","0731.png","0732.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.BIO_CHARGE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_biocharge_imagecombo444.setProperty(hmUI.prop.VISIBLE, false);

				normal_img445 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 195,
					y: 373,
					w: 28,
					h: 35,
					src: '0733.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img445.setProperty(hmUI.prop.VISIBLE, false);

				normal_img447 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 163,
					y: 380,
					w: 154,
					h: 25,
					src: '0722.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img447.setProperty(hmUI.prop.VISIBLE, false);

				normal_second_imagecombo448 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 223,
					second_startY: 378,
					second_array: ["0734.png","0735.png","0736.png","0737.png","0738.png","0739.png","0740.png","0741.png","0742.png","0743.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo448.setProperty(hmUI.prop.VISIBLE, false);

				normal_img450 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 163,
					y: 380,
					w: 154,
					h: 25,
					src: '0722.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img450.setProperty(hmUI.prop.VISIBLE, false);

				normal_ampm24_imageset453 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 230,
					y: 261,
					w: 230,
					h: 261,
					src: '0747.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_heart_shortcut456 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 167,
					y: 420,
					w: 150,
					h: 100,
					src: '',
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_shortcut457 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 410,
					y: 162,
					w: 100,
					h: 150,
					src: '',
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stress_shortcut458 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: -50,
					y: 162,
					w: 100,
					h: 150,
					src: '',
					type: hmUI.data_type.STRESS,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_shortcut459 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 167,
					y: -40,
					w: 150,
					h: 100,
					src: '',
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_img461 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0748.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_stress_imageset462 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: -1,
					y: 127,
					image_array: ["0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png"],
					image_length: 11,
					type: hmUI.data_type.STRESS,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_heart_rate_imageset464 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 72,
					y: 397,
					image_array: ["0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png"],
					image_length: 11,
					type: hmUI.data_type.HEART,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_humidity_imageset466 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 425,
					y: 126,
					image_array: ["0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0051.png"],
					image_length: 11,
					type: hmUI.data_type.HUMIDITY,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_battery_imageset468 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 71,
					y: 0,
					image_array: ["0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0040.png"],
					image_length: 11,
					type: hmUI.data_type.BATTERY,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img470 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 481,
					src: '0749.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img471 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 152,
					y: 29,
					w: 301,
					h: 425,
					src: '0123.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img472 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 233,
					y: 204,
					w: 16,
					h: 53,
					src: '0750.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img473 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 29,
					y: 31,
					w: 420,
					h: 420,
					src: '0201.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img474 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 25,
					y: 49,
					w: 435,
					h: 435,
					src: '0200.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img475 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -3,
					y: -3,
					w: 487,
					h: 487,
					src: '0272.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img476 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 5,
					y: 6,
					w: 468,
					h: 468,
					src: '0255.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_minute_imagecombo477 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 257,
					minute_startY: 177,
					minute_array: ["0751.png","0752.png","0753.png","0754.png","0755.png","0756.png","0757.png","0758.png","0759.png","0760.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_hour_imagecombo478 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 96,
					hour_startY: 177,
					hour_array: ["0761.png","0762.png","0763.png","0764.png","0765.png","0766.png","0767.png","0768.png","0769.png","0770.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_ampm24_imageset479 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 230,
					y: 261,
					w: 230,
					h: 261,
					src: '0747.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_steps_imagecombo481 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 197,
					y: 323,
					font_array: ["0456.png","0457.png","0458.png","0459.png","0460.png","0461.png","0462.png","0463.png","0464.png","0465.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_calories_imagecombo483 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 313,
					y: 323,
					font_array: ["0405.png","0406.png","0407.png","0408.png","0409.png","0410.png","0411.png","0412.png","0413.png","0771.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_distance_imagecombo485 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 100,
					y: 323,
					font_array: ["0405.png","0406.png","0407.png","0408.png","0409.png","0410.png","0411.png","0412.png","0413.png","0417.png"],
					padding: false,
					h_space: 0,
					dot_image: '0418.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.DISTANCE,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_weather_imageset487 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 190,
					y: 70,
					image_array: ["0509.png","0510.png","0511.png","0512.png","0513.png","0514.png","0515.png","0516.png","0517.png","0518.png","0519.png","0520.png","0521.png","0522.png","0523.png","0524.png","0525.png","0526.png","0527.png","0528.png","0529.png","0530.png","0531.png","0532.png","0533.png","0534.png","0535.png","0536.png","0537.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_temperature_current_imagecombo488 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 242,
					y: 76,
					font_array: ["0538.png","0539.png","0540.png","0541.png","0542.png","0543.png","0544.png","0545.png","0546.png","0547.png"],
					padding: false,
					h_space: 0,
					unit_sc: ["0549.png"],
					unit_tc: ["0549.png"],
					unit_en: ["0549.png"],
					negative_image: ["0548.png"],
					invalid_image: ["0548.png"],
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_stress_second_imageset490 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 38,
					y: 160,
					w: 44,
					h: 159,
					src: '0211.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_stress_first_imageset491 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 43,
					y: 147,
					w: 49,
					h: 147,
					src: '0221.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_stress_third_imageset492 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 33,
					y: 173,
					w: 39,
					h: 171,
					src: '0223.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_heart_rate_first_imageset494 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 304,
					y: 419,
					w: 307,
					h: 421,
					src: '0186.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_heart_rate_second_imageset495 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 293,
					y: 424,
					w: 296,
					h: 425,
					src: '0196.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_heart_rate_third_imageset496 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 281,
					y: 429,
					w: 284,
					h: 430,
					src: '0199.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_humidity_imageset498 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 428,
					y: 273,
					image_array: ["0256.png","0257.png","0258.png","0259.png","0260.png","0261.png","0262.png","0263.png","0264.png","0265.png","0256.png"],
					image_length: 11,
					type: hmUI.data_type.HUMIDITY,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_humidity_imageset499 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 430,
					y: 262,
					image_array: ["0266.png","0266.png","0266.png","0266.png","0266.png","0266.png","0266.png","0266.png","0266.png","0266.png","0267.png"],
					image_length: 11,
					type: hmUI.data_type.HUMIDITY,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img500 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 418,
					y: 296,
					w: 25,
					h: 21,
					src: '0268.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_humidity_imageset501 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 433,
					y: 259,
					image_array: ["0269.png","0269.png","0269.png","0269.png","0269.png","0269.png","0269.png","0269.png","0269.png","0269.png","0270.png"],
					image_length: 11,
					type: hmUI.data_type.HUMIDITY,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img502 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 425,
					y: 285,
					w: 21,
					h: 14,
					src: '0271.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_battery_first_imageset504 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 294,
					y: 35,
					w: 297,
					h: 36,
					src: '0233.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_battery_third_imageset505 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 272,
					y: 29,
					w: 273,
					h: 30,
					src: '0243.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_battery_second_imageset506 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 283,
					y: 31,
					w: 285,
					h: 32,
					src: '0253.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_img507 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 305,
					y: 38,
					w: 22,
					h: 25,
					src: '0254.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_month_imageset509 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 131,
					month_startY: 130,
					month_sc_array: ["0323.png","0324.png","0325.png","0326.png","0327.png","0328.png","0329.png","0330.png","0331.png","0332.png","0333.png","0334.png"],
					month_tc_array: ["0323.png","0324.png","0325.png","0326.png","0327.png","0328.png","0329.png","0330.png","0331.png","0332.png","0333.png","0334.png"],
					month_en_array: ["0323.png","0324.png","0325.png","0326.png","0327.png","0328.png","0329.png","0330.png","0331.png","0332.png","0333.png","0334.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_week_imageset510 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 286,
					y: 129,
					week_en: ["0335.png","0336.png","0337.png","0338.png","0339.png","0340.png","0341.png"],
					week_tc: ["0335.png","0336.png","0337.png","0338.png","0339.png","0340.png","0341.png"],
					week_sc: ["0335.png","0336.png","0337.png","0338.png","0339.png","0340.png","0341.png"],
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_date_high_imageset511 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 209,
					y: 128,
					w: 209,
					h: 128,
					src: '0775.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_date_low_imageset512 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 227,
					y: 128,
					w: 227,
					h: 128,
					src: '0785.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_img514 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 195,
					y: 373,
					w: 28,
					h: 35,
					src: '0733.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_biocharge_imagecombo515 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 239,
					y: 378,
					font_array: ["0723.png","0724.png","0725.png","0726.png","0727.png","0728.png","0729.png","0730.png","0731.png","0732.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.BIO_CHARGE,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img517 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 341,
					y: 380,
					w: 30,
					h: 30,
					src: '0707.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img518 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 110,
					y: 380,
					w: 32,
					h: 30,
					src: '0709.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_bt_status519 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 341,
					y: 380,
					w: 30,
					h: 30,
					type: hmUI.system_status.DISCONNECT,
					src: '0708.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_alarm_status520 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 110,
					y: 380,
					w: 33,
					h: 31,
					type: hmUI.system_status.CLOCK,
					src: '0710.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img522 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 304,
					y: 288,
					w: 87,
					h: 30,
					src: '0415.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img523 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 196,
					y: 288,
					w: 87,
					h: 30,
					src: '0415.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img524 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 95,
					y: 288,
					w: 87,
					h: 30,
					src: '0415.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img525 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 326,
					y: 295,
					w: 43,
					h: 22,
					src: '0416.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img526 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 214,
					y: 295,
					w: 52,
					h: 22,
					src: '0490.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img527 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 115,
					y: 295,
					w: 39,
					h: 22,
					src: '0419.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				container_1752984972990 = hmUI.createWidget(hmUI.widget.BUTTON, {
					x: 125,
					y: 126,
					w: 230,
					h: 40,
					text: "",
					normal_src: '0029.png',
					press_src: '0029.png',
					click_func: () => {
						container_1752984972990_selected = (container_1752984972990_selected+1 > container_1752984972990_customs.length-1) ? 0 : container_1752984972990_selected+1;
						for (let w = 0; w < container_1752984972990_customs.length; w++) {
							for (let z of container_1752984972990_customs[w].widgets) {
								eval(z).setProperty(hmUI.prop.VISIBLE, ((w == container_1752984972990_selected) ? true : false));
							}
						}
						hmUI.showToast({
							text: container_1752984972990_customs[container_1752984972990_selected].label.toString() + ' On'
						});
						vibrateSensor.stop();
						vibrateSensor.scene = 0;
						vibrateSensor.start();
					},
					show_level: hmUI.show_level.ONLY_NORMAL
				});

				container_1753929349836 = hmUI.createWidget(hmUI.widget.BUTTON, {
					x: 310,
					y: 190,
					w: 100,
					h: 100,
					text: "",
					normal_src: '0124.png',
					press_src: '0124.png',
					click_func: () => {
						container_1753929349836_selected = (container_1753929349836_selected+1 > container_1753929349836_customs.length-1) ? 0 : container_1753929349836_selected+1;
						for (let w = 0; w < container_1753929349836_customs.length; w++) {
							for (let z of container_1753929349836_customs[w].widgets) {
								eval(z).setProperty(hmUI.prop.VISIBLE, ((w == container_1753929349836_selected) ? true : false));
							}
						}
						hmUI.showToast({
							text: container_1753929349836_customs[container_1753929349836_selected].label.toString() + ' On'
						});
						vibrateSensor.stop();
						vibrateSensor.scene = 0;
						vibrateSensor.start();
					},
					show_level: hmUI.show_level.ONLY_NORMAL
				});

				container_1752930086541 = hmUI.createWidget(hmUI.widget.BUTTON, {
					x: 70,
					y: 190,
					w: 100,
					h: 100,
					text: "",
					normal_src: '0124.png',
					press_src: '0124.png',
					click_func: () => {
						container_1752930086541_selected = (container_1752930086541_selected+1 > container_1752930086541_customs.length-1) ? 0 : container_1752930086541_selected+1;
						for (let w = 0; w < container_1752930086541_customs.length; w++) {
							for (let z of container_1752930086541_customs[w].widgets) {
								eval(z).setProperty(hmUI.prop.VISIBLE, ((w == container_1752930086541_selected) ? true : false));
							}
						}
						hmUI.showToast({
							text: container_1752930086541_customs[container_1752930086541_selected].label.toString() + ' On'
						});
						vibrateSensor.stop();
						vibrateSensor.scene = 0;
						vibrateSensor.start();
					},
					show_level: hmUI.show_level.ONLY_NORMAL
				});

				container_1762045954004 = hmUI.createWidget(hmUI.widget.BUTTON, {
					x: 190,
					y: 190,
					w: 100,
					h: 100,
					text: "",
					normal_src: '0124.png',
					press_src: '0124.png',
					click_func: () => {
						container_1762045954004_selected = (container_1762045954004_selected+1 > container_1762045954004_customs.length-1) ? 0 : container_1762045954004_selected+1;
						for (let w = 0; w < container_1762045954004_customs.length; w++) {
							for (let z of container_1762045954004_customs[w].widgets) {
								eval(z).setProperty(hmUI.prop.VISIBLE, ((w == container_1762045954004_selected) ? true : false));
							}
						}
						hmUI.showToast({
							text: container_1762045954004_customs[container_1762045954004_selected].label.toString() + ' On'
						});
						vibrateSensor.stop();
						vibrateSensor.scene = 0;
						vibrateSensor.start();
					},
					show_level: hmUI.show_level.ONLY_NORMAL
				});

				container_1762060414232 = hmUI.createWidget(hmUI.widget.BUTTON, {
					x: 310,
					y: 290,
					w: 70,
					h: 70,
					text: "",
					normal_src: '0491.png',
					press_src: '0491.png',
					click_func: () => {
						container_1762060414232_selected = (container_1762060414232_selected+1 > container_1762060414232_customs.length-1) ? 0 : container_1762060414232_selected+1;
						for (let w = 0; w < container_1762060414232_customs.length; w++) {
							for (let z of container_1762060414232_customs[w].widgets) {
								eval(z).setProperty(hmUI.prop.VISIBLE, ((w == container_1762060414232_selected) ? true : false));
							}
						}
						hmUI.showToast({
							text: container_1762060414232_customs[container_1762060414232_selected].label.toString() + ' On'
						});
						vibrateSensor.stop();
						vibrateSensor.scene = 0;
						vibrateSensor.start();
					},
					show_level: hmUI.show_level.ONLY_NORMAL
				});

				container_1762060412254 = hmUI.createWidget(hmUI.widget.BUTTON, {
					x: 204,
					y: 288,
					w: 70,
					h: 70,
					text: "",
					normal_src: '0491.png',
					press_src: '0491.png',
					click_func: () => {
						container_1762060412254_selected = (container_1762060412254_selected+1 > container_1762060412254_customs.length-1) ? 0 : container_1762060412254_selected+1;
						for (let w = 0; w < container_1762060412254_customs.length; w++) {
							for (let z of container_1762060412254_customs[w].widgets) {
								eval(z).setProperty(hmUI.prop.VISIBLE, ((w == container_1762060412254_selected) ? true : false));
							}
						}
						hmUI.showToast({
							text: container_1762060412254_customs[container_1762060412254_selected].label.toString() + ' On'
						});
						vibrateSensor.stop();
						vibrateSensor.scene = 0;
						vibrateSensor.start();
					},
					show_level: hmUI.show_level.ONLY_NORMAL
				});

				container_1762060416564 = hmUI.createWidget(hmUI.widget.BUTTON, {
					x: 100,
					y: 290,
					w: 70,
					h: 70,
					text: "",
					normal_src: '0491.png',
					press_src: '0491.png',
					click_func: () => {
						container_1762060416564_selected = (container_1762060416564_selected+1 > container_1762060416564_customs.length-1) ? 0 : container_1762060416564_selected+1;
						for (let w = 0; w < container_1762060416564_customs.length; w++) {
							for (let z of container_1762060416564_customs[w].widgets) {
								eval(z).setProperty(hmUI.prop.VISIBLE, ((w == container_1762060416564_selected) ? true : false));
							}
						}
						hmUI.showToast({
							text: container_1762060416564_customs[container_1762060416564_selected].label.toString() + ' On'
						});
						vibrateSensor.stop();
						vibrateSensor.scene = 0;
						vibrateSensor.start();
					},
					show_level: hmUI.show_level.ONLY_NORMAL
				});

				container_1762061459828 = hmUI.createWidget(hmUI.widget.BUTTON, {
					x: 130,
					y: 60,
					w: 224,
					h: 50,
					text: "",
					normal_src: '0706.png',
					press_src: '0706.png',
					click_func: () => {
						container_1762061459828_selected = (container_1762061459828_selected+1 > container_1762061459828_customs.length-1) ? 0 : container_1762061459828_selected+1;
						for (let w = 0; w < container_1762061459828_customs.length; w++) {
							for (let z of container_1762061459828_customs[w].widgets) {
								eval(z).setProperty(hmUI.prop.VISIBLE, ((w == container_1762061459828_selected) ? true : false));
							}
						}
						hmUI.showToast({
							text: container_1762061459828_customs[container_1762061459828_selected].label.toString() + ' On'
						});
						vibrateSensor.stop();
						vibrateSensor.scene = 0;
						vibrateSensor.start();
					},
					show_level: hmUI.show_level.ONLY_NORMAL
				});

				container_1762305733715 = hmUI.createWidget(hmUI.widget.BUTTON, {
					x: 160,
					y: 369,
					w: 161,
					h: 30,
					text: "",
					normal_src: '0744.png',
					press_src: '0744.png',
					click_func: () => {
						container_1762305733715_selected = (container_1762305733715_selected+1 > container_1762305733715_customs.length-1) ? 0 : container_1762305733715_selected+1;
						for (let w = 0; w < container_1762305733715_customs.length; w++) {
							for (let z of container_1762305733715_customs[w].widgets) {
								eval(z).setProperty(hmUI.prop.VISIBLE, ((w == container_1762305733715_selected) ? true : false));
							}
						}
						hmUI.showToast({
							text: container_1762305733715_customs[container_1762305733715_selected].label.toString() + ' On'
						});
						vibrateSensor.stop();
						vibrateSensor.scene = 0;
						vibrateSensor.start();
					},
					show_level: hmUI.show_level.ONLY_NORMAL
				});

				function updateTime() {
					normal_date_high_imageset238.setProperty(hmUI.prop.MORE, {
						src: normal_date_high_imageset238_array[(timeSensor.day.toString().length == 2 ? timeSensor.day.toString().charAt(0) : 0)]
					})
					normal_date_low_imageset239.setProperty(hmUI.prop.MORE, {
						src: normal_date_low_imageset239_array[(timeSensor.day.toString().length == 2 ? timeSensor.day.toString().charAt(1) : timeSensor.day.toString().charAt(0))]
					})
					normal_ampm24_imageset453.setProperty(hmUI.prop.MORE, {
						src: normal_ampm24_imageset453_array[(hmSetting.getTimeFormat() == 0 ? (timeSensor.hour >= 0 && timeSensor.hour < 12 ? 0 : 1) : 2)]
					})
					idle_ampm24_imageset479.setProperty(hmUI.prop.MORE, {
						src: idle_ampm24_imageset479_array[(hmSetting.getTimeFormat() == 0 ? (timeSensor.hour >= 0 && timeSensor.hour < 12 ? 0 : 1) : 2)]
					})
					idle_date_high_imageset511.setProperty(hmUI.prop.MORE, {
						src: idle_date_high_imageset511_array[(timeSensor.day.toString().length == 2 ? timeSensor.day.toString().charAt(0) : 0)]
					})
					idle_date_low_imageset512.setProperty(hmUI.prop.MORE, {
						src: idle_date_low_imageset512_array[(timeSensor.day.toString().length == 2 ? timeSensor.day.toString().charAt(1) : timeSensor.day.toString().charAt(0))]
					})
				}

				function updateBattery() {
					normal_battery_first_imageset187.setProperty(hmUI.prop.MORE, {
						src: normal_battery_first_imageset187_array[batterySensor.current.toString().padStart(3, '0').charAt(2)]
					})
					normal_battery_third_imageset188.setProperty(hmUI.prop.MORE, {
						src: normal_battery_third_imageset188_array[batterySensor.current.toString().padStart(3, '0').charAt(0)]
					})
					normal_battery_second_imageset189.setProperty(hmUI.prop.MORE, {
						src: normal_battery_second_imageset189_array[batterySensor.current.toString().padStart(3, '0').charAt(1)]
					})
					idle_battery_first_imageset504.setProperty(hmUI.prop.MORE, {
						src: idle_battery_first_imageset504_array[batterySensor.current.toString().padStart(3, '0').charAt(2)]
					})
					idle_battery_third_imageset505.setProperty(hmUI.prop.MORE, {
						src: idle_battery_third_imageset505_array[batterySensor.current.toString().padStart(3, '0').charAt(0)]
					})
					idle_battery_second_imageset506.setProperty(hmUI.prop.MORE, {
						src: idle_battery_second_imageset506_array[batterySensor.current.toString().padStart(3, '0').charAt(1)]
					})
				}

				function updateHeart() {
					normal_heart_rate_first_imageset177.setProperty(hmUI.prop.MORE, {
						src: normal_heart_rate_first_imageset177_array[heartSensor.last.toString().padStart(3, '0').charAt(2)]
					})
					normal_heart_rate_second_imageset178.setProperty(hmUI.prop.MORE, {
						src: normal_heart_rate_second_imageset178_array[heartSensor.last.toString().padStart(3, '0').charAt(1)]
					})
					normal_heart_rate_third_imageset179.setProperty(hmUI.prop.MORE, {
						src: normal_heart_rate_third_imageset179_array[heartSensor.last.toString().padStart(3, '0').charAt(0)]
					})
					idle_heart_rate_first_imageset494.setProperty(hmUI.prop.MORE, {
						src: idle_heart_rate_first_imageset494_array[heartSensor.last.toString().padStart(3, '0').charAt(2)]
					})
					idle_heart_rate_second_imageset495.setProperty(hmUI.prop.MORE, {
						src: idle_heart_rate_second_imageset495_array[heartSensor.last.toString().padStart(3, '0').charAt(1)]
					})
					idle_heart_rate_third_imageset496.setProperty(hmUI.prop.MORE, {
						src: idle_heart_rate_third_imageset496_array[heartSensor.last.toString().padStart(3, '0').charAt(0)]
					})
				}

				function updateWeather() {
					let forecastData = weatherSensor.getForecastWeather().forecastData;
					normal_weatherplusone_imageset411.setProperty(hmUI.prop.MORE, {
						src: normal_weatherplusone_imageset411_array[typeof forecastData.data[1] != 'undefined' ? forecastData.data[1].index : 25]
					})
					normal_weatherplustwo_imageset412.setProperty(hmUI.prop.MORE, {
						src: normal_weatherplustwo_imageset412_array[typeof forecastData.data[2] != 'undefined' ? forecastData.data[2].index : 25]
					})
					normal_weatherplusthree_imageset413.setProperty(hmUI.prop.MORE, {
						src: normal_weatherplusthree_imageset413_array[typeof forecastData.data[3] != 'undefined' ? forecastData.data[3].index : 25]
					})
					normal_weatherplusfour_imageset414.setProperty(hmUI.prop.MORE, {
						src: normal_weatherplusfour_imageset414_array[typeof forecastData.data[4] != 'undefined' ? forecastData.data[4].index : 0]
					})
					let tideData = weatherSensor.getForecastWeather().tideData;
					normal_sunrise_hours_high_imageset421.setProperty(hmUI.prop.MORE, {
						src: normal_sunrise_hours_high_imageset421_array[tideData.data[0].sunrise.hour.toString().padStart(2, '0').charAt(0)]
					})
					normal_sunrise_hours_low_imageset422.setProperty(hmUI.prop.MORE, {
						src: normal_sunrise_hours_low_imageset422_array[tideData.data[0].sunrise.hour.toString().padStart(2, '0').charAt(1)]
					})
					normal_sunrise_minutes_high_imageset423.setProperty(hmUI.prop.MORE, {
						src: normal_sunrise_minutes_high_imageset423_array[tideData.data[0].sunrise.minute.toString().padStart(2, '0').charAt(0)]
					})
					normal_sunrise_minutes_low_imageset424.setProperty(hmUI.prop.MORE, {
						src: normal_sunrise_minutes_low_imageset424_array[tideData.data[0].sunrise.minute.toString().padStart(2, '0').charAt(1)]
					})
					normal_sunset_hours_high_imageset427.setProperty(hmUI.prop.MORE, {
						src: normal_sunset_hours_high_imageset427_array[tideData.data[0].sunset.hour.toString().padStart(2, '0').charAt(0)]
					})
					normal_sunset_hours_low_imageset428.setProperty(hmUI.prop.MORE, {
						src: normal_sunset_hours_low_imageset428_array[tideData.data[0].sunset.hour.toString().padStart(2, '0').charAt(1)]
					})
					normal_sunset_minutes_high_imageset429.setProperty(hmUI.prop.MORE, {
						src: normal_sunset_minutes_high_imageset429_array[tideData.data[0].sunset.minute.toString().padStart(2, '0').charAt(0)]
					})
					normal_sunset_minutes_low_imageset430.setProperty(hmUI.prop.MORE, {
						src: normal_sunset_minutes_low_imageset430_array[tideData.data[0].sunset.minute.toString().padStart(2, '0').charAt(1)]
					})
				}

				function updateStress() {
					normal_stress_second_imageset183.setProperty(hmUI.prop.MORE, {
						src: normal_stress_second_imageset183_array[stressSensor.current.toString().padStart(3, '0').charAt(1)]
					})
					normal_stress_first_imageset184.setProperty(hmUI.prop.MORE, {
						src: normal_stress_first_imageset184_array[stressSensor.current.toString().padStart(3, '0').charAt(2)]
					})
					normal_stress_third_imageset185.setProperty(hmUI.prop.MORE, {
						src: normal_stress_third_imageset185_array[stressSensor.current.toString().padStart(3, '0').charAt(0)]
					})
					idle_stress_second_imageset490.setProperty(hmUI.prop.MORE, {
						src: idle_stress_second_imageset490_array[stressSensor.current.toString().padStart(3, '0').charAt(1)]
					})
					idle_stress_first_imageset491.setProperty(hmUI.prop.MORE, {
						src: idle_stress_first_imageset491_array[stressSensor.current.toString().padStart(3, '0').charAt(2)]
					})
					idle_stress_third_imageset492.setProperty(hmUI.prop.MORE, {
						src: idle_stress_third_imageset492_array[stressSensor.current.toString().padStart(3, '0').charAt(0)]
					})
				}

				function updateSleep() {
					normal_sleep_hour_high_imageset270.setProperty(hmUI.prop.MORE, {
						src: normal_sleep_hour_high_imageset270_array[Math.floor(sleepSensor.getTotalTime() / 60).toString().padStart(2, '0').charAt(0)]
					})
					normal_sleep_hour_low_imageset271.setProperty(hmUI.prop.MORE, {
						src: normal_sleep_hour_low_imageset271_array[Math.floor(sleepSensor.getTotalTime() / 60).toString().padStart(2, '0').charAt(1)]
					})
					normal_sleep_minute_high_imageset272.setProperty(hmUI.prop.MORE, {
						src: normal_sleep_minute_high_imageset272_array[Math.floor(sleepSensor.getTotalTime() % 60).toString().padStart(2, '0').charAt(0)]
					})
					normal_sleep_minute_low_imageset273.setProperty(hmUI.prop.MORE, {
						src: normal_sleep_minute_low_imageset273_array[Math.floor(sleepSensor.getTotalTime() % 60).toString().padStart(2, '0').charAt(1)]
					})
					normal_sleep_hour_high_imageset324.setProperty(hmUI.prop.MORE, {
						src: normal_sleep_hour_high_imageset324_array[Math.floor(sleepSensor.getTotalTime() / 60).toString().padStart(2, '0').charAt(0)]
					})
					normal_sleep_hour_low_imageset325.setProperty(hmUI.prop.MORE, {
						src: normal_sleep_hour_low_imageset325_array[Math.floor(sleepSensor.getTotalTime() / 60).toString().padStart(2, '0').charAt(1)]
					})
					normal_sleep_minute_high_imageset326.setProperty(hmUI.prop.MORE, {
						src: normal_sleep_minute_high_imageset326_array[Math.floor(sleepSensor.getTotalTime() % 60).toString().padStart(2, '0').charAt(0)]
					})
					normal_sleep_minute_low_imageset327.setProperty(hmUI.prop.MORE, {
						src: normal_sleep_minute_low_imageset327_array[Math.floor(sleepSensor.getTotalTime() % 60).toString().padStart(2, '0').charAt(1)]
					})
					normal_sleep_hour_low_imageset366.setProperty(hmUI.prop.MORE, {
						src: normal_sleep_hour_low_imageset366_array[Math.floor(sleepSensor.getTotalTime() / 60).toString().padStart(2, '0').charAt(1)]
					})
					normal_sleep_minute_high_imageset367.setProperty(hmUI.prop.MORE, {
						src: normal_sleep_minute_high_imageset367_array[Math.floor(sleepSensor.getTotalTime() % 60).toString().padStart(2, '0').charAt(0)]
					})
					normal_sleep_minute_low_imageset368.setProperty(hmUI.prop.MORE, {
						src: normal_sleep_minute_low_imageset368_array[Math.floor(sleepSensor.getTotalTime() % 60).toString().padStart(2, '0').charAt(1)]
					})
					normal_sleep_hour_high_imageset369.setProperty(hmUI.prop.MORE, {
						src: normal_sleep_hour_high_imageset369_array[Math.floor(sleepSensor.getTotalTime() / 60).toString().padStart(2, '0').charAt(0)]
					})
				}

				timeSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateTime();
				});

				batterySensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateBattery();
				});

				heartSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateHeart();
				});

				weatherSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateWeather();
				});

				stressSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateStress();
				});

				sleepSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateSleep();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateTime();
						updateBattery();
						updateHeart();
						updateWeather();
						updateStress();
						updateSleep();
						timeInterval = setInterval(updateTime, 1000);
					}),
					pause_call: (function () {
						clearInterval(timeInterval);
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}