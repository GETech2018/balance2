﻿    /*
    ** Watch_Face_Editor tool v 18.0
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_circle_scale_2 = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_pai_icon_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_date_img_date_month_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_minute_separator_img = ''
        let idle_background_bg = ''
        let idle_battery_icon_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_digital_clock_minute_separator_img = ''
        let idle_step_icon_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 427,
              y: 183,
              src: 'icon_heart_lightgrey.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_circle_scale_2 = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 242,
              center_y: 239,
              start_angle: 60,
              end_angle: 120,
              radius: 233,
              line_width: 15,
              corner_flag: 0,
              type: hmUI.data_type.HEART,
              color: 0xFFD8D6D6,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 388,
              y: 191,
              font_array: ["red_NBatt0001.png","red_NBatt0002.png","red_NBatt0003.png","red_NBatt0004.png","red_NBatt0005.png","red_NBatt0006.png","red_NBatt0007.png","red_NBatt0008.png","red_NBatt0009.png","red_NBatt0010.png"],
              padding: false,
              h_space: -75,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 430,
              y: 253,
              src: 'red_Batt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 244,
              // center_y: 240,
              // start_angle: 60,
              // end_angle: 120,
              // radius: 240,
              // line_width: 10,
              // line_cap: Rounded,
              // color: 0xFF991502,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 244,
              center_y: 240,
              start_angle: 60,
              end_angle: 120,
              radius: 235,
              line_width: 10,
              corner_flag: 0,
              color: 0xFF991502,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 386,
              y: 224,
              font_array: ["red_NBatt0001.png","red_NBatt0002.png","red_NBatt0003.png","red_NBatt0004.png","red_NBatt0005.png","red_NBatt0006.png","red_NBatt0007.png","red_NBatt0008.png","red_NBatt0009.png","red_NBatt0010.png"],
              padding: false,
              h_space: -74,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 434,
              y: 359,
              src: 'red_incon5.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 148,
              day_startY: 400,
              day_sc_array: ["red_Date0001.png","red_Date0002.png","red_Date0003.png","red_Date0004.png","red_Date0005.png","red_Date0006.png","red_Date0007.png","red_Date0008.png","red_Date0009.png","red_Date0010.png"],
              day_tc_array: ["red_Date0001.png","red_Date0002.png","red_Date0003.png","red_Date0004.png","red_Date0005.png","red_Date0006.png","red_Date0007.png","red_Date0008.png","red_Date0009.png","red_Date0010.png"],
              day_en_array: ["red_Date0001.png","red_Date0002.png","red_Date0003.png","red_Date0004.png","red_Date0005.png","red_Date0006.png","red_Date0007.png","red_Date0008.png","red_Date0009.png","red_Date0010.png"],
              day_zero: 1,
              day_space: -74,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 239,
              y: 387,
              src: 'red_Icon2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 138,
              y: 367,
              week_en: ["red_Day0001.png","red_Day0002.png","red_Day0003.png","red_Day0004.png","red_Day0005.png","red_Day0006.png","red_Day0007.png"],
              week_tc: ["red_Day0001.png","red_Day0002.png","red_Day0003.png","red_Day0004.png","red_Day0005.png","red_Day0006.png","red_Day0007.png"],
              week_sc: ["red_Day0001.png","red_Day0002.png","red_Day0003.png","red_Day0004.png","red_Day0005.png","red_Day0006.png","red_Day0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 446,
              y: 239,
              src: 'red_Icon4.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 268,
              y: 379,
              src: 'red_Steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 222,
              y: 400,
              font_array: ["red_Date0001.png","red_Date0002.png","red_Date0003.png","red_Date0004.png","red_Date0005.png","red_Date0006.png","red_Date0007.png","red_Date0008.png","red_Date0009.png","red_Date0010.png"],
              padding: false,
              h_space: -74,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 431,
              y: 118,
              src: 'red_incon5.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 148,
              month_startY: 50,
              month_sc_array: ["red_Month0001.png","red_Month0002.png","red_Month0003.png","red_Month0004.png","red_Month0005.png","red_Month0006.png","red_Month0007.png","red_Month0008.png","red_Month0009.png","red_Month0010.png","red_Month0011.png","red_Month0012.png"],
              month_tc_array: ["red_Month0001.png","red_Month0002.png","red_Month0003.png","red_Month0004.png","red_Month0005.png","red_Month0006.png","red_Month0007.png","red_Month0008.png","red_Month0009.png","red_Month0010.png","red_Month0011.png","red_Month0012.png"],
              month_en_array: ["red_Month0001.png","red_Month0002.png","red_Month0003.png","red_Month0004.png","red_Month0005.png","red_Month0006.png","red_Month0007.png","red_Month0008.png","red_Month0009.png","red_Month0010.png","red_Month0011.png","red_Month0012.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 309,
              am_y: 269,
              am_sc_path: '0041.png',
              am_en_path: '0041.png',
              pm_x: 309,
              pm_y: 269,
              pm_sc_path: '0042.png',
              pm_en_path: '0042.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -96,
              hour_startY: -41,
              hour_array: ["red_HR0001.png","red_HR0002.png","red_HR0003.png","red_HR0004.png","red_HR0005.png","red_HR0006.png","red_HR0007.png","red_HR0008.png","red_HR0009.png","red_HR0010.png"],
              hour_zero: 1,
              hour_space: -459,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 279,
              minute_startY: 285,
              minute_array: ["red_Min0001.png","red_Min0002.png","red_Min0003.png","red_Min0004.png","red_Min0005.png","red_Min0006.png","red_Min0007.png","red_Min0008.png","red_Min0009.png","red_Min0010.png"],
              minute_zero: 1,
              minute_space: -70,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 306,
              y: 352,
              src: 'red_Icon1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 136,
              y: 352,
              src: 'red_Icon1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 162,
              y: -3,
              src: 'Logo_4.51z.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 309,
              am_y: 269,
              am_sc_path: '0041.png',
              am_en_path: '0041.png',
              pm_x: 309,
              pm_y: 269,
              pm_sc_path: '0042.png',
              pm_en_path: '0042.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -96,
              hour_startY: -41,
              hour_array: ["red_HR0001.png","red_HR0002.png","red_HR0003.png","red_HR0004.png","red_HR0005.png","red_HR0006.png","red_HR0007.png","red_HR0008.png","red_HR0009.png","red_HR0010.png"],
              hour_zero: 1,
              hour_space: -459,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 279,
              minute_startY: 285,
              minute_array: ["red_Min0001.png","red_Min0002.png","red_Min0003.png","red_Min0004.png","red_Min0005.png","red_Min0006.png","red_Min0007.png","red_Min0008.png","red_Min0009.png","red_Min0010.png"],
              minute_zero: 1,
              minute_space: -70,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 306,
              y: 438,
              src: 'red_Icon1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 136,
              y: 433,
              src: 'red_Icon1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -50,
              y: 0,
              src: 'Picture69.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 244,
                      center_y: 240,
                      start_angle: 60,
                      end_angle: 120,
                      radius: 235,
                      line_width: 10,
                      corner_flag: 0,
                      color: 0xFF991502,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}