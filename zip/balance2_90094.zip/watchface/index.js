﻿/*
** Watch_Face_Editor tool v 18.1
** watchface js version v2.1.1
** Copyright © SashaCX75. All Rights Reserved
*/

try {
  (() => {
    //start of ignored block
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    function getApp() {
      return __$$app$$__.app;
    }
    function getCurrentPage() {
      return __$$app$$__.current && __$$app$$__.current.module;
    }
    const __$$module$$__ = __$$app$$__.current;
    const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
    const {px} = __$$app$$__.__globals__;
    const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
    //end of ignored block

    //dynamic modify start

    let normal_background_bg_img = ''
    let normal_battery_current_text_font = ''
    let normal_dow_text_font = ''

    // ===== LANGUES (jour de la semaine) =====
    const DOW_FR = ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'];
    const DOW_EN = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    const DOW_ES = ['Lun', 'Mar', 'Mie', 'Jue', 'Vie', 'Sab', 'Dom'];
    const DOW_LIST = [DOW_FR, DOW_EN, DOW_ES];
    const LANG_NAMES = ['Français', 'English', 'Español'];
    let langIndex = 0; // 0 = français, 1 = anglais, 2 = espagnol
    let normal_DOW_Array = DOW_FR;
    let idle_DOW_Array = DOW_FR;
    let Button_Switch_Lang = '';
    // ========================================

    let normal_day_text_font = ''
    let normal_analog_clock_pro_hour_pointer_img = ''
    let normal_analog_clock_pro_minute_pointer_img = ''
    let normal_timerUpdateSec = undefined;
    let normal_analog_clock_pro_second_pointer_img = ''
    let normal_timerUpdateSecSmooth = undefined;
    let lastTime = 0;
    let idle_background_bg_img = ''
	let idle_battery_current_text_font = ''
    let idle_dow_text_font = ''
    let idle_day_text_font = ''
    let idle_analog_clock_pro_hour_pointer_img = ''
    let idle_analog_clock_pro_minute_pointer_img = ''
    let Button_Switch_BG = ''

    let backgroundIndex = 0;
    let backgroundList = ['bg1.png', 'bg7.png', 'bg2.png', 'bg3.png', 'bg4.png', 'bg5.png', 'bg6.png', 'bg8.png'];
    let backgroundToastList = ['1', '2', '3', '4', '5', '6', '7', '8'];
    const watchfaceId = hmApp.packageInfo().watchfaceId;
    let timeSensor = '';

    //dynamic modify end

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        //dynamic modify start
        
        // FontName: steelfish bd it.ttf; FontSize: 30
        hmUI.createWidget(hmUI.widget.TEXT, {
          x: 478,
          y: 478,
          w: 234,
          h: 43,
          text_size: 30,
          char_space: 0,
          line_space: 0,
          font: 'fonts/steelfish bd it.ttf',
          color: 0xFFFFFFFF,
          align_h: hmUI.align.LEFT,
          align_v: hmUI.align.BOTTOM,
          text_style: hmUI.text_style.ELLIPSIS,
          text: "0123456789 _-.,:;`'%°\\/",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // FontName: steelfish bd it.ttf; FontSize: 30; Cache: full
        hmUI.createWidget(hmUI.widget.TEXT, {
          x: 478,
          y: 478,
          w: 36,
          h: 36,
          text_size: 30,
          char_space: 0,
          line_space: 0,
          font: 'fonts/steelfish bd it.ttf',
          color: 0xFFFFFFFF,
          align_h: hmUI.align.RIGHT,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.NONE,
          text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя ҐЄІЇґєії _-.,:;`'%°\\/",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        //#region SwitchBackground
        console.log('SwitchBackground');
        function switchBackground() {
          backgroundIndex++;
          if (backgroundIndex >= backgroundList.length) backgroundIndex = 0;
          hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
          let toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
          if (toastText.length > 0) hmUI.showToast({text: toastText});
          normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
        };
        //#endregion

        //#region SwitchLang
        console.log('SwitchLang');
        function applyLang() {
          normal_DOW_Array = DOW_LIST[langIndex];
          idle_DOW_Array = DOW_LIST[langIndex];
        };

        function switchLang() {
          langIndex++;
          if (langIndex >= DOW_LIST.length) langIndex = 0;
          hmFS.SysProSetInt(`langIndex_${watchfaceId}`, langIndex);
          applyLang();
          time_update(true, false); // met à jour le jour de la semaine
          
          // Affichage du Toast natif Zepp OS (infobulle avec fond semi-transparent)
          hmUI.showToast({ text: LANG_NAMES[langIndex] });
        };
        //#endregion

        console.log('Watch_Face.ScreenNormal');
        normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 480,
          h: 480,
          src: 'bg1.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
          x: 303,
          y: 224,
          w: 150,
          h: 32,
          text_size: 30,
          char_space: 0,
          font: 'fonts/steelfish bd it.ttf',
          color: 0xFFFFFFFF,
          line_space: 0,
          align_v: hmUI.align.BOTTOM,
          text_style: hmUI.text_style.ELLIPSIS,
          align_h: hmUI.align.LEFT,
          unit_type: 1,
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
        timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
          time_update(true);
        });

        normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 104,
          y: 220,
          w: 49,
          h: 32,
          text_size: 30,
          char_space: 0,
          font: 'fonts/steelfish bd it.ttf',
          color: 0xFFFFFFFF,
          line_space: 0,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          align_h: hmUI.align.RIGHT,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 157,
          y: 220,
          w: 22,
          h: 32,
          text_size: 30,
          char_space: 0,
          font: 'fonts/steelfish bd it.ttf',
          color: 0xFFFFFFFF,
          line_space: 0,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        const deviceInfo = hmSetting.getDeviceInfo();
        timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
          let updateHour = timeSensor.minute == 0;
          time_update(updateHour, true);
        });

        normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 240 - 240,
          pos_y: 240 - 240,
          center_x: 240,
          center_y: 240,
          src: 'atom hr.png',
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let screenType = hmSetting.getScreenType();

        normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 240 - 240,
          pos_y: 240 - 240,
          center_x: 240,
          center_y: 240,
          src: 'atom mn.png',
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 240 - 240,
          pos_y: 240 - 240,
          center_x: 240,
          center_y: 240,
          src: 'atom sec.png',
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        function startSecAnim(sec, animDuration) {
          const secAnim = {
            anim_steps: [{
              anim_rate: 'linear',
              anim_duration: animDuration,
              anim_from: sec,
              anim_to: sec + (360*(animDuration*6/1000))/360,
              anim_key: 'angle',
            }],
            anim_fps: 15,
            anim_auto_start: 1,
            anim_repeat: 0,
            anim_auto_destroy: 1,
          }
          normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, secAnim);
        }

        console.log('Watch_Face.ScreenAOD');
        idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 480,
          h: 480,
          src: 'aod.png',
          show_level: hmUI.show_level.ONLY_AOD,
        });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 303,
              y: 224,
              w: 150,
              h: 32,
              text_size: 30,
              char_space: 0,
              font: 'fonts/steelfish bd it.ttf',
              alpha: 200,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });
			
        idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 104,
              y: 220,
              w: 49,
              h: 32,
              text_size: 30,
              char_space: 0,
              font: 'fonts/steelfish bd it.ttf',
              alpha: 200,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 157,
              y: 220,
              w: 22,
              h: 32,
              text_size: 30,
              char_space: 0,
              font: 'fonts/steelfish bd it.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 240 - 240,
          pos_y: 240 - 240,
          center_x: 240,
          center_y: 240,
          src: 'aod hr.png',
          angle: 0,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 240 - 240,
          pos_y: 240 - 240,
          center_x: 240,
          center_y: 240,
          src: 'aod mn.png',
          angle: 0,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        console.log('Watch_Face.SwitchBackground');
        Button_Switch_BG = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 175,
          y: 0,
          w: 137,
          h: 150,
          text: '',
          color: 0xFFFF8C00,
          text_size: 25,
          press_src: 'dot.png',
          normal_src: 'dot.png',
          click_func: (button_widget) => {
            switchBackground();
          }, // end func
          show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        console.log('Watch_Face.SwitchLang');
        // Bouton de langue : posé sur le jour de la semaine + numéro du jour
        Button_Switch_Lang = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 100,
          y: 214,
          w: 85,
          h: 44,
          text: '',
          color: 0xFFFFFFFF,
          text_size: 18,
          press_src: 'dot.png',
          normal_src: 'dot.png',
          click_func: (button_widget) => {
            switchLang();
          }, // end func
          show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        //#region time_update
        function time_update(updateHour = false, updateMinute = false) {
          console.log('time_update()');
          let hour = timeSensor.hour;
          let minute = timeSensor.minute;
          let second = timeSensor.second;
          let format_hour = timeSensor.format_hour;

          console.log('day of week font');
          if (updateHour) {
            let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
            normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
          };

          console.log('day font');
          if (updateHour) {
            let normal_dayStr = timeSensor.day.toString();
            normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
          };

          if (updateMinute) { // Hour Pointer
            let normal_hour = hour;
            let normal_fullAngle_hour = 360;
            if (normal_hour > 11) normal_hour -= 12;
            let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
            if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
          };

          let normal_fullAngle_minute = 360;
          let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
          if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);

          console.log('day of week font');
          if (updateHour) {
            let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
            idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
          };

          console.log('day font');
          if (updateHour) {
            let idle_dayStr = timeSensor.day.toString();
            idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
          };

          if (updateMinute) { // Hour Pointer
            let idle_hour = hour;
            let idle_fullAngle_hour = 360;
            if (idle_hour > 11) idle_hour -= 12;
            let idle_angle_hour = 0 + idle_fullAngle_hour*idle_hour/12 + (idle_fullAngle_hour/12)*minute/60;
            if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
          };

          if (updateMinute) { // Minute Pointer
            let idle_fullAngle_minute = 360;
            let idle_angle_minute = 0 + idle_fullAngle_minute*minute/60;
            if (idle_analog_clock_pro_minute_pointer_img) idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_minute);
          };

        };

        //#endregion
        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: (function () {
            console.log('resume_call()');

            // Restauration de la langue mémorisée (avant time_update)
            if (hmFS.SysProGetInt(`langIndex_${watchfaceId}`) === undefined) {
              langIndex = 0;
              hmFS.SysProSetInt(`langIndex_${watchfaceId}`, langIndex);
            } else {
              langIndex = hmFS.SysProGetInt(`langIndex_${watchfaceId}`);
              if (langIndex < 0 || langIndex >= DOW_LIST.length) langIndex = 0;
            };
            applyLang();

            time_update(true, true);
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              if (!normal_timerUpdateSec) {
                let animDelay = timeSensor.utc % 1000;
                let animRepeat = 1000;
                normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                  time_update(false, true);
                }));  // end timer 
              };  // end timer check
            };  // end screenType

            let secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
            normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, secAngle);
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              if (!normal_timerUpdateSecSmooth) {
                let duration = 0;
                let animDuration = 5000;
                if (timeSensor.second > 55) animDuration = 1000*(60.1 - (timeSensor.second - (timeSensor.utc % 1000) / 1000));
                let diffTime = timeSensor.utc - lastTime;
                if (diffTime < animDuration) duration = animDuration - diffTime;
                normal_timerUpdateSecSmooth = timer.createTimer(duration, animDuration, (function (option) {
                  lastTime = timeSensor.utc;
                  secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                  startSecAnim(secAngle, animDuration);
                }));  // end timer 
              };  // end timer check
            };  // end screenType


            //SwitchBackground
            if (hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`) === undefined) {
              backgroundIndex = 0;
              hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
            } else {
              backgroundIndex = hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`);
            };
            if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg_img) normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
          }),
          pause_call: (function () {
            console.log('pause_call()');
            if (normal_timerUpdateSec) {
              timer.stopTimer(normal_timerUpdateSec);
              normal_timerUpdateSec = undefined;
            }
            if (normal_timerUpdateSecSmooth) {
              timer.stopTimer(normal_timerUpdateSecSmooth);
              normal_timerUpdateSecSmooth = undefined;
            }
          }),
        });

        //dynamic modify end
      },
      onInit() {
        logger.log('index page.js on init invoke');
      },
      build() {
        this.init_view();
        logger.log('index page.js on ready invoke');
      },
      onDestroy() {
        logger.log('index page.js on destroy invoke');
      }
    });
  })();
} catch (e) {
  console.log('Mini Program Error', e);
  e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
}