﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_widget_text_1 = ''
        let normal_widget_text_2 = ''
        let normal_widget_text_3 = ''
        let normal_widget_text_4 = ''
        let normal_sleep_time_font = ''
        let normal_alarm_clock_current_text_font = ''
        let normal_system_disconnect_img = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['Lunedì', 'Martedì', 'Mercoledì', 'Giovedì', 'Venerdì', 'Sabato', 'Domenica'];
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''
        let normal_month_name_font = ''
        let normal_Month_Array = ['Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno', 'Lugli', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre', ];
        let normal_day_text_font = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_heart_rate_text_font = ''
        let normal_distance_current_text_font = ''
        let normal_step_current_text_font = ''
        let normal_step_image_progress_img_level = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_current_text_font = ''
        let normal_bio_charge_image_progress_img_level = ''
        let normal_bio_charge_current_text_font = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_widget_text_1 = ''
        let idle_widget_text_2 = ''
        let idle_widget_text_3 = ''
        let idle_widget_text_4 = ''
        let idle_sleep_time_font = ''
        let idle_alarm_clock_current_text_font = ''
        let idle_system_disconnect_img = ''
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['Lunedì', 'Martedì', 'Mercoledì', 'Giovedì', 'Venerdì', 'Sabato', 'Domenica'];
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_font = ''
        let idle_month_name_font = ''
        let idle_Month_Array = ['Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno', 'Lugli', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre', ];
        let idle_day_text_font = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_heart_rate_text_font = ''
        let idle_distance_current_text_font = ''
        let idle_step_current_text_font = ''
        let idle_step_image_progress_img_level = ''
        let idle_battery_image_progress_img_level = ''
        let idle_battery_current_text_font = ''
        let idle_bio_charge_image_progress_img_level = ''
        let idle_bio_charge_current_text_font = ''
        let idle_digital_clock_img_time = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_walking_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let timeSensor = '';
        let sleepSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'background BIS.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_1 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 25,
              y: 21,
              w: 428,
              h: 428,
              text_size: 25,
              char_space: 3,
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: -65,
              end_angle: 71,
              mode: 0,
              // radius: 214,
              align_h: hmUI.align.CENTER_H,
              text: 'BIOCHARGE',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_2 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 138,
              y: 87,
              w: 322,
              h: 322,
              text_size: 25,
              char_space: 3,
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 68,
              end_angle: 132,
              mode: 1,
              // radius: 161,
              align_h: hmUI.align.CENTER_H,
              text: 'BATTITI',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_3 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 22,
              y: 104,
              w: 308,
              h: 308,
              text_size: 25,
              char_space: 3,
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 237,
              end_angle: 279,
              mode: 0,
              // radius: 154,
              align_h: hmUI.align.CENTER_H,
              text: 'PASSI',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_4 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 30,
              y: 46,
              w: 412,
              h: 412,
              text_size: 25,
              char_space: 3,
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 150,
              end_angle: 218,
              mode: 1,
              // radius: 206,
              align_h: hmUI.align.CENTER_H,
              text: 'BATTERIA',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_time_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 212,
              y: 332,
              w: 150,
              h: 65,
              text_size: 35,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 279,
              y: 332,
              w: 150,
              h: 51,
              text_size: 35,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 228,
              y: 388,
              src: 'st_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 64,
              y: 129,
              w: 150,
              h: 54,
              text_size: 30,
              char_space: 0,
              color: 0xFFDDC7A6,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: Lunedì,Martedì,Mercoledì,Giovedì,Venerdì,Sabato,Domenica,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 206,
              y: 59,
              image_array: ["75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png","103.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 311,
              y: 80,
              w: 150,
              h: 65,
              text_size: 37,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 259,
              y: 129,
              w: 150,
              h: 70,
              text_size: 30,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: Gennaio,Febbraio,Marzo,Aprile,Maggio,Giugno,Lugli,Agosto,Settembre,Ottobre,Novembre,Dicembre,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 165,
              y: 125,
              w: 150,
              h: 50,
              text_size: 34,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 438,
              y: 139,
              image_array: ["battbar_1.png","battbar_2.png","battbar_3.png","battbar_4.png","battbar_5.png","battbar_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 153,
              y: 59,
              w: 300,
              h: 300,
              text_size: 25,
              char_space: 3,
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: -25,
              end_angle: 180,
              mode: 1,
              // radius: 150,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 53,
              y: 332,
              w: 150,
              h: 51,
              text_size: 35,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 24,
              y: 40,
              w: 364,
              h: 364,
              text_size: 25,
              char_space: 2,
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: -257,
              end_angle: 184,
              mode: 0,
              // radius: 182,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 5,
              y: 136,
              image_array: ["hrvbar_1.png","hrvbar_2.png","hrvbar_3.png","hrvbar_4.png","hrvbar_5.png","hrvbar_6.png","hrvbar_7.png","hrvbar_8.png","hrvbar_9.png","hrvbar_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 83,
              y: 403,
              image_array: ["bpmbar_1.png","bpmbar_2.png","bpmbar_3.png","bpmbar_4.png","bpmbar_5.png","bpmbar_6.png","bpmbar_7.png","bpmbar_8.png","bpmbar_9.png","bpmbar_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 108,
              y: 156,
              w: 300,
              h: 300,
              text_size: 25,
              char_space: 3,
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 89,
              end_angle: 204,
              mode: 1,
              // radius: 150,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 84,
              y: 4,
              image_array: ["biobar_1.png","biobar_2.png","biobar_3.png","biobar_4.png","biobar_5.png","biobar_6.png","biobar_7.png","biobar_8.png","biobar_9.png","biobar_10.png"],
              image_length: 10,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 124,
              y: 40,
              w: 338,
              h: 338,
              text_size: 25,
              char_space: 0,
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: -130,
              end_angle: 180,
              mode: 0,
              // radius: 169,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 70,
              hour_startY: 189,
              hour_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'colon.png',
              hour_unit_tc: 'colon.png',
              hour_unit_en: 'colon.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 257,
              minute_startY: 189,
              minute_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'background BIS.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_widget_text_1 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 29,
              y: 24,
              w: 412,
              h: 412,
              text_size: 25,
              char_space: 3,
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: -96,
              end_angle: 74,
              mode: 0,
              // radius: 206,
              align_h: hmUI.align.CENTER_H,
              text: 'BIOCHARGE',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_widget_text_2 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 138,
              y: 87,
              w: 322,
              h: 322,
              text_size: 25,
              char_space: 3,
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 68,
              end_angle: 132,
              mode: 1,
              // radius: 161,
              align_h: hmUI.align.CENTER_H,
              text: 'BATTITI',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_widget_text_3 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 22,
              y: 104,
              w: 308,
              h: 308,
              text_size: 25,
              char_space: 3,
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 237,
              end_angle: 279,
              mode: 0,
              // radius: 154,
              align_h: hmUI.align.CENTER_H,
              text: 'PASSI',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_widget_text_4 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 30,
              y: 46,
              w: 412,
              h: 412,
              text_size: 25,
              char_space: 3,
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 150,
              end_angle: 218,
              mode: 1,
              // radius: 206,
              align_h: hmUI.align.CENTER_H,
              text: 'BATTERIA',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sleep_time_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 212,
              y: 332,
              w: 150,
              h: 65,
              text_size: 35,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_alarm_clock_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 279,
              y: 332,
              w: 150,
              h: 51,
              text_size: 35,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 228,
              y: 388,
              src: 'st_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 64,
              y: 129,
              w: 150,
              h: 54,
              text_size: 30,
              char_space: 0,
              color: 0xFFDDC7A6,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: Lunedì,Martedì,Mercoledì,Giovedì,Venerdì,Sabato,Domenica,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 206,
              y: 59,
              image_array: ["75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png","103.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 323,
              y: 71,
              w: 150,
              h: 65,
              text_size: 35,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 259,
              y: 129,
              w: 150,
              h: 70,
              text_size: 30,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: Gennaio,Febbraio,Marzo,Aprile,Maggio,Giugno,Lugli,Agosto,Settembre,Ottobre,Novembre,Dicembre,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 165,
              y: 125,
              w: 150,
              h: 50,
              text_size: 34,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 438,
              y: 139,
              image_array: ["battbar_1.png","battbar_2.png","battbar_3.png","battbar_4.png","battbar_5.png","battbar_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 153,
              y: 59,
              w: 300,
              h: 300,
              text_size: 25,
              char_space: 3,
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: -25,
              end_angle: 180,
              mode: 1,
              // radius: 150,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 53,
              y: 332,
              w: 150,
              h: 51,
              text_size: 35,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 24,
              y: 40,
              w: 364,
              h: 364,
              text_size: 25,
              char_space: 2,
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: -257,
              end_angle: 184,
              mode: 0,
              // radius: 182,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 5,
              y: 136,
              image_array: ["hrvbar_1.png","hrvbar_2.png","hrvbar_3.png","hrvbar_4.png","hrvbar_5.png","hrvbar_6.png","hrvbar_7.png","hrvbar_8.png","hrvbar_9.png","hrvbar_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 83,
              y: 403,
              image_array: ["bpmbar_1.png","bpmbar_2.png","bpmbar_3.png","bpmbar_4.png","bpmbar_5.png","bpmbar_6.png","bpmbar_7.png","bpmbar_8.png","bpmbar_9.png","bpmbar_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 108,
              y: 156,
              w: 300,
              h: 300,
              text_size: 25,
              char_space: 3,
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 89,
              end_angle: 204,
              mode: 1,
              // radius: 150,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_bio_charge_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 84,
              y: 4,
              image_array: ["biobar_1.png","biobar_2.png","biobar_3.png","biobar_4.png","biobar_5.png","biobar_6.png","biobar_7.png","biobar_8.png","biobar_9.png","biobar_10.png"],
              image_length: 10,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_bio_charge_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 92,
              y: 28,
              w: 338,
              h: 338,
              text_size: 25,
              char_space: 0,
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: -134,
              end_angle: 180,
              mode: 0,
              // radius: 169,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 70,
              hour_startY: 189,
              hour_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'colon.png',
              hour_unit_tc: 'colon.png',
              hour_unit_en: 'colon.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 257,
              minute_startY: 189,
              minute_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: BT Scollegato,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: BT Collegato,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "BT Scollegato"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "BT Collegato"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            //#region vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            //#endregion
            console.log('Watch_Face.Shortcuts');

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 302,
              w: 106,
              h: 90,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_walking_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 74,
              y: 301,
              w: 112,
              h: 90,
              type: hmUI.data_type.WALKING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 5,
              y: 133,
              w: 60,
              h: 214,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 417,
              y: 138,
              w: 124,
              h: 211,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 104,
              y: 397,
              w: 288,
              h: 104,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 155,
              y: 72,
              w: 215,
              h: 56,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 299,
              y: 302,
              w: 103,
              h: 89,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 84,
              y: 131,
              w: 320,
              h: 51,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'todoListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 261,
              y: 185,
              w: 152,
              h: 115,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ClubCardsScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 72,
              y: 185,
              w: 152,
              h: 115,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AppListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 95,
              y: 12,
              w: 299,
              h: 56,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BioChargeHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('month font');
              if (updateHour) {
                let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );
              };

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

              console.log('month font');
              if (updateHour) {
                let idle_Month_Str = idle_Month_Array[timeSensor.month-1];
                idle_month_name_font.setProperty(hmUI.prop.TEXT, idle_Month_Str );
              };

              console.log('day font');
              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };

            };

            //#endregion
            if (!sleepSensor) sleepSensor = hmSensor.createSensor(hmSensor.id.SLEEP);
            //#region sleep_update
            function sleep_update() {
              console.log('sleep_update()');

              console.log('sleep duration time');
              let sleepTime = sleepSensor.getTotalTime();
              const modelData = sleepSensor.getSleepStageModel();
              let sleepStageArray = sleepSensor.getSleepStageData();
              let wakeupTime = 0;
              let wakeupCount = 0;

              for (let i = 0; i < sleepStageArray.length; i++) {
                let data = sleepStageArray[i];
                if (data.model == modelData.WAKE_STAGE) {
                  wakeupTime += data.stop + 1 - data.start;
                  wakeupCount++;
                };
              };
              sleepTime -= wakeupTime;
              let sleepTimeHour = Math.floor(sleepTime / 60);
              let sleepTimeMin = sleepTime % 60;

              let normal_sleepTimeHourStr = sleepTimeHour.toString();
              let normal_sleepTimeMinStr = sleepTimeMin.toString().padStart(2, '0');
              let normal_sleepTimeStr = normal_sleepTimeHourStr + ':' + normal_sleepTimeMinStr;
              if (normal_sleep_time_font) normal_sleep_time_font.setProperty(hmUI.prop.TEXT, normal_sleepTimeStr);

              console.log('sleep duration time');
              let idle_sleepTimeHourStr = sleepTimeHour.toString();
              let idle_sleepTimeMinStr = sleepTimeMin.toString().padStart(2, '0');
              let idle_sleepTimeStr = idle_sleepTimeHourStr + ':' + idle_sleepTimeMinStr;
              if (idle_sleep_time_font) idle_sleep_time_font.setProperty(hmUI.prop.TEXT, idle_sleepTimeStr);

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                sleep_update();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}