﻿    /*
    ** Watch_Face_Editor tool v 18.1
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_hour_tens_img = ''
        let normal_hour_ones_img = ''
        let normal_minute_tens_img = ''
        let normal_minute_ones_img = ''
        let timeSensor = ''
        let normal_time_widget_delegate = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'fond.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // Clock: four digit images. Each slot has its own colour set so the
            // pink/aqua gradient runs across the row; rows are centred on real widths.
            const digit_width = [103, 68, 102, 97, 109, 100, 94, 92, 103, 98];
            const digit_height = 128;
            const digit_gap = 9;
            const hour_y = 102;
            const minute_y = 250;

            normal_hour_tens_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 120, y: hour_y, src: 'ht_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_hour_ones_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 240, y: hour_y, src: 'ho_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_minute_tens_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 120, y: minute_y, src: 'mt_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_minute_ones_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 240, y: minute_y, src: 'mo_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function place_row(left_img, right_img, d1, d2, y, left_prefix, right_prefix) {
              const w1 = digit_width[d1];
              const w2 = digit_width[d2];
              const x = 240 - Math.round((w1 + digit_gap + w2) / 2);
              left_img.setProperty(hmUI.prop.MORE, { x: x, y: y, w: w1, h: digit_height, src: left_prefix + d1 + '.png' });
              right_img.setProperty(hmUI.prop.MORE, { x: x + w1 + digit_gap, y: y, w: w2, h: digit_height, src: right_prefix + d2 + '.png' });
            }

            function time_update() {
              if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
              const hour = timeSensor.format_hour;   // follows the watch's 12/24 h setting
              const minute = timeSensor.minute;
              place_row(normal_hour_tens_img, normal_hour_ones_img, Math.floor(hour / 10), hour % 10, hour_y, 'ht_', 'ho_');
              place_row(normal_minute_tens_img, normal_minute_ones_img, Math.floor(minute / 10), minute % 10, minute_y, 'mt_', 'mo_');
            }

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function () {
              time_update();
            });

            normal_time_widget_delegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                time_update();
              }),
            });

            time_update();


            console.log('Watch_Face.ScreenAOD');

            console.log('Watch_Face.Shortcuts');

            console.log('Watch_Face.Buttons');
                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}