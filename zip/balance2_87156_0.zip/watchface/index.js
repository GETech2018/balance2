﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_step_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_step_current_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_battery_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let Button_Switch_BG = ''

        let backgroundIndex = 0;
        let backgroundList = ['Quadrante_00.png', 'Quadrante_01.png', 'Quadrante_02.png'];
        let backgroundToastList = ['Sfondo %s', 'Sfondo %s', 'Sfondo %s'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            //#region SwitchBackground
            console.log('SwitchBackground');
            function switchBackground() {
              backgroundIndex++;
              if (backgroundIndex >= backgroundList.length) backgroundIndex = 0;
              hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
              let toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
              vibro(28);
            };
            //#endregion

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Quadrante_00.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 351,
              y: 197,
              src: 'Off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 348,
              y: 178,
              src: 'AL.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 137,
              y: 132,
              font_array: ["Nr.Att_00.png","Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 161,
              y: 76,
              font_array: ["Nr.Att_00.png","Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png"],
              padding: false,
              h_space: 2,
              dot_image: 'Nr.Att_10.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 170,
              y: 23,
              font_array: ["Nr.Att_00.png","Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 23,
              y: 318,
              font_array: ["Nr.Sist_00.png","Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 353,
              y: 318,
              font_array: ["Nr.Sist_00.png","Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png"],
              padding: false,
              h_space: 3,
              invalid_image: 'Nr.Sist_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 150,
              y: 377,
              image_array: ["weatherd_00.png","weatherd_01.png","weatherd_02.png","weatherd_03.png","weatherd_04.png","weatherd_05.png","weatherd_06.png","weatherd_07.png","weatherd_08.png","weatherd_09.png","weatherd_10.png","weatherd_11.png","weatherd_12.png","weatherd_13.png","weatherd_14.png","weatherd_15.png","weatherd_16.png","weatherd_17.png","weatherd_18.png","weatherd_19.png","weatherd_20.png","weatherd_21.png","weatherd_22.png","weatherd_23.png","weatherd_24.png","weatherd_25.png","weatherd_26.png","weatherd_27.png","weatherd_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 401,
              font_array: ["Nr.Sist_00.png","Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Nr.Sist_11.png',
              unit_tc: 'Nr.Sist_11.png',
              unit_en: 'Nr.Sist_11.png',
              imperial_unit_sc: 'Nr.Sist_11.png',
              imperial_unit_tc: 'Nr.Sist_11.png',
              imperial_unit_en: 'Nr.Sist_11.png',
              negative_image: 'Nr.Sist_10.png',
              invalid_image: 'Nr.Sist_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 216,
                y: 401,
                font_array: ["Nr.Sist_00.png","Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png"],
                padding: false,
                h_space: 3,
                unit_sc: 'Nr.Sist_11.png',
                unit_tc: 'Nr.Sist_11.png',
                unit_en: 'Nr.Sist_11.png',
                imperial_unit_sc: 'Nr.Sist_11.png',
                imperial_unit_tc: 'Nr.Sist_11.png',
                imperial_unit_en: 'Nr.Sist_11.png',
                negative_image: 'Nr.Sist_10.png',
                invalid_image: 'Nr.Sist_12.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 373,
              day_startY: 249,
              day_sc_array: ["Num Giorno_00.png","Num Giorno_01.png","Num Giorno_02.png","Num Giorno_03.png","Num Giorno_04.png","Num Giorno_05.png","Num Giorno_06.png","Num Giorno_07.png","Num Giorno_08.png","Num Giorno_09.png"],
              day_tc_array: ["Num Giorno_00.png","Num Giorno_01.png","Num Giorno_02.png","Num Giorno_03.png","Num Giorno_04.png","Num Giorno_05.png","Num Giorno_06.png","Num Giorno_07.png","Num Giorno_08.png","Num Giorno_09.png"],
              day_en_array: ["Num Giorno_00.png","Num Giorno_01.png","Num Giorno_02.png","Num Giorno_03.png","Num Giorno_04.png","Num Giorno_05.png","Num Giorno_06.png","Num Giorno_07.png","Num Giorno_08.png","Num Giorno_09.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 383,
              month_startY: 192,
              month_sc_array: ["Mese_00.png","Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png"],
              month_tc_array: ["Mese_00.png","Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png"],
              month_en_array: ["Mese_00.png","Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 146,
              y: 310,
              week_en: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              week_tc: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              week_sc: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 12,
              hour_startY: 187,
              hour_array: ["Ore_00.png","Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 202,
              minute_startY: 187,
              minute_array: ["Ore_00.png","Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,


              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Quadrante_00.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 351,
              y: 197,
              src: 'Off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 348,
              y: 178,
              src: 'AL.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 137,
              y: 132,
              font_array: ["Nr.Att_00.png","Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 161,
              y: 76,
              font_array: ["Nr.Att_00.png","Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png"],
              padding: false,
              h_space: 2,
              dot_image: 'Nr.Att_10.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 170,
              y: 23,
              font_array: ["Nr.Att_00.png","Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 23,
              y: 318,
              font_array: ["Nr.Sist_00.png","Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 353,
              y: 318,
              font_array: ["Nr.Sist_00.png","Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png"],
              padding: false,
              h_space: 3,
              invalid_image: 'Nr.Sist_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 150,
              y: 377,
              image_array: ["weatherd_00.png","weatherd_01.png","weatherd_02.png","weatherd_03.png","weatherd_04.png","weatherd_05.png","weatherd_06.png","weatherd_07.png","weatherd_08.png","weatherd_09.png","weatherd_10.png","weatherd_11.png","weatherd_12.png","weatherd_13.png","weatherd_14.png","weatherd_15.png","weatherd_16.png","weatherd_17.png","weatherd_18.png","weatherd_19.png","weatherd_20.png","weatherd_21.png","weatherd_22.png","weatherd_23.png","weatherd_24.png","weatherd_25.png","weatherd_26.png","weatherd_27.png","weatherd_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 401,
              font_array: ["Nr.Sist_00.png","Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Nr.Sist_11.png',
              unit_tc: 'Nr.Sist_11.png',
              unit_en: 'Nr.Sist_11.png',
              imperial_unit_sc: 'Nr.Sist_11.png',
              imperial_unit_tc: 'Nr.Sist_11.png',
              imperial_unit_en: 'Nr.Sist_11.png',
              negative_image: 'Nr.Sist_10.png',
              invalid_image: 'Nr.Sist_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //#region temperatureUnit
            if (temperatureUnit == 1) {
              idle_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 216,
                y: 401,
                font_array: ["Nr.Sist_00.png","Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png"],
                padding: false,
                h_space: 3,
                unit_sc: 'Nr.Sist_11.png',
                unit_tc: 'Nr.Sist_11.png',
                unit_en: 'Nr.Sist_11.png',
                imperial_unit_sc: 'Nr.Sist_11.png',
                imperial_unit_tc: 'Nr.Sist_11.png',
                imperial_unit_en: 'Nr.Sist_11.png',
                negative_image: 'Nr.Sist_10.png',
                invalid_image: 'Nr.Sist_12.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //#endregion

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 373,
              day_startY: 249,
              day_sc_array: ["Num Giorno_00.png","Num Giorno_01.png","Num Giorno_02.png","Num Giorno_03.png","Num Giorno_04.png","Num Giorno_05.png","Num Giorno_06.png","Num Giorno_07.png","Num Giorno_08.png","Num Giorno_09.png"],
              day_tc_array: ["Num Giorno_00.png","Num Giorno_01.png","Num Giorno_02.png","Num Giorno_03.png","Num Giorno_04.png","Num Giorno_05.png","Num Giorno_06.png","Num Giorno_07.png","Num Giorno_08.png","Num Giorno_09.png"],
              day_en_array: ["Num Giorno_00.png","Num Giorno_01.png","Num Giorno_02.png","Num Giorno_03.png","Num Giorno_04.png","Num Giorno_05.png","Num Giorno_06.png","Num Giorno_07.png","Num Giorno_08.png","Num Giorno_09.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 383,
              month_startY: 192,
              month_sc_array: ["Mese_00.png","Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png"],
              month_tc_array: ["Mese_00.png","Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png"],
              month_en_array: ["Mese_00.png","Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 146,
              y: 310,
              week_en: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              week_tc: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              week_sc: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 12,
              hour_startY: 187,
              hour_array: ["Ore_00.png","Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 202,
              minute_startY: 187,
              minute_array: ["Ore_00.png","Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,


              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.SwitchBackground');
            // Button_Switch_BG = hmUI.createWidget(hmUI.widget.SwitchBackground, {
              // x: 134,
              // y: 172,
              // w: 100,
              // h: 150,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // press_src: 'Tasto_00.png',
              // normal_src: 'Tasto_00.png',
              // bg_list: Quadrante_00|Quadrante_01|Quadrante_02,
              // toast_list: Sfondo %s|Sfondo %s|Sfondo %s,
              // use_crown: False,
              // use_in_AOD: True,
              // vibro: True,
            // });

            Button_Switch_BG = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 134,
              y: 172,
              w: 100,
              h: 150,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Tasto_00.png',
              normal_src: 'Tasto_00.png',
              click_func: (button_widget) => {
                switchBackground();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            //#region vibrate function
            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;

            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            //#endregion

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');

                //SwitchBackground
                if (hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`) === undefined) {
                  backgroundIndex = 0;
                  hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
                } else {
                  backgroundIndex = hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg_img) normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
                if (screenType == hmSetting.screen_type.AOD && idle_background_bg_img) idle_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}