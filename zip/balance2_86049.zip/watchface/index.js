﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_pointer_progress_img_pointer = ''
        let normal_stress_text_text_img = ''
        let normal_stress_image_progress_img_level = ''
        let normal_bio_charge_text_text_img = ''
        let normal_bio_charge_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_distance_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_fat_burning_pointer_progress_img_pointer = ''
        let normal_fat_burning_current_text_img = ''
        let normal_calorie_pointer_progress_img_pointer = ''
        let normal_calorie_current_text_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''
        let Button_1 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 155,
              y: 70,
              font_array: ["batt_0.png","batt_1.png","batt_2.png","batt_3.png","batt_4.png","batt_5.png","batt_6.png","batt_7.png","batt_8.png","batt_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dots.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 255,
              y: 70,
              font_array: ["batt_0.png","batt_1.png","batt_2.png","batt_3.png","batt_4.png","batt_5.png","batt_6.png","batt_7.png","batt_8.png","batt_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dots.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'sunmoon_sun.png',
              center_x: 240,
              center_y: 125,
              x: 24,
              y: 128,
              start_angle: -42,
              end_angle: 42,
              invalid_visible: false,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 45,
              y: 109,
              font_array: ["batt_0.png","batt_1.png","batt_2.png","batt_3.png","batt_4.png","batt_5.png","batt_6.png","batt_7.png","batt_8.png","batt_9.png"],
              padding: false,
              h_space: 0,
              angle: -54,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 14,
              y: 127,
              image_array: ["stress_1.png","stress_2.png","stress_3.png","stress_4.png","stress_5.png","stress_6.png","stress_7.png","stress_8.png","stress_9.png","stress_10.png"],
              image_length: 10,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 392,
              y: 86,
              font_array: ["batt_0.png","batt_1.png","batt_2.png","batt_3.png","batt_4.png","batt_5.png","batt_6.png","batt_7.png","batt_8.png","batt_9.png"],
              padding: false,
              h_space: 0,
              angle: 54,
              invalid_image: 'none.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 418,
              y: 127,
              image_array: ["bio_1.png","bio_2.png","bio_3.png","bio_4.png","bio_5.png","bio_6.png","bio_7.png","bio_8.png","bio_9.png","bio_10.png"],
              image_length: 10,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 316,
              y: 425,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 138,
              y: 425,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 206,
              y: 372,
              font_array: ["batt_0.png","batt_1.png","batt_2.png","batt_3.png","batt_4.png","batt_5.png","batt_6.png","batt_7.png","batt_8.png","batt_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 68,
              y: 155,
              font_array: ["batt_0.png","batt_1.png","batt_2.png","batt_3.png","batt_4.png","batt_5.png","batt_6.png","batt_7.png","batt_8.png","batt_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 373,
              y: 155,
              font_array: ["batt_0.png","batt_1.png","batt_2.png","batt_3.png","batt_4.png","batt_5.png","batt_6.png","batt_7.png","batt_8.png","batt_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'img_track_start.png',
              center_x: 352,
              center_y: 311,
              x: 11,
              y: 57,
              start_angle: -136,
              end_angle: 137,
              invalid_visible: false,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 328,
              y: 300,
              font_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'img_track_start.png',
              center_x: 128,
              center_y: 311,
              x: 11,
              y: 57,
              start_angle: -136,
              end_angle: 136,
              invalid_visible: false,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 93,
              y: 300,
              font_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'img_track_start.png',
              center_x: 239,
              center_y: 299,
              x: 11,
              y: 57,
              start_angle: -136,
              end_angle: 136,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 203,
              y: 290,
              font_array: ["batt_0.png","batt_1.png","batt_2.png","batt_3.png","batt_4.png","batt_5.png","batt_6.png","batt_7.png","batt_8.png","batt_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 80,
              y: 393,
              image_array: ["step_1.png","step_2.png","step_3.png","step_4.png","step_5.png","step_6.png","step_7.png","step_8.png","step_9.png","step_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 397,
              month_startY: 210,
              month_sc_array: ["batt_0.png","batt_1.png","batt_2.png","batt_3.png","batt_4.png","batt_5.png","batt_6.png","batt_7.png","batt_8.png","batt_9.png"],
              month_tc_array: ["batt_0.png","batt_1.png","batt_2.png","batt_3.png","batt_4.png","batt_5.png","batt_6.png","batt_7.png","batt_8.png","batt_9.png"],
              month_en_array: ["batt_0.png","batt_1.png","batt_2.png","batt_3.png","batt_4.png","batt_5.png","batt_6.png","batt_7.png","batt_8.png","batt_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 55,
              day_startY: 210,
              day_sc_array: ["batt_0.png","batt_1.png","batt_2.png","batt_3.png","batt_4.png","batt_5.png","batt_6.png","batt_7.png","batt_8.png","batt_9.png"],
              day_tc_array: ["batt_0.png","batt_1.png","batt_2.png","batt_3.png","batt_4.png","batt_5.png","batt_6.png","batt_7.png","batt_8.png","batt_9.png"],
              day_en_array: ["batt_0.png","batt_1.png","batt_2.png","batt_3.png","batt_4.png","batt_5.png","batt_6.png","batt_7.png","batt_8.png","batt_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 98,
              y: 204,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 113,
              hour_startY: 102,
              hour_array: ["hour_0.png","hour_1.png","hour_2.png","hour_3.png","hour_4.png","hour_5.png","hour_6.png","hour_7.png","hour_8.png","hour_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'colon.png',
              hour_unit_tc: 'colon.png',
              hour_unit_en: 'colon.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 253,
              minute_startY: 102,
              minute_array: ["min_0.png","min_1.png","min_2.png","min_3.png","min_4.png","min_5.png","min_6.png","min_7.png","min_8.png","min_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 254,
              month_startY: 317,
              month_sc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              month_tc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              month_en_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 190,
              day_startY: 317,
              day_sc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_tc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_en_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 97,
              y: 125,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 95,
              hour_startY: 193,
              hour_array: ["hour_0.png","hour_1.png","hour_2.png","hour_3.png","hour_4.png","hour_5.png","hour_6.png","hour_7.png","hour_8.png","hour_9.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 259,
              minute_startY: 193,
              minute_array: ["min_0.png","min_1.png","min_2.png","min_3.png","min_4.png","min_5.png","min_6.png","min_7.png","min_8.png","min_9.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');
			
			const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if (scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro() {
              vibrate.stop();
              if (timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 191,
              y: 275,
              w: 100,
              h: 100,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 80,
              y: 270,
              w: 100,
              h: 100,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 365,
              y: 145,
              w: 70,
              h: 80,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 50,
              y: 145,
              w: 70,
              h: 80,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 35,
              y: 35,
              w: 100,
              h: 100,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 300,
              y: 270,
              w: 100,
              h: 100,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 193,
              y: 200,
              w: 100,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'todoListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 385,
              w: 100,
              h: 100,
              text: '',
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
                vibro(20);
                panel_visible = !panel_visible;
                gr_panels.setProperty(hmUI.prop.VISIBLE, panel_visible);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			let gr_panels = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
            });
            gr_panels.setProperty(hmUI.prop.VISIBLE, false);

            let gr_panels_fill = gr_panels.createWidget(hmUI.widget.FILL_RECT, {
              x: 70,
              y: 70,
              w: 480 - 140,
              h: 480 - 140,
              color: '0xAA211d1e',
              radius: 20,
              alpha: 220,
              show_level:

                hmUI.show_level.ONLY_NORMAL,
            });

            //кнопка 1
            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 100,
              y: 100,
              w: 70,
              h: 70,
              text: '',
              normal_src: 'phone.png',
              press_src: 'phone.png',
              click_func: () => {
                vibro(20);
                hmApp.startApp({
                  appid: 1,
                  url: 'PhoneRecentCallScreen',
                  native: true
                });
                //запуск приложения 1

              },
              longpress_func: () => {
               hmApp.startApp({ url: "PhoneContactsScreen", native: true });
              },

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            //кнопка 2
            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 100,
              w: 70,
              h: 70,
              text: '',
              normal_src: 'music.png',
              press_src: 'music.png',
              click_func: () => {
                vibro(20);
                hmApp.startApp({
                  appid: 1,
                  url: 'LocalMusicScreen',
                  native: true
                });
                //запуск приложения 2

              },
              longpress_func: () => {
               hmApp.startApp({ url: "MusicCommonScreen", native: true });

              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //кнопка 3
            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 300,
              y: 100,
              w: 70,
              h: 70,
              text: '',
              normal_src: 'voicememo.png',
              press_src: 'Empty.png',
              click_func: () => {
                vibro(20);
                hmApp.startApp({
                  appid: 1,
                  url: 'VoiceMemoScreen',
                  native: true
                });
                //запуск приложения 3

              },

              longpress_func: () => {

              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 100,
              y: 200,
              w: 70,
              h: 70,
              text: '',
              normal_src: 'stopwatch.png',
              press_src: 'Empty.png',
              click_func: () => {
                vibro(20);
                hmApp.startApp({
                  appid: 1,
                  url: 'StopWatchScreen',
                  native: true
                });
                //запуск приложения 4

              },

              longpress_func: () => {

              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 100,
              y: 300,
              w: 70,
              h: 70,
              text: '',
              normal_src: 'compass.png',
              press_src: 'compass.png',
              click_func: () => {
                vibro(20);
                hmApp.startApp({
                  appid: 1,
                  url: 'CompassScreen',
                  native: true
                });
                //запуск приложения 5

              },

              longpress_func: () => {
			hmApp.startApp({ url: "BaroAltimeterScreen", native: true });
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 200,
              w: 70,
              h: 70,
              text: '',
              normal_src: 'countdown.png',
              press_src: 'Empty.png',
              click_func: () => {
                vibro(20);
                hmApp.startApp({
                  appid: 1,
                  url: 'CountdownAppScreen',
                  native: true
                });
                //запуск приложения 6

              },

              longpress_func: () => {

              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 300,
              w: 70,
              h: 70,
              text: '',
              normal_src: 'measurement.png',
              press_src: 'Empty.png',
              click_func: () => {
                vibro(20);
                hmApp.startApp({
                  appid: 1,
                  url: 'oneKeyAppScreen',
                  native: true
                });
                //запуск приложения 7

              },

              longpress_func: () => {

              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 300,
              y: 300,
              w: 70,
              h: 70,
              text: '',
              normal_src: 'setting.png',
              press_src: 'setting.png',
              click_func: () => {
                vibro(20);
                hmApp.startApp({
                  appid: 1,
                  url: 'Settings_homeScreen',
                  native: true
                });
                //запуск приложения 8

              },

              longpress_func: () => {
               hmApp.startApp({url: 'HmReStartScreen', native: true });
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 300,
              y: 200,
              w: 70,
              h: 70,
              text: '',
              normal_src: 'sport.png',
              press_src: 'sport.png',
              click_func: () => {
                vibro(20);
                hmApp.startApp({
                  appid: 1,
                  url: 'SportListScreen',
                  native: true
                });
                //запуск приложения 9

              },

              longpress_func: () => {
               hmApp.startApp({ url: "SportRecordListScreen", native: true });
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            
            let panel_visible = false;
            
            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 365,
              y: 55,
              w: 50,
              h: 50,
              radius: 25,
              text: 'X',
              normal_color: 0x992255,
              press_color: 0xfeb4a8,
              click_func: () => {

                vibro(24);
                panel_visible = !panel_visible;
                gr_panels.setProperty(hmUI.prop.VISIBLE, panel_visible);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}